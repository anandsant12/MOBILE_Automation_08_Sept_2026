import axios from "axios";
import {
  Config, SessionStatus, Step, Mode, DeviceInfo, ScenarioSummary, ScenarioDetail,
  RecordedStep, StartRunResponse, RunStatusResponse, InspectedElement, HealedLocator, PopupHandlers,
  SavedScreenElement, StepSuggestion, StartSettings, RunSummary,
} from "../types";

const BASE_URL = process.env.REACT_APP_API_BASE_URL || "http://localhost:8000";

const api = axios.create({ baseURL: BASE_URL });

/** The live MJPEG mirror is an <img> pointed straight at this URL - the browser
 * renders the stream natively, no polling. `key` is a cache-buster: bump it to
 * force a fresh connection (e.g. after reconnecting the device session). */
export function streamUrl(key: number): string {
  return `${BASE_URL}/api/session/stream?k=${key}`;
}

export function extractErrorMessage(err: unknown): string {
  if (axios.isAxiosError(err)) {
    return (err.response?.data as any)?.detail || err.message;
  }
  return String(err);
}

export async function getConfig(): Promise<Config> {
  const { data } = await api.get("/api/config");
  return data;
}

export async function connectSession(
  pkg: string, activity: string, udid?: string, platformVersion?: string,
): Promise<SessionStatus & { screenshot?: string }> {
  const { data } = await api.post("/api/session/connect", {
    android_app_package: pkg, android_app_activity: activity, udid, platform_version: platformVersion,
  });
  return data;
}

/** Phones plugged in over USB right now. */
export async function listDevices(): Promise<{ devices: DeviceInfo[]; error: string | null }> {
  const { data } = await api.get("/api/session/devices");
  return data;
}

export async function disconnectSession(): Promise<void> {
  await api.post("/api/session/disconnect");
}

export async function reconnectSession(): Promise<SessionStatus & { screenshot?: string }> {
  const { data } = await api.post("/api/session/reconnect");
  return data;
}

export async function getSessionStatus(): Promise<SessionStatus> {
  const { data } = await api.get("/api/session/status");
  return data;
}

export async function getScreenshot(): Promise<string> {
  const { data } = await api.get("/api/session/screenshot");
  return data.screenshot;
}

export async function tap(x_pct: number, y_pct: number, mode: Mode): Promise<RecordedStep> {
  const { data } = await api.post("/api/session/tap", { x_pct, y_pct, mode });
  return data;
}

/** The element at that point on the mirror and its current state, for adding a check. Nothing is tapped. */
export async function inspectElement(x_pct: number, y_pct: number): Promise<InspectedElement> {
  const { data } = await api.post("/api/session/inspect", { x_pct, y_pct });
  return data;
}

export async function typeText(x_pct: number, y_pct: number, text: string, mode: Mode): Promise<RecordedStep> {
  const { data } = await api.post("/api/session/type", { x_pct, y_pct, text, mode });
  return data;
}

export async function swipe(
  x1_pct: number, y1_pct: number, x2_pct: number, y2_pct: number, mode: Mode,
): Promise<RecordedStep> {
  const { data } = await api.post("/api/session/swipe", { x1_pct, y1_pct, x2_pct, y2_pct, mode });
  return data;
}

export async function pressKey(key: "back" | "home", mode: Mode): Promise<RecordedStep> {
  const { data } = await api.post("/api/session/key", { key, mode });
  return data;
}

export interface PhysicalCaptureStatus {
  available: boolean;
  starting?: boolean;            // the helper is still connecting (the first couple of seconds)
  error: string | null;
  adb?: string | null;
  touch_device?: string | null;
  stats: { seen: number; recorded: number; skipped: number };
  recent: string[];
  fields_typed?: number;         // text fields typed into so far (counted when you leave a field)
  helper?: boolean;              // the recorder helper app on the phone identifies each touch
  helper_error?: string | null;  // why it isn't (touches are then matched against screen snapshots)
}

export async function setPhysicalCapture(enabled: boolean, mode: Mode): Promise<PhysicalCaptureStatus> {
  const { data } = await api.post("/api/session/physical-capture", { enabled, mode });
  return data;
}

/** replace=true: `steps` is the whole current list of phone steps (live drafts while recording,
 * the final list once after stopping) and replaces what's shown; false: new steps to add. */
export async function getPhysicalSteps(): Promise<{ steps: RecordedStep[]; replace?: boolean; status: PhysicalCaptureStatus }> {
  const { data } = await api.get("/api/session/physical-steps");
  return data;
}

export async function listScenarios(): Promise<ScenarioSummary[]> {
  const { data } = await api.get("/api/scenarios");
  return data;
}

export async function saveScenario(
  name: string, mode: Mode, pkg: string, activity: string, steps: Step[], variables?: Record<string, string>,
  start?: StartSettings,
): Promise<ScenarioDetail> {
  const { data } = await api.post("/api/scenarios", {
    name, mode, android_app_package: pkg, android_app_activity: activity, steps, variables, start,
  });
  return data;
}

export async function getScenario(id: number): Promise<ScenarioDetail> {
  const { data } = await api.get(`/api/scenarios/${id}`);
  return data;
}

export async function deleteScenario(id: number): Promise<void> {
  await api.delete(`/api/scenarios/${id}`);
}

export type PlaybackSpeed = "fast" | "medium" | "slow";

export async function startScenarioRun(
  id: number, overrides?: Record<number, string>, speed: PlaybackSpeed = "fast", startIndex = 0, retries = 0,
  heal = true,
): Promise<StartRunResponse> {
  const { data } = await api.post(`/api/scenarios/${id}/run`, {
    overrides: overrides || {}, speed, start_index: startIndex, retries, heal,
  });
  return data;
}

/** Per step: data of the account under test to make test data, dates to make relative to the
 * run's date - and whether calendar taps could be merged into Pick date steps. */
export async function getStepSuggestions(steps: Step[]): Promise<{ suggestions: StepSuggestion[]; merge_dates: boolean }> {
  const { data } = await api.post("/api/steps/suggestions", { steps });
  return data;
}

/** The step with ${name} in place of `value` wherever it finds its element. */
export async function makeStepData(step: Step, value: string, name: string): Promise<{ step: Step; name: string }> {
  const { data } = await api.post("/api/steps/make-data", { step, value, name });
  return data;
}

/** The step with a ${today...} date in place of a recorded one. */
export async function applyDateSuggestion(step: Step, s: StepSuggestion): Promise<Step> {
  const { data } = await api.post("/api/steps/use-date", { step, field: s.field, value: s.value, token: s.token });
  return data.step;
}

/** Calendar taps recorded as separate steps -> one Pick date step each. */
export async function mergeDateSteps(steps: Step[]): Promise<Step[]> {
  const { data } = await api.post("/api/steps/merge-dates", { steps });
  return data.steps;
}

/** A screen saved while recording: its elements worth checking. */
export async function getSavedScreen(screenId: string): Promise<SavedScreenElement[]> {
  const { data } = await api.get(`/api/screens/${screenId}`);
  return data.elements;
}

/** A check step on one element of a saved screen. */
export async function checkFromSavedScreen(
  screenId: string, index: number, check?: string, expected?: string | null,
): Promise<Step> {
  const { data } = await api.post(`/api/screens/${screenId}/check`, { index, check, expected });
  return data;
}

/** Self-healing: make the locator a run fell back to (or found by the element's fingerprint)
 * the one this step tries first. */
export async function preferLocator(id: number, orderIndex: number, s: HealedLocator): Promise<void> {
  await api.post(`/api/scenarios/${id}/steps/${orderIndex}/prefer-locator`, {
    strategy: s.strategy, value: s.value, index: s.index, locator: s.locator, web: s.web,
  });
}

/** Save a file the browser was handed (an export) under `filename`. */
function download(content: BlobPart, filename: string, type: string) {
  const url = URL.createObjectURL(new Blob([content], { type }));
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

function safeName(name: string): string {
  return name.replace(/[^\w.-]+/g, "_").replace(/^_+|_+$/g, "") || "scenario";
}

/** The scenario as a portable JSON file (Import reads it back). */
export async function exportScenarioJson(id: number, name: string): Promise<void> {
  const { data } = await api.get(`/api/scenarios/${id}/export`);
  download(JSON.stringify(data, null, 1), `${safeName(name)}.json`, "application/json");
}

/** The scenario as a standalone pytest + Appium test. */
export async function exportScenarioPytest(id: number, name: string): Promise<void> {
  const { data } = await api.get(`/api/scenarios/${id}/pytest`, { responseType: "text" });
  download(data, `test_${safeName(name).toLowerCase()}.py`, "text/x-python");
}

export async function importScenario(file: File): Promise<ScenarioDetail> {
  let parsed: unknown;
  try {
    parsed = JSON.parse(await file.text());
  } catch {
    throw new Error(`${file.name} isn't a JSON file.`);
  }
  const { data } = await api.post("/api/scenarios/import", parsed);
  return data;
}

/** A finished run as JUnit XML, for CI systems. */
export async function downloadRunJunit(runId: string): Promise<void> {
  const { data } = await api.get(`/api/runs/${runId}/junit`, { responseType: "text" });
  download(data, `run-${runId.slice(0, 8)}.xml`, "application/xml");
}

export async function getPopupHandlers(): Promise<PopupHandlers> {
  const { data } = await api.get("/api/settings/popup-handlers");
  return data;
}

export async function savePopupHandlers(handlers: PopupHandlers): Promise<PopupHandlers> {
  const { data } = await api.put("/api/settings/popup-handlers", handlers);
  return data;
}

/** Replace a saved scenario's name and steps (the Steps editor) - and its test data, when given. */
export async function updateScenario(
  id: number, name: string, mode: Mode, pkg: string, activity: string, steps: Step[],
  variables?: Record<string, string>, start?: StartSettings,
): Promise<ScenarioDetail> {
  const { data } = await api.put(`/api/scenarios/${id}`, {
    name, mode, android_app_package: pkg, android_app_activity: activity, steps, variables, start,
  });
  return data;
}

/** A scenario's latest finished runs, newest first (kept across backend restarts). */
export async function getScenarioRuns(id: number): Promise<RunSummary[]> {
  const { data } = await api.get(`/api/scenarios/${id}/runs`);
  return data.runs;
}

export async function startAssistRun(instruction: string): Promise<StartRunResponse> {
  const { data } = await api.post("/api/assist/execute", { instruction });
  return data;
}

export async function getRunStatus(runId: string): Promise<RunStatusResponse> {
  const { data } = await api.get(`/api/runs/${runId}`);
  return data;
}

/** Stopping finalizes the run on the server immediately and returns its final state. */
export async function stopRun(runId: string): Promise<RunStatusResponse> {
  const { data } = await api.post(`/api/runs/${runId}/stop`);
  return data;
}

/** The most recent run of this kind (running or finished). The UI renders this
 * rather than tracking a run itself. */
export async function getActiveRun(kind: "scenario" | "assist"): Promise<RunStatusResponse | null> {
  const { data } = await api.get("/api/runs/active", { params: { kind } });
  return data.run;
}
