import React, { useEffect, useMemo, useState } from "react";
import { checkFromSavedScreen, extractErrorMessage, getSavedScreen } from "../api/client";
import { CHECK_LABELS, CheckKind, ELEMENT_CHECKS, RecordedStep, SavedScreenElement, Step, TEXT_CHECKS } from "../types";

interface SavedScreenCheckProps {
  step: Step;
  onAdd: (check: RecordedStep) => void;
  onCancel: () => void;
}

/**
 * A check on anything that was on the screen a step acted on - or the one it led to - from the
 * screens saved while recording on the phone. No phone needed, and the app needn't be on that
 * screen now.
 */
export default function SavedScreenCheck({ step, onAdd, onCancel }: SavedScreenCheckProps) {
  const sources: { key: "after" | "before"; id: string; label: string }[] = [];
  if (step.screen_after) sources.push({ key: "after", id: step.screen_after, label: "The screen after this step" });
  if (step.screen && step.screen !== step.screen_after) {
    sources.push({ key: "before", id: step.screen, label: "The screen this step acted on" });
  }
  const [source, setSource] = useState(sources[0]?.id ?? "");
  const [elements, setElements] = useState<SavedScreenElement[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [query, setQuery] = useState("");
  const [picked, setPicked] = useState<number | null>(null);
  const [check, setCheck] = useState<CheckKind>("visible");
  const [expected, setExpected] = useState("");
  const [adding, setAdding] = useState(false);

  useEffect(() => {
    if (!source) return;
    let alive = true;
    setElements(null);
    setPicked(null);
    getSavedScreen(source)
      .then((els) => { if (alive) setElements(els); })
      .catch((e) => { if (alive) setError(extractErrorMessage(e)); });
    return () => { alive = false; };
  }, [source]);

  const shown = useMemo(() => {
    const q = query.trim().toLowerCase();
    return (elements || []).filter((e) => !q || e.label.toLowerCase().includes(q));
  }, [elements, query]);

  const pick = (el: SavedScreenElement) => {
    setPicked(el.index);
    setCheck(el.check);
    setExpected(el.expected ?? "");
  };

  const add = async () => {
    if (picked == null) return;
    setAdding(true);
    setError(null);
    try {
      const made = await checkFromSavedScreen(source, picked, check, TEXT_CHECKS.includes(check) ? expected : null);
      onAdd({ ...made, ts: Date.now() / 1000 });
    } catch (e) {
      setError(extractErrorMessage(e));
    } finally {
      setAdding(false);
    }
  };

  if (sources.length === 0) {
    return <p className="muted">No screen was saved for this step (recordings made on the phone save them).</p>;
  }
  const needsText = TEXT_CHECKS.includes(check);
  return (
    <div className="saved-screen">
      {sources.length > 1 && (
        <div className="segmented">
          {sources.map((s) => (
            <button key={s.key} className={source === s.id ? "segmented__on" : ""} onClick={() => setSource(s.id)}>
              {s.label}
            </button>
          ))}
        </div>
      )}
      <input
        className="saved-screen__find"
        placeholder="Find - text, id or description"
        aria-label="Find an element"
        value={query}
        onChange={(e) => setQuery(e.target.value)}
      />
      {elements == null && !error && <p className="muted">Loading the saved screen&hellip;</p>}
      {elements != null && shown.length === 0 && <p className="muted">No element matches.</p>}
      <ul className="saved-screen__list" role="listbox" aria-label="Elements on the saved screen">
        {shown.map((el) => (
          <li key={el.index}>
            <button
              role="option"
              aria-selected={picked === el.index}
              className={`saved-screen__item${picked === el.index ? " saved-screen__item--on" : ""}`}
              onClick={() => pick(el)}
            >
              {el.label}
            </button>
          </li>
        ))}
      </ul>
      {picked != null && (
        <div className="inline-edit inline-edit--check">
          <select value={check} onChange={(e) => setCheck(e.target.value as CheckKind)} aria-label="Check that it">
            {ELEMENT_CHECKS.map((k) => <option key={k} value={k}>{CHECK_LABELS[k]}</option>)}
          </select>
          {needsText && (
            <input value={expected} placeholder="Expected text" aria-label="Expected text"
                   onChange={(e) => setExpected(e.target.value)} />
          )}
          <button className="btn btn--small btn--primary" onClick={add} disabled={adding || (needsText && !expected.trim())}>
            Add check
          </button>
          <button className="btn btn--small btn--ghost" onClick={onCancel}>Cancel</button>
        </div>
      )}
      {error && <p className="error-text">{error}</p>}
    </div>
  );
}
