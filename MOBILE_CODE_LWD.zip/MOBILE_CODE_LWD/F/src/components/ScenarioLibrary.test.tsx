import React from "react";
import { render, screen, fireEvent } from "@testing-library/react";
import ScenarioLibrary from "./ScenarioLibrary";
import RunPanel from "./RunPanel";
import { useScenarioRuns } from "../hooks/useScenarioRuns";
import * as api from "../api/client";

// A factory is required: automocking would load the real client, and axios ships
// as ESM which Jest 27 (bundled with CRA) can't parse.
jest.mock("../api/client", () => ({
  listScenarios: jest.fn(),
  deleteScenario: jest.fn(),
  getScenario: jest.fn(),
  startScenarioRun: jest.fn(),
  stopRun: jest.fn(),
  getActiveRun: jest.fn(),
  extractErrorMessage: (e: unknown) => String(e),
}));
const m = api as any;
jest.setTimeout(15000);

const ok = { action: "tap", description: "x", status: "ok" };
const mkRun = (status: string, log: any[], start_index = 0) =>
  ({ run_id: "r1", kind: "scenario", scenario_id: 1, status, total_steps: 2, log, start_index });

// The "backend": what GET /api/runs/active would answer right now.
let server: any = null;

beforeEach(() => {
  jest.resetAllMocks();
  server = null;
  m.listScenarios.mockResolvedValue([
    { id: 1, name: "t1", mode: "basic", android_app_package: "pkg", android_app_activity: "act", step_count: 2, created_at: "" },
  ]);
  m.getScenario.mockResolvedValue({
    id: 1, name: "t1", mode: "basic", android_app_package: "pkg", android_app_activity: "act", step_count: 2, created_at: "",
    steps: [
      { action: "tap", description: "Step A", locator: {} },
      { action: "tap", description: "Step B", locator: {} },
    ],
  });
  m.getActiveRun.mockImplementation(async () => server);
  m.startScenarioRun.mockImplementation(async (_id: number, _o: any, _speed: string, startIndex = 0) => {
    server = mkRun("running", [], startIndex);
    return { run_id: "r1", total_steps: 2 - startIndex };
  });
});

// What RecorderPlayback wires together: the list starts runs, the Run tab follows them.
function Harness() {
  const runs = useScenarioRuns("fast");
  return (
    <>
      <ScenarioLibrary
        mode="basic" refreshToken={0} connected run={runs.run} speed="fast" onSpeedChange={() => {}}
        onRun={(id, overrides) => { runs.start(id, overrides); }} onEdit={() => {}}
      />
      <RunPanel
        run={runs.run} scenarioName={runs.runName} steps={runs.runSteps} stopping={runs.stopping} canRun
        onStop={runs.stop} onRunFrom={(i) => { if (runs.run?.scenario_id != null) runs.start(runs.run.scenario_id, undefined, i); }}
        error={runs.error}
      />
    </>
  );
}

// index.tsx wraps the app in React.StrictMode, which in development mounts, unmounts and
// re-mounts every component once - the exact condition that used to freeze the UI on "Running...".
const renderStrict = () => render(<React.StrictMode><Harness /></React.StrictMode>);

test("live progress follows the server's state (StrictMode)", async () => {
  renderStrict();
  fireEvent.click(await screen.findByRole("button", { name: /^run$/i }));
  expect(await screen.findByText("Running…")).toBeTruthy();
  server = mkRun("running", [ok]);
  server = mkRun("passed", [{ ...ok, order_index: 0 }, { ...ok, order_index: 1 }]);
  expect(await screen.findByText("Passed", {}, { timeout: 4000 })).toBeTruthy();
});

test("Stop updates the UI immediately from the stop response, and the spinner goes away", async () => {
  renderStrict();
  fireEvent.click(await screen.findByRole("button", { name: /^run$/i }));
  await screen.findByText("Running…");
  await screen.findByText(/Step A/);
  expect(document.querySelector(".step-checklist__icon-svg--spin")).not.toBeNull();

  m.stopRun.mockImplementation(async () => {
    server = mkRun("stopped", [{ ...ok, order_index: 0 }]);
    return server;
  });
  fireEvent.click(await screen.findByRole("button", { name: /stop/i }));
  expect(m.stopRun).toHaveBeenCalledWith("r1");
  expect(await screen.findByText("Stopped", {}, { timeout: 2000 })).toBeTruthy();
  expect(screen.queryByRole("button", { name: /stop/i })).toBeNull();
  expect(document.querySelector(".step-checklist__icon-svg--spin")).toBeNull();
});

test("a failed Stop request re-enables the button so it can be retried", async () => {
  renderStrict();
  fireEvent.click(await screen.findByRole("button", { name: /^run$/i }));
  await screen.findByText("Running…");
  m.stopRun.mockRejectedValueOnce(new Error("network down"));
  fireEvent.click(await screen.findByRole("button", { name: /stop/i }));
  await screen.findByText(/network down/);
  expect((screen.getByRole("button", { name: /stop/i }) as HTMLButtonElement).disabled).toBe(false);
});

test("reattaches to a run that is already in progress (page refreshed)", async () => {
  server = mkRun("running", [{ ...ok, order_index: 0 }]);
  renderStrict();
  expect(await screen.findByText("Running…", {}, { timeout: 4000 })).toBeTruthy();
  expect(screen.getByRole("button", { name: /stop/i })).toBeTruthy();
});

test("a finished run can be run again from a chosen step", async () => {
  server = mkRun("failed", [{ ...ok, order_index: 0 }, { action: "tap", description: "Step B", status: "error", error: "boom", order_index: 1 }]);
  renderStrict();
  await screen.findByText("Failed", {}, { timeout: 4000 });
  expect(screen.getByText(/Failed at: Step B/)).toBeTruthy();
  const runFrom = await screen.findAllByTitle("Run from this step");
  fireEvent.click(runFrom[1]);
  await screen.findByText("Running…");
  expect(m.startScenarioRun).toHaveBeenCalledWith(1, undefined, "fast", 1, 0, true);   // self-heal on
  expect(await screen.findByText(/from step 2/)).toBeTruthy();
});
