import React, { useState } from "react";
import { render, screen, fireEvent } from "@testing-library/react";
import StepEditor from "./StepEditor";
import TestDataPanel, { variablesUsed } from "./TestDataPanel";
import { RecordedStep } from "../types";

// The verify panel's screen checks import the API client (axios is ESM, which Jest 27 can't parse).
jest.mock("../api/client", () => ({ getSessionStatus: jest.fn(() => Promise.resolve({ connected: false })) }));

const tapLocator = { candidates: [["xpath", '//*[@text="Login Failed"]']] as [string, string][], text: "Login Failed" };
const initial: RecordedStep[] = [
  {
    action: "assert", check: "text_equals", text: "Login Failed", description: 'Check text is "Login Failed"',
    locator: { ...tapLocator, as_tap: { action: "tap", description: "Login Failed", locator: tapLocator, x_pct: 0.5, y_pct: 0.4 } },
  },
  {
    action: "keypad", description: "Enter '1234' on Pinpad", text: "1234",
    locator: { resource_id: "com.x:id/pinpad", key_class: "android.widget.Button" },
  },
  {
    action: "tap", description: "Rupay card", disabled: true,
    locator: { resource_id: "list", warning: "nothing about this element was unique on screen" },
  },
];

let latest: RecordedStep[] = [];
function Harness() {
  const [steps, setSteps] = useState(initial);
  latest = steps;
  return <StepEditor steps={steps} editable onChange={setSteps} />;
}

test("a tap recorded as a check can be turned back into the tap", () => {
  render(<Harness />);
  expect(screen.getByText(/you tapped this text and nothing happened/)).toBeTruthy();
  fireEvent.click(screen.getByRole("button", { name: "Make it a tap" }));
  expect(latest[0].action).toBe("tap");
  expect(latest[0].description).toBe("Login Failed");
  expect(latest[0].check).toBeNull();
  expect(latest[0].text).toBeUndefined();
  expect(latest[0].locator.text).toBe("Login Failed");
  expect(screen.queryByRole("button", { name: "Make it a tap" })).toBeNull();
});

test("keypad steps show their keys and can be edited", () => {
  render(<Harness />);
  expect(screen.getByText("Keypad")).toBeTruthy();
  expect(screen.getByText('"1234"')).toBeTruthy();
  fireEvent.click(screen.getAllByTitle("Edit")[1]);
  fireEvent.change(screen.getByLabelText(/Keys to enter/), { target: { value: "${pin}" } });
  expect(latest[1].text).toBe("${pin}");
});

test("recorder warnings and disabled steps are shown; a step can be re-enabled", () => {
  render(<Harness />);
  expect(screen.getByText("nothing about this element was unique on screen")).toBeTruthy();
  expect(screen.getByText("disabled")).toBeTruthy();
  fireEvent.click(screen.getAllByTitle("Edit")[2]);
  fireEvent.click(screen.getByLabelText(/Disabled/));
  expect(latest[2].disabled).toBe(false);
});

test("regex and selected checks are offered for an element", () => {
  render(<Harness />);
  fireEvent.click(screen.getAllByTitle("Edit")[0]);
  const select = screen.getByLabelText("Check that") as HTMLSelectElement;
  const options = Array.from(select.options).map((o) => o.value);
  expect(options).toEqual(expect.arrayContaining(["text_matches", "selected"]));
  fireEvent.change(select, { target: { value: "text_matches" } });
  expect(screen.getByLabelText(/Pattern \(regular expression\)/)).toBeTruthy();
});

test("test data: names used in steps are listed, env secrets aren't", () => {
  const steps: RecordedStep[] = [
    { action: "type", description: "user", text: "${user}", locator: {} },
    { action: "type", description: "pwd", text: "${env:APP_PASSWORD}", locator: {} },
    { action: "assert", check: "text_contains", description: "c", text: "Hi ${user}, ${greeting}", locator: {} },
    { action: "swipe", description: "s", text: "${not_data}", locator: {} },
  ];
  expect(variablesUsed(steps)).toEqual(["greeting", "user"]);

  let vars: [string, string][] = [["user", "demo"]];
  const { rerender } = render(<TestDataPanel steps={steps} variables={vars} onChange={(v) => { vars = v; }} />);
  expect(screen.getByText(/No value yet for: greeting/)).toBeTruthy();
  fireEvent.click(screen.getByRole("button", { name: /greeting/ }));
  expect(vars).toEqual([["user", "demo"], ["greeting", ""]]);
  rerender(<TestDataPanel steps={steps} variables={vars} onChange={(v) => { vars = v; }} />);
  fireEvent.change(screen.getAllByLabelText("Value")[1], { target: { value: "Hello" } });
  expect(vars[1]).toEqual(["greeting", "Hello"]);
});
