import React, { useEffect, useRef, useState } from "react";
import { Smartphone, Plug, Unplug } from "lucide-react";
import { DeviceInfo, SessionStatus } from "../types";
import { listDevices } from "../api/client";

interface ConnectionBarProps {
  defaultPackage: string;
  defaultActivity: string;
  status: SessionStatus;
  busy: boolean;
  error?: string | null;
  onConnect: (pkg: string, activity: string, device?: DeviceInfo) => void;
  onDisconnect: () => void;
  /** The connected phone was unplugged. */
  onDeviceLost: () => void;
}

const POLL_MS = 2000;
const AUTO_KEY = "autoConnect";

function savedAuto(): boolean {
  try {
    return localStorage.getItem(AUTO_KEY) !== "false";
  } catch {
    return true;
  }
}

/**
 * Which phone, which app, connect. Phones are found automatically (adb, every couple of
 * seconds): the only ready one is picked, and with auto-connect on it's connected as soon
 * as it's plugged in. Unplugging the connected phone disconnects cleanly.
 */
export default function ConnectionBar({
  defaultPackage, defaultActivity, status, busy, error, onConnect, onDisconnect, onDeviceLost,
}: ConnectionBarProps) {
  const [pkg, setPkg] = useState(defaultPackage);
  const [activity, setActivity] = useState(defaultActivity);
  const [devices, setDevices] = useState<DeviceInfo[] | null>(null);   // null = not looked yet
  const [adbError, setAdbError] = useState<string | null>(null);
  const [selected, setSelected] = useState("");
  const [auto, setAutoState] = useState(savedAuto);
  // Phones auto-connect has already tried while plugged in - unplugging and plugging back in
  // tries again, but a failed attempt isn't repeated every poll.
  const tried = useRef(new Set<string>());
  const misses = useRef(0);
  // Read by the poll below, which is set up once.
  const statusRef = useRef(status);
  statusRef.current = status;
  const lostRef = useRef(onDeviceLost);
  lostRef.current = onDeviceLost;

  const setAuto = (on: boolean) => {
    setAutoState(on);
    try { localStorage.setItem(AUTO_KEY, String(on)); } catch { /* per-browser convenience only */ }
  };

  useEffect(() => {
    let alive = true;
    const poll = () => {
      listDevices()
        .then((r) => {
          if (!alive) return;
          setDevices(r.devices);
          setAdbError(r.error);
          const present = new Set(r.devices.filter((d) => d.state === "device").map((d) => d.serial));
          tried.current.forEach((s) => { if (!present.has(s)) tried.current.delete(s); });
          // The connected phone unplugged: two polls in a row without it (not one hiccup).
          const { connected, udid } = statusRef.current;
          if (!connected || !udid || present.has(udid)) {
            misses.current = 0;
          } else if (++misses.current >= 2) {
            misses.current = 0;
            lostRef.current();
          }
        })
        .catch(() => { /* backend busy - try again next time */ });
    };
    poll();
    const id = window.setInterval(poll, POLL_MS);
    return () => { alive = false; window.clearInterval(id); };
  }, []);

  const ready = (devices || []).filter((d) => d.state === "device");
  const waiting = (devices || []).filter((d) => d.state !== "device");
  const current = ready.find((d) => d.serial === selected);

  // Keep a phone selected: the one connected, else the chosen one while it's there, else the first ready one.
  useEffect(() => {
    if (status.connected && status.udid) {
      if (selected !== status.udid) setSelected(status.udid);
    } else if (!ready.some((d) => d.serial === selected)) {
      setSelected(ready[0]?.serial ?? "");
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [devices, status.connected, status.udid]);

  // Auto-connect a phone as soon as it's ready.
  useEffect(() => {
    if (!auto || status.connected || busy || !current || tried.current.has(current.serial)) return;
    tried.current.add(current.serial);
    onConnect(pkg, activity, current);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [auto, status.connected, busy, current?.serial]);

  const connectedDevice = (devices || []).find((d) => d.serial === status.udid);

  return (
    <div className="connection-bar">
      <div className="connection-bar__status">
        <span className={`status-dot${status.connected ? " status-dot--on" : ""}`} />
        <Smartphone size={15} />
      </div>

      <label className="connection-bar__field connection-bar__field--device">
        <span>Phone</span>
        {status.connected ? (
          <div className="connection-bar__device">{connectedDevice?.label ?? status.udid ?? "Connected"}</div>
        ) : ready.length > 0 ? (
          <select value={selected} onChange={(e) => setSelected(e.target.value)}>
            {ready.map((d) => <option key={d.serial} value={d.serial}>{d.label}</option>)}
          </select>
        ) : (
          <div className="connection-bar__device connection-bar__device--none">
            {devices === null ? "Looking for phones…"
              : waiting.length > 0 ? waiting[0].label
                : "Plug in a phone with USB debugging on"}
          </div>
        )}
      </label>

      <label className="connection-bar__field">
        <span>Package</span>
        <input
          value={pkg}
          onChange={(e) => setPkg(e.target.value)}
          disabled={status.connected}
          placeholder="com.example.app"
          spellCheck={false}
        />
      </label>

      <label className="connection-bar__field">
        <span>Activity</span>
        <input
          value={activity}
          onChange={(e) => setActivity(e.target.value)}
          disabled={status.connected}
          placeholder=".MainActivity"
          spellCheck={false}
        />
      </label>

      {status.connected ? (
        <button className="btn btn--ghost" onClick={onDisconnect} disabled={busy}>
          <Unplug size={14} /> Disconnect
        </button>
      ) : (
        <button className="btn btn--primary" onClick={() => onConnect(pkg, activity, current)} disabled={busy || ready.length === 0}>
          <Plug size={14} /> {busy ? "Connecting…" : "Connect"}
        </button>
      )}

      <label className="checkbox connection-bar__auto" title="Connect as soon as a phone is plugged in">
        <input type="checkbox" checked={auto} onChange={(e) => setAuto(e.target.checked)} />
        Auto-connect
      </label>

      {(error || adbError) && <span className="connection-bar__error">{error || `adb: ${adbError}`}</span>}
    </div>
  );
}
