import React, { useState } from "react";
import { Check, ChevronDown, ChevronRight, Copy, Crosshair } from "lucide-react";
import { CheckKind, Locator, LocatorStrategy, SCREEN_CHECKS, Step } from "../types";

/** Steps that find an element - the ones with a locator worth showing. */
export function hasLocator(step: Step): boolean {
  if (step.action === "assert") return !(step.check && SCREEN_CHECKS.includes(step.check as CheckKind));
  // A Pick date step without a date field works on a calendar that's already open.
  if (step.action === "pick_date") return Object.keys(step.locator || {}).length > 0;
  return ["tap", "long_press", "type", "select", "keypad"].includes(step.action);
}

function shorten(value: string, max = 70): string {
  return value.length > max ? `${value.slice(0, max - 1)}…` : value;
}

/**
 * One line under a step: how replay finds its element (the main locator), with the rest -
 * the backups, in the order tried - one click away. Shown while recording, editing and running.
 */
export function LocatorSummary({ locator, foundBy }: { locator: Locator; foundBy?: string }) {
  const [open, setOpen] = useState(false);
  const list = locatorStrategies(locator);
  const main = locator.web
    ? { strategy: "web", value: `${locator.web.css}${locator.web.text ? ` "${locator.web.text}"` : ""}` }
    : list[0];
  const backups = locator.web ? list.length : Math.max(0, list.length - 1);

  if (!main) {
    return (
      <div className="locator-summary locator-summary--none" title="Nothing identifies this element - replayed at the recorded screen position">
        <Crosshair size={11} /> by screen position
      </div>
    );
  }
  return (
    <div className="locator-summary">
      <div className="locator-summary__line">
        <span className="locator-summary__label">{locator.anchor ? "near label" : "locator"}</span>
        <code className="locator-summary__value" title={`${main.strategy} = ${main.value}`}>
          <span className="locator-summary__strategy">{main.strategy}</span> = {shorten(main.value)}
        </code>
        {(backups > 0 || locator.anchor || locator.tap_offset || locator.tap_at || locator.fingerprint) && (
          <button className="locator-summary__more" onClick={() => setOpen((o) => !o)} aria-expanded={open}>
            {open ? <ChevronDown size={12} /> : <ChevronRight size={12} />}
            {backups > 0 ? `${backups} backup${backups === 1 ? "" : "s"}` : "details"}
          </button>
        )}
        {foundBy && (
          <span className="locator-summary__found" title="How the last run found it">
            <Check size={11} /> found by {shorten(foundBy, 50)}
          </span>
        )}
      </div>
      {open && <LocatorInfo locator={locator} strategies={list} />}
    </div>
  );
}

/**
 * Every way replay can find an element, in the order it tries them - the same order as
 * locator_strategies() in backend/app/automation/mobile_control.py.
 */
export function locatorStrategies(loc: Locator): LocatorStrategy[] {
  const out: LocatorStrategy[] = [];
  const add = (strategy: string, value?: string | null, index = 0) => {
    if (value && !out.some((s) => s.strategy === strategy && s.value === value)) out.push({ strategy, value, index });
  };
  if (loc.prefer) add(loc.prefer[0], loc.prefer[1], loc.prefer[2] ?? 0);
  (loc.candidates || []).forEach(([s, v]) => add(s, v));
  add("xpath", loc.label_xpath);
  add("id", loc.resource_id, loc.resource_id_index ?? 0);
  add("content-desc", loc.content_desc, loc.content_desc_index ?? 0);
  add("text", loc.text, loc.text_index ?? 0);
  add("xpath", loc.xpath);
  return out;
}

/** Plain-language notes on how the found element is then used. */
function howUsed(loc: Locator): string[] {
  const notes: string[] = [];
  if (loc.web) notes.push(`On the app's web page it's found by CSS "${loc.web.css}"${loc.web.text ? ` with text "${loc.web.text}"` : ""} - tried first.`);
  if (loc.anchor) notes.push("The text is a fixed label next to the target: the tap lands at a set offset from it (the target's own text changes, or it has none).");
  else if (loc.tap_offset) notes.push("Tapped at a set offset from the element's centre (an icon drawn on it, e.g. show/hide password).");
  if (loc.changing && loc.beside) notes.push(`It shows a value that changes between runs (a balance, a date) - found by the label "${loc.beside}" next to it instead.`);
  else if (loc.changing) notes.push("It shows a value that changes between runs (a balance, a date) - never found by that value.");
  if (loc.field_label) notes.push(`A text field with no id or hint: found as the first field after the label "${loc.field_label}".`);
  if (loc.tap_at) notes.push(`Tapped at the same spot within it as recorded (${Math.round(loc.tap_at[0] * 100)}% across, ${Math.round(loc.tap_at[1] * 100)}% down) - it's a big container, whose middle may be something else.`);
  if (loc.in_list) notes.push("Searched for inside the scrolling list, scrolling if needed.");
  if (loc.key_class) notes.push("Each key is pressed by the character it shows (keypads may be shuffled).");
  if (loc.candidates?.length) notes.push("The phone recorder ranked these by how uniquely each identified the element; replay takes the first that matches exactly one element.");
  notes.push("If nothing matches for a second, names are also tried with spacing and an appended state (\", selected\") ignored; identical copies of it at the same spot count as one.");
  if (loc.unique === false) notes.push("Nothing about it was unique on screen when recorded - add a check after it to be sure the right one was used.");
  if (loc.fingerprint) notes.push("If none of these match, it's looked for by its recorded fingerprint (its attributes and surroundings) - used only when there's one clear match (self-healing).");
  if (loc.prefer) notes.push("The first way was promoted after a run found it by a backup.");
  return notes;
}

function CopyButton({ value }: { value: string }) {
  const [copied, setCopied] = useState(false);
  return (
    <button
      className="icon-btn"
      title="Copy"
      onClick={() => {
        navigator.clipboard?.writeText(value).then(() => {
          setCopied(true);
          window.setTimeout(() => setCopied(false), 1200);
        }).catch(() => {});
      }}
    >
      {copied ? <Check size={13} /> : <Copy size={13} />}
    </button>
  );
}

export default function LocatorInfo({ locator, strategies }: { locator: Locator; strategies?: LocatorStrategy[] }) {
  const list = strategies ?? locatorStrategies(locator);
  const notes = howUsed(locator);
  if (list.length === 0 && !locator.web) {
    return <p className="muted locator-info__none">{locator.key_class
      ? "Each key is found by the character it shows, anywhere on screen."
      : "No locator - replayed by its screen position."}</p>;
  }
  return (
    <div className="locator-info">
      <ol className="locator-info__list">
        {list.map((s, i) => (
          <li key={`${s.strategy}:${s.value}`}>
            <span className="locator-info__rank">{i === 0 ? "main" : "backup"}</span>
            <span className="locator-info__strategy">{s.strategy}</span>
            <code className="locator-info__value">{s.value}{s.index ? `  [match #${s.index + 1}]` : ""}</code>
            <CopyButton value={s.value} />
          </li>
        ))}
      </ol>
      {notes.map((n) => <p key={n} className="muted locator-info__note">{n}</p>)}
    </div>
  );
}
