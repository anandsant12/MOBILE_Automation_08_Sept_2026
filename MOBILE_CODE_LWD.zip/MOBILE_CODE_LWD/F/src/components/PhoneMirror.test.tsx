import React from "react";
import { render, screen, fireEvent } from "@testing-library/react";
import PhoneMirror from "./PhoneMirror";

const noop = () => {};

test("uses the live stream URL as the image source and reports a broken stream", () => {
  const onStreamError = jest.fn();
  render(<PhoneMirror connected streamUrl="http://x/api/session/stream?k=0" onTap={noop} onSwipe={noop} onStreamError={onStreamError} />);
  const img = screen.getByAltText("Device screen") as HTMLImageElement;
  expect(img.src).toContain("/api/session/stream");
  fireEvent.error(img);
  expect(onStreamError).toHaveBeenCalledTimes(1);
});

test("falls back to the snapshot when there is no stream, and ignores image errors then", () => {
  const onStreamError = jest.fn();
  render(<PhoneMirror connected screenshot="QUJD" onTap={noop} onSwipe={noop} onStreamError={onStreamError} />);
  const img = screen.getByAltText("Device screen") as HTMLImageElement;
  expect(img.src).toBe("data:image/jpeg;base64,QUJD");
  fireEvent.error(img);
  expect(onStreamError).not.toHaveBeenCalled();
});
