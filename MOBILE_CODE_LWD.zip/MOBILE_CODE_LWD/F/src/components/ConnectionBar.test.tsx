import React from "react";
import { act, render, screen } from "@testing-library/react";
import ConnectionBar from "./ConnectionBar";
import * as api from "../api/client";
import { DeviceInfo } from "../types";

jest.mock("../api/client", () => ({ listDevices: jest.fn() }));
const m = api as any;

const phone: DeviceInfo = {
  serial: "RZCT30QFEMB", state: "device", manufacturer: "samsung", model: "SM-A546E",
  android_version: "14", sdk: "34", label: "Samsung SM-A546E · Android 14",
};
let plugged: DeviceInfo[] = [];

beforeEach(() => {
  jest.useFakeTimers();
  plugged = [];
  m.listDevices.mockImplementation(async () => ({ devices: plugged, error: null }));
  localStorage.clear();
});
afterEach(() => jest.useRealTimers());

const tick = async () => { await act(async () => { jest.advanceTimersByTime(2000); }); };

function renderBar(props: Partial<React.ComponentProps<typeof ConnectionBar>> = {}) {
  const onConnect = jest.fn();
  const onDeviceLost = jest.fn();
  const utils = render(
    <ConnectionBar
      defaultPackage="com.demo" defaultActivity="" status={{ connected: false }} busy={false}
      onConnect={onConnect} onDisconnect={() => {}} onDeviceLost={onDeviceLost} {...props}
    />,
  );
  return { onConnect, onDeviceLost, ...utils };
}

test("no phone: says to plug one in", async () => {
  renderBar();
  await tick();
  expect(screen.getByText(/plug in a phone/i)).toBeTruthy();
  expect((screen.getByRole("button", { name: /connect/i }) as HTMLButtonElement).disabled).toBe(true);
});

test("plugging a phone in connects it automatically, once", async () => {
  const { onConnect } = renderBar();
  await tick();
  expect(onConnect).not.toHaveBeenCalled();
  plugged = [phone];
  await tick();
  expect(onConnect).toHaveBeenCalledTimes(1);
  expect(onConnect).toHaveBeenCalledWith("com.demo", "", phone);
  await tick();
  await tick();
  expect(onConnect).toHaveBeenCalledTimes(1);   // a failed attempt isn't repeated every poll
});

test("an unauthorized phone shows what to do, and isn't connected", async () => {
  plugged = [{ ...phone, state: "unauthorized", label: "SM-A546E - allow USB debugging on the phone" }];
  const { onConnect } = renderBar();
  await tick();
  expect(screen.getByText(/allow USB debugging/i)).toBeTruthy();
  expect(onConnect).not.toHaveBeenCalled();
});

test("auto-connect off: nothing connects by itself", async () => {
  localStorage.setItem("autoConnect", "false");
  plugged = [phone];
  const { onConnect } = renderBar();
  await tick();
  expect(screen.getByDisplayValue("Samsung SM-A546E · Android 14")).toBeTruthy();   // picked, ready to Connect
  expect(onConnect).not.toHaveBeenCalled();
});

test("unplugging the connected phone is reported", async () => {
  plugged = [phone];
  const { onDeviceLost } = renderBar({ status: { connected: true, udid: phone.serial } });
  await tick();
  expect(screen.getByText("Samsung SM-A546E · Android 14")).toBeTruthy();
  plugged = [];
  await tick();
  expect(onDeviceLost).not.toHaveBeenCalled();   // one missed poll could be a hiccup
  await tick();
  expect(onDeviceLost).toHaveBeenCalledTimes(1);
});
