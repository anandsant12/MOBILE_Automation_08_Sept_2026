import React, { useState } from "react";
import {
  CalendarDays, Circle, GripVertical, ListChecks, Lock, Pencil, Plus, Repeat, Smartphone, Timer, Trash2,
} from "lucide-react";
import LocatorInfo, { hasLocator, LocatorSummary } from "./LocatorInfo";
import StepCheckPanel from "./StepCheckPanel";
import {
  CheckKind, CHECK_LABELS, describeCheck, ELEMENT_CHECKS, Normalize, NORMALIZE_LABELS, OPTIONAL_TEXT_CHECKS,
  RecordedStep, SCREEN_CHECKS, Step, StepSuggestion, TEXT_CHECKS,
} from "../types";

const ACTION_LABEL: Record<string, string> = {
  tap: "Tap", long_press: "Hold", type: "Type", select: "Select", keypad: "Keypad", swipe: "Swipe", key: "Key",
  assert: "Check", wait: "Wait", pick_date: "Date", capture: "Remember", run_case: "Flow",
};
const KEYS = ["back", "home", "enter", "recents", "menu"];
// Steps that act on an element - the ones "optional" (skip if it doesn't appear) applies to.
const ELEMENT_ACTIONS = ["tap", "long_press", "type", "select", "keypad", "assert", "pick_date", "capture"];
const NORMALIZE_KEYS: Normalize[] = ["raw", "trim", "digits", "number"];
const REMEMBER_HINT = `A name to store the value under - use it later as ${"$"}{name} in a check's expected value or a field`;
const VARIABLE_HINT = `Use ${"$"}{name} for the scenario's test data, or ${"$"}{env:NAME} for an environment variable`;
const DATE_HINT = `25/10/2026, ${"$"}{today}, ${"$"}{today+7d}, ${"$"}{today+1m}, or test data like ${"$"}{start_date}`;
const NEXT_WEEK = `${"$"}{today+7d}`;

export interface ScenarioRef {
  id: number;
  name: string;
}

export function stepDetail(step: Step): string {
  if (step.action === "assert" && step.check) {
    return describeCheck(step.check, step.text) + (SCREEN_CHECKS.includes(step.check) ? " (whole screen)" : "");
  }
  if (step.action === "wait") return `${step.text ?? "1"}s`;
  if (step.action === "capture") {
    return `→ \${${step.var || "value"}}${step.normalize && step.normalize !== "raw" ? ` (${NORMALIZE_LABELS[step.normalize]})` : ""}`;
  }
  if (step.action === "type" || step.action === "select" || step.action === "keypad" || step.action === "pick_date") {
    return `"${step.text ?? ""}"`;
  }
  if (step.action === "swipe" || step.action === "key") return step.text ?? "";
  return "";   // a tap: what it found is the locator line under it (LocatorSummary)
}

/** A manual edit fixes the order: re-stamp times so later additions (a check) go after it. */
export function restamp<T extends Step>(steps: T[]): T[] {
  return steps.map((s, i) => ({ ...s, ts: i }));
}

interface StepEditorProps {
  steps: RecordedStep[];
  editable: boolean;
  onChange: (steps: RecordedStep[]) => void;
  emptyText?: string;
  /** Per step: test data / date suggestions (see backend app/services/step_tools.py). */
  suggestions?: StepSuggestion[];
  onMakeData?: (index: number, s: StepSuggestion, name: string) => void;
  onUseDate?: (index: number, s: StepSuggestion) => void;
  /** Offered when calendar taps could become Pick date steps. */
  onMergeDates?: () => void;
  /** Saved scenarios another one can run as a step (a reusable flow such as Login). */
  scenarios?: ScenarioRef[];
  /** Record on the phone and insert what's recorded at this position. */
  onRecordHere?: (position: number) => void;
}

export default function StepEditor({
  steps, editable, onChange, emptyText, suggestions = [], onMakeData, onUseDate, onMergeDates, scenarios = [],
  onRecordHere,
}: StepEditorProps) {
  const [open, setOpen] = useState<number | null>(null);
  // Drag-to-reorder: the step being dragged, and the gap it would drop into (0..steps.length).
  const [dragFrom, setDragFrom] = useState<number | null>(null);
  const [dropAt, setDropAt] = useState<number | null>(null);
  // "Verify after this step" open under step N.
  const [verifying, setVerifying] = useState<number | null>(null);
  // "Add after this step" options open under step N.
  const [adding, setAdding] = useState<number | null>(null);
  // Names typed for "make it test data", per step.
  const [dataNames, setDataNames] = useState<Record<number, string>>({});

  if (steps.length === 0) {
    return <p className="muted">{emptyText ?? "No steps yet."}</p>;
  }

  const change = (next: RecordedStep[]) => onChange(restamp(next));
  const update = (i: number, patch: Partial<RecordedStep>) =>
    change(steps.map((s, j) => (j === i ? { ...s, ...patch } : s)));
  /** Move step `from` into gap `to` (the gap before step `to`; steps.length = after the last). */
  const moveTo = (from: number, to: number) => {
    const target = to > from ? to - 1 : to;
    if (target === from || target < 0 || target >= steps.length) return;
    const next = [...steps];
    const [moved] = next.splice(from, 1);
    next.splice(target, 0, moved);
    setOpen((o) => (o === from ? target : null));   // an open edit form follows its step
    change(next);
  };
  const endDrag = () => {
    setDragFrom(null);
    setDropAt(null);
  };
  const remove = (i: number) => {
    setOpen(null);
    change(steps.filter((_, j) => j !== i));
  };
  const insertAfter = (i: number, step: RecordedStep) => {
    change([...steps.slice(0, i + 1), step, ...steps.slice(i + 1)]);
    setVerifying(null);
    setOpen(null);
  };
  const insertWait = (i: number) => {
    const wait: RecordedStep = { action: "wait", description: "Wait 2 seconds", text: "2", locator: {} };
    change([...steps.slice(0, i + 1), wait, ...steps.slice(i + 1)]);
    setOpen(i + 1);
  };
  const insertNew = (i: number, step: RecordedStep) => {
    change([...steps.slice(0, i + 1), step, ...steps.slice(i + 1)]);
    setAdding(null);
    setOpen(i + 1);
  };
  const scenarioName = (id?: string) => scenarios.find((s) => String(s.id) === String(id ?? ""))?.name;
  /** Names remembered by "capture" steps up to (and including) index `i` - offered to checks after them. */
  const rememberedUpTo = (i: number): string[] =>
    Array.from(new Set(steps.slice(0, i + 1)
      .filter((s) => s.action === "capture" && (s.var ?? "").trim())
      .map((s) => (s.var as string).trim())));
  /** A tap the recorder took for a check (on text that did nothing) - turned back into the tap. */
  const makeTap = (i: number) => {
    const asTap = steps[i].locator?.as_tap;
    if (!asTap) return;
    change(steps.map((s, j) => (j === i
      ? { ...s, ...asTap, locator: asTap.locator || {}, check: null, text: undefined }
      : s)));
  };

  return (
    <>
    {editable && onMergeDates && (
      <div className="step-suggestion step-suggestion--banner">
        <span>
          <CalendarDays size={13} /> Some steps tap days in a calendar. As one <strong>Pick date</strong> step, the date
          becomes data (e.g. <code>{NEXT_WEEK}</code>) and the calendar is moved to the right month when it runs.
        </span>
        <button className="btn btn--small btn--ghost" onClick={onMergeDates}>Merge calendar taps</button>
      </div>
    )}
    <ol className="step-editor">
      {steps.map((step, i) => {
        const isOpen = editable && open === i;
        const classes = [
          "step-editor__item",
          `step-editor__item--${step.action}`,
          editable && "step-editor__item--editable",
          isOpen && "step-editor__item--open",
          dragFrom === i && "step-editor__item--dragging",
          dragFrom !== null && dropAt === i && "step-editor__item--drop-before",
          dragFrom !== null && dropAt === steps.length && i === steps.length - 1 && "step-editor__item--drop-after",
        ].filter(Boolean).join(" ");
        return (
          <li
            key={i}
            className={classes}
            onDragOver={(e) => {
              if (dragFrom === null) return;
              e.preventDefault();
              const rect = e.currentTarget.getBoundingClientRect();
              setDropAt(e.clientY > rect.top + rect.height / 2 ? i + 1 : i);
            }}
            onDrop={(e) => {
              e.preventDefault();
              if (dragFrom !== null && dropAt !== null) moveTo(dragFrom, dropAt);
              endDrag();
            }}
          >
            <div className={`step-editor__row${editable ? " step-editor__row--editable" : ""}`}>
              {editable && (
                <span
                  className="step-editor__grip"
                  role="button"
                  tabIndex={0}
                  draggable
                  title="Drag to move (or focus it and press ↑ / ↓)"
                  aria-label={`Move step ${i + 1}`}
                  onDragStart={(e) => {
                    setDragFrom(i);
                    if (e.dataTransfer) {
                      e.dataTransfer.effectAllowed = "move";
                      e.dataTransfer.setData("text/plain", String(i));
                      const row = e.currentTarget.closest("li");
                      if (row) e.dataTransfer.setDragImage(row, 16, 16);
                    }
                  }}
                  onDragEnd={endDrag}
                  onKeyDown={(e) => {
                    if (e.key === "ArrowUp") { e.preventDefault(); moveTo(i, i - 1); }
                    if (e.key === "ArrowDown") { e.preventDefault(); moveTo(i, i + 2); }
                  }}
                >
                  <GripVertical size={15} />
                </span>
              )}
              <span className="step-editor__num">{i + 1}</span>
              <span className={`step-list__badge step-list__badge--${step.action}`}>{ACTION_LABEL[step.action] ?? step.action}</span>
              <div className="step-editor__text">
                <span className="step-list__desc">
                  {step.description || "(untitled)"}
                  {step.draft && <span className="step-list__tag step-list__tag--live" title="Shown as it happens; finalised when you stop recording">live</span>}
                  {step.source === "physical" && <span className="step-list__tag step-list__tag--muted" title="Captured from a touch on the phone itself"><Smartphone size={10} /> phone</span>}
                  {step.redacted && <span className="step-list__tag step-list__tag--muted" title="Value not saved - you'll be asked for it before each run"><Lock size={10} /> redacted</span>}
                  {(step.approximate || step.locator?.warning) && (
                    <span
                      className="step-list__tag step-list__tag--warn"
                      title={step.locator?.warning || "Matched against a screen that may have been out of date - check this step"}
                    >
                      check this
                    </span>
                  )}
                  {step.disabled && <span className="step-list__tag step-list__tag--muted" title="Kept, but skipped when the scenario runs">disabled</span>}
                  {step.optional && <span className="step-list__tag" title="Skipped if its element doesn't appear">optional</span>}
                  {step.continue_on_failure && <span className="step-list__tag" title="A failure is reported, but the run continues">continue on fail</span>}
                </span>
                {step.locator?.warning && <span className="step-list__warning">{step.locator.warning}</span>}
                {step.action === "assert" && step.locator?.as_tap && (
                  <span className="step-list__as-tap">
                    Recorded as a check: you tapped this text and nothing happened.
                    {editable && (
                      <button className="btn btn--small btn--ghost" onClick={() => makeTap(i)} title="It was meant as a tap - turn it back">
                        Make it a tap
                      </button>
                    )}
                  </span>
                )}
                {stepDetail(step) && <code className="step-list__detail">{stepDetail(step)}</code>}
                {step.action === "run_case" && (
                  <code className="step-list__detail">
                    {scenarioName(step.text) ? `runs "${scenarioName(step.text)}"` : "no scenario picked"}
                  </code>
                )}
                {step.checked_target != null && step.action === "tap" && (
                  <span className="step-list__as-tap">
                    {step.checked_target ? "Makes it checked" : "Makes it unchecked"} &mdash; skipped when it already is
                  </span>
                )}
                {hasLocator(step) && <LocatorSummary locator={step.locator || {}} />}
                {editable && suggestions.filter((s) => s.index === i).map((s) => (
                  <div className="step-suggestion" key={`${s.kind}:${s.field ?? ""}:${s.value}`}>
                    {s.kind === "data" ? (
                      <>
                        <span>
                          <code>{s.value}</code> looks like data of the account under test (another login shows another
                          one). Make it test data, so the scenario runs with any account.
                        </span>
                        <input
                          aria-label="Test data name"
                          value={dataNames[i] ?? s.name ?? ""}
                          onChange={(e) => setDataNames((n) => ({ ...n, [i]: e.target.value }))}
                        />
                        <button className="btn btn--small btn--ghost"
                                onClick={() => onMakeData?.(i, s, (dataNames[i] ?? s.name ?? "").trim() || "number")}>
                          Make it test data
                        </button>
                      </>
                    ) : (
                      <>
                        <span>
                          <code>{s.value}</code> is a date - recorded as it is, it&apos;s wrong tomorrow.{" "}
                          <code>{s.token}</code> is the same day relative to when the scenario runs.
                        </span>
                        <button className="btn btn--small btn--ghost" onClick={() => onUseDate?.(i, s)}>
                          Use {s.token}
                        </button>
                      </>
                    )}
                  </div>
                ))}
              </div>
              {editable && (
                <div className="step-editor__tools">
                  {step.action !== "assert" && step.action !== "wait" && (
                    <button
                      className={`icon-btn icon-btn--verify${verifying === i ? " icon-btn--on" : ""}`}
                      title="Verify after this step - add a check below it"
                      onClick={() => { setVerifying(verifying === i ? null : i); setOpen(null); }}
                    >
                      <ListChecks size={14} /> <span className="icon-btn__label">Verify</span>
                    </button>
                  )}
                  <button className="icon-btn" title="Edit" onClick={() => { setOpen(isOpen ? null : i); setVerifying(null); }}><Pencil size={14} /></button>
                  <button className="icon-btn" title="Add a wait after this step" onClick={() => insertWait(i)}><Plus size={12} /><Timer size={13} /></button>
                  <button
                    className={`icon-btn${adding === i ? " icon-btn--on" : ""}`}
                    title="Add after this step: record missed steps, pick a date, run another scenario"
                    onClick={() => { setAdding(adding === i ? null : i); setVerifying(null); }}
                  >
                    <Plus size={14} />
                  </button>
                  <button className="icon-btn icon-btn--danger" title="Delete" onClick={() => remove(i)}><Trash2 size={14} /></button>
                </div>
              )}
            </div>

            {editable && adding === i && (
              <div className="step-add">
                <span className="step-add__title">Add after step {i + 1}</span>
                {onRecordHere && (
                  <button
                    className="btn btn--small btn--ghost"
                    title="Bring the phone to where the missing steps begin, then do them on the phone - they're inserted here"
                    onClick={() => { setAdding(null); onRecordHere(i + 1); }}
                  >
                    <Circle size={12} /> Record steps here
                  </button>
                )}
                <button
                  className="btn btn--small btn--ghost"
                  title="Picks a date in Android's calendar: opens it from a date field, moves to the month, taps the day"
                  onClick={() => insertNew(i, {
                    action: "pick_date", text: NEXT_WEEK, locator: {},
                    description: "Pick a date in the open calendar",
                  })}
                >
                  <CalendarDays size={12} /> Pick a date
                </button>
                <button
                  className="btn btn--small btn--ghost"
                  disabled={scenarios.length === 0}
                  title={scenarios.length ? "Run another saved scenario's steps here - a reusable flow such as Login"
                    : "No other saved scenario to run"}
                  onClick={() => insertNew(i, {
                    action: "run_case", text: String(scenarios[0]?.id ?? ""), locator: {},
                    description: `Run scenario "${scenarios[0]?.name ?? ""}"`,
                  })}
                >
                  <Repeat size={12} /> Run another scenario
                </button>
              </div>
            )}

            {isOpen && (
              <div className="step-editor__form">
                <label>
                  Name
                  <input value={step.description} onChange={(e) => update(i, { description: e.target.value })} />
                </label>
                {(step.action === "type" || step.action === "select" || step.action === "keypad") && (
                  <label title={VARIABLE_HINT}>
                    {step.action === "type" ? "Text to type" : step.action === "select" ? "Option to pick"
                      : "Keys to enter (each by the character on its key)"}
                    <input
                      value={step.text ?? ""}
                      placeholder={VARIABLE_HINT}
                      onChange={(e) => update(i, { text: e.target.value, redacted: step.action === "type" ? false : step.redacted })}
                    />
                  </label>
                )}
                {step.action === "assert" && (
                  <>
                    <label>
                      Check that
                      <select value={step.check ?? "visible"} onChange={(e) => update(i, { check: e.target.value as CheckKind })}>
                        {/* An element check stays about its element; a screen check about the screen. */}
                        {(step.check && SCREEN_CHECKS.includes(step.check) ? SCREEN_CHECKS : ELEMENT_CHECKS)
                          .map((k) => <option key={k} value={k}>{CHECK_LABELS[k]}</option>)}
                      </select>
                    </label>
                    {step.check && TEXT_CHECKS.includes(step.check) && (
                      <label title={`${VARIABLE_HINT}. Compare to a value remembered earlier with $\{name}.`}>
                        {step.check === "on_screen" ? "Screen (activity)"
                          : step.check === "text_matches" ? "Pattern (regular expression)" : "Expected text"}
                        {OPTIONAL_TEXT_CHECKS.includes(step.check) || step.check === "on_screen" ? " - optional" : ""}
                        {(step.text ?? "").length > 80 ? (
                          <textarea rows={3} value={step.text ?? ""} onChange={(e) => update(i, { text: e.target.value })} />
                        ) : (
                          <input value={step.text ?? ""} onChange={(e) => update(i, { text: e.target.value })} />
                        )}
                      </label>
                    )}
                    {step.check && TEXT_CHECKS.includes(step.check) && !SCREEN_CHECKS.includes(step.check)
                      && rememberedUpTo(i - 1).length > 0 && (
                      <label title="Compare against a value a 'Remember' step saved earlier in the scenario">
                        Or a remembered value
                        <select
                          value=""
                          onChange={(e) => {
                            if (e.target.value) update(i, { text: `\${${e.target.value}}`, normalize: step.normalize ?? "digits" });
                          }}
                        >
                          <option value="">pick one…</option>
                          {rememberedUpTo(i - 1).map((n) => <option key={n} value={n}>{n}</option>)}
                        </select>
                      </label>
                    )}
                    {step.check && (step.check === "text_equals" || step.check === "text_contains") && (
                      <label title="Reduce the shown value and the expected one the same way before comparing - for amounts or account numbers (₹ 1,94,86,145.35 vs 19486145.35), or a value remembered earlier">
                        Compare as
                        <select value={step.normalize ?? "raw"}
                                onChange={(e) => update(i, { normalize: e.target.value as Normalize })}>
                          {NORMALIZE_KEYS.map((k) => <option key={k} value={k}>{NORMALIZE_LABELS[k]}</option>)}
                        </select>
                      </label>
                    )}
                  </>
                )}
                {step.action === "capture" && (
                  <>
                    <label title={REMEMBER_HINT}>
                      Remember value as
                      <input
                        value={step.var ?? ""}
                        placeholder="e.g. account_number"
                        onChange={(e) => update(i, { var: e.target.value })}
                      />
                    </label>
                    <label title="How the value is stored - ignore currency/commas so it matches another screen's formatting">
                      Keep the value
                      <select value={step.normalize ?? "raw"}
                              onChange={(e) => update(i, { normalize: e.target.value as Normalize })}>
                        {NORMALIZE_KEYS.map((k) => <option key={k} value={k}>{NORMALIZE_LABELS[k]}</option>)}
                      </select>
                    </label>
                    <span className="muted step-editor__hint">
                      Reads what this element shows when the scenario runs and stores it. Use it later as{" "}
                      <code>{"${" + (step.var || "value") + "}"}</code> in a check&apos;s expected value or a typed field.
                    </span>
                  </>
                )}
                {step.action === "pick_date" && (
                  <label title={DATE_HINT}>
                    Date
                    <input value={step.text ?? ""} placeholder={DATE_HINT}
                           onChange={(e) => update(i, { text: e.target.value })} />
                    <span className="muted step-editor__hint">
                      {Object.keys(step.locator || {}).length
                        ? "Taps the date field, moves the calendar to that month, picks the day, then OK."
                        : "The calendar must already be open (the step before opens it)."}
                    </span>
                  </label>
                )}
                {step.action === "run_case" && (
                  <label>
                    Scenario to run here
                    <select
                      value={step.text ?? ""}
                      onChange={(e) => update(i, {
                        text: e.target.value, description: `Run scenario "${scenarioName(e.target.value) ?? ""}"`,
                      })}
                    >
                      {!scenarioName(step.text) && <option value={step.text ?? ""}>(pick one)</option>}
                      {scenarios.map((s) => <option key={s.id} value={String(s.id)}>{s.name}</option>)}
                    </select>
                    <span className="muted step-editor__hint">
                      Its steps run in place of this one; its test data is used unless this scenario sets the same name.
                    </span>
                  </label>
                )}
                {step.action === "tap" && (
                  <label>
                    If it&apos;s a checkbox or switch
                    <select
                      value={step.checked_target == null ? "tap" : step.checked_target ? "check" : "uncheck"}
                      onChange={(e) => update(i, {
                        checked_target: e.target.value === "tap" ? null : e.target.value === "check",
                      })}
                    >
                      <option value="tap">Always tap it</option>
                      <option value="check">Make it checked (skip the tap if it already is)</option>
                      <option value="uncheck">Make it unchecked (skip the tap if it already is)</option>
                    </select>
                  </label>
                )}
                {step.action === "key" && (
                  <label>
                    Key
                    <select value={step.text ?? "back"} onChange={(e) => update(i, { text: e.target.value })}>
                      {Array.from(new Set([...KEYS, step.text ?? "back"])).map((k) => <option key={k} value={k}>{k}</option>)}
                    </select>
                  </label>
                )}
                {step.action === "wait" && (
                  <label>
                    Seconds
                    <input
                      type="number" min={0.5} max={600} step={0.5} value={step.text ?? "2"}
                      onChange={(e) => update(i, { text: e.target.value, description: `Wait ${e.target.value} seconds` })}
                    />
                  </label>
                )}
                <div className="step-editor__options">
                  {ELEMENT_ACTIONS.includes(step.action) && (
                    <label className="checkbox">
                      <input type="checkbox" checked={!!step.optional} onChange={(e) => update(i, { optional: e.target.checked })} />
                      Optional &mdash; skip it if its element doesn&apos;t appear (a popup that only sometimes shows)
                    </label>
                  )}
                  <label className="checkbox">
                    <input
                      type="checkbox" checked={!!step.continue_on_failure}
                      onChange={(e) => update(i, { continue_on_failure: e.target.checked })}
                    />
                    Continue the run if this step fails (it&apos;s still reported)
                  </label>
                  <label className="checkbox">
                    <input type="checkbox" checked={!!step.disabled} onChange={(e) => update(i, { disabled: e.target.checked })} />
                    Disabled &mdash; keep it, but skip it when the scenario runs
                  </label>
                </div>
                {!["wait", "swipe", "key", "run_case"].includes(step.action) && !(step.check && SCREEN_CHECKS.includes(step.check)) && (
                  <details className="step-editor__locator" open>
                    <summary>How replay finds it</summary>
                    <LocatorInfo locator={step.locator || {}} />
                  </details>
                )}
                <button className="btn btn--small btn--ghost" onClick={() => setOpen(null)}>Done</button>
              </div>
            )}

            {editable && verifying === i && (
              <StepCheckPanel
                step={step}
                remembered={rememberedUpTo(i)}
                onAdd={(check) => insertAfter(i, check)}
                onCancel={() => setVerifying(null)}
              />
            )}
          </li>
        );
      })}
    </ol>
    </>
  );
}
