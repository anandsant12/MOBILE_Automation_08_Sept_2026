import React, { useEffect, useState } from "react";
import { Plus, ShieldCheck, Trash2 } from "lucide-react";
import { extractErrorMessage, getPopupHandlers, savePopupHandlers } from "../api/client";
import { PopupHandlers } from "../types";

/**
 * Interruptions replay dismisses by itself, so they needn't be recorded into every scenario:
 * Android permission requests, and "when the screen shows X, tap Y" rules. They're checked
 * when a step can't find its element (usually because something popped up over it).
 */
export default function PopupHandlersPanel() {
  const [handlers, setHandlers] = useState<PopupHandlers | null>(null);
  const [draft, setDraft] = useState({ when_text: "", tap_text: "" });
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    getPopupHandlers().then(setHandlers).catch((e) => setError(extractErrorMessage(e)));
  }, []);

  const save = (next: PopupHandlers) => {
    setHandlers(next);
    setError(null);
    savePopupHandlers(next).then(setHandlers).catch((e) => setError(extractErrorMessage(e)));
  };

  if (!handlers) return error ? <p className="error-text">{error}</p> : null;

  const addRule = () => {
    if (!draft.when_text.trim() || !draft.tap_text.trim()) return;
    save({ ...handlers, rules: [...handlers.rules, { ...draft, enabled: true }] });
    setDraft({ when_text: "", tap_text: "" });
  };

  return (
    <details className="popup-handlers">
      <summary>
        <ShieldCheck size={14} /> Popup handlers
        <span className="muted"> &middot; {handlers.rules.filter((r) => r.enabled).length + (handlers.auto_allow_permissions ? 1 : 0)} active</span>
      </summary>
      <p className="muted popup-handlers__intro">
        Dismissed automatically during a run whenever they block a step - no need to record them.
      </p>
      <label className="checkbox">
        <input
          type="checkbox" checked={handlers.auto_allow_permissions}
          onChange={(e) => save({ ...handlers, auto_allow_permissions: e.target.checked })}
        />
        Allow Android permission requests
      </label>
      {handlers.rules.length > 0 && (
        <ul className="popup-handlers__rules">
          {handlers.rules.map((r, i) => (
            <li key={i}>
              <input
                type="checkbox" checked={r.enabled} title="On / off"
                onChange={(e) => save({ ...handlers, rules: handlers.rules.map((x, j) => (j === i ? { ...x, enabled: e.target.checked } : x)) })}
              />
              <span>When screen shows <strong>&ldquo;{r.when_text}&rdquo;</strong>, tap <strong>&ldquo;{r.tap_text}&rdquo;</strong></span>
              <button className="icon-btn icon-btn--danger" title="Remove" onClick={() => save({ ...handlers, rules: handlers.rules.filter((_, j) => j !== i) })}>
                <Trash2 size={13} />
              </button>
            </li>
          ))}
        </ul>
      )}
      <div className="popup-handlers__add">
        <input placeholder="When screen shows…" value={draft.when_text} onChange={(e) => setDraft({ ...draft, when_text: e.target.value })} />
        <input
          placeholder="…tap"
          value={draft.tap_text}
          onChange={(e) => setDraft({ ...draft, tap_text: e.target.value })}
          onKeyDown={(e) => { if (e.key === "Enter") addRule(); }}
        />
        <button className="btn btn--small btn--ghost" onClick={addRule} disabled={!draft.when_text.trim() || !draft.tap_text.trim()}>
          <Plus size={13} /> Add
        </button>
      </div>
      {error && <p className="error-text">{error}</p>}
    </details>
  );
}
