import React from "react";
import { Plus, Trash2 } from "lucide-react";
import { Step } from "../types";

const VAR = /\$\{([^}]+)\}/g;
const NAME_SYNTAX = `${"$"}{name}`;
const ENV_SYNTAX = `${"$"}{env:NAME}`;

// ${today}, ${today-30d}, ${today+1d:dd-MM-yyyy}, ${now:HH:mm}: the run's date / time, not test data.
const DATE_VAR = /^(today|now)\s*(?:[+-]\s*\d+\s*[dwmy]?)?\s*(?::.+)?$/i;

/** Names used as ${name} in the steps' typed text, options, expected values, dates and locators
 * (not ${env:...}, and not the run's date like ${today+7d}). */
export function variablesUsed(steps: Step[]): string[] {
  const names = new Set<string>();
  const scan = (value: string) => {
    Array.from(value.matchAll(VAR)).forEach((m) => {
      const name = m[1].trim();
      if (!name.startsWith("env:") && !DATE_VAR.test(name)) names.add(name);
    });
  };
  steps.forEach((s) => {
    if (["type", "select", "keypad", "assert", "pick_date"].includes(s.action) && s.text) scan(s.text);
    // An account picked from a list as ${account}: in what finds the element.
    const locator = JSON.stringify(s.locator || {});
    if (locator.includes("${")) scan(locator);
  });
  return Array.from(names).sort();
}

interface TestDataPanelProps {
  steps: Step[];
  variables: [string, string][];
  onChange: (variables: [string, string][]) => void;
}

/**
 * The scenario's test data: values for ${name} in its steps, so one recording runs with
 * other data. Secrets don't belong here (they're saved) - use ${env:NAME} for those.
 */
export default function TestDataPanel({ steps, variables, onChange }: TestDataPanelProps) {
  const used = variablesUsed(steps);
  const defined = new Set(variables.map(([k]) => k.trim()).filter(Boolean));
  const missing = used.filter((n) => !defined.has(n));
  const set = (i: number, at: 0 | 1, value: string) =>
    onChange(variables.map((row, j) => (j === i ? (at === 0 ? [value, row[1]] : [row[0], value]) : row)));

  return (
    <details className="test-data" open={variables.length > 0 || missing.length > 0}>
      <summary>
        Test data{variables.length ? ` (${variables.length})` : ""}
        <span className="muted"> &mdash; type <code>{NAME_SYNTAX}</code> in a step&apos;s text to use a value</span>
      </summary>
      {variables.map(([name, value], i) => (
        <div className="test-data__row" key={i}>
          <input aria-label="Name" placeholder="name" value={name} onChange={(e) => set(i, 0, e.target.value)} />
          <input aria-label="Value" placeholder="value" value={value} onChange={(e) => set(i, 1, e.target.value)} />
          <button className="icon-btn icon-btn--danger" title="Remove" onClick={() => onChange(variables.filter((_, j) => j !== i))}>
            <Trash2 size={13} />
          </button>
        </div>
      ))}
      <div className="test-data__actions">
        <button className="btn btn--small btn--ghost" onClick={() => onChange([...variables, ["", ""]])}>
          <Plus size={12} /> Add a value
        </button>
        {missing.map((n) => (
          <button key={n} className="btn btn--small btn--ghost" title="Used in a step but has no value yet" onClick={() => onChange([...variables, [n, ""]])}>
            <Plus size={12} /> {n}
          </button>
        ))}
      </div>
      {missing.length > 0 && (
        <p className="error-text">No value yet for: {missing.join(", ")} &mdash; those steps fail until it&apos;s set.</p>
      )}
      <p className="muted test-data__hint">
        Passwords and other secrets: use <code>{ENV_SYNTAX}</code> instead &mdash; read from the backend&apos;s
        environment when the scenario runs, never saved.
      </p>
    </details>
  );
}
