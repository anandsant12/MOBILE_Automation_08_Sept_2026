import React, { useEffect, useRef, useState } from "react";
import { Check, X, Circle, Loader2, CornerDownRight, Lock, Minus, Play, Wrench } from "lucide-react";
import { Step, RunLogEntry, RunStatus, HealedLocator } from "../types";
import { hasLocator, LocatorSummary } from "./LocatorInfo";

interface StepChecklistProps {
  steps: Step[];
  log: RunLogEntry[];
  status: RunStatus;
  startIndex?: number;
  onRunFrom?: (index: number) => void;   // offered on every step when no run is in progress
  onPromote?: (index: number, healed: HealedLocator) => Promise<void>;   // self-healing, accepted
}

export default function StepChecklist({ steps, log, status, startIndex = 0, onRunFrom, onPromote }: StepChecklistProps) {
  const [promoted, setPromoted] = useState<Record<number, boolean>>({});
  // Results carry the scenario position of their step (order_index), which is what lines
  // them up when a run started part-way through ("run from this step").
  const byIndex = new Map<number, RunLogEntry>();
  log.forEach((e) => { if (e.order_index != null) byIndex.set(e.order_index, e); });
  // A step that runs another scenario has a result per step of that scenario, all under its place.
  const done = byIndex.size;
  const last = [...log].reverse().find((e) => e.order_index != null);
  const activeIndex = status !== "running" ? -1
    : last?.called && last.status === "ok" && last.order_index != null ? last.order_index : startIndex + done;

  // Keep the step being run in view as the run moves down a long list.
  const listRef = useRef<HTMLOListElement>(null);
  useEffect(() => {
    if (activeIndex < 0) return;
    const el = listRef.current?.querySelector(".step-checklist__item--active") as HTMLElement | null;
    el?.scrollIntoView?.({ block: "nearest", behavior: "smooth" });
  }, [activeIndex]);

  return (
    <ol className="step-checklist" ref={listRef}>
      {steps.map((step, i) => {
        const entry = byIndex.get(i);
        let icon = <Circle className="step-checklist__icon-svg" size={14} />;
        let stateClass = "pending";
        if (i < startIndex) {
          icon = <Minus className="step-checklist__icon-svg" size={14} />;
          stateClass = "not-run";
        } else if (entry) {
          if (entry.status === "ok") {
            icon = entry.skipped
              ? <CornerDownRight className="step-checklist__icon-svg" size={14} />
              : <Check className="step-checklist__icon-svg" size={15} />;
            stateClass = "done";
          } else {
            icon = <X className="step-checklist__icon-svg" size={14} />;
            stateClass = "error";
          }
        } else if (i === activeIndex) {
          icon = <Loader2 className="step-checklist__icon-svg step-checklist__icon-svg--spin" size={14} />;
          stateClass = "active";
        }
        return (
          <li key={i} className={`step-checklist__item step-checklist__item--${stateClass}`}>
            <span className="step-checklist__icon">{icon}</span>
            <span className="step-checklist__desc">
              <span className="step-checklist__num">{i + 1}.</span> {step.description || "(untitled)"}
              {step.redacted && <Lock size={11} className="step-checklist__lock" />}
              {step.disabled && <span className="step-list__tag step-list__tag--muted">disabled</span>}
            </span>
            {entry?.duration != null && <span className="step-checklist__time">{entry.duration.toFixed(1)}s</span>}
            {onRunFrom && status !== "running" && (
              <button className="icon-btn step-checklist__run-from" title="Run from this step" onClick={() => onRunFrom(i)}>
                <Play size={12} />
              </button>
            )}
            {entry?.called && entry.description && (
              <span className="step-checklist__note" title={`A step of "${entry.called}", which this step runs`}>
                {entry.status === "ok" && i !== activeIndex ? "last: " : ""}{entry.description}
              </span>
            )}
            {entry?.note && (
              <span className={`step-checklist__note${entry.status === "error" ? " step-checklist__note--error" : ""}`}>
                {entry.note}
              </span>
            )}
            {entry?.error && <span className="step-checklist__note step-checklist__note--error">{entry.error}</span>}
            {hasLocator(step) ? (
              <div className="step-checklist__locator">
                <LocatorSummary locator={step.locator || {}} foundBy={entry?.found_by} />
              </div>
            ) : entry?.found_by ? (
              <span className="step-checklist__found" title="How replay found this step's element">
                found by <code>{entry.found_by}</code>
              </span>
            ) : null}
            {entry?.healed && onPromote && (
              <span className="step-checklist__heal">
                {promoted[i] ? (
                  <span className="text-success">Saved into the step.</span>
                ) : (
                  <button
                    className="btn btn--small btn--ghost"
                    title={entry.healed.locator || entry.healed.web
                      ? "Self-healing found it by its recorded fingerprint - save its new locator into the step"
                      : "A backup locator found it - try that one first from now on"}
                    onClick={() => onPromote(i, entry.healed!).then(() => setPromoted((p) => ({ ...p, [i]: true }))).catch(() => {})}
                  >
                    <Wrench size={12} /> {entry.healed.locator || entry.healed.web ? "Save the healed locator" : "Make this the main locator"}
                  </button>
                )}
              </span>
            )}
          </li>
        );
      })}
    </ol>
  );
}
