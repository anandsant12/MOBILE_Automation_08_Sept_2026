import React, { useEffect, useState } from "react";
import { MonitorCheck } from "lucide-react";
import { getSessionStatus } from "../api/client";
import { CheckKind, CHECK_LABELS, describeCheck, OPTIONAL_TEXT_CHECKS, RecordedStep, SCREEN_CHECKS, TEXT_CHECKS } from "../types";

interface ScreenCheckFormProps {
  onAdd: (step: RecordedStep) => void;
  showTitle?: boolean;
}

const PLACEHOLDER: Partial<Record<CheckKind, string>> = {
  screen_has_text: "Text that should be on screen",
  screen_lacks_text: "Text that should NOT be on screen",
  toast: "Text in the toast (empty = any toast)",
  on_screen: "Screen (activity) - empty = just the app",
};

/** A check about the whole screen - nothing to pick on the mirror. */
export default function ScreenCheckForm({ onAdd, showTitle = true }: ScreenCheckFormProps) {
  const [check, setCheck] = useState<CheckKind>("screen_has_text");
  const [text, setText] = useState("");
  const [pkg, setPkg] = useState("");
  const needsText = TEXT_CHECKS.includes(check);
  const textOptional = OPTIONAL_TEXT_CHECKS.includes(check) || check === "on_screen";

  // "App / screen is": start from where the phone is now.
  useEffect(() => {
    if (check !== "on_screen") return;
    let alive = true;
    getSessionStatus()
      .then((s) => { if (alive) { setPkg(s.package || ""); setText(s.activity || ""); } })
      .catch(() => {});
    return () => { alive = false; };
  }, [check]);

  const add = () => {
    const value = needsText ? text.trim() : "";
    onAdd({
      action: "assert",
      check,
      text: value || undefined,
      description: check === "on_screen"
        ? `Check the app is ${pkg}${value ? ` on ${value}` : ""}`
        : `Check ${describeCheck(check, value)}`,
      locator: check === "on_screen" && pkg ? { package: pkg } : {},
      ts: Date.now() / 1000,
    });
    setText("");
  };

  return (
    <div className={`screen-check${showTitle ? "" : " screen-check--bare"}`}>
      {showTitle && <div className="screen-check__title"><MonitorCheck size={14} /> Or check the whole screen</div>}
      <div className="screen-check__row">
        <select value={check} onChange={(e) => { setCheck(e.target.value as CheckKind); setText(""); }}>
          {SCREEN_CHECKS.map((k) => <option key={k} value={k}>{CHECK_LABELS[k]}</option>)}
        </select>
        {needsText && (
          <input
            value={text}
            placeholder={PLACEHOLDER[check]}
            onChange={(e) => setText(e.target.value)}
            onKeyDown={(e) => { if (e.key === "Enter" && (textOptional || text.trim())) add(); }}
          />
        )}
        <button className="btn btn--small btn--primary" onClick={add} disabled={needsText && !textOptional && !text.trim()}>
          Add check
        </button>
      </div>
      {check === "toast" && (
        <p className="muted screen-check__hint">Put this right after the step that shows the toast - toasts vanish after 2-3 seconds.</p>
      )}
    </div>
  );
}
