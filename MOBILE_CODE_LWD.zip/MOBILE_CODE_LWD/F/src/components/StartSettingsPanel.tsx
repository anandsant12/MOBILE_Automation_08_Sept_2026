import React from "react";
import { StartSettings } from "../types";
import { ScenarioRef } from "./StepEditor";

interface StartSettingsPanelProps {
  start: StartSettings;
  onChange: (start: StartSettings) => void;
  /** Scenarios that can run first (not this one). */
  scenarios: ScenarioRef[];
}

/**
 * How a run of this scenario starts - so every run begins from the same known state instead
 * of wherever the app was left. Not applied when running from a step (that continues from
 * where the app is).
 */
export default function StartSettingsPanel({ start, onChange, scenarios }: StartSettingsPanelProps) {
  const app = start.app ?? "as_is";
  const setup = start.setup_scenario_id ?? null;
  const set = (patch: Partial<StartSettings>) => onChange({ ...start, ...patch });

  return (
    <details className="test-data start-settings" open={app !== "as_is" || setup != null}>
      <summary>
        Before it runs
        <span className="muted">
          {" "}&mdash; {app === "restart" ? "restart the app" : app === "clear" ? "clear the app's data" : "the app as it is"}
          {setup != null ? `, then "${scenarios.find((s) => s.id === setup)?.name ?? "a scenario"}"` : ""}
        </span>
      </summary>
      <label>
        The app
        <select value={app} onChange={(e) => set({ app: e.target.value as StartSettings["app"] })}>
          <option value="as_is">Use it as it is (whatever screen it&apos;s on)</option>
          <option value="restart">Restart it (close and open it again)</option>
          <option value="clear">Clear its data, then open it (as if freshly installed)</option>
        </select>
      </label>
      {app === "clear" && (
        <p className="error-text start-settings__warn">
          Clearing the app&apos;s data logs it out and removes anything saved on the phone - for banking apps
          that can mean registering the device again. Usually &ldquo;Restart&rdquo; plus a Login scenario is enough.
        </p>
      )}
      <label>
        Then run first
        <select
          value={setup == null ? "" : String(setup)}
          onChange={(e) => set({ setup_scenario_id: e.target.value ? Number(e.target.value) : null })}
        >
          <option value="">Nothing</option>
          {scenarios.map((s) => <option key={s.id} value={String(s.id)}>{s.name}</option>)}
        </select>
      </label>
      <p className="muted test-data__hint">
        E.g. restart the app, then run your Login scenario - so the steps always begin on the same screen.
        Skipped when you run from a chosen step.
      </p>
    </details>
  );
}
