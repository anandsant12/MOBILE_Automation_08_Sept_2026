import React from "react";
import { render, screen, fireEvent, waitFor } from "@testing-library/react";
import RunPanel from "./RunPanel";
import RunHistory from "./RunHistory";
import StartSettingsPanel from "./StartSettingsPanel";
import { RunStatusResponse, StartSettings, Step } from "../types";

// axios is ESM, which Jest 27 can't parse: the client is mocked (plain functions - the test setup
// resets jest.fn implementations before each test).
jest.mock("../api/client", () => ({
  downloadRunJunit: () => Promise.resolve(),
  extractErrorMessage: (e: unknown) => String(e),
  getScenarioRuns: () => Promise.resolve([
    { run_id: "r2", status: "failed", created_at: Date.now() / 1000 - 120, duration: 12.5, steps_done: 3, total_steps: 5,
      failure: { kind: "app_crashed", group: "app", summary: "The app crashed" } },
    { run_id: "r1", status: "passed", created_at: Date.now() / 1000 - 7200, duration: 20, steps_done: 5, total_steps: 5 },
  ]),
}));

const steps: Step[] = [
  { action: "tap", description: "Pay", locator: { text: "Pay" } },
  { action: "tap", description: "Confirm", locator: { text: "Confirm" } },
];

const failedRun: RunStatusResponse = {
  run_id: "abc", kind: "scenario", status: "failed", total_steps: 2, scenario_id: 1, created_at: 1790000000,
  failure: { kind: "app_crashed", group: "app", summary: "The app crashed", detail: "java.lang.NullPointerException" },
  log: [
    { order_index: -1, action: "start", status: "ok", description: "Restarted the app", setup: true },
    { order_index: -1, action: "tap", status: "ok", description: "[Login 1/1] Log in", setup: true },
    { order_index: 0, action: "tap", status: "ok", description: "Pay" },
    { order_index: 1, action: "tap", status: "error", description: "Confirm", error: "Could not find 'Confirm'" },
  ],
};

test("a failed run says whose problem it is, and what ran before the steps", () => {
  render(<RunPanel run={failedRun} scenarioName="Pay" steps={steps} stopping={false} canRun onStop={() => {}} onRunFrom={() => {}} />);
  expect(screen.getByText(/App problem: The app crashed/)).toBeTruthy();
  expect(screen.getByText("java.lang.NullPointerException")).toBeTruthy();
  expect(screen.getByText(/worth reporting as a bug/)).toBeTruthy();
  expect(screen.getByText(/Restarted the app/)).toBeTruthy();
  expect(screen.getByText(/\[Login 1\/1\] Log in/)).toBeTruthy();
  // The setup doesn't count as the scenario's steps.
  expect(screen.getByText(/2\/2 steps/)).toBeTruthy();
});

test("a past run is shown read-only, with a way back to the latest", () => {
  const closed: string[] = [];
  render(<RunPanel run={failedRun} steps={steps} stopping={false} canRun onStop={() => {}} onRunFrom={() => {}}
                   pastRun={{ onClose: () => closed.push("x") }} />);
  expect(screen.getByText(/A past run/)).toBeTruthy();
  expect(screen.queryByTitle("Run from this step")).toBeNull();
  fireEvent.click(screen.getByRole("button", { name: "Back to the latest run" }));
  expect(closed).toEqual(["x"]);
});

test("history: recent pass rate and each run, which opens", async () => {
  const opened: string[] = [];
  render(<RunHistory scenarioId={1} scenarioName="Pay" onOpen={(id) => opened.push(id)} />);
  await waitFor(() => expect(screen.getByText("passed 1 of the last 2")).toBeTruthy());
  expect(screen.getByText("App problem")).toBeTruthy();
  fireEvent.click(screen.getAllByTitle("Open this run")[0]);
  expect(opened).toEqual(["r2"]);
});

test("before it runs: restart the app, then a Login scenario; clearing data warns", () => {
  let start: StartSettings = {};
  const { rerender } = render(
    <StartSettingsPanel start={start} onChange={(s) => { start = s; }} scenarios={[{ id: 2, name: "Login" }]} />);
  fireEvent.change(screen.getByLabelText(/The app/), { target: { value: "restart" } });
  expect(start.app).toBe("restart");
  rerender(<StartSettingsPanel start={start} onChange={(s) => { start = s; }} scenarios={[{ id: 2, name: "Login" }]} />);
  fireEvent.change(screen.getByLabelText(/Then run first/), { target: { value: "2" } });
  expect(start).toEqual({ app: "restart", setup_scenario_id: 2 });
  rerender(<StartSettingsPanel start={{ app: "clear" }} onChange={() => {}} scenarios={[]} />);
  expect(screen.getByText(/logs it out/)).toBeTruthy();
});
