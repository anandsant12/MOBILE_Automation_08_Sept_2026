import React, { useEffect, useState } from "react";
import { History } from "lucide-react";
import { extractErrorMessage, getScenarioRuns } from "../api/client";
import { RunSummary } from "../types";
import { FAILURE_GROUPS } from "./RunPanel";

interface RunHistoryProps {
  scenarioId: number;
  scenarioName?: string;
  /** Changes when a run of it finishes - the list is read again. */
  refreshKey?: string;
  openRunId?: string | null;
  onOpen: (runId: string) => void;
}

function ago(epoch: number): string {
  const s = Math.max(0, Date.now() / 1000 - epoch);
  if (s < 60) return "just now";
  if (s < 3600) return `${Math.floor(s / 60)} min ago`;
  if (s < 86400) return `${Math.floor(s / 3600)} h ago`;
  return new Date(epoch * 1000).toLocaleDateString();
}

/** A scenario's past runs (kept across restarts): how often it passed lately, and each run. */
export default function RunHistory({ scenarioId, scenarioName, refreshKey, openRunId, onOpen }: RunHistoryProps) {
  const [runs, setRuns] = useState<RunSummary[] | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let alive = true;
    getScenarioRuns(scenarioId)
      .then((r) => { if (alive) { setRuns(r); setError(null); } })
      .catch((e) => { if (alive) setError(extractErrorMessage(e)); });
    return () => { alive = false; };
  }, [scenarioId, refreshKey]);

  if (error) return <p className="error-text">{error}</p>;
  if (!runs) return null;
  const finished = runs.filter((r) => r.status === "passed" || r.status === "failed").slice(0, 10);
  const passed = finished.filter((r) => r.status === "passed").length;

  return (
    <section className="run-history">
      <h4 className="run-history__title">
        <History size={14} /> History{scenarioName ? ` of ${scenarioName}` : ""}
        {finished.length > 0 && (
          <span className="run-history__rate" title="Of its last finished runs">
            passed {passed} of the last {finished.length}
          </span>
        )}
      </h4>
      {runs.length === 0 && <p className="muted">No finished runs yet - they're kept here once they finish.</p>}
      <ol className="run-history__list">
        {runs.map((r) => (
          <li key={r.run_id}>
            <button
              className={`run-history__item run-history__item--${r.status}${openRunId === r.run_id ? " run-history__item--open" : ""}`}
              onClick={() => onOpen(r.run_id)}
              title="Open this run"
            >
              <span className={`run-history__dot run-history__dot--${r.status}`} />
              <span className="run-history__when">{ago(r.created_at)}</span>
              <span className="run-history__status">{r.status}</span>
              <span className="muted">
                {r.steps_done}/{r.total_steps ?? "?"} steps &middot; {r.duration.toFixed(1)}s
                {r.start_index ? ` · from step ${r.start_index + 1}` : ""}
              </span>
              {r.failure && (
                <span className={`run-history__why run-history__why--${r.failure.group}`}>
                  {FAILURE_GROUPS[r.failure.group]?.title ?? r.failure.group}
                </span>
              )}
            </button>
          </li>
        ))}
      </ol>
    </section>
  );
}
