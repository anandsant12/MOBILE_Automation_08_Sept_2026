import React from "react";
import { Crosshair, ListChecks } from "lucide-react";
import { InspectedElement } from "../types";
import LocatorInfo from "./LocatorInfo";

interface InspectorPanelProps {
  element: InspectedElement | null;
  inspecting: boolean;
  connected: boolean;
  onToggle: () => void;
  onAddCheck: (element: InspectedElement) => void;
}

// Attributes shown first; the rest follow alphabetically.
const MAIN_ATTRS = ["text", "content-desc", "resource-id", "class", "hint", "bounds", "package"];
const FLAGS = ["clickable", "long-clickable", "checkable", "checked", "enabled", "focused", "selected", "scrollable", "password", "displayed"];

/** The Inspector tab: what Android reports about an element picked on the mirror, and how replay would find it. */
export default function InspectorPanel({ element, inspecting, connected, onToggle, onAddCheck }: InspectorPanelProps) {
  const attrs = element?.attributes || {};
  const rest = Object.keys(attrs).filter((k) => !MAIN_ATTRS.includes(k) && !FLAGS.includes(k)).sort();

  return (
    <div className="inspector">
      <div className="inspector__bar">
        <button className={`btn btn--small ${inspecting ? "btn--primary" : "btn--ghost"}`} onClick={onToggle} disabled={!connected}>
          <Crosshair size={13} /> {inspecting ? "Click an element on the mirror…" : "Pick an element"}
        </button>
        {inspecting && <span className="muted">Clicks on the mirror inspect instead of tapping.</span>}
      </div>

      {!element ? (
        <p className="muted">Pick an element to see its properties, where it sits on the screen, and every way replay can find it.</p>
      ) : (
        <>
          <div className="inspector__title">
            <strong>{element.description}</strong>
            {element.dynamic && (
              <span className="step-list__tag step-list__tag--warn" title="Its text looks like data (an amount, a number, a date) - it's never used to find the element">
                changing value
              </span>
            )}
            <button className="btn btn--small btn--ghost" onClick={() => onAddCheck(element)}>
              <ListChecks size={13} /> Add a check on it
            </button>
          </div>

          <section>
            <h4>How replay finds it</h4>
            <LocatorInfo locator={element.locator} strategies={element.strategies} />
          </section>

          <section>
            <h4>Properties</h4>
            <table className="inspector__props">
              <tbody>
                {[...MAIN_ATTRS, ...rest].filter((k) => attrs[k]).map((k) => (
                  <tr key={k}><th>{k}</th><td><code>{attrs[k]}</code></td></tr>
                ))}
              </tbody>
            </table>
            <div className="inspector__flags">
              {FLAGS.filter((k) => attrs[k] !== undefined).map((k) => (
                <span key={k} className={`inspector__flag${attrs[k] === "true" ? " inspector__flag--on" : ""}`}>{k}</span>
              ))}
            </div>
          </section>

          {element.path && element.path.length > 0 && (
            <section>
              <h4>Where it sits</h4>
              <ol className="inspector__path">
                {element.path.map((p, i) => <li key={i} style={{ paddingLeft: i * 10 }}>{p}</li>)}
                <li className="inspector__path-self" style={{ paddingLeft: element.path.length * 10 }}>{element.description}</li>
              </ol>
            </section>
          )}
        </>
      )}
    </div>
  );
}
