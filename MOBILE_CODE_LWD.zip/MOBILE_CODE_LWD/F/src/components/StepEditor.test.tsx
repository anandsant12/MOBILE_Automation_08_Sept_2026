import React, { useState } from "react";
import { render, screen, fireEvent, within } from "@testing-library/react";
import StepEditor from "./StepEditor";
import { RecordedStep } from "../types";

// The verify panel's screen checks import the API client (axios is ESM, which Jest 27 can't parse).
jest.mock("../api/client", () => ({ getSessionStatus: jest.fn(() => Promise.resolve({ connected: false })) }));

const initial: RecordedStep[] = [
  { action: "tap", description: "Log In", locator: { text: "Log In" }, ts: 10 },
  { action: "type", description: "PF Index", locator: { resource_id: "com.x:id/pf" }, text: "12345", ts: 11 },
  { action: "tap", description: "Welcome To", locator: {}, ts: 12 },
];

let latest: RecordedStep[] = [];
function Harness({ editable = true }: { editable?: boolean }) {
  const [steps, setSteps] = useState(initial);
  latest = steps;
  return <StepEditor steps={steps} editable={editable} onChange={setSteps} />;
}

const names = () => latest.map((s) => s.description);

test("drag a step to a new place", () => {
  render(<Harness />);
  const rows = screen.getAllByRole("listitem");
  const grips = screen.getAllByRole("button", { name: /move step/i });
  // Drag step 3 ("Welcome To") onto the top half of step 1: it lands first.
  fireEvent.dragStart(grips[2]);
  fireEvent.dragOver(rows[0], { clientY: -1 });
  fireEvent.drop(rows[0]);
  expect(names()).toEqual(["Welcome To", "Log In", "PF Index"]);
  expect(latest.map((s) => s.ts)).toEqual([0, 1, 2]);   // re-stamped: later additions go after
});

test("the drag handle also moves a step with the arrow keys", () => {
  render(<Harness />);
  fireEvent.keyDown(screen.getAllByRole("button", { name: /move step/i })[0], { key: "ArrowDown" });
  expect(names()).toEqual(["PF Index", "Log In", "Welcome To"]);
  fireEvent.keyDown(screen.getAllByRole("button", { name: /move step/i })[2], { key: "ArrowUp" });
  expect(names()).toEqual(["PF Index", "Welcome To", "Log In"]);
});

test("delete and edit a step's value", () => {
  render(<Harness />);
  fireEvent.click(screen.getAllByTitle("Delete")[2]);
  expect(names()).toEqual(["Log In", "PF Index"]);
  fireEvent.keyDown(screen.getAllByRole("button", { name: /move step/i })[1], { key: "ArrowUp" });
  expect(names()).toEqual(["PF Index", "Log In"]);

  fireEvent.click(screen.getAllByTitle("Edit")[0]);
  fireEvent.change(screen.getByLabelText("Text to type"), { target: { value: "99999" } });
  fireEvent.click(screen.getByLabelText(/Optional/));
  expect(latest[0].text).toBe("99999");
  expect(latest[0].optional).toBe(true);
  expect(screen.getByText("optional")).toBeTruthy();
});

test("insert a wait after a step", () => {
  render(<Harness />);
  fireEvent.click(screen.getAllByTitle("Add a wait after this step")[0]);
  expect(latest.map((s) => s.action)).toEqual(["tap", "wait", "type", "tap"]);
  fireEvent.change(screen.getByLabelText("Seconds"), { target: { value: "5" } });
  expect(latest[1]).toMatchObject({ text: "5", description: "Wait 5 seconds" });
});

test("verify after a step: a check on that step's element, inserted right below it", () => {
  render(<Harness />);
  // Step 1 tapped the text "Log In" - verify its text.
  fireEvent.click(screen.getAllByTitle(/verify after this step/i)[0]);
  expect((screen.getByDisplayValue("Log In") as HTMLInputElement)).toBeTruthy();   // prefilled from the step
  fireEvent.change(screen.getByRole("combobox"), { target: { value: "text_contains" } });
  fireEvent.change(screen.getByDisplayValue("Log In"), { target: { value: "log" } });
  fireEvent.click(screen.getByRole("button", { name: /^add check$/i }));
  expect(latest.map((s) => s.action)).toEqual(["tap", "assert", "type", "tap"]);
  expect(latest[1]).toMatchObject({ check: "text_contains", text: "log", locator: { text: "Log In" } });
});

test("verify after a typed field: checks the value typed", () => {
  render(<Harness />);
  fireEvent.click(screen.getAllByTitle(/verify after this step/i)[1]);
  expect(screen.getByDisplayValue("12345")).toBeTruthy();
});

test("verify with a whole-screen check", () => {
  render(<Harness />);
  fireEvent.click(screen.getAllByTitle(/verify after this step/i)[2]);
  fireEvent.click(screen.getByRole("button", { name: /whole screen/i }));
  fireEvent.change(screen.getByPlaceholderText(/should be on screen/i), { target: { value: "Login Failed" } });
  fireEvent.click(screen.getByRole("button", { name: /^add check$/i }));
  expect(latest[3]).toMatchObject({ action: "assert", check: "screen_has_text", text: "Login Failed" });
});

test("the edit form shows how replay finds the step", () => {
  render(<Harness />);
  fireEvent.click(screen.getAllByTitle("Edit")[0]);
  expect(screen.getByText("How replay finds it")).toBeTruthy();
  expect(screen.getByText("main")).toBeTruthy();
  expect(screen.getAllByText("text").length).toBeGreaterThan(1);   // the step's locator line + the full list
});

test("each step shows its locator while recording (read-only)", () => {
  render(<Harness editable={false} />);
  const lines = screen.getAllByTitle(/=/).map((el) => el.getAttribute("title"));
  expect(lines).toEqual(["text = Log In", "id = com.x:id/pf"]);
  expect(screen.getByText(/by screen position/)).toBeTruthy();   // step 3 has nothing to find it by
});

test("the locator line expands to every backup, in order", () => {
  render(<StepEditor
    steps={[{ action: "tap", description: "Pay", ts: 1, locator: { resource_id: "com.x:id/pay", text: "Pay", xpath: "//android.widget.Button[@text='Pay']" } }]}
    editable={false} onChange={() => {}}
  />);
  fireEvent.click(screen.getByRole("button", { name: /2 backups/ }));
  expect(screen.getAllByText(/^(main|backup)$/).map((el) => el.textContent)).toEqual(["main", "backup", "backup"]);
});

test("read-only while recording", () => {
  render(<Harness editable={false} />);
  const list = screen.getByRole("list");
  expect(within(list).queryByTitle("Delete")).toBeNull();
  expect(within(list).queryByRole("button", { name: /move step/i })).toBeNull();
  expect(screen.getByText("Welcome To")).toBeTruthy();
});
