import React from "react";
import { RunLogEntry } from "../types";

export default function RunLog({ log }: { log: RunLogEntry[] }) {
  if (log.length === 0) return null;
  return (
    <ol className="run-log">
      {log.map((entry, i) => (
        <li key={i} className={`run-log__item run-log__item--${entry.status}`}>
          <span className="run-log__index">{i + 1}</span>
          <div className="run-log__body">
            <div className="run-log__headline">
              <strong>{entry.action}</strong>
              {entry.target ? <span> &mdash; {entry.target}</span> : null}
              {entry.description ? <span> &mdash; {entry.description}</span> : null}
            </div>
            {entry.reasoning && <div className="run-log__reasoning">{entry.reasoning}</div>}
            {entry.error && <div className="run-log__error">{entry.error}</div>}
          </div>
        </li>
      ))}
    </ol>
  );
}
