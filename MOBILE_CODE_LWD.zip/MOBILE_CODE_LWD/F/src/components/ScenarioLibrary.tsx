import React, { useCallback, useEffect, useRef, useState } from "react";
import { Download, FileCode, Pencil, Play, Trash2, Upload } from "lucide-react";
import { Mode, RunStatusResponse, ScenarioSummary, Step } from "../types";
import {
  listScenarios, deleteScenario, getScenario, extractErrorMessage, PlaybackSpeed, exportScenarioJson,
  exportScenarioPytest, importScenario,
} from "../api/client";
import RedactedValuesPrompt from "./RedactedValuesPrompt";

const SPEEDS: { value: PlaybackSpeed; label: string; hint: string }[] = [
  { value: "fast", label: "Fast", hint: "No pause between steps" },
  { value: "medium", label: "Medium", hint: "1 second between steps" },
  { value: "slow", label: "Slow", hint: "2.5 seconds between steps - easy to follow" },
];

interface ScenarioLibraryProps {
  mode: Mode;
  refreshToken: number;
  connected: boolean;
  run: RunStatusResponse | null;
  speed: PlaybackSpeed;
  onSpeedChange: (s: PlaybackSpeed) => void;
  retries?: number;
  onRetriesChange?: (n: number) => void;
  heal?: boolean;
  onHealChange?: (on: boolean) => void;
  onRun: (id: number, overrides?: Record<number, string>) => void;
  onEdit: (id: number) => void;
  onHistory?: (id: number) => void;   // show its past runs (Run tab)
  editingId?: number | null;
  runError?: string | null;
}

/** Saved scenarios: run, edit (opens in the Steps tab), delete. A run is followed in the Run tab. */
export default function ScenarioLibrary({
  mode, refreshToken, connected, run, speed, onSpeedChange, retries = 0, onRetriesChange, heal = true, onHealChange,
  onRun, onEdit, onHistory, editingId, runError,
}: ScenarioLibraryProps) {
  const [scenarios, setScenarios] = useState<ScenarioSummary[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [deletingId, setDeletingId] = useState<number | null>(null);
  // Run clicked on a scenario with password steps whose value wasn't saved: ask for them first.
  const [pending, setPending] = useState<{ id: number; steps: Step[] } | null>(null);

  const refresh = useCallback(() => {
    listScenarios()
      .then((all) => setScenarios(all.filter((s) => s.mode === mode)))
      .catch((e) => setError(extractErrorMessage(e)));
  }, [mode]);

  // A run that just finished changes the scenario's recent results.
  const finishedRun = run && run.status !== "running" ? `${run.run_id}:${run.status}` : "";
  useEffect(() => { refresh(); }, [refresh, refreshToken, finishedRun]);

  const handleRun = async (id: number) => {
    setError(null);
    try {
      const { steps } = await getScenario(id);
      if (steps.some((s) => s.redacted)) {
        setPending({ id, steps });
        return;
      }
      onRun(id);
    } catch (e) {
      setError(extractErrorMessage(e));
    }
  };

  const handleDelete = async (id: number) => {
    if (!window.confirm("Delete this scenario?")) return;
    setDeletingId(id);
    setError(null);
    try {
      await deleteScenario(id);
      refresh();
    } catch (e) {
      setError(extractErrorMessage(e));
    } finally {
      setDeletingId(null);
    }
  };

  const fileInput = useRef<HTMLInputElement>(null);
  const [notice, setNotice] = useState<string | null>(null);

  const handleImport = async (file?: File) => {
    if (!file) return;
    setError(null);
    setNotice(null);
    try {
      const saved = await importScenario(file);
      setNotice(`Imported as "${saved.name}"${saved.mode !== mode ? ` (a ${saved.mode} scenario - switch mode to see it)` : ""}.`);
      refresh();
    } catch (e) {
      setError(extractErrorMessage(e));
    } finally {
      if (fileInput.current) fileInput.current.value = "";
    }
  };

  const handleExport = async (s: ScenarioSummary, kind: "json" | "pytest") => {
    setError(null);
    try {
      await (kind === "json" ? exportScenarioJson(s.id, s.name) : exportScenarioPytest(s.id, s.name));
    } catch (e) {
      setError(extractErrorMessage(e));
    }
  };

  const anyRunInProgress = run?.status === "running";

  return (
    <div className="scenario-library">
      <div className="scenario-library__header">
        <h3>Saved scenarios</h3>
        <div className="scenario-library__options">
          <label className="scenario-library__speed" title={SPEEDS.find((s) => s.value === speed)?.hint}>
            Speed
            <select value={speed} onChange={(e) => onSpeedChange(e.target.value as PlaybackSpeed)}>
              {SPEEDS.map((s) => <option key={s.value} value={s.value}>{s.label}</option>)}
            </select>
          </label>
          {onRetriesChange && (
            <label
              className="scenario-library__speed"
              title="If a step's element isn't found (or a check isn't true yet), try it again this many times before failing - for slow screens. A tap that already happened is never repeated."
            >
              Retries
              <select value={retries} onChange={(e) => onRetriesChange(Number(e.target.value))}>
                {[0, 1, 2].map((n) => <option key={n} value={n}>{n}</option>)}
              </select>
            </label>
          )}
          {onHealChange && (
            <label
              className="scenario-library__speed scenario-library__heal"
              title="Self-heal: when none of a step's locators match, find its element by its recorded fingerprint (used only for one clear match; the run says so). Off: such steps fail."
            >
              <input type="checkbox" checked={heal} onChange={(e) => onHealChange(e.target.checked)} />
              Self-heal
            </label>
          )}
          <button
            className="btn btn--small btn--ghost"
            onClick={() => fileInput.current?.click()}
            title="Add a scenario from a .json file exported here (or by a teammate)"
          >
            <Upload size={13} /> Import
          </button>
          <input
            ref={fileInput}
            type="file"
            accept=".json,application/json"
            hidden
            data-testid="import-file"
            onChange={(e) => handleImport(e.target.files?.[0])}
          />
        </div>
      </div>
      {scenarios.length === 0 && <p className="muted">Nothing saved yet in this mode.</p>}
      <ul className="scenario-library__list">
        {scenarios.map((s) => {
          const last = run && run.scenario_id === s.id ? run.status : null;
          return (
            <li
              key={s.id}
              className={`scenario-library__item${editingId === s.id ? " scenario-library__item--editing" : ""}${last ? ` scenario-library__item--${last}` : ""}`}
            >
              <div className="scenario-library__row">
                <div className="scenario-library__name">
                  <strong>{s.name}</strong>
                  {last && <span className={`scenario-library__tag scenario-library__tag--${last}`}>{last}</span>}
                </div>
                <div className="scenario-library__meta">
                  {s.step_count} step{s.step_count === 1 ? "" : "s"} &middot; {s.android_app_package}
                </div>
                {s.recent_runs && s.recent_runs.length > 0 && (
                  <button
                    className="scenario-library__recent"
                    onClick={() => onHistory?.(s.id)}
                    title={`Its last ${s.recent_runs.length} runs, newest first - click for the history`}
                    aria-label={`Run history: passed ${s.recent_runs.filter((r) => r === "passed").length} of the last ${s.recent_runs.length}`}
                  >
                    {s.recent_runs.map((r, i) => <span key={i} className={`run-history__dot run-history__dot--${r}`} />)}
                    <span className="muted">
                      {s.recent_runs.filter((r) => r === "passed").length}/{s.recent_runs.length} passed
                    </span>
                  </button>
                )}
                <div className="scenario-library__actions">
                  <button
                    className="btn btn--small btn--primary"
                    onClick={() => handleRun(s.id)}
                    disabled={!connected || anyRunInProgress}
                    title={connected ? "Run this scenario" : "Connect a device first"}
                  >
                    <Play size={13} /> Run
                  </button>
                  <button className="btn btn--small btn--ghost" onClick={() => onEdit(s.id)} title="Edit its steps">
                    <Pencil size={13} /> Edit
                  </button>
                  <button
                    className="btn btn--small btn--ghost"
                    onClick={() => handleExport(s, "json")}
                    title="Export as a .json file - to share it, or keep it in version control"
                    aria-label="Export as JSON"
                  >
                    <Download size={13} />
                  </button>
                  <button
                    className="btn btn--small btn--ghost"
                    onClick={() => handleExport(s, "pytest")}
                    title="Export as a pytest + Appium test script"
                    aria-label="Export as pytest"
                  >
                    <FileCode size={13} />
                  </button>
                  <button
                    className="btn btn--small btn--ghost"
                    onClick={() => handleDelete(s.id)}
                    disabled={deletingId === s.id || (anyRunInProgress && run?.scenario_id === s.id)}
                    title="Delete"
                  >
                    <Trash2 size={13} />
                  </button>
                </div>
              </div>
              {pending?.id === s.id && (
                <RedactedValuesPrompt
                  steps={pending.steps.filter((st) => st.redacted)}
                  onSubmit={(overrides) => {
                    // The prompt's field order matches steps.filter(redacted); map that back to
                    // each step's position in the scenario, which the backend keys overrides by.
                    const positions = pending.steps.map((st, i) => (st.redacted ? i : -1)).filter((i) => i >= 0);
                    const byPosition: Record<number, string> = {};
                    Object.entries(overrides).forEach(([i, v]) => { byPosition[positions[Number(i)]] = v; });
                    setPending(null);
                    onRun(s.id, byPosition);
                  }}
                  onCancel={() => setPending(null)}
                />
              )}
            </li>
          );
        })}
      </ul>

      {notice && !error && <p className="muted">{notice}</p>}
      {(error || runError) && <p className="error-text">{error || runError}</p>}
    </div>
  );
}
