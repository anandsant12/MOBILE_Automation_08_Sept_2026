import React, { useState } from "react";
import { Lock, Play } from "lucide-react";
import { Step } from "../types";

interface RedactedValuesPromptProps {
  steps: Step[];   // the redacted steps needing a value, in order
  onSubmit: (overrides: Record<number, string>) => void;
  onCancel: () => void;
}

/**
 * A scenario with a password/PIN/OTP step has no value stored for it (see the
 * README's "Physical-device recording" section - that's deliberate). Rather than
 * running with those fields left blank, this collects a value for each one right
 * before the run starts - held only in this component's own state, sent with the
 * run request, and never saved anywhere.
 */
export default function RedactedValuesPrompt({ steps, onSubmit, onCancel }: RedactedValuesPromptProps) {
  const [values, setValues] = useState<Record<number, string>>({});
  const allFilled = steps.every((_, i) => (values[i] ?? "").length > 0);

  return (
    <div className="redacted-prompt">
      <p className="redacted-prompt__intro">
        <Lock size={13} /> This scenario has {steps.length} field{steps.length === 1 ? "" : "s"} whose value
        wasn&apos;t saved (for security). Provide {steps.length === 1 ? "it" : "them"} for this run - nothing
        typed here is stored.
      </p>
      {steps.map((step, i) => (
        <label key={i} className="redacted-prompt__field">
          <span>{(step.description || "Value").replace(/\s*\(value not saved.*\)/i, "")}</span>
          <input
            type="password"
            autoComplete="off"
            value={values[i] ?? ""}
            onChange={(e) => setValues((prev) => ({ ...prev, [i]: e.target.value }))}
          />
        </label>
      ))}
      <div className="redacted-prompt__actions">
        <button className="btn btn--small btn--primary" disabled={!allFilled} onClick={() => onSubmit(values)}>
          <Play size={13} /> Start run
        </button>
        <button className="btn btn--small btn--ghost" onClick={onCancel}>Cancel</button>
      </div>
    </div>
  );
}
