import React from "react";
import { render, screen, fireEvent, waitFor } from "@testing-library/react";
import ScreenCheckForm from "./ScreenCheckForm";
import * as api from "../api/client";

jest.mock("../api/client", () => ({ getSessionStatus: jest.fn() }));
const m = api as any;

test("screen text check: needs text, becomes an assert step with no element", () => {
  const onAdd = jest.fn();
  render(<ScreenCheckForm onAdd={onAdd} />);
  const add = screen.getByRole("button", { name: /add check/i }) as HTMLButtonElement;
  expect(add.disabled).toBe(true);
  fireEvent.change(screen.getByPlaceholderText(/should be on screen/i), { target: { value: "Welcome" } });
  fireEvent.click(add);
  expect(onAdd).toHaveBeenCalledWith(expect.objectContaining({
    action: "assert", check: "screen_has_text", text: "Welcome", locator: {},
    description: 'Check screen shows text "Welcome"',
  }));
});

test("toast check works without text (any toast)", () => {
  const onAdd = jest.fn();
  render(<ScreenCheckForm onAdd={onAdd} />);
  fireEvent.change(screen.getByRole("combobox"), { target: { value: "toast" } });
  fireEvent.click(screen.getByRole("button", { name: /add check/i }));
  expect(onAdd).toHaveBeenCalledWith(expect.objectContaining({ check: "toast", description: "Check toast message appears" }));
});

test("app / screen check starts from where the phone is now", async () => {
  m.getSessionStatus.mockResolvedValue({ connected: true, package: "com.demo", activity: ".MainActivity" });
  const onAdd = jest.fn();
  render(<ScreenCheckForm onAdd={onAdd} />);
  fireEvent.change(screen.getByRole("combobox"), { target: { value: "on_screen" } });
  await waitFor(() => expect((screen.getByRole("textbox") as HTMLInputElement).value).toBe(".MainActivity"));
  fireEvent.click(screen.getByRole("button", { name: /add check/i }));
  expect(onAdd).toHaveBeenCalledWith(expect.objectContaining({
    check: "on_screen", text: ".MainActivity", locator: { package: "com.demo" },
  }));
});
