import React, { useState } from "react";
import { render, screen, fireEvent, waitFor } from "@testing-library/react";
import StepEditor from "./StepEditor";
import SavedScreenCheck from "./SavedScreenCheck";
import { variablesUsed } from "./TestDataPanel";
import { RecordedStep, StepSuggestion } from "../types";

// axios is ESM, which Jest 27 can't parse: the client is mocked (plain functions - the test setup
// resets jest.fn implementations before each test).
jest.mock("../api/client", () => ({
  getSessionStatus: () => Promise.resolve({ connected: false }),
  getSavedScreen: () => Promise.resolve([
    { index: 0, label: "'Welcome back' · TextView", check: "text_equals", expected: "Welcome back" },
    { index: 3, label: "'Balance ₹ 1,200.00' · bal", check: "text_matches", expected: "^Balance" },
  ]),
  checkFromSavedScreen: (id: string, index: number, check: string, expected: string) => Promise.resolve({
    action: "assert", check, text: expected, locator: { text: "Welcome back" }, description: `Check ${index}`,
  }),
  extractErrorMessage: (e: unknown) => String(e),
}));

const initial: RecordedStep[] = [
  { action: "tap", description: "Agree", locator: { resource_id: "com.x:id/agree" }, checked_target: true },
  { action: "tap", description: "00000030002836619", locator: { text: "00000030002836619" } },
  { action: "pick_date", description: "Pick date", text: "12/10/2026", locator: { resource_id: "com.x:id/from" } },
  { action: "run_case", description: "Run scenario \"Login\"", text: "2", locator: {} },
];

let latest: RecordedStep[] = [];
const calls: { kind: string; args: unknown[] }[] = [];

function Harness({ suggestions = [] as StepSuggestion[], merge = false }) {
  const [steps, setSteps] = useState(initial);
  latest = steps;
  return (
    <StepEditor
      steps={steps}
      editable
      onChange={setSteps}
      suggestions={suggestions}
      onMakeData={(...args) => calls.push({ kind: "data", args })}
      onUseDate={(...args) => calls.push({ kind: "date", args })}
      onMergeDates={merge ? () => calls.push({ kind: "merge", args: [] }) : undefined}
      scenarios={[{ id: 2, name: "Login" }, { id: 3, name: "Logout" }]}
      onRecordHere={(position) => calls.push({ kind: "record", args: [position] })}
    />
  );
}

beforeEach(() => { calls.length = 0; });

test("a checkbox tap shows and changes the state it makes", () => {
  render(<Harness />);
  expect(screen.getByText(/Makes it checked/)).toBeTruthy();
  fireEvent.click(screen.getAllByTitle("Edit")[0]);
  fireEvent.change(screen.getByLabelText(/If it's a checkbox or switch/), { target: { value: "tap" } });
  expect(latest[0].checked_target).toBeNull();
  fireEvent.change(screen.getByLabelText(/If it's a checkbox or switch/), { target: { value: "uncheck" } });
  expect(latest[0].checked_target).toBe(false);
});

test("Pick date and Run another scenario steps are edited", () => {
  render(<Harness />);
  expect(screen.getByText("Date")).toBeTruthy();
  expect(screen.getByText('runs "Login"')).toBeTruthy();
  fireEvent.click(screen.getAllByTitle("Edit")[2]);
  fireEvent.change(screen.getByLabelText(/^Date/), { target: { value: "${today+7d}" } });
  expect(latest[2].text).toBe("${today+7d}");
  fireEvent.click(screen.getByText("Done"));
  fireEvent.click(screen.getAllByTitle("Edit")[3]);
  fireEvent.change(screen.getByLabelText(/Scenario to run here/), { target: { value: "3" } });
  expect(latest[3].text).toBe("3");
  expect(latest[3].description).toBe('Run scenario "Logout"');
});

test("add after a step: pick a date, run a scenario, record steps here", () => {
  render(<Harness />);
  const addButtons = screen.getAllByTitle(/Add after this step/);
  fireEvent.click(addButtons[0]);
  fireEvent.click(screen.getByRole("button", { name: /Pick a date/ }));
  expect(latest[1].action).toBe("pick_date");
  expect(latest[1].text).toBe("${today+7d}");
  fireEvent.click(screen.getByText("Done"));
  fireEvent.click(screen.getAllByTitle(/Add after this step/)[0]);
  fireEvent.click(screen.getByRole("button", { name: /Run another scenario/ }));
  expect(latest[1].action).toBe("run_case");
  expect(latest[1].text).toBe("2");
  fireEvent.click(screen.getByText("Done"));
  fireEvent.click(screen.getAllByTitle(/Add after this step/)[2]);
  fireEvent.click(screen.getByRole("button", { name: /Record steps here/ }));
  expect(calls).toEqual([{ kind: "record", args: [3] }]);
});

test("suggestions: make it test data, use a date, merge calendar taps", () => {
  render(<Harness merge suggestions={[
    { index: 1, kind: "data", value: "00000030002836619", name: "beneficiary_account" },
    { index: 2, kind: "date", field: "text", value: "12/10/2026", token: "${today+7d}" },
  ]} />);
  fireEvent.change(screen.getByLabelText("Test data name"), { target: { value: "account" } });
  fireEvent.click(screen.getByRole("button", { name: "Make it test data" }));
  fireEvent.click(screen.getByRole("button", { name: "Use ${today+7d}" }));
  fireEvent.click(screen.getByRole("button", { name: "Merge calendar taps" }));
  expect(calls.map((c) => c.kind)).toEqual(["data", "date", "merge"]);
  expect(calls[0].args[2]).toBe("account");
});

test("a check on anything that was on a step's saved screen", async () => {
  const added: RecordedStep[] = [];
  render(<SavedScreenCheck step={{ action: "tap", description: "Login", locator: {}, screen_after: "abc" }}
                           onAdd={(s) => added.push(s)} onCancel={() => {}} />);
  await waitFor(() => expect(screen.getByText("'Welcome back' · TextView")).toBeTruthy());
  fireEvent.change(screen.getByLabelText("Find an element"), { target: { value: "balance" } });
  expect(screen.queryByText("'Welcome back' · TextView")).toBeNull();
  fireEvent.change(screen.getByLabelText("Find an element"), { target: { value: "" } });
  fireEvent.click(screen.getByText("'Welcome back' · TextView"));
  expect((screen.getByLabelText("Expected text") as HTMLInputElement).value).toBe("Welcome back");
  fireEvent.click(screen.getByRole("button", { name: "Add check" }));
  await waitFor(() => expect(added).toHaveLength(1));
  expect(added[0].action).toBe("assert");
  expect(added[0].text).toBe("Welcome back");
});

test("test data names: from locators and Pick date too, never the run's date", () => {
  expect(variablesUsed([
    { action: "tap", description: "", locator: { candidates: [["xpath", '//*[@text="${account}"]']] } },
    { action: "pick_date", description: "", text: "${today+7d}", locator: {} },
    { action: "pick_date", description: "", text: "${start_date}", locator: {} },
    { action: "assert", description: "", text: "${now:HH:mm}", locator: {} },
  ])).toEqual(["account", "start_date"]);
});
