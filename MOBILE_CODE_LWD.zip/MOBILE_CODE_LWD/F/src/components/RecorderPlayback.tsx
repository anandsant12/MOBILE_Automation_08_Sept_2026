import React, { useEffect, useRef, useState } from "react";
import { Circle, Square, Save, X, Smartphone, RefreshCw, Plug, Hand, ListChecks } from "lucide-react";
import { InspectedElement, Mode, RecordedStep, RunStatusResponse, StartSettings, StepSuggestion } from "../types";
import {
  tap, typeText, swipe, getScreenshot, saveScenario, updateScenario, getScenario, extractErrorMessage,
  setPhysicalCapture, getPhysicalSteps, reconnectSession, streamUrl, PhysicalCaptureStatus,
  getStepSuggestions, makeStepData, applyDateSuggestion, mergeDateSteps, listScenarios, getRunStatus,
} from "../api/client";
import { usePlaybackHeal, usePlaybackRetries, usePlaybackSpeed, useScenarioRuns } from "../hooks/useScenarioRuns";
import PopupHandlersPanel from "./PopupHandlersPanel";
import PhoneMirror from "./PhoneMirror";
import CheckForm from "./CheckForm";
import StepEditor, { restamp, ScenarioRef } from "./StepEditor";
import TestDataPanel from "./TestDataPanel";
import StartSettingsPanel from "./StartSettingsPanel";
import RunHistory from "./RunHistory";
import RunPanel from "./RunPanel";
import ScenarioLibrary from "./ScenarioLibrary";

// NOTE: there was also an "inspect" tab (the Inspector - InspectorPanel.tsx), removed on request
// 2026-10-07. To bring it back: add "inspect" here, restore the tab button and the InspectorPanel
// branch below, the inspecting/inspected state, inspectAt(), and the inspectElement import.
type WorkspaceTab = "steps" | "run";

interface RecorderPlaybackProps {
  mode: Mode;
  title: string;
  description: string;
  connected: boolean;
  mirror?: "mjpeg" | "poll";
  currentPackage: string;
  currentActivity: string;
  onRecordingChange?: (recording: boolean) => void;
}

interface PendingEdit {
  xPct: number;
  yPct: number;
  description: string;
}

const MIRROR_POLL_MS = 700;
// Continuous polling stops after this long with no activity, and restarts
// on the next interaction - live mirroring is only worth its cost (device
// screenshot capture + network + server-side JPEG re-encoding, repeated
// indefinitely) while someone's actually watching or interacting; nobody
// benefits from it running forever against a tab left open and idle.
const MIRROR_IDLE_TIMEOUT_MS = 12000;
const PHYSICAL_STEPS_POLL_MS = 600;

// Phone touches reach the page a moment after they happen (they're detected on the
// server first), so a mirror click made in between can arrive earlier. Every step
// carries the time it actually happened; keep the list in that order.
function addSteps(prev: RecordedStep[], incoming: RecordedStep[]): RecordedStep[] {
  // A password typed on the phone first shows as dots (a "value not saved" placeholder);
  // once its real value is readable (e.g. after tapping the eye icon) it replaces that.
  const revealed = new Set(incoming.filter((s) => s.field_key && !s.redacted).map((s) => s.field_key));
  const kept = prev.filter((s) => !(s.redacted && s.field_key && revealed.has(s.field_key)));
  return [...kept, ...incoming.filter((s) => !(s.redacted && s.field_key && revealed.has(s.field_key)))]
    .map((step, index) => ({ step, index }))
    .sort((a, b) => (a.step.ts ?? Number.MAX_SAFE_INTEGER) - (b.step.ts ?? Number.MAX_SAFE_INTEGER) || a.index - b.index)
    .map((x) => x.step);
}

function formatElapsed(since: number | null): string {
  if (since == null) return "0:00";
  const s = Math.max(0, Math.floor((Date.now() - since) / 1000));
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`;
}

// Phone steps arrive either as the whole current list (replace: live drafts, then the final
// list when recording stops) or as new steps to add (the snapshot fallback).
function mergePhoneSteps(prev: RecordedStep[], incoming: RecordedStep[], replace?: boolean): RecordedStep[] {
  return replace ? addSteps(prev.filter((s) => s.source !== "physical"), incoming) : addSteps(prev, incoming);
}

export default function RecorderPlayback({
  mode, title, description, connected, mirror, currentPackage, currentActivity, onRecordingChange,
}: RecorderPlaybackProps) {
  const [screenshot, setScreenshot] = useState<string | undefined>(undefined);
  const [isRecording, setIsRecording] = useState(false);
  const [steps, setSteps] = useState<RecordedStep[]>([]);
  const [pendingEdit, setPendingEdit] = useState<PendingEdit | null>(null);
  const [typedText, setTypedText] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [scenarioName, setScenarioName] = useState("");
  const [saving, setSaving] = useState(false);
  const [saveMessage, setSaveMessage] = useState<string | null>(null);
  const [libraryRefreshToken, setLibraryRefreshToken] = useState(0);
  const [physicalCaptureError, setPhysicalCaptureError] = useState<string | null>(null);
  const [physicalStatus, setPhysicalStatus] = useState<PhysicalCaptureStatus | null>(null);
  const [mirrorError, setMirrorError] = useState<string | null>(null);
  // A check being set up on an element picked in the Inspector (checks on recorded steps are
  // added with Verify, in the Steps tab).
  const [checkTarget, setCheckTarget] = useState<InspectedElement | null>(null);
  // The center workspace: the steps being recorded/edited, or the run being followed.
  const [tab, setTab] = useState<WorkspaceTab>("steps");
  // A saved scenario opened for editing (its steps are in `steps`); null = a new recording.
  const [editing, setEditing] = useState<{ id: number; name: string } | null>(null);
  // Test data for ${name} in the steps (saved with the scenario).
  const [variables, setVariables] = useState<[string, string][]>([]);
  // How a run of the scenario starts (restart the app, run Login first...), saved with it.
  const [start, setStart] = useState<StartSettings>({});
  // A past run opened from the history (the Run tab shows it instead of the latest).
  const [pastRun, setPastRun] = useState<RunStatusResponse | null>(null);
  const [pastSteps, setPastSteps] = useState<RecordedStep[] | undefined>(undefined);
  const [speed, setSpeed] = usePlaybackSpeed();
  const [retries, setRetries] = usePlaybackRetries();
  const [heal, setHeal] = usePlaybackHeal();
  const runs = useScenarioRuns(speed, retries, heal);
  // A recording started to fill in missed steps: where they go, into which list of steps.
  const insertRef = useRef<{ position: number; outer: RecordedStep[] } | null>(null);
  const [insertingAt, setInsertingAt] = useState<number | null>(null);
  // Suggestions for the steps being edited (test data, dates, calendar taps to merge).
  const [suggestions, setSuggestions] = useState<StepSuggestion[]>([]);
  const [canMergeDates, setCanMergeDates] = useState(false);
  // Saved scenarios, for "run another scenario" steps.
  const [scenarioRefs, setScenarioRefs] = useState<ScenarioRef[]>([]);
  // When the current recording started, for the elapsed time in the recording bar.
  const [recordingSince, setRecordingSince] = useState<number | null>(null);
  const [, setClock] = useState(0);
  useEffect(() => {
    if (!isRecording) return;
    const id = window.setInterval(() => setClock((c) => c + 1), 1000);
    return () => window.clearInterval(id);
  }, [isRecording]);
  const pollFailuresRef = useRef(0);
  const [streamKey, setStreamKey] = useState(0);
  const [streamFailed, setStreamFailed] = useState(false);
  // Live stream when the backend opened one; snapshot polling otherwise (or if the stream errors).
  const streaming = connected && mirror === "mjpeg" && !streamFailed;
  const isRecordingRef = useRef(false);
  useEffect(() => {
    isRecordingRef.current = isRecording;
    onRecordingChange?.(isRecording);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isRecording]);
  // Leaving this recorder mid-recording (it's unmounted) must not leave the phone-touch
  // capture running on the backend with nothing reading its steps.
  useEffect(() => () => {
    if (isRecordingRef.current) {
      setPhysicalCapture(false, mode).catch(() => {});
      onRecordingChange?.(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Kept in a ref (not state) so the poll loop below always sees the
  // latest value without needing to be torn down and restarted every
  // time an action starts/finishes.
  const busyRef = useRef(busy);
  useEffect(() => { busyRef.current = busy; }, [busy]);

  const lastActivityRef = useRef(Date.now());
  const pollActiveRef = useRef(false);
  const pollTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const stopPollLoop = () => {
    pollActiveRef.current = false;
    if (pollTimeoutRef.current) {
      clearTimeout(pollTimeoutRef.current);
      pollTimeoutRef.current = null;
    }
  };

  const startPollLoop = () => {
    if (pollActiveRef.current) return;
    pollActiveRef.current = true;
    const tick = () => {
      if (!pollActiveRef.current) return;
      // Recording counts as activity: touches on the physical phone never pass through
      // this page, so without this the snapshot mirror froze 12 s after the last click.
      if (isRecordingRef.current) lastActivityRef.current = Date.now();
      if (Date.now() - lastActivityRef.current > MIRROR_IDLE_TIMEOUT_MS) {
        pollActiveRef.current = false; // gone idle - markActivity() below restarts this on the next interaction
        return;
      }
      // Tab hidden or an action mid-flight: skip the actual fetch this
      // tick, but keep the loop alive so it resumes instantly once
      // visible/free again rather than needing a fresh trigger.
      if (document.visibilityState === "visible" && !busyRef.current) {
        getScreenshot()
          .then((shot) => {
            if (!pollActiveRef.current) return;
            pollFailuresRef.current = 0;
            setMirrorError(null);
            setScreenshot(shot);
          })
          .catch((e) => {
            // One missed tick is noise. Several in a row means the device
            // session itself is gone (the backend already tried to recover
            // it once) - say so, rather than leaving a silently frozen mirror.
            pollFailuresRef.current += 1;
            if (pollFailuresRef.current >= 3) setMirrorError(extractErrorMessage(e));
          });
      }
      pollTimeoutRef.current = setTimeout(tick, MIRROR_POLL_MS);
    };
    tick();
  };

  const markActivity = () => {
    lastActivityRef.current = Date.now();
    startPollLoop();
  };

  // Live mirroring runs only while connected AND recently active (see
  // markActivity calls below) - not continuously for as long as the tab
  // happens to be open.
  useEffect(() => {
    if (!connected) {
      setScreenshot(undefined);
      setIsRecording(false);
      setStreamFailed(false);
      stopPollLoop();
      return;
    }
    if (streaming) {
      stopPollLoop(); // the live stream needs no polling at all
      return;
    }
    markActivity();
    return stopPollLoop;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [connected, streaming]);

  const runGuarded = async (fn: () => Promise<RecordedStep>) => {
    markActivity();
    setBusy(true);
    setError(null);
    try {
      const step = await fn();
      if (step.screenshot) setScreenshot(step.screenshot);
      if (step.is_editable) {
        setPendingEdit({ xPct: step.x_pct ?? 0, yPct: step.y_pct ?? 0, description: step.description });
      } else if (isRecording) {
        setSteps((prev) => addSteps(prev, [step]));
      }
    } catch (e) {
      setError(extractErrorMessage(e));
    } finally {
      setBusy(false);
    }
  };

  const addCheck = (step: RecordedStep) => {
    setSteps((prev) => addSteps(prev, [step]));
    setCheckTarget(null);
  };

  const handleTap = (xPct: number, yPct: number) => runGuarded(() => tap(xPct, yPct, mode));
  const handleSwipe = (x1: number, y1: number, x2: number, y2: number) => runGuarded(() => swipe(x1, y1, x2, y2, mode));

  const submitPendingEdit = async () => {
    if (!pendingEdit) return;
    markActivity();
    setBusy(true);
    setError(null);
    try {
      const step = await typeText(pendingEdit.xPct, pendingEdit.yPct, typedText, mode);
      if (step.screenshot) setScreenshot(step.screenshot);
      if (isRecording) setSteps((prev) => addSteps(prev, [step]));
    } catch (e) {
      setError(extractErrorMessage(e));
    } finally {
      setPendingEdit(null);
      setTypedText("");
      setBusy(false);
    }
  };

  const handleReconnect = async () => {
    setBusy(true);
    setError(null);
    try {
      const r = await reconnectSession();
      if (r.screenshot) setScreenshot(r.screenshot);
      pollFailuresRef.current = 0;
      setMirrorError(null);
      setStreamKey((k) => k + 1); // reopen the stream against the new session
      setStreamFailed(r.mirror === "poll");
      markActivity();
      if (isRecording) {
        // The physical-touch listener was tied to the crashed session - restart it.
        setPhysicalCapture(true, mode)
          .then((s) => setPhysicalCaptureError(s.available ? null : s.error))
          .catch((e) => setPhysicalCaptureError(extractErrorMessage(e)));
      }
    } catch (e) {
      setMirrorError(extractErrorMessage(e));
    } finally {
      setBusy(false);
    }
  };

  const beginCapture = () => {
    markActivity();
    setSteps([]);
    setTab("steps");
    setSaveMessage(null);
    setRecordingSince(Date.now());
    setIsRecording(true);
    setPhysicalCaptureError(null);
    setPhysicalCapture(true, mode)
      .then((status) => { setPhysicalStatus(status); if (!status.available) setPhysicalCaptureError(status.error); })
      .catch((e) => setPhysicalCaptureError(extractErrorMessage(e)));
  };

  const startRecording = () => {
    if (steps.length > 0 && !window.confirm("Start a new recording? The unsaved steps will be discarded.")) return;
    insertRef.current = null;
    setInsertingAt(null);
    setEditing(null);
    setScenarioName("");
    setVariables([]);
    setStart({});
    beginCapture();
  };

  /** Record missed steps: what's recorded now is inserted at `position` of the steps being edited. */
  const recordHere = (position: number) => {
    insertRef.current = { position, outer: steps };
    setInsertingAt(position);
    beginCapture();
  };

  const stopRecording = () => {
    setIsRecording(false);
    const insert = insertRef.current;
    insertRef.current = null;
    setInsertingAt(null);
    const finish = (merge: (prev: RecordedStep[]) => RecordedStep[]) => setSteps((prev) => {
      const recorded = merge(prev);
      if (!insert) return recorded;
      // Recorded to fill in missed steps: put them in their place in the list being edited.
      return restamp([...insert.outer.slice(0, insert.position), ...recorded, ...insert.outer.slice(insert.position)]);
    });
    // Stopping also flushes text typed on the phone since its last touch - pick that up too.
    setPhysicalCapture(false, mode)
      .then(() => getPhysicalSteps())
      .then(({ steps: last, replace }) => finish((prev) => (last.length > 0 || replace ? mergePhoneSteps(prev, last, replace) : prev)))
      .catch(() => finish((prev) => prev));   // best-effort - recording has already stopped either way
  };

  // Suggestions for the steps being edited - asked again (debounced) as they change.
  useEffect(() => {
    if (isRecording || steps.length === 0) {
      setSuggestions([]);
      setCanMergeDates(false);
      return;
    }
    let alive = true;
    const id = window.setTimeout(() => {
      getStepSuggestions(steps.map(({ screenshot: _s, ...s }) => s))
        .then((r) => { if (alive) { setSuggestions(r.suggestions); setCanMergeDates(r.merge_dates); } })
        .catch(() => { /* suggestions are an extra */ });
    }, 400);
    return () => { alive = false; window.clearTimeout(id); };
  }, [steps, isRecording]);

  const makeData = async (index: number, s: StepSuggestion, name: string) => {
    try {
      const { step, name: saved } = await makeStepData(steps[index], s.value, name);
      setSteps((prev) => prev.map((p, j) => (j === index ? { ...p, ...step } : p)));
      setVariables((vars) => (vars.some(([k]) => k === saved) ? vars : [...vars, [saved, s.value]]));
    } catch (e) {
      setError(extractErrorMessage(e));
    }
  };

  const applyDate = async (index: number, s: StepSuggestion) => {
    try {
      const step = await applyDateSuggestion(steps[index], s);
      setSteps((prev) => prev.map((p, j) => (j === index ? { ...p, ...step } : p)));
    } catch (e) {
      setError(extractErrorMessage(e));
    }
  };

  const mergeDates = async () => {
    try {
      setSteps(restamp(await mergeDateSteps(steps)));
    } catch (e) {
      setError(extractErrorMessage(e));
    }
  };

  useEffect(() => {
    listScenarios()
      .then((all) => setScenarioRefs(all.map((s) => ({ id: s.id, name: s.name }))))
      .catch(() => {});
  }, [libraryRefreshToken]);

  // While recording, also poll for steps built from real touches on the
  // physical device (see backend/app/services/physical_capture_service.py) -
  // a completely separate input path from tapping the mirror, running
  // alongside it rather than replacing it.
  useEffect(() => {
    if (!isRecording) return;
    let cancelled = false;
    const id = setInterval(() => {
      getPhysicalSteps()
        .then(({ steps: physicalSteps, replace, status }) => {
          if (cancelled) return;
          setPhysicalStatus(status);
          if (physicalSteps.length === 0 && !replace) return;
          setSteps((prev) => mergePhoneSteps(prev, physicalSteps, replace));
          const last = physicalSteps[physicalSteps.length - 1];
          if (last.screenshot) setScreenshot(last.screenshot);
        })
        .catch(() => { /* physical capture may simply not be available on this device - not an error to surface repeatedly */ });
    }, PHYSICAL_STEPS_POLL_MS);
    return () => { cancelled = true; clearInterval(id); };
  }, [isRecording]);

  // A run in progress (just started, or found running on page load) is followed in the Run tab.
  const followedRun = useRef<string | null>(null);
  const runId = runs.run?.run_id;
  const runRunning = runs.run?.status === "running";
  useEffect(() => {
    if (runId && runRunning && followedRun.current !== runId) {
      followedRun.current = runId;
      setTab("run");
    }
  }, [runId, runRunning]);

  // The mirror shows what each replayed step left on screen (when it isn't a live stream).
  const lastShot = runs.run ? [...runs.run.log].reverse().find((e) => e.screenshot)?.screenshot : undefined;
  useEffect(() => { if (lastShot) setScreenshot(lastShot); }, [lastShot]);

  const runScenario = (id: number, overrides?: Record<number, string>) => {
    setPastRun(null);
    runs.start(id, overrides).then((ok) => { if (ok) setTab("run"); });
  };

  // The history shown in the Run tab: of the past run opened, else of the latest run's scenario
  // (or the one chosen with History in the scenario list).
  const [historyFor, setHistoryFor] = useState<number | null>(null);
  const historyScenarioId = pastRun?.scenario_id ?? historyFor ?? runs.run?.scenario_id ?? null;
  const historyName = scenarioRefs.find((s) => s.id === historyScenarioId)?.name;

  const openPastRun = async (runId: string) => {
    try {
      const run = await getRunStatus(runId);
      setPastRun(run);
      setPastSteps(undefined);
      if (run.scenario_id != null) {
        getScenario(run.scenario_id).then((d) => setPastSteps(d.steps)).catch(() => setPastSteps([]));
      }
    } catch (e) {
      setError(extractErrorMessage(e));
    }
  };

  const showHistory = (id: number) => {
    setHistoryFor(id);
    setPastRun(null);
    setTab("run");
  };

  const runFrom = (index: number) => {
    if (runs.run?.scenario_id != null) runs.start(runs.run.scenario_id, undefined, index);
  };

  const openForEditing = async (id: number) => {
    if (steps.length > 0 && !editing && !window.confirm("Replace the unsaved steps with this scenario's?")) return;
    setError(null);
    try {
      const detail = await getScenario(id);
      setSteps(restamp(detail.steps));
      setVariables(Object.entries(detail.variables || {}));
      setStart(detail.start || {});
      setEditing({ id, name: detail.name });
      setScenarioName(detail.name);
      setSaveMessage(null);
      setTab("steps");
    } catch (e) {
      setError(extractErrorMessage(e));
    }
  };

  const discard = () => {
    setSteps([]);
    setScenarioName("");
    setVariables([]);
    setStart({});
    setEditing(null);
    setCheckTarget(null);
  };

  const save = async () => {
    if (!scenarioName.trim()) {
      setError("Give the scenario a name before saving.");
      return;
    }
    setSaving(true);
    setError(null);
    const data: Record<string, string> = {};
    variables.forEach(([k, v]) => { if (k.trim()) data[k.trim()] = v; });
    try {
      if (editing) {
        await updateScenario(editing.id, scenarioName.trim(), mode, currentPackage, currentActivity, steps, data, start);
        runs.refreshSteps();
      } else {
        await saveScenario(scenarioName.trim(), mode, currentPackage, currentActivity, steps, data, start);
      }
      setSaveMessage(`Saved "${scenarioName.trim()}" (${steps.length} steps).`);
      setSteps([]);
      setScenarioName("");
      setVariables([]);
      setStart({});
      setEditing(null);
      setCheckTarget(null);
      setLibraryRefreshToken((t) => t + 1);
    } catch (e) {
      setError(extractErrorMessage(e));
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="recorder">
      <div className="recorder__phone">
        <div className="recorder__intro">
          {title && <h2>{title}</h2>}
          <p className="muted">{description}</p>
        </div>

        <div className="recorder__toolbar">
          {!isRecording ? (
            <button className="btn btn--primary" onClick={startRecording} disabled={!connected || busy}>
              <Circle size={13} fill="currentColor" /> Start recording
            </button>
          ) : (
            <button className="btn btn--danger" onClick={stopRecording} disabled={busy}>
              <Square size={13} /> Stop recording
            </button>
          )}
          {connected && (
            <span
              className="physical-capture-badge"
              title={streaming ? "Smooth live stream straight from the phone" : "Snapshot mirror (slower) - live streaming wasn't available for this session"}
            >
              {streaming ? "Live stream" : "Snapshot mirror"}
            </span>
          )}
          {isRecording && (
            <span className="physical-capture-badge" title={physicalCaptureError || "Taps on the physical device itself are also being captured"}>
              <Smartphone size={12} />
              {physicalStatus?.starting ? "Connecting to the phone…"
                : physicalCaptureError ? "Physical touch capture unavailable" : "Physical touch capture on"}
            </span>
          )}
        </div>

        {isRecording && physicalStatus && (
          <div className="physical-diagnostics">
            {physicalStatus.starting ? (
              <p className="muted">Connecting to the phone to capture its touches&hellip; (a moment)</p>
            ) : !physicalStatus.available ? (
              <p className="error-text">
                Touches on the phone aren&apos;t being captured: {physicalStatus.error || "unknown reason"}. Recording
                through the mirror still works.
              </p>
            ) : (
              <details>
                <summary>
                  {physicalStatus.helper ? (
                    <>
                      Phone: {physicalStatus.stats.seen} touches &middot; {physicalStatus.stats.recorded} matched to
                      elements &middot; {physicalStatus.fields_typed ?? 0} fields typed &mdash; steps marked
                      &ldquo;live&rdquo; are tidied up when you stop
                    </>
                  ) : (
                    <>
                      Phone touches: {physicalStatus.stats.seen} seen &middot; {physicalStatus.stats.recorded} recorded
                      &middot; {physicalStatus.stats.skipped} skipped
                    </>
                  )}
                </summary>
                <ul>
                  {physicalStatus.recent.length === 0 && <li>Nothing yet - touch the phone.</li>}
                  {physicalStatus.recent.map((line, i) => <li key={i}>{line}</li>)}
                </ul>
                <p className="muted">
                  {physicalStatus.helper
                    ? "Touches identified on the phone by the recorder helper"
                    : `Recorder helper off${physicalStatus.helper_error ? ` (${physicalStatus.helper_error})` : ""} - touches matched against screen snapshots`}
                </p>
                <p className="muted">touch device {physicalStatus.touch_device} &middot; adb {physicalStatus.adb}</p>
              </details>
            )}
          </div>
        )}

        {mirrorError && (
          <div className="session-banner" role="alert">
            <div className="session-banner__text">
              <strong>Lost contact with the device session.</strong>
              <span>{mirrorError}</span>
            </div>
            <button className="btn btn--small btn--primary" onClick={handleReconnect} disabled={busy}>
              <RefreshCw size={13} /> Reconnect
            </button>
          </div>
        )}

        <PhoneMirror
          screenshot={screenshot}
          streamUrl={streaming ? streamUrl(streamKey) : undefined}
          onStreamError={() => setStreamFailed(true)}
          connected={connected}
          isBusy={busy}
          isRecording={isRecording}
          onTap={handleTap}
          onSwipe={handleSwipe}
        />

        {checkTarget && (
          <CheckForm element={checkTarget} onAdd={addCheck} onCancel={() => setCheckTarget(null)} />
        )}

        {pendingEdit && (
          <div className="inline-edit">
            <span>Type into <strong>{pendingEdit.description}</strong>:</span>
            <input
              autoFocus
              value={typedText}
              onChange={(e) => setTypedText(e.target.value)}
              onKeyDown={(e) => { if (e.key === "Enter") submitPendingEdit(); }}
            />
            <button className="btn btn--small btn--primary" onClick={submitPendingEdit} disabled={busy}>
              Enter text
            </button>
            <button className="btn btn--small btn--ghost" onClick={() => { setPendingEdit(null); setTypedText(""); }}>
              Cancel
            </button>
          </div>
        )}

        {error && <p className="error-text">{error}</p>}
      </div>

      <section className="workspace">
        <div className="workspace__tabs" role="tablist">
          <button
            role="tab" aria-selected={tab === "steps"}
            className={`workspace__tab${tab === "steps" ? " workspace__tab--active" : ""}`}
            onClick={() => setTab("steps")}
          >
            Steps{steps.length > 0 ? ` (${steps.length})` : ""}
          </button>
          <button
            role="tab" aria-selected={tab === "run"}
            className={`workspace__tab${tab === "run" ? " workspace__tab--active" : ""}`}
            onClick={() => setTab("run")}
          >
            Run
            {runs.run && <span className={`workspace__dot workspace__dot--${runs.run.status}`} />}
          </button>
        </div>

        {tab === "steps" && isRecording && (
          <div className="recording-bar" role="status">
            <span className="recording-bar__dot" />
            Recording
            <span className="recording-bar__time">{formatElapsed(recordingSince)}</span>
            <span className="recording-bar__count">{steps.length} step{steps.length === 1 ? "" : "s"}</span>
            <span className="recording-bar__hint">
              {insertingAt != null
                ? `Recording steps to insert after step ${insertingAt}${editing ? ` of ${editing.name}` : ""} - they go in there when you stop`
                : "Use the phone or click the mirror — edit and verify once you stop"}
            </span>
          </div>
        )}

        {tab === "steps" && !isRecording && steps.length === 0 && !editing ? (
          <div className="workspace__body">
            <div className="empty-guide">
              <h3>Record a test in four steps</h3>
              <ol>
                <li><span className="empty-guide__icon"><Plug size={16} /></span><div><strong>Connect</strong> your phone above.</div></li>
                <li><span className="empty-guide__icon"><Circle size={16} /></span><div><strong>Start recording</strong> on the left.</div></li>
                <li><span className="empty-guide__icon"><Hand size={16} /></span><div><strong>Use the app</strong> on the phone or by clicking the mirror &mdash; steps appear here as you go.</div></li>
                <li><span className="empty-guide__icon"><ListChecks size={16} /></span><div><strong>Stop, verify and save</strong> &mdash; add a check after any step, name it, save.</div></li>
              </ol>
              <p className="muted">Or pick <strong>Edit</strong> on a saved scenario to change it.</p>
            </div>
          </div>
        ) : tab === "steps" ? (
          <div className="workspace__body">
            {!isRecording && (
              <p className="workspace__caption">
                {editing
                  ? <>Editing <strong>{editing.name}</strong> &mdash; changes are kept when you save.</>
                  : "New recording \u2014 fix anything that's off, add checks with Verify, then name it and save."}
              </p>
            )}
            <StepEditor
              steps={steps}
              editable={!isRecording}
              onChange={setSteps}
              emptyText="No steps yet - interact with the mirror, or the phone itself, while recording."
              suggestions={suggestions}
              onMakeData={makeData}
              onUseDate={applyDate}
              onMergeDates={canMergeDates ? mergeDates : undefined}
              scenarios={scenarioRefs.filter((s) => s.id !== editing?.id)}
              onRecordHere={connected ? recordHere : undefined}
            />
            {!isRecording && (steps.length > 0 || editing) && (
              <>
                <StartSettingsPanel
                  start={start}
                  onChange={setStart}
                  scenarios={scenarioRefs.filter((s) => s.id !== editing?.id)}
                />
                <TestDataPanel steps={steps} variables={variables} onChange={setVariables} />
              </>
            )}
            {!isRecording && (steps.length > 0 || editing) && (
              <div className="save-bar">
                <input
                  placeholder="Name this scenario"
                  value={scenarioName}
                  onChange={(e) => setScenarioName(e.target.value)}
                />
                <button className="btn btn--primary" onClick={save} disabled={saving || steps.length === 0}>
                  <Save size={14} /> {saving ? "Saving\u2026" : editing ? "Save changes" : "Save scenario"}
                </button>
                <button className="btn btn--ghost" onClick={discard}>
                  <X size={14} /> {editing ? "Close" : "Discard"}
                </button>
              </div>
            )}
            {saveMessage && <p className="success-text">{saveMessage}</p>}
          </div>
        ) : tab === "run" ? (
          <div className="workspace__body">
            {pastRun ? (
              <RunPanel
                run={pastRun}
                steps={pastSteps}
                stopping={false}
                canRun={false}
                onStop={() => {}}
                onRunFrom={() => {}}
                pastRun={{ onClose: () => setPastRun(null) }}
              />
            ) : (
              <RunPanel
                run={runs.run}
                scenarioName={runs.runName}
                steps={runs.runSteps}
                stopping={runs.stopping}
                canRun={connected}
                onStop={runs.stop}
                onRunFrom={runFrom}
                error={runs.error}
                onPromote={runs.promote}
              />
            )}
            {historyScenarioId != null && (
              <RunHistory
                scenarioId={historyScenarioId}
                scenarioName={historyName}
                refreshKey={`${runs.run?.run_id}:${runs.run?.status}:${libraryRefreshToken}`}
                openRunId={pastRun?.run_id ?? null}
                onOpen={openPastRun}
              />
            )}
          </div>
        ) : null}
      </section>

      <aside className="recorder__side">
        <ScenarioLibrary
          mode={mode}
          refreshToken={libraryRefreshToken}
          connected={connected}
          run={runs.run}
          speed={speed}
          onSpeedChange={setSpeed}
          retries={retries}
          onRetriesChange={setRetries}
          heal={heal}
          onHealChange={setHeal}
          onRun={runScenario}
          onEdit={openForEditing}
          onHistory={showHistory}
          editingId={editing?.id ?? null}
          runError={tab === "steps" ? runs.error : null}
        />
        <PopupHandlersPanel />
      </aside>
    </div>
  );
}
