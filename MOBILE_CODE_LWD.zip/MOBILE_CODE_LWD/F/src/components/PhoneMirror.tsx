import React, { useCallback, useRef, useState } from "react";

interface PhoneMirrorProps {
  screenshot?: string;
  /** When set, the mirror is a live MJPEG stream the browser renders itself. */
  streamUrl?: string;
  connected: boolean;
  isBusy?: boolean;
  isRecording?: boolean;
  onTap: (xPct: number, yPct: number) => void;
  onSwipe: (x1Pct: number, y1Pct: number, x2Pct: number, y2Pct: number) => void;
  onStreamError?: () => void;
}

const DRAG_THRESHOLD_PX = 14;
const RIPPLE_MS = 650;

export default function PhoneMirror({
  screenshot, streamUrl, connected, isBusy, isRecording, onTap, onSwipe, onStreamError,
}: PhoneMirrorProps) {
  const imgRef = useRef<HTMLImageElement>(null);
  const pointerDown = useRef<{ x: number; y: number } | null>(null);
  const rippleId = useRef(0);
  const [ripples, setRipples] = useState<{ id: number; x: number; y: number }[]>([]);

  const pctFromClient = useCallback((clientX: number, clientY: number) => {
    const el = imgRef.current;
    if (!el) return null;
    const rect = el.getBoundingClientRect();
    return {
      xPct: Math.min(1, Math.max(0, (clientX - rect.left) / rect.width)),
      yPct: Math.min(1, Math.max(0, (clientY - rect.top) / rect.height)),
    };
  }, []);

  // Instant local feedback: the click registers visibly right away, instead of
  // the mirror looking dead until the device round trip finishes.
  const showRipple = (xPct: number, yPct: number) => {
    const id = ++rippleId.current;
    setRipples((r) => [...r, { id, x: xPct, y: yPct }]);
    window.setTimeout(() => setRipples((r) => r.filter((item) => item.id !== id)), RIPPLE_MS);
  };

  const handlePointerDown = (e: React.PointerEvent) => {
    if (isBusy) return;
    pointerDown.current = { x: e.clientX, y: e.clientY };
    // Keep receiving the pointer after it leaves the image, so a swipe that ends past the
    // mirror's edge still gets its pointerup (it was silently dropped before).
    try {
      e.currentTarget.setPointerCapture(e.pointerId);
    } catch {
      // not supported (e.g. some test environments) - worst case, the old behaviour
    }
  };

  const handlePointerUp = (e: React.PointerEvent) => {
    if (isBusy || !pointerDown.current) return;
    const start = pointerDown.current;
    pointerDown.current = null;
    const dist = Math.hypot(e.clientX - start.x, e.clientY - start.y);

    if (dist < DRAG_THRESHOLD_PX) {
      const p = pctFromClient(e.clientX, e.clientY);
      if (p) {
        showRipple(p.xPct, p.yPct);
        onTap(p.xPct, p.yPct);
      }
    } else {
      const p1 = pctFromClient(start.x, start.y);
      const p2 = pctFromClient(e.clientX, e.clientY);
      if (p1 && p2) onSwipe(p1.xPct, p1.yPct, p2.xPct, p2.yPct);
    }
  };

  const src = streamUrl ?? (screenshot ? `data:image/jpeg;base64,${screenshot}` : undefined);
  const showImage = connected && !!src;

  return (
    <div className={`phone-mirror${isRecording ? " phone-mirror--recording" : ""}`}>
      {isRecording && (
        <div className="phone-mirror__rec-badge">
          <span className="phone-mirror__rec-dot" />
          Recording
        </div>
      )}
      <div className={`phone-mirror__screen${showImage ? "" : " phone-mirror__screen--empty"}`}>
        {showImage ? (
          <img
            ref={imgRef}
            src={src}
            alt="Device screen"
            className="phone-mirror__image"
            draggable={false}
            onPointerDown={handlePointerDown}
            onPointerUp={handlePointerUp}
            onPointerCancel={() => { pointerDown.current = null; }}
            onError={streamUrl ? onStreamError : undefined}
          />
        ) : (
          <div className="phone-mirror__placeholder">
            {connected ? "Loading screen\u2026" : "Connect a device to see its screen here"}
          </div>
        )}
        {ripples.map((r) => (
          <span key={r.id} className="phone-mirror__ripple" style={{ left: `${r.x * 100}%`, top: `${r.y * 100}%` }} />
        ))}
        {isBusy && (
          <div className="phone-mirror__busy" title="Working on the device">
            <div className="spinner" />
          </div>
        )}
      </div>
    </div>
  );
}
