import React, { useState } from "react";
import { InspectedElement, RecordedStep } from "../types";
import CheckForm from "./CheckForm";
import ScreenCheckForm from "./ScreenCheckForm";
import SavedScreenCheck from "./SavedScreenCheck";
import { locatorStrategies } from "./LocatorInfo";

/** The element a recorded step acted on, as a check target - with what it showed then. */
function elementOf(step: RecordedStep): InspectedElement | null {
  const loc = step.locator || {};
  if (!["tap", "long_press", "type", "select", "pick_date"].includes(step.action)) return null;
  if (locatorStrategies(loc).length === 0 && !loc.web) return null;
  const shown =
    step.action === "type" || step.action === "select" ? step.text ?? ""   // the value typed / picked
      : loc.anchor ? ""                                                    // its own text wasn't kept (a value)
        : loc.text || loc.content_desc || loc.web?.text || "";
  const name = step.description.replace(/\s*\(value not saved.*\)$/i, "");
  return {
    description: step.action === "select" ? name.replace(/^Select '.*' from /, "") : name,
    locator: loc,
    x_pct: step.x_pct ?? 0,
    y_pct: step.y_pct ?? 0,
    text: shown,
    enabled: null, checked: null, checkable: null,
    suggested_check: shown ? "text_equals" : "visible",
  };
}

interface StepCheckPanelProps {
  step: RecordedStep;
  onAdd: (check: RecordedStep) => void;
  onCancel: () => void;
  /** Names remembered by earlier "capture" steps, to compare a check against. */
  remembered?: string[];
}

/** "Verify after this step": a check on the element the step used, or on the whole screen. */
export default function StepCheckPanel({ step, onAdd, onCancel, remembered = [] }: StepCheckPanelProps) {
  const element = elementOf(step);
  const saved = !!(step.screen || step.screen_after);
  const [about, setAbout] = useState<"element" | "saved" | "screen">(element ? "element" : saved ? "saved" : "screen");

  return (
    <div className="step-check">
      <div className="step-check__head">
        <span className="step-check__title">Verify after this step</span>
        <div className="segmented">
          <button className={about === "element" ? "segmented__on" : ""} onClick={() => setAbout("element")} disabled={!element}>
            This step&apos;s element
          </button>
          {saved && (
            <button
              className={about === "saved" ? "segmented__on" : ""}
              onClick={() => setAbout("saved")}
              title="Anything that was on this step's screen (saved while recording) - no phone needed"
            >
              Anything on its screen
            </button>
          )}
          <button className={about === "screen" ? "segmented__on" : ""} onClick={() => setAbout("screen")}>
            Whole screen
          </button>
        </div>
        <button className="btn btn--small btn--ghost" onClick={onCancel}>Cancel</button>
      </div>
      {about === "element" && element ? (
        <CheckForm element={element} onAdd={onAdd} onCancel={onCancel} remembered={remembered} />
      ) : about === "saved" ? (
        <SavedScreenCheck step={step} onAdd={onAdd} onCancel={onCancel} />
      ) : (
        <ScreenCheckForm onAdd={onAdd} showTitle={false} />
      )}
      {!element && (
        <p className="muted step-check__hint">
          This step has no element to check ({step.action === "swipe" || step.action === "key" ? "it's a gesture" : "no locator"}) -
          check the screen, or use Add check on the mirror.
        </p>
      )}
    </div>
  );
}
