import React from "react";
import { AlertOctagon, Bug, Check, Download, PlugZap, Square, X } from "lucide-react";
import { downloadRunJunit } from "../api/client";
import { HealedLocator, RunFailure, RunStatusResponse, Step } from "../types";
import StepChecklist from "./StepChecklist";

interface RunPanelProps {
  run: RunStatusResponse | null;
  scenarioName?: string;
  steps?: Step[];
  stopping: boolean;
  canRun: boolean;
  onStop: () => void;
  onRunFrom: (index: number) => void;
  error?: string | null;   // starting or stopping a run failed
  onPromote?: (index: number, strategy: HealedLocator) => Promise<void>;
  /** A past run opened from the history: when it ran, and how to get back to the latest. */
  pastRun?: { onClose: () => void };
}

const STATUS_TEXT = { running: "Running…", passed: "Passed", failed: "Failed", stopped: "Stopped" };

/** How a failure is presented: whose problem it is, and what to do about it. */
export const FAILURE_GROUPS: Record<RunFailure["group"], { title: string; hint: string; icon: React.ReactNode }> = {
  app: {
    title: "App problem",
    hint: "The app itself misbehaved - worth reporting as a bug (with the screenshot and detail below).",
    icon: <AlertOctagon size={15} />,
  },
  test: {
    title: "Test problem",
    hint: "The app didn't look the way the test expects - the screen changed, a locator broke, or the expected value is out of date. Check the step.",
    icon: <Bug size={15} />,
  },
  environment: {
    title: "Phone / setup problem",
    hint: "The phone, the Appium session or starting the app failed - not the app or the test. Check the connection and run again.",
    icon: <PlugZap size={15} />,
  },
};

/** The Run tab: the latest run of a saved scenario (or one from its history), step by step. */
export default function RunPanel({
  run, scenarioName, steps, stopping, canRun, onStop, onRunFrom, error, onPromote, pastRun,
}: RunPanelProps) {
  if (!run) {
    return (
      <>
        <p className="muted">Run a saved scenario (on the right) to follow it here step by step.</p>
        {error && <p className="error-text">{error}</p>}
      </>
    );
  }
  // Steps of a scenario run by a step all count as that one step; what ran before the steps
  // (the app restarted, a Login scenario) doesn't count.
  const own = run.log.filter((e) => e.order_index != null && e.order_index >= 0);
  const done = new Set(own.map((e) => e.order_index)).size;
  const setup = run.log.filter((e) => e.order_index != null && e.order_index < 0);
  const total = run.total_steps ?? steps?.length ?? 0;
  const failedEntry = [...run.log].reverse().find((e) => e.status === "error");
  const failShot = failedEntry?.screenshot;
  const elapsed = run.log.reduce((sum, e) => sum + (e.duration ?? 0), 0);
  const diagnosis = run.failure ? FAILURE_GROUPS[run.failure.group] : null;
  const when = run.created_at ? new Date(run.created_at * 1000).toLocaleString() : null;

  return (
    <div className="run-panel">
      {pastRun && (
        <div className="run-panel__past">
          <span>A past run{when ? ` - ${when}` : ""}. Its steps are shown as the scenario is now.</span>
          <button className="btn btn--small btn--ghost" onClick={pastRun.onClose}>Back to the latest run</button>
        </div>
      )}
      <div className="run-panel__header">
        <div>
          <strong>{scenarioName ?? run.scenario_name ?? "Scenario"}</strong>
          <div className={`scenario-library__run-status scenario-library__run-status--${run.status}`}>
            {run.status === "running" && stopping ? "Stopping…" : STATUS_TEXT[run.status]}
            <span className="muted">
              {" "}&middot; {done}/{total} steps{elapsed > 0 ? ` · ${elapsed.toFixed(1)}s` : ""}
              {run.start_index ? ` · from step ${run.start_index + 1}` : ""}
            </span>
          </div>
        </div>
        {run.status === "running" && !pastRun ? (
          <button className="btn btn--small btn--danger" onClick={onStop} disabled={stopping}>
            <Square size={13} /> {stopping ? "Stopping…" : "Stop"}
          </button>
        ) : (
          <button
            className="btn btn--small btn--ghost"
            onClick={() => downloadRunJunit(run.run_id).catch(() => {})}
            title="Download this run as a JUnit XML report (for CI systems)"
          >
            <Download size={13} /> JUnit report
          </button>
        )}
      </div>

      {error && !pastRun && <p className="error-text">{error}</p>}

      <div className="run-panel__progress">
        <div
          className={`run-panel__bar run-panel__bar--${run.status}`}
          style={{ width: `${total ? Math.min(100, (done / total) * 100) : 0}%` }}
        />
      </div>

      {setup.length > 0 && (
        <ul className="run-panel__setup" aria-label="Before the steps">
          {setup.map((e, i) => (
            <li key={i} className={e.status === "error" ? "run-panel__setup--error" : ""}>
              {e.status === "error" ? <X size={12} /> : <Check size={12} />} {e.description}
              {e.error && <span className="error-text"> - {e.error}</span>}
            </li>
          ))}
        </ul>
      )}

      {run.failure && diagnosis && (
        <div className={`run-panel__diagnosis run-panel__diagnosis--${run.failure.group}`} role="alert">
          <div className="run-panel__diagnosis-title">{diagnosis.icon} {diagnosis.title}: {run.failure.summary}</div>
          {run.failure.detail && <code className="run-panel__diagnosis-detail">{run.failure.detail}</code>}
          <p className="muted">{diagnosis.hint}</p>
        </div>
      )}

      {failedEntry && (
        <div className="run-panel__failure">
          <div>
            <strong>Failed at: {failedEntry.description || failedEntry.action}</strong>
            <p className="error-text">{failedEntry.error}</p>
          </div>
          {failShot && (
            <img className="run-panel__shot" src={`data:image/jpeg;base64,${failShot}`} alt="Screen when the step failed" />
          )}
        </div>
      )}

      {steps ? (
        <StepChecklist
          steps={steps} log={own} status={run.status} startIndex={run.start_index ?? 0}
          onRunFrom={canRun && !pastRun ? onRunFrom : undefined}
          onPromote={pastRun ? undefined : onPromote}
        />
      ) : (
        <p className="muted">Loading steps&hellip;</p>
      )}
      {canRun && !pastRun && run.status !== "running" && (
        <p className="muted">Use &#9654; on a step to run again from there.</p>
      )}
    </div>
  );
}
