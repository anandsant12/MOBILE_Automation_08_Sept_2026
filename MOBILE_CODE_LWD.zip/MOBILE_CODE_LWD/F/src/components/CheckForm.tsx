import React, { useState } from "react";
import {
  CheckKind, CHECK_LABELS, describeCheck, ELEMENT_CHECKS, InspectedElement, Normalize, NORMALIZE_LABELS,
  RecordedStep, TEXT_CHECKS,
} from "../types";

interface CheckFormProps {
  element: InspectedElement;
  onAdd: (step: RecordedStep) => void;
  onCancel: () => void;
  /** Names remembered by "capture" steps earlier in the scenario - offered to compare against. */
  remembered?: string[];
}

const NORMALIZE_KEYS: Normalize[] = ["raw", "trim", "digits", "number"];

/** A name from the element's description: "Account Number" -> account_number. Empty when the
 *  description is really a value (a number/amount) and makes a poor name - the user names it. */
function suggestVar(element: InspectedElement): string {
  const base = element.description.replace(/^(select|choose|pick|enter)\s+/i, "");
  const name = base.replace(/\W+/g, "_").replace(/^_+|_+$/g, "").toLowerCase();
  return /[a-z]{3}/.test(name) ? name.slice(0, 40) : "";
}

/** What to verify about the element picked on the mirror (an "assert" step), or remember its
 *  value for later ("capture"). */
export default function CheckForm({ element, onAdd, onCancel, remembered = [] }: CheckFormProps) {
  const [mode, setMode] = useState<"check" | "capture">("check");
  const [check, setCheck] = useState<CheckKind>(element.suggested_check);
  // A changing value (a balance, the time) comes suggested as a pattern that holds next run too.
  const [expected, setExpected] = useState(element.suggested_expected ?? element.text);
  const [normalize, setNormalize] = useState<Normalize>("raw");
  const [varName, setVarName] = useState(suggestVar(element));
  const needsText = TEXT_CHECKS.includes(check);
  const showNormalize = mode === "capture" || check === "text_equals" || check === "text_contains";

  const addCheck = () => {
    const what = describeCheck(check, needsText ? expected : null);
    onAdd({
      action: "assert",
      check,
      text: needsText ? expected : undefined,
      normalize: showNormalize && normalize !== "raw" ? normalize : undefined,
      description: `Check ${element.description} ${what}`,
      locator: element.locator,
      x_pct: element.x_pct,
      y_pct: element.y_pct,
      ts: Date.now() / 1000,
    });
  };

  const addCapture = () => {
    const name = varName.trim() || "value";
    onAdd({
      action: "capture",
      var: name,
      normalize: normalize !== "raw" ? normalize : undefined,
      description: `Remember ${element.description} as \${${name}}`,
      locator: element.locator,
      x_pct: element.x_pct,
      y_pct: element.y_pct,
      ts: Date.now() / 1000,
    });
  };

  return (
    <div className="inline-edit inline-edit--check">
      <div className="segmented segmented--small">
        <button className={mode === "check" ? "segmented__on" : ""} onClick={() => setMode("check")}>Check it</button>
        <button
          className={mode === "capture" ? "segmented__on" : ""}
          onClick={() => setMode("capture")}
          title="Read this value now and remember it, to compare against (or type) in a later step"
        >
          Remember its value
        </button>
      </div>
      <span>
        {mode === "check" ? "Check" : "Remember"} <strong>{element.description}</strong>
        {element.text && <span className="muted"> (now: &ldquo;{element.text}&rdquo;)</span>}
      </span>

      {mode === "check" ? (
        <>
          <select value={check} onChange={(e) => setCheck(e.target.value as CheckKind)}>
            {ELEMENT_CHECKS.map((k) => <option key={k} value={k}>{CHECK_LABELS[k]}</option>)}
          </select>
          {needsText && (
            <input
              autoFocus
              value={expected}
              placeholder={remembered.length ? "Type a value, or pick a remembered one →" : "Expected text"}
              onChange={(e) => setExpected(e.target.value)}
              onKeyDown={(e) => { if (e.key === "Enter" && expected.trim()) addCheck(); }}
            />
          )}
          {needsText && remembered.length > 0 && (
            <select
              value=""
              title="Compare against a value a 'Remember' step saved earlier"
              onChange={(e) => { if (e.target.value) { setExpected("${" + e.target.value + "}"); setNormalize("digits"); } }}
            >
              <option value="">use remembered…</option>
              {remembered.map((n) => <option key={n} value={n}>{n}</option>)}
            </select>
          )}
        </>
      ) : (
        <input
          autoFocus
          value={varName}
          placeholder="Name to remember it as, e.g. account_number"
          onChange={(e) => setVarName(e.target.value)}
          onKeyDown={(e) => { if (e.key === "Enter" && varName.trim()) addCapture(); }}
        />
      )}

      {showNormalize && (
        <select
          value={normalize}
          onChange={(e) => setNormalize(e.target.value as Normalize)}
          title={mode === "capture" ? "How the value is stored" : "Reduce both values the same way before comparing"}
        >
          {NORMALIZE_KEYS.map((k) => <option key={k} value={k}>{NORMALIZE_LABELS[k]}</option>)}
        </select>
      )}

      {mode === "check" ? (
        <button className="btn btn--small btn--primary" onClick={addCheck} disabled={needsText && !expected.trim()}>
          Add check
        </button>
      ) : (
        <button className="btn btn--small btn--primary" onClick={addCapture} disabled={!varName.trim()}>
          Remember value
        </button>
      )}
      <button className="btn btn--small btn--ghost" onClick={onCancel}>Cancel</button>
    </div>
  );
}
