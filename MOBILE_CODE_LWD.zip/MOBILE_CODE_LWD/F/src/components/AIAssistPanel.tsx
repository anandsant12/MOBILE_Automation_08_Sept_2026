import React, { useState } from "react";
import { Sparkles, Square } from "lucide-react";
import { startAssistRun, stopRun, extractErrorMessage } from "../api/client";
import { useActiveRun } from "../hooks/useActiveRun";
import RunLog from "./RunLog";

export default function AIAssistPanel({ connected }: { connected: boolean }) {
  const [instruction, setInstruction] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [stopping, setStopping] = useState(false);
  const { run, setRun } = useActiveRun("assist");

  const status = run?.status ?? null;
  const isRunning = status === "running";
  const log = run?.log ?? [];
  const finalScreenshot = [...log].reverse().find((e) => e.screenshot)?.screenshot;

  const execute = async () => {
    if (!instruction.trim()) return;
    setError(null);
    setStopping(false);
    try {
      const started = await startAssistRun(instruction.trim());
      setRun({ run_id: started.run_id, kind: "assist", status: "running", total_steps: started.total_steps, log: [] });
    } catch (e) {
      setError(extractErrorMessage(e));
    }
  };

  const stop = async () => {
    if (!run) return;
    setStopping(true);
    try {
      setRun(await stopRun(run.run_id));
    } catch (e) {
      setError(extractErrorMessage(e));
      setStopping(false);
    }
  };

  return (
    <div className="ai-assist">
      <h3>Ask the AI to do something</h3>
      <p className="muted">
        Describe a goal in plain English. The model looks at the current screen, draws on
        anything recorded earlier for this app, and carries it out one step at a time.
      </p>
      <div className="ai-assist__input">
        <textarea
          placeholder='e.g. "Open the compose screen and start a new message"'
          value={instruction}
          onChange={(e) => setInstruction(e.target.value)}
          rows={3}
          disabled={!connected || isRunning}
        />
        {isRunning ? (
          <button className="btn btn--danger" onClick={stop} disabled={stopping}>
            <Square size={14} /> {stopping ? "Stopping\u2026" : "Stop"}
          </button>
        ) : (
          <button className="btn btn--primary" onClick={execute} disabled={!connected || !instruction.trim()}>
            <Sparkles size={14} /> Execute
          </button>
        )}
      </div>
      {!connected && <p className="muted">Connect a device first.</p>}
      {error && <p className="error-text">{error}</p>}

      {status && (
        <div className="ai-assist__result">
          <div className={`scenario-library__run-status scenario-library__run-status--${status}`}>
            {status === "running" && (stopping ? "Stopping\u2026" : "Working\u2026")}
            {status === "passed" && "Done"}
            {status === "failed" && "Failed"}
            {status === "stopped" && "Stopped"}
          </div>
          {finalScreenshot && (
            <img
              className="ai-assist__screenshot"
              src={`data:image/jpeg;base64,${finalScreenshot}`}
              alt="Screen after the run"
            />
          )}
          <div className="ai-assist__log">
            <h4>Run log</h4>
            <RunLog log={log} />
          </div>
        </div>
      )}
    </div>
  );
}
