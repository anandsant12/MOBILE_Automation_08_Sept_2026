import { useCallback, useEffect, useState } from "react";
import { extractErrorMessage, getScenario, PlaybackSpeed, preferLocator, startScenarioRun, stopRun } from "../api/client";
import { HealedLocator, ScenarioDetail } from "../types";
import { useActiveRun } from "./useActiveRun";

const SPEED_KEY = "playbackSpeed";

function savedSpeed(): PlaybackSpeed {
  try {
    const v = localStorage.getItem(SPEED_KEY);
    return v === "medium" || v === "slow" ? v : "fast";
  } catch {
    return "fast";
  }
}

/** Playback speed, remembered in this browser. */
export function usePlaybackSpeed(): [PlaybackSpeed, (s: PlaybackSpeed) => void] {
  const [speed, setSpeedState] = useState<PlaybackSpeed>(savedSpeed);
  const setSpeed = useCallback((s: PlaybackSpeed) => {
    setSpeedState(s);
    try { localStorage.setItem(SPEED_KEY, s); } catch { /* per-browser convenience only */ }
  }, []);
  return [speed, setSpeed];
}

const RETRIES_KEY = "playbackRetries";

/** Retries for a step whose element wasn't found / check wasn't true yet (0-2), remembered in this browser. */
export function usePlaybackRetries(): [number, (n: number) => void] {
  const [retries, setState] = useState<number>(() => {
    try {
      const n = Number(localStorage.getItem(RETRIES_KEY));
      return n >= 0 && n <= 2 ? n : 0;
    } catch {
      return 0;
    }
  });
  const set = useCallback((n: number) => {
    setState(n);
    try { localStorage.setItem(RETRIES_KEY, String(n)); } catch { /* per-browser convenience only */ }
  }, []);
  return [retries, set];
}

const HEAL_KEY = "playbackHeal";

/** Self-healing on (a step whose locators broke is found by its recorded fingerprint) or off,
 * remembered in this browser. */
export function usePlaybackHeal(): [boolean, (on: boolean) => void] {
  const [heal, setState] = useState<boolean>(() => {
    try {
      return localStorage.getItem(HEAL_KEY) !== "off";
    } catch {
      return true;
    }
  });
  const set = useCallback((on: boolean) => {
    setState(on);
    try { localStorage.setItem(HEAL_KEY, on ? "on" : "off"); } catch { /* per-browser convenience only */ }
  }, []);
  return [heal, set];
}

/**
 * Scenario runs, shared by the scenario list (starts them) and the Run tab (follows them).
 * The run itself lives on the server (see useActiveRun); this adds starting - from the top
 * or from a given step - stopping, and the steps of the scenario being run.
 */
export function useScenarioRuns(speed: PlaybackSpeed, retries = 0, heal = true) {
  const { run, setRun } = useActiveRun("scenario");
  const [stopping, setStopping] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [detail, setDetail] = useState<ScenarioDetail | null>(null);
  const [detailVersion, setDetailVersion] = useState(0);

  const scenarioId = run?.scenario_id ?? null;
  useEffect(() => {
    if (scenarioId == null) return;
    let alive = true;
    getScenario(scenarioId).then((d) => { if (alive) setDetail(d); }).catch(() => {});
    return () => { alive = false; };
  }, [scenarioId, detailVersion]);

  useEffect(() => {
    if (run && run.status !== "running") setStopping(false);
  }, [run]);

  const start = useCallback(async (id: number, overrides?: Record<number, string>, startIndex = 0) => {
    setError(null);
    setStopping(false);
    try {
      const started = await startScenarioRun(id, overrides, speed, startIndex, retries, heal);
      setRun({
        run_id: started.run_id, kind: "scenario", scenario_id: id, start_index: startIndex,
        status: "running", total_steps: started.total_steps, log: [],
      });
      return true;
    } catch (e) {
      setError(extractErrorMessage(e));
      return false;
    }
  }, [speed, retries, heal, setRun]);

  /** Self-healing, accepted: a step of the scenario being run was found by a backup locator. */
  const promote = useCallback(async (index: number, strategy: HealedLocator) => {
    if (scenarioId == null) return;
    await preferLocator(scenarioId, index, strategy);
    setDetailVersion((v) => v + 1);
  }, [scenarioId]);

  const stop = useCallback(async () => {
    if (!run) return;
    setStopping(true);
    try {
      // The server finalizes the run on the spot and answers with its final state.
      setRun(await stopRun(run.run_id));
    } catch (e) {
      setError(extractErrorMessage(e));
      setStopping(false); // let them try again
    }
  }, [run, setRun]);

  return {
    run, stopping, error, start, stop, promote,
    runSteps: detail && detail.id === scenarioId ? detail.steps : undefined,
    runName: detail && detail.id === scenarioId ? detail.name : undefined,
    /** A saved scenario changed (edited) - re-read the steps the Run tab shows. */
    refreshSteps: useCallback(() => setDetailVersion((v) => v + 1), []),
  };
}
