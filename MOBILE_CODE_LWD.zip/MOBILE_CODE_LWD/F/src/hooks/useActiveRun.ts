import { useCallback, useEffect, useRef, useState } from "react";
import { getActiveRun } from "../api/client";
import { RunStatusResponse } from "../types";

const RUNNING_POLL_MS = 500;
const IDLE_POLL_MS = 3000;

/**
 * The run's state lives on the server; this only mirrors it.
 *
 * Earlier versions started a long-lived promise loop from the Run button's click
 * handler and guarded it with a "component unmounted" flag. That flag was reset
 * nowhere, so React StrictMode's dev-time unmount/remount left it set and the
 * loop silently quit - the UI froze on "Running..." while the server had long
 * since stopped. Here there is no per-click loop and no shared flag: each effect
 * run owns its own closure, so a remount just starts a fresh, correct poll, and
 * a page refresh reattaches to whatever is running.
 *
 * setRun applies a known state immediately (a Stop response, a just-started run)
 * and discards any older in-flight poll so it can't overwrite it.
 */
export function useActiveRun(kind: "scenario" | "assist") {
  const [run, setRunState] = useState<RunStatusResponse | null>(null);
  const version = useRef(0);
  const pollNow = useRef<() => void>(() => {});

  useEffect(() => {
    let disposed = false;
    let inFlight = false;
    let again = false;
    let timer: number | undefined;

    const poll = async () => {
      if (disposed) return;
      if (inFlight) {
        again = true;
        return;
      }
      inFlight = true;
      window.clearTimeout(timer);
      const seen = version.current;
      let delay = IDLE_POLL_MS;
      try {
        const latest = await getActiveRun(kind);
        if (disposed) return;
        if (seen === version.current) {
          setRunState(latest);
          if (latest && latest.status === "running") delay = RUNNING_POLL_MS;
        } else {
          delay = 0; // a local update landed mid-request - read again straight away
        }
      } catch {
        // backend hiccup: keep showing the last known state and try again
      }
      inFlight = false;
      if (disposed) return;
      timer = window.setTimeout(poll, again ? 0 : delay);
      again = false;
    };

    pollNow.current = () => { poll(); };
    poll();
    return () => {
      disposed = true;
      window.clearTimeout(timer);
    };
  }, [kind]);

  const setRun = useCallback((next: RunStatusResponse | null) => {
    version.current += 1;
    setRunState(next);
    pollNow.current();
  }, []);

  return { run, setRun };
}
