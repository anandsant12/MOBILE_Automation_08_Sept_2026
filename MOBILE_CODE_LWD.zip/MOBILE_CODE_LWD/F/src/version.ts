// Compared with the backend's API_VERSION (shown in the footer) so a stale bundle or a
// half-updated install is obvious. Keep in step with backend/app/version.py.
export const UI_VERSION = "2026.10.07-r48";
