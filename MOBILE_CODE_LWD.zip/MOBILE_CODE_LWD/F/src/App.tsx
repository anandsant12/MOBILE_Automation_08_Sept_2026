import React, { useEffect, useState } from "react";
import "./App.css";
import { Config, DeviceInfo, SessionStatus } from "./types";
import { getConfig, connectSession, disconnectSession, extractErrorMessage } from "./api/client";
import ConnectionBar from "./components/ConnectionBar";
import RecorderPlayback from "./components/RecorderPlayback";
import AIAssistPanel from "./components/AIAssistPanel";
import { UI_VERSION } from "./version";

type Tab = "recorder" | "ai";

export default function App() {
  const [config, setConfig] = useState<Config | null>(null);
  const [configError, setConfigError] = useState<string | null>(null);
  const [status, setStatus] = useState<SessionStatus>({ connected: false });
  const [connectBusy, setConnectBusy] = useState(false);
  const [connectError, setConnectError] = useState<string | null>(null);
  const [tab, setTab] = useState<Tab>("recorder");
  // Each tab has its own recorder; switching mid-recording would drop the steps and leave
  // the phone-touch capture running on the backend with nothing reading it.
  const [recording, setRecording] = useState(false);
  const tabLockTitle = recording ? "Stop recording before switching tabs" : undefined;

  useEffect(() => {
    getConfig().then(setConfig).catch((e) => setConfigError(extractErrorMessage(e)));
  }, []);

  const handleConnect = async (pkg: string, activity: string, device?: DeviceInfo) => {
    setConnectBusy(true);
    setConnectError(null);
    try {
      const result = await connectSession(pkg, activity, device?.serial, device?.android_version || undefined);
      setStatus({
        connected: true, udid: result.udid ?? device?.serial, package: result.package, activity: result.activity,
        screen: result.screen, mirror: result.mirror,
      });
    } catch (e) {
      setConnectError(extractErrorMessage(e));
    } finally {
      setConnectBusy(false);
    }
  };

  const handleDisconnect = async () => {
    setConnectBusy(true);
    try {
      await disconnectSession();
    } finally {
      setStatus({ connected: false });
      setConnectBusy(false);
    }
  };

  // The connected phone was unplugged: close the (now dead) session; plugging it back in
  // reconnects it (with auto-connect on).
  const handleDeviceLost = () => {
    disconnectSession().catch(() => {});
    setStatus({ connected: false });
    setConnectError("The phone was disconnected. Plug it back in to reconnect.");
  };

  if (configError) {
    return (
      <div className="app-shell">
        <div className="config-error">
          <h1>Can&apos;t reach the backend</h1>
          <p>{configError}</p>
          <p className="muted">Make sure the FastAPI server is running (see the project README).</p>
        </div>
      </div>
    );
  }

  if (!config) {
    return (
      <div className="app-shell">
        <div className="spinner" />
      </div>
    );
  }

  return (
    <div className="app-shell">
      <header className="app-header">
        <h1>Mobile Automation Studio</h1>
        {config.enable_llm_assisted && (
          <nav className="tabs">
            <button
              className={`tabs__item${tab === "recorder" ? " tabs__item--active" : ""}`}
              onClick={() => setTab("recorder")}
              disabled={recording && tab !== "recorder"}
              title={tabLockTitle}
            >
              Recorder &amp; Playback
            </button>
            <button
              className={`tabs__item${tab === "ai" ? " tabs__item--active" : ""}`}
              onClick={() => setTab("ai")}
              disabled={recording && tab !== "ai"}
              title={tabLockTitle}
            >
              AI Assisted
            </button>
          </nav>
        )}
      </header>

      <ConnectionBar
        defaultPackage={config.android_app_package}
        defaultActivity={config.android_app_activity}
        status={status}
        busy={connectBusy}
        error={connectError}
        onConnect={handleConnect}
        onDisconnect={handleDisconnect}
        onDeviceLost={handleDeviceLost}
      />

      <main className="app-main">
        {tab === "recorder" && (
          <RecorderPlayback
            mode="basic"
            title=""
            description="Record a sequence of taps, typed text, and swipes, name it, and replay it anytime - no AI involved."
            connected={status.connected}
            mirror={status.mirror}
            currentPackage={status.package || config.android_app_package}
            currentActivity={status.activity || config.android_app_activity}
            onRecordingChange={setRecording}
          />
        )}

        {tab === "ai" && config.enable_llm_assisted && (
          <>
            <RecorderPlayback
              mode="ai"
              title="Record for the AI"
              description="Record the same way as the basic module - each step also gets an AI-written description and is embedded for later retrieval."
              connected={status.connected}
              mirror={status.mirror}
              currentPackage={status.package || config.android_app_package}
              currentActivity={status.activity || config.android_app_activity}
              onRecordingChange={setRecording}
            />
            <AIAssistPanel connected={status.connected} />
          </>
        )}
      </main>

      <footer className="app-footer">
        UI {UI_VERSION} &middot; API {config.api_version ?? "unknown (old backend)"}
        {config.api_version !== UI_VERSION && (
          <strong className="app-footer__warn">
            {" "}Versions differ - restart the backend, re-copy any files you skipped, and hard-refresh this page (Ctrl+F5).
          </strong>
        )}
      </footer>
    </div>
  );
}
