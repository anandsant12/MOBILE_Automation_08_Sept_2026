export type Mode = "basic" | "ai";
export type ActionKind =
  | "tap" | "long_press" | "type" | "select" | "keypad" | "swipe" | "key" | "assert" | "wait"
  | "pick_date"   // tap the date field, move the calendar to the date's month, tap the day, OK (text: the date)
  | "capture"     // read an element's value and remember it (var) for the rest of the run, as ${var}
  | "run_case";   // run another saved scenario's steps here - a reusable flow (text: its id)

/** How a captured value / a text check's value is reduced before it's kept or compared. */
export type Normalize = "raw" | "trim" | "digits" | "number";
export const NORMALIZE_LABELS: Record<Normalize, string> = {
  raw: "exactly as shown",
  trim: "trim spaces",
  digits: "digits only",
  number: "number (ignore ₹ and commas)",
};
export type CheckKind =
  // about one element, picked on the mirror
  | "visible" | "not_visible" | "text_equals" | "text_contains" | "text_matches"
  | "enabled" | "disabled" | "checked" | "unchecked" | "selected"
  // about the whole screen - nothing to pick
  | "screen_has_text" | "screen_lacks_text" | "toast" | "on_screen"
  | "dialog_shown" | "no_dialog" | "keyboard_shown" | "keyboard_hidden";

export const CHECK_LABELS: Record<CheckKind, string> = {
  visible: "is visible",
  not_visible: "is not visible",
  text_equals: "text is",
  text_contains: "text contains",
  text_matches: "text matches (regex)",
  enabled: "is enabled",
  disabled: "is disabled",
  checked: "is checked",
  unchecked: "is not checked",
  selected: "is selected",
  screen_has_text: "screen shows text",
  screen_lacks_text: "screen doesn't show text",
  toast: "toast message appears",
  on_screen: "app / screen is",
  dialog_shown: "a popup is open",
  no_dialog: "no popup is open",
  keyboard_shown: "keyboard is shown",
  keyboard_hidden: "keyboard is hidden",
};
export const ELEMENT_CHECKS: CheckKind[] = [
  "visible", "not_visible", "text_equals", "text_contains", "text_matches", "enabled", "disabled", "checked",
  "unchecked", "selected",
];
export const SCREEN_CHECKS: CheckKind[] = [
  "screen_has_text", "screen_lacks_text", "toast", "on_screen", "dialog_shown", "no_dialog",
  "keyboard_shown", "keyboard_hidden",
];
/** Checks with a text value: required, except for a toast (any toast, if left empty). */
export const TEXT_CHECKS: CheckKind[] = [
  "text_equals", "text_contains", "text_matches", "screen_has_text", "screen_lacks_text", "on_screen", "toast",
];
export const OPTIONAL_TEXT_CHECKS: CheckKind[] = ["toast"];

/** Plain-language description of a check step, e.g. `screen shows text "Welcome"`. */
export function describeCheck(check: CheckKind, text?: string | null): string {
  return CHECK_LABELS[check] + (TEXT_CHECKS.includes(check) && text ? ` "${text}"` : "");
}

/** What POST /api/session/inspect says about the element picked for a check. */
export interface InspectedElement {
  description: string;
  locator: Locator;
  x_pct: number;
  y_pct: number;
  text: string;
  enabled: boolean | null;
  checked: boolean | null;
  checkable: boolean | null;
  suggested_check: CheckKind;
  suggested_expected?: string;  // a changing value (a balance) is suggested as a pattern
  // Inspector details
  attributes?: Record<string, string>;
  path?: string[];           // its ancestors, outermost first
  strategies?: LocatorStrategy[];
  dynamic?: boolean;         // shows data (an amount, a number...) - never used to find it
}

/** One way replay can find an element; the first in a list is the main way. */
export interface LocatorStrategy {
  strategy: string;
  value: string;
  index: number;
}

export interface PopupRule {
  when_text: string;
  tap_text: string;
  enabled: boolean;
}

export interface PopupHandlers {
  auto_allow_permissions: boolean;
  rules: PopupRule[];
}
export type StepStatus = "ok" | "error" | "stopped";
export type RunStatus = "running" | "passed" | "failed" | "stopped";

export interface Config {
  llm_provider: string;
  enable_llm_assisted: boolean;
  android_app_package: string;
  android_app_activity: string;
  android_device_name: string;
  appium_server_url: string;
  api_version?: string;
}

export interface Screen {
  width: number;
  height: number;
}

/** A phone plugged in over USB, as `adb devices` reports it (GET /api/session/devices). */
export interface DeviceInfo {
  serial: string;            // the UDID
  state: string;             // "device" (ready) | "unauthorized" | "offline" ...
  manufacturer: string;
  model: string;
  android_version: string;
  sdk: string;
  label: string;             // e.g. "Samsung SM-A546E · Android 14"
}

export interface SessionStatus {
  connected: boolean;
  udid?: string | null;      // the phone this session drives
  package?: string;
  activity?: string;
  screen?: Screen;
  mirror?: "mjpeg" | "poll";
}

export interface Locator {
  resource_id?: string;
  resource_id_index?: number;
  content_desc?: string;
  content_desc_index?: number;
  text?: string;
  text_index?: number;
  xpath?: string;
  label_xpath?: string;   // a bare control with a shared id, found by the label before it
  state_xpath?: string;   // where a row's checked state is read (its switch, not its label)
  in_list?: boolean;      // recorded inside a scrolling list (a dropdown's options)
  list_index?: number;
  anchor?: boolean;       // text/content_desc is a nearby label, not the target itself...
  tap_offset?: { dx: number; dy: number };  // ...which is tapped at this offset (fractions of the screen)
  candidates?: [string, string][];  // recorded on the phone: (strategy, value) pairs, tried in order
  package?: string;       // "app / screen is" checks: the app expected in front
  prefer?: [string, string, number?];  // promoted after a run found it by a backup (self-healing)
  web?: WebLocator;       // an element of the app's web page
  // From the phone recorder:
  fingerprint?: Record<string, unknown>;  // the element's attributes and surroundings - for self-healing
  tap_at?: [number, number];  // a tap on a big container's empty part: where within it (fractions of its size)
  unique?: boolean;       // false: nothing about it was unique on screen when recorded
  id_shared?: boolean;
  label?: string;         // the text inside it (a tile's caption)
  near?: string;          // an unnamed icon: the label beside it
  beside?: string;        // a changing value (a balance): the fixed label next to it
  changing?: boolean;     // it shows a value that changes between runs - never found by that
  field_label?: string;   // a text field with no id or hint: the label before it
  class_name?: string;
  key_class?: string;     // keypad steps: the class of its keys
  warning?: string;       // why the recorder wasn't sure about this step
  as_tap?: Pick<Step, "action" | "description" | "locator" | "x_pct" | "y_pct">;  // a check that was a tap
}

export interface WebLocator {
  css: string;
  text?: string | null;
  full_text?: string | null;
  package?: string;
  matches?: number;
  in_dialog?: boolean;
  [key: string]: unknown;
}

export interface Step {
  action: ActionKind;
  description: string;
  locator: Locator;
  x_pct?: number;
  y_pct?: number;
  x2_pct?: number;
  y2_pct?: number;
  text?: string;
  is_editable?: boolean;
  checked_target?: boolean | null;
  redacted?: boolean | null;
  ts?: number; // when it happened - used to order phone touches against mirror clicks
  source?: "mirror" | "physical";
  approximate?: boolean; // matched against a screen snapshot that was already out of date
  field_key?: string;    // phone-typed steps: which field (a later real value replaces its placeholder)
  check?: CheckKind | null;  // "assert" steps: what to verify (text holds the expected value)
  var?: string;          // "capture" steps: the name to remember the read value under (used later as ${name})
  normalize?: Normalize;  // "capture" / text-check steps: how to reduce the value before keeping / comparing
  draft?: boolean;       // a phone step shown live while recording; finalised when recording stops
  optional?: boolean | null;             // skip it if its element doesn't appear (a popup that only sometimes shows)
  continue_on_failure?: boolean | null;  // report a failure but keep running
  disabled?: boolean | null;             // kept, but skipped by replay
  screen?: string;        // the screen it acted on, saved while recording (for adding checks later)
  screen_after?: string;  // ...and the screen it led to
}

/** A suggestion for one step (POST /api/steps/suggestions). */
export interface StepSuggestion {
  index: number;
  kind: "data" | "date";
  value: string;
  name?: string;    // data: the suggested test data name
  field?: string;   // date: "text" or "locator"
  token?: string;   // date: e.g. ${today+7d}
}

/** One element of a screen saved while recording. */
export interface SavedScreenElement {
  index: number;
  label: string;
  check: CheckKind;
  expected: string | null;
}

export interface RecordedStep extends Step {
  screenshot?: string;
}

export interface ScenarioSummary {
  id: number;
  name: string;
  mode: Mode;
  android_app_package: string;
  android_app_activity: string;
  step_count: number;
  created_at: string;
  recent_runs?: RunStatus[];   // the latest runs' results, newest first
}

export interface ScenarioDetail extends ScenarioSummary {
  steps: Step[];
  variables?: Record<string, string>;  // test data: ${name} in typed text, options and expected values
  start?: StartSettings;
}

/** How a run of the scenario starts. */
export interface StartSettings {
  app?: "as_is" | "restart" | "clear";      // as it is / closed and reopened / data cleared, then opened
  setup_scenario_id?: number | null;        // a scenario run first, e.g. Login
}

/** Why a run failed (backend app/services/run_diagnosis.py). */
export interface RunFailure {
  kind: string;     // app_crashed | app_not_responding | app_closed | check_failed | element_not_found | test_data | environment | error
  group: "app" | "test" | "environment";
  summary: string;
  detail?: string;
  step?: number | null;        // order_index of the failed step
  description?: string | null;
}

/** A finished run in a scenario's history. */
export interface RunSummary {
  run_id: string;
  status: RunStatus;
  created_at: number;
  finished_at?: number | null;
  duration: number;
  steps_done: number;
  total_steps: number | null;
  start_index?: number;
  failure?: RunFailure | null;
}

/** What a run found by self-healing or a backup locator - offered to be saved into the step. */
export interface HealedLocator extends LocatorStrategy {
  locator?: { candidates: [string, string][]; resource_id?: string | null; content_desc?: string | null; text?: string | null };
  web?: WebLocator;
  score?: number;
  matched?: string[];
  element?: string;
}

export interface RunLogEntry {
  order_index?: number;
  step?: number;
  action: string;
  description?: string;
  target?: string;
  reasoning?: string;
  status: StepStatus;
  error?: string;
  screenshot?: string;
  skipped?: boolean;
  note?: string;
  duration?: number;   // seconds the step took
  found_by?: string;   // how replay found its element, e.g. "text = Log In"
  healed?: HealedLocator;  // found by a backup / its fingerprint, not its main locator - offer to save it
  called?: string;     // one of the steps of another scenario this step runs
  setup?: boolean;     // before the steps: the app restarted / cleared, or the scenario run first
  failure_kind?: string;   // the failed step that the run's failure diagnosis is about
}

export interface RunStatusResponse {
  run_id: string;
  kind: "scenario" | "assist";
  status: RunStatus;
  total_steps: number | null;
  log: RunLogEntry[];
  scenario_id?: number | null;
  start_index?: number;   // "run from this step": the steps before it weren't run
  created_at?: number;
  finished_at?: number | null;
  failure?: RunFailure | null;   // why it failed
  scenario_name?: string;        // runs read back from history
}

export interface StartRunResponse {
  run_id: string;
  total_steps: number | null;
}
