"""How often the recorder's touch lookup finds the element the app says was clicked.

Every tap the app reported a click for is a free test: the click event names
the element that really handled the tap, and each phone recording's diagnostics
file (recordings/phone_<time>_debug.json) keeps what the helper's lookup found
at touch time. This compares the two across all recordings and sorts each
mismatch into a problem class, so accuracy can be measured instead of found one
recording at a time.

    python tools/lookup_accuracy.py [recordings_dir] [-v]

Adapted from android-record-playback's tools/lookup_accuracy.py.
"""

import json
import sys
from collections import Counter
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from app.arp import helper_recorder as hr  # noqa: E402
from app.arp.locator import parse_bounds  # noqa: E402

DEFAULT_DIR = Path(__file__).resolve().parent.parent / "recordings"


def _box(bounds):
    try:
        x1, y1, x2, y2 = parse_bounds(bounds)
    except (ValueError, AttributeError):
        return None
    return (x1, y1, x2, y2) if x2 > x1 and y2 > y1 else None


def _inside(inner, outer):
    return inner and outer and outer[0] <= inner[0] and outer[1] <= inner[1] and inner[2] <= outer[2] \
        and inner[3] <= outer[3]


def _overlaps(a, b):
    return a and b and a[0] < b[2] and b[0] < a[2] and a[1] < b[3] and b[1] < a[3]


def _area(b):
    return (b[2] - b[0]) * (b[3] - b[1]) if b else 0


def _screen_area(d):
    """The phone's screen area, judged from the largest window seen in the recording."""
    biggest = 0
    for e in d.get("events", []):
        for w in e.get("windows") or []:
            biggest = max(biggest, _area(_box(w.get("bounds"))))
    return biggest or 1080 * 2400


def classify(touch, click, screen_area):
    """"ok", or the problem class of a lookup that disagrees with the app's click."""
    truth = _box(click["node"].get("bounds"))
    found = [n for n in (touch.get("target"), touch.get("node")) if n]
    boxes = [_box(n.get("bounds")) for n in found]
    ids = {n.get("resource_id") for n in found if n.get("resource_id")}
    if click["node"].get("resource_id") in ids and click["node"].get("resource_id"):
        return "ok"
    if any(b and truth and (b == truth or _inside(b, truth)) for b in boxes):
        return "ok"  # the clicked element, or a label inside it
    x, y = touch["px"]
    if truth is None or not (truth[0] <= x <= truth[2] and truth[1] <= y <= truth[3]):
        return "click element moved/hidden as it was clicked (screen changing)"
    node_box = _box((touch.get("node") or {}).get("bounds"))
    if node_box and _area(node_box) > 0.5 * screen_area:
        return "lookup saw the next screen (full-screen container)"
    if any(_inside(truth, b) for b in boxes if b):
        return "lookup found a container around the clicked element"
    if node_box and not _overlaps(node_box, truth):
        return "lookup found something else under the finger (drawn behind / next screen)"
    return "lookup found an overlapping element (drawn behind the clicked one)"


def main(directory=DEFAULT_DIR, verbose=False):
    totals, per_case, examples = Counter(), {}, {}
    unverifiable = 0
    for path in sorted(Path(directory).glob("*_debug.json")):
        d = json.loads(path.read_text(encoding="utf-8"))
        screen_area = _screen_area(d)
        clicks = [e for e in d.get("events", []) if e["event"] in ("click", "long_click") and e.get("node")]
        counts = Counter()
        for t in d.get("touches", []):
            if t.get("error") or t.get("keyboard") or not t.get("node"):
                continue
            # Only clicks whose element contains the touch point count as ground truth here.
            click = next((c for c in clicks if hr._when(t) - 0.05 <= c["mono"] <= hr._when(t) + 1.5
                          and hr.locator_mod.is_identifiable(c["node"])), None)
            if click is None:
                unverifiable += 1
                continue
            verdict = classify(t, click, screen_area)
            counts[verdict] += 1
            if verdict != "ok":
                examples.setdefault(verdict, []).append(
                    f"{path.name.replace('_debug.json', '')} {t['px']}: clicked "
                    f"{click['node'].get('resource_id') or click['node'].get('text')!r}, lookup "
                    f"{(t.get('node') or {}).get('resource_id') or (t.get('node') or {}).get('class_name')!r}")
        if counts:
            per_case[path.name.replace("_debug.json", "")] = counts
            totals.update(counts)
    checked = sum(totals.values())
    ok = totals["ok"]
    print(f"Taps with a click report from the app (verifiable): {checked}; without one: {unverifiable}")
    if checked:
        print(f"Lookup agreed with the app's click: {ok}/{checked} ({100 * ok / checked:.0f}%)\n")
    for verdict, n in totals.most_common():
        if verdict != "ok":
            print(f"  {n:3d}  {verdict}")
            if verbose:
                for line in examples[verdict][:5]:
                    print(f"         {line}")
    print("\nPer recording (mismatches / verifiable taps):")
    for name, counts in per_case.items():
        bad = sum(v for k, v in counts.items() if k != "ok")
        print(f"  {name:24s} {bad}/{sum(counts.values())}")


if __name__ == "__main__":
    args = [a for a in sys.argv[1:] if not a.startswith("-")]
    main(args[0] if args else DEFAULT_DIR, verbose="-v" in sys.argv)
