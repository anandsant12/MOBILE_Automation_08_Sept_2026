"""Grade the locators the recorder would record on the app's web page now on screen.

Read-only: it never taps, types or navigates - it only scrolls the page (and
scrolls it back). For every visible control and text on the current screen it
asks the recorder's page logic (web_cdp) what it would record, checks that the
locator finds exactly that element again, and grades it like locator_audit.
Open the screen you want checked in the app first; run it again per screen.

    python tools/explore_web_app.py <app.package> [serial] [report.json] [--adb PATH]

Works with any app whose WebView allows debugging. Adapted from
android-record-playback's tools/explore_web_app.py, without its app-specific
navigation.
"""

import json
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from app.arp import web_cdp  # noqa: E402
from tools.locator_audit import grade_web  # noqa: E402

# In-page: every visible control/text on the screen, what the recorder would record for it,
# and whether that locator finds exactly that element again.
_SCAN = r"""
(() => {
  const out = [];
  for (const d of __arp.listed()) {
    const [l, t, w, h] = d.rect;
    const near = [l + w / 2, t + h / 2];
    const f = __arp.find({css: d.css, text: d.text, context: d.context, within: d.within, exact: d.exact}, near);
    const same = !!f.rect && Math.abs(f.rect[0] - l) < 2 && Math.abs(f.rect[1] - t) < 2;
    out.push({css: d.css, text: d.text, exact: d.exact, within: d.within, tag: d.tag, tappable: d.tappable,
              in_dialog: d.in_dialog, matches: f.count, visible: f.visible, same});
  }
  return out;
})()
"""


def scan(web, pages=6):
    """Rows for every element seen while scrolling the page from top to bottom."""
    seen, rows = set(), []
    start = web.call("scrollY") or 0
    web.call("scrollTo({top: 0, behavior: 'instant'})")
    for _ in range(pages):
        time.sleep(0.6)
        for r in web.call(_SCAN) or []:
            key = (r["css"], r["text"], json.dumps(r["within"]))
            if key in seen:
                continue
            seen.add(key)
            # What replay sees: it only uses visible matches (a hidden twin doesn't count).
            r["grade"], r["kind"], r["issues"] = grade_web(dict(r, matches=r["visible"]))
            rows.append(r)
        before = web.call("scrollY")
        web.call("scrollBy({top: innerHeight * 0.8, behavior: 'instant'})")
        time.sleep(0.4)
        if web.call("scrollY") == before:
            break
    web.call(f"scrollTo({{top: {int(start)}, behavior: 'instant'}})")
    return rows


def main(package, serial=None, out=None, adb_bin="adb"):
    web = web_cdp.WebViewClient(package, serial, adb_bin)
    try:
        page = web.call("location.href") or "(unknown page)"
        rows = scan(web)
    except web_cdp.WebViewUnavailable as e:
        raise SystemExit(f"Can't inspect {package}'s web page: {e}")
    finally:
        web.close()
    found_self = sum(r["same"] for r in rows)
    grades = {g: sum(r["grade"] == g for r in rows) for g in ("strong", "ok", "weak")}
    print(f"{page}: {len(rows)} elements, {found_self} found again exactly, grades {grades}")
    for r in rows:
        if not r["same"] or r["grade"] == "weak":
            what = f"{r['css']} {r['text']!r}" if r["text"] else r["css"]
            print(f"  [{r['grade']}{'' if r['same'] else ', finds another element'}] {what[:90]}"
                  + (f" -- {', '.join(r['issues'])}" if r["issues"] else ""))
    if out:
        Path(out).write_text(json.dumps({"page": page, "grades": grades, "elements": rows}, indent=1,
                                        ensure_ascii=False), encoding="utf-8")
        print(f"Report written to {out}")
    return rows


if __name__ == "__main__":
    argv = sys.argv[1:]
    adb = "adb"
    if "--adb" in argv:
        i = argv.index("--adb")
        adb = argv[i + 1]
        del argv[i:i + 2]
    if not argv:
        raise SystemExit(__doc__)
    main(argv[0], argv[1] if len(argv) > 1 else None, argv[2] if len(argv) > 2 else None, adb)
