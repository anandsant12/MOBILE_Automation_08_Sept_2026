"""Grade how every saved step will find its element at replay (read-only).

For each step that acts on or checks an element, the way replay tries first is
classified (steps recorded on an app's web page: the page's own locator; others:
the first native strategy, see mobile_control.locator_strategies) and graded:

  strong  -- a stable identity: a unique id, a test attribute, a developer hook
             class, an accessibility id, or text
  ok      -- works but can break with UI changes: a plain class, a tag + text,
             an id-plus-label combination
  weak    -- likely to break: position paths, shared ids, text containing
             changing numbers, icon-font glyphs, state classes
  none    -- no element recorded (replayed by screen position)

    python tools/locator_audit.py [path/to/scenarios.db] [-v]

Adapted from android-record-playback's tools/locator_audit.py to this app's database.
"""

import json
import re
import sqlite3
import sys
from collections import Counter, defaultdict
from pathlib import Path

GLYPHS = re.compile("[-​-‍﻿]")
HOOK = re.compile(r"(_h|-js|_js)$|^(js|qa|test|e2e|t)[-_]", re.I)
STATE = re.compile(r"(^|[-_])(non[-_]?|in|is[-_]|un)?(active|selected|current|open|opened|closed|expanded|collapsed|"
                   r"checked|hover|focus|disabled|visible|hidden|shown|show)([-_]|$)", re.I)
NUMBER = re.compile(r"\d")
ELEMENT_STEPS = {"tap", "long_press", "type", "select", "assert", "keypad"}
SCREEN_CHECKS = {"screen_has_text", "screen_lacks_text", "toast", "on_screen", "dialog_shown", "no_dialog",
                 "keyboard_shown", "keyboard_hidden"}
DEFAULT_DB = Path(__file__).resolve().parent.parent / "scenarios.db"


def _numbers_in(text):
    """Text with digits in it (counts, amounts, dates) - they change from run to run."""
    return bool(text) and bool(NUMBER.search(text)) and bool(re.search(r"[A-Za-z]", text))


def grade_web(web):
    css, text = web.get("css") or "", web.get("text") or ""
    within = web.get("within") or {}
    issues = []
    if ":nth-of-type" in css:
        return "weak", "web: position path (nth-of-type)", ["position path"]
    # Numbers kept on purpose ("exact": they tell elements apart) are identity, not a risk.
    if (_numbers_in(text) and not web.get("exact")) or (_numbers_in(within.get("text")) and not within.get("exact")):
        issues.append("text with numbers")
    classes = re.findall(r"\.([\w-]+)", css)
    if any(STATE.search(c) and not HOOK.search(c) for c in classes):
        issues.append("state class")
    if (web.get("matches") or 1) > 1:
        issues.append(f"matches {web['matches']}")
    if css.startswith("[data-"):
        kind, grade = "web: test attribute", "strong"
    elif css.startswith("#"):
        kind, grade = "web: #id", "strong"
    elif any(HOOK.search(c) for c in classes):
        kind, grade = "web: hook class", "strong"
    elif text or within:
        kind, grade = "web: class/tag + text", "ok"
    elif classes:
        kind, grade = "web: plain class", "ok"
    else:
        kind, grade = "web: tag only", "weak"
    if issues:
        grade = "weak"
    return grade, kind, issues


def first_strategy(loc):
    """(strategy, value) replay tries first - the order of mobile_control.locator_strategies."""
    if loc.get("prefer"):
        return loc["prefer"][0], str(loc["prefer"][1])
    for strategy, value in loc.get("candidates") or []:
        return strategy, str(value)
    for key, strategy in (("label_xpath", "xpath"), ("resource_id", "id"), ("content_desc", "accessibility id"),
                          ("text", "text"), ("xpath", "xpath")):
        if loc.get(key):
            return strategy, str(loc[key])
    return None, None


def grade_native(loc):
    strategy, value = first_strategy(loc)
    if strategy is None:
        return "none", "no element (screen position)", []
    # normalize-space(@text)="X" (text with irregular spacing) grades like @text="X".
    value = re.sub(r"normalize-space[(](@[\w-]+)[)]", r"\1", str(value))
    issues = []
    if GLYPHS.search(value) or '@text=""' in value:
        issues.append("icon glyph as text")
    if loc.get("id_shared") or loc.get("resource_id_index"):
        issues.append("shared id")
    if loc.get("unique") is False:
        issues.append("nothing unique when recorded")
    if strategy == "id":
        kind, grade = "native: resource-id", "strong"
    elif strategy in ("accessibility id", "content-desc"):
        kind, grade = "native: accessibility id", "strong"
    elif strategy == "text":
        kind, grade = "native: text", "ok"
        if _numbers_in(value):
            issues.append("text with numbers")
    elif value.startswith("//android.widget.FrameLayout/") or re.search(r"\[\d+\]/", value):
        kind, grade = "native: position path", "weak"
    elif "@resource-id=" in value and ("@text=" in value or "ancestor" in value
                                       or "//*[@resource-id" in value.split("]", 1)[-1]):
        kind, grade = "native: id + label/scope", "ok"
    elif "@resource-id=" in value:
        kind, grade = "native: resource-id (xpath)", "strong"
    elif "@content-desc=" in value and "@text=" not in value:
        kind, grade = "native: description", "strong"
    elif "@text=" in value:
        kind, grade = "native: text", "ok"
        if _numbers_in(loc.get("text") or ""):
            issues.append("text with numbers")
    else:
        kind, grade = "native: other xpath", "weak"
    if issues:
        grade = "weak"
    return grade, kind, issues


def grade(step):
    loc = step["locator"]
    if loc.get("web"):
        # Found by the page first; Android's view is only a fallback.
        return grade_web(loc["web"])
    return grade_native(loc)


def load_steps(db_path):
    con = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True)
    try:
        cols = {row[1] for row in con.execute("PRAGMA table_info(steps)")}
        disabled = "st.disabled" if "disabled" in cols else "NULL"
        rows = con.execute(f"select s.name, s.created_at, st.order_index, st.action, st.description, "
                           f"st.locator_json, st.check_kind, {disabled} from steps st "
                           "join scenarios s on s.id = st.scenario_id order by s.id, st.order_index").fetchall()
    finally:
        con.close()
    for name, created, index, action, description, locator_json, check, is_disabled in rows:
        yield {"scenario": name, "created_at": str(created or ""), "index": index + 1, "action": action,
               "label": description or action, "locator": json.loads(locator_json or "{}"), "check": check,
               "disabled": bool(is_disabled)}


def main(db_path=DEFAULT_DB, verbose=False):
    grades, kinds, issues_count = Counter(), Counter(), Counter()
    per_case = {}
    weak_examples = defaultdict(list)
    for step in load_steps(db_path):
        if step["action"] not in ELEMENT_STEPS or step["disabled"] or step["check"] in SCREEN_CHECKS:
            continue
        g, kind, issues = grade(step)
        grades[g] += 1
        kinds[kind] += 1
        created, counts = per_case.setdefault(step["scenario"], (step["created_at"][:16], Counter()))
        counts[g] += 1
        for i in issues:
            issues_count[i] += 1
        if g in ("weak", "none"):
            weak_examples[kind].append(f"{step['scenario']} #{step['index']}: {step['label'][:60]}"
                                       + (f" [{', '.join(issues)}]" if issues else ""))
    total = sum(grades.values())
    print(f"Element steps: {total}")
    for g in ("strong", "ok", "weak", "none"):
        if total:
            print(f"  {g:6s} {grades[g]:4d}  ({100 * grades[g] / total:.0f}%)")
    print("\nBy locator kind:")
    for kind, n in kinds.most_common():
        print(f"  {n:4d}  {kind}")
    print("\nProblems found:")
    for issue, n in issues_count.most_common():
        print(f"  {n:4d}  {issue}")
    print("\nPer scenario (created, strong/ok/weak/none):")
    for name, (created, c) in sorted(per_case.items(), key=lambda kv: kv[1][0]):
        print(f"  {name[:30]:30s} {created}  {c['strong']:3d} {c['ok']:3d} {c['weak']:3d} {c['none']:3d}")
    if verbose:
        print("\nWeak / missing locators:")
        for kind, lines in weak_examples.items():
            print(f"  {kind}:")
            for line in lines[:8]:
                print(f"    {line}")
    return grades


if __name__ == "__main__":
    args = [a for a in sys.argv[1:] if not a.startswith("-")]
    main(args[0] if args else DEFAULT_DB, verbose="-v" in sys.argv)
