"""
Command line for the mobile automation tool - for CI jobs and scripts.

It talks to the running backend (uvicorn main:app), which owns the phone's Appium
session, so start that first. Standard library only.

    python cli.py list
    python cli.py run "Login flow" 12 --junit report.xml --var user=demo --retries 1
    python cli.py run --all --junit report.xml
    python cli.py export "Login flow" -o login.json        # portable JSON
    python cli.py import login.json
    python cli.py pytest "Login flow" -o test_login.py      # standalone pytest + Appium test

Exit status of `run`: 0 every scenario passed, 1 any failed, 2 it couldn't run
(backend not reachable, unknown scenario, stopped, timed out).
"""

import argparse
import json
import sys
import urllib.error
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
from pathlib import Path

DEFAULT_SERVER = "http://127.0.0.1:8000"
EXIT_PASSED, EXIT_FAILED, EXIT_ERROR = 0, 1, 2


class CliError(Exception):
    pass


def _request(server, method, path, body=None, timeout=60, raw=False):
    data = json.dumps(body).encode("utf-8") if body is not None else None
    req = urllib.request.Request(server.rstrip("/") + path, data=data, method=method,
                                 headers={"Content-Type": "application/json"} if data else {})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            payload = resp.read()
    except urllib.error.HTTPError as e:
        try:
            detail = json.loads(e.read().decode("utf-8")).get("detail")
        except Exception:
            detail = None
        raise CliError(f"{method} {path} failed ({e.code}): {detail or e.reason}")
    except urllib.error.URLError as e:
        raise CliError(f"The backend isn't reachable at {server} ({e.reason}) - start it first "
                       "(uvicorn main:app --port 8000)")
    return payload.decode("utf-8") if raw else json.loads(payload.decode("utf-8") or "null")


def _scenarios(server):
    return _request(server, "GET", "/api/scenarios")


def _resolve(server, ref):
    """A scenario by id or exact name."""
    scenarios = _scenarios(server)
    for s in scenarios:
        if str(s["id"]) == str(ref) or s["name"] == ref:
            return s
    lowered = [s for s in scenarios if s["name"].lower() == str(ref).lower()]
    if len(lowered) == 1:
        return lowered[0]
    raise CliError(f"No scenario named or numbered {ref!r} (see: python cli.py list)")


def _parse_vars(pairs):
    variables = {}
    for pair in pairs or []:
        if "=" not in pair:
            raise CliError(f"--var expects NAME=VALUE, got {pair!r}")
        key, value = pair.split("=", 1)
        variables[key.strip()] = value
    return variables


def cmd_list(args):
    scenarios = _scenarios(args.server)
    if not scenarios:
        print("No saved scenarios.")
    for s in scenarios:
        print(f"{s['id']:>4}  {s['name']}  ({s['step_count']} steps, {s['android_app_package'] or 'any app'})")
    return EXIT_PASSED


def _print_run(run):
    for e in run.get("log") or []:
        if e.get("order_index") is None:
            print(f"   ERROR: {e.get('error')}")
            continue
        mark = "SKIP" if e.get("skipped") else ("HEAL" if e.get("healed") and e["status"] == "ok"
                                                else "ok  " if e["status"] == "ok" else "FAIL")
        detail = e.get("error") or e.get("note") or ""
        print(f"   [{mark}] {e['order_index'] + 1:>3}. {e.get('description') or e.get('action')}"
              + (f" -- {detail}" if detail else ""))


def cmd_run(args):
    targets = [_resolve(args.server, ref) for ref in args.scenarios]
    if args.all:
        targets = _scenarios(args.server)
    if not targets:
        raise CliError("Name the scenarios to run (or --all).")
    body = {"speed": args.speed, "retries": args.retries, "variables": _parse_vars(args.var), "heal": not args.no_heal}
    runs, outcome = [], EXIT_PASSED
    for s in targets:
        print(f"== {s['name']}")
        query = urllib.parse.urlencode({"wait": "true", "timeout": args.timeout})
        run = _request(args.server, "POST", f"/api/scenarios/{s['id']}/run?{query}", body, timeout=args.timeout + 30)
        _print_run(run)
        status = run.get("status")
        print(f"   {str(status).upper()}")
        runs.append(run)
        if status == "failed":
            outcome = max(outcome, EXIT_FAILED)
        elif status != "passed":
            outcome = EXIT_ERROR   # stopped, or still running when the wait ran out
    passed = sum(r.get("status") == "passed" for r in runs)
    print(f"\n{passed}/{len(runs)} scenarios passed.")
    if args.junit:
        suites = ET.Element("testsuites")
        for run in runs:
            xml = _request(args.server, "GET", f"/api/runs/{run['run_id']}/junit", raw=True)
            suites.append(ET.fromstring(xml.split("?>", 1)[-1]))
        ET.indent(suites)
        Path(args.junit).write_text(ET.tostring(suites, encoding="unicode", xml_declaration=True), encoding="utf-8")
        print(f"JUnit report written to {args.junit}")
    return outcome


def cmd_export(args):
    s = _resolve(args.server, args.scenario)
    data = _request(args.server, "GET", f"/api/scenarios/{s['id']}/export")
    target = Path(args.output or f"{s['name']}.json")
    target.write_text(json.dumps(data, indent=1, ensure_ascii=False), encoding="utf-8")
    print(f"Wrote {target}")
    return EXIT_PASSED


def cmd_import(args):
    data = json.loads(Path(args.file).read_text(encoding="utf-8"))
    saved = _request(args.server, "POST", "/api/scenarios/import", data)
    print(f"Imported as '{saved['name']}' (id {saved['id']}, {len(saved.get('steps') or [])} steps)")
    return EXIT_PASSED


def cmd_pytest(args):
    s = _resolve(args.server, args.scenario)
    code = _request(args.server, "GET", f"/api/scenarios/{s['id']}/pytest", raw=True)
    name = "".join(c if c.isalnum() else "_" for c in s["name"]).strip("_").lower() or "recorded"
    target = Path(args.output or f"test_{name}.py")
    target.write_text(code, encoding="utf-8")
    print(f"Wrote {target}  (run it with: pytest {target})")
    return EXIT_PASSED


def build_parser():
    parser = argparse.ArgumentParser(prog="cli.py", description="Run and export mobile automation scenarios.")
    parser.add_argument("--server", default=DEFAULT_SERVER, help=f"Backend URL (default {DEFAULT_SERVER})")
    sub = parser.add_subparsers(dest="command", required=True)

    sub.add_parser("list", help="List saved scenarios").set_defaults(func=cmd_list)

    p_run = sub.add_parser("run", help="Run scenarios; exit 1 if any fails, 2 if one couldn't run")
    p_run.add_argument("scenarios", nargs="*", help="Scenario names or ids")
    p_run.add_argument("--all", action="store_true", help="Run every saved scenario")
    p_run.add_argument("--var", action="append", metavar="NAME=VALUE", help="Test data for this run (repeatable)")
    p_run.add_argument("--retries", type=int, default=0, choices=range(0, 4), help="Retry a step not found yet (0-3)")
    p_run.add_argument("--speed", default="fast", choices=("fast", "medium", "slow"))
    p_run.add_argument("--timeout", type=int, default=1800, help="Most seconds to wait for each scenario")
    p_run.add_argument("--junit", metavar="FILE", help="Write a JUnit XML report (for CI)")
    p_run.add_argument("--no-heal", action="store_true",
                       help="Fail steps whose locators broke instead of finding their element by its fingerprint")
    p_run.set_defaults(func=cmd_run)

    p_export = sub.add_parser("export", help="Save a scenario as a portable JSON file")
    p_export.add_argument("scenario", help="Scenario name or id")
    p_export.add_argument("--output", "-o")
    p_export.set_defaults(func=cmd_export)

    p_import = sub.add_parser("import", help="Add a scenario from a JSON file made by export")
    p_import.add_argument("file")
    p_import.set_defaults(func=cmd_import)

    p_pytest = sub.add_parser("pytest", help="Save a scenario as a standalone pytest + Appium test")
    p_pytest.add_argument("scenario", help="Scenario name or id")
    p_pytest.add_argument("--output", "-o")
    p_pytest.set_defaults(func=cmd_pytest)
    return parser


def main(argv=None):
    args = build_parser().parse_args(argv)
    try:
        return args.func(args)
    except CliError as e:
        print(f"error: {e}", file=sys.stderr)
        return EXIT_ERROR


if __name__ == "__main__":
    sys.exit(main())
