"""
Central configuration. Everything reads from .env via pydantic-settings.
Import `settings` anywhere you need a config value - never read
os.environ directly elsewhere in the project.
"""

from pathlib import Path
from typing import Optional

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict

BASE_DIR = Path(__file__).resolve().parent


class Settings(BaseSettings):
    # ---- LLM provider toggle ----
    # "azure" or "groq" - everything in app/llm/ branches on this one value.
    llm_provider: str = Field("azure", alias="LLM_PROVIDER")
    # Master switch for Aim 2 (recording+AI-assisted). When false, the
    # backend refuses assist/AI-recording routes and /api/config tells the
    # frontend to hide that whole module - Aim 1 (plain record/playback)
    # is always available regardless of this flag.
    enable_llm_assisted: bool = Field(False, alias="ENABLE_LLM_ASSISTED")

    # ---- Groq ----
    groq_api_key: Optional[str] = Field(None, alias="GROQ_API_KEY")
    groq_model: str = Field("openai/gpt-oss-20b", alias="GROQ_MODEL")
    groq_vision_model: str = Field("qwen/qwen3.8-27b", alias="GROQ_VISION_MODEL")
    groq_base_url: str = Field("https://api.groq.com/openai/v1", alias="GROQ_BASE_URL")

    # ---- Azure OpenAI ----
    azure_openai_api_key: Optional[str] = Field(None, alias="AZURE_OPENAI_API_KEY")
    azure_openai_endpoint: Optional[str] = Field(None, alias="AZURE_OPENAI_ENDPOINT")
    azure_openai_api_version: str = Field("2024-12-01-preview", alias="AZURE_OPENAI_API_VERSION")
    azure_openai_deployment: Optional[str] = Field(None, alias="AZURE_OPENAI_DEPLOYMENT")
    azure_openai_vision_deployment: Optional[str] = Field(None, alias="AZURE_OPENAI_VISION_DEPLOYMENT")
    azure_openai_embedding_deployment: Optional[str] = Field(None, alias="AZURE_OPENAI_EMBEDDING_DEPLOYMENT")

    # ---- Appium / mobile target ----
    appium_server_url: str = Field("http://127.0.0.1:4723", alias="APPIUM_SERVER_URL")
    android_device_name: str = Field("Android Device", alias="ANDROID_DEVICE_NAME")
    android_udid: Optional[str] = Field(None, alias="ANDROID_UDID")
    android_platform_version: Optional[str] = Field(None, alias="ANDROID_PLATFORM_VERSION")
    android_app_package: str = Field("", alias="ANDROID_APP_PACKAGE")
    android_app_activity: str = Field("", alias="ANDROID_APP_ACTIVITY")
    android_no_reset: bool = Field(True, alias="ANDROID_NO_RESET")
    android_new_command_timeout: int = Field(900, alias="ANDROID_NEW_COMMAND_TIMEOUT")
    android_fast_session: bool = Field(False, alias="ANDROID_FAST_SESSION")
    android_launch_verify_timeout: int = Field(15, alias="ANDROID_LAUNCH_VERIFY_TIMEOUT")

    # ---- Appium server lifecycle ----
    auto_start_appium_server: bool = Field(True, alias="AUTO_START_APPIUM_SERVER")
    appium_server_startup_timeout: int = Field(30, alias="APPIUM_SERVER_STARTUP_TIMEOUT")
    # Where an auto-started Appium server writes its log (relative to backend/). On Windows the
    # Appium client would otherwise discard that output, hiding the reason a session crashed.
    appium_log_file: str = Field("appium.log", alias="APPIUM_LOG_FILE")
    # Only needed if `adb` isn't on PATH and ANDROID_HOME/ANDROID_SDK_ROOT aren't set.
    adb_path: Optional[str] = Field(None, alias="ADB_PATH")
    # Physical-touch recording asks the recorder helper app on the phone (helper_app/, installed
    # automatically) what each touch landed on, at the moment it lands. False (or the helper
    # failing to start) falls back to matching touches against page-source snapshots.
    use_recorder_helper: bool = Field(True, alias="USE_RECORDER_HELPER")
    # False: password/PIN/OTP fields typed on the phone are recorded with their value, like any
    # other field (stored in plain text in scenarios.db). True: recorded as a placeholder whose
    # value is asked for before each run and never stored.
    redact_sensitive_values: bool = Field(False, alias="REDACT_SENSITIVE_VALUES")

    # ---- Aim 2 behaviour ----
    ai_max_steps: int = Field(8, alias="AI_MAX_STEPS")
    ai_retrieval_k: int = Field(5, alias="AI_RETRIEVAL_K")
    chroma_persist_dir: str = Field("chroma_store", alias="CHROMA_PERSIST_DIR")

    # ---- Screen mirror ----
    # Every mirrored frame is downscaled to this width and re-encoded as
    # JPEG before being sent to the frontend - the single biggest lever
    # for a smooth-feeling mirror, since a raw device screenshot is a
    # full-resolution PNG that's often 1-3 MB.
    screenshot_max_width: int = Field(480, alias="SCREENSHOT_MAX_WIDTH")
    screenshot_jpeg_quality: int = Field(70, alias="SCREENSHOT_JPEG_QUALITY")

    # How many scroll attempts replay makes (pages)
    # to bring a recorded tap/type target into view before giving up -
    # see resolve_with_scroll_search in app/automation/mobile_control.py.
    # Recorded swipes leading up to such a step are skipped at replay time
    # in favour of this - it scrolls exactly as far as THIS run actually
    # needs, rather than blindly replaying however many swipes recording
    # happened to use.
    # Pages of scrolling allowed per step. (Renamed from SCROLL_SEARCH_MAX_ATTEMPTS on purpose: an
    # older .env still carried the old default of 16, which silently capped long-list searches.)
    scroll_search_max_pages: int = Field(60, alias="SCROLL_SEARCH_MAX_PAGES")
    # A step whose target (text / id / xpath) can't be found FAILS, rather than tapping the coordinates it
    # was recorded at - which lands on whatever happens to be there. Set true to restore the old behaviour.
    allow_coordinate_fallback: bool = Field(False, alias="ALLOW_COORDINATE_FALLBACK")
    # How long a replayed step waits for its target to appear (a screen still loading after a
    # login) before it starts scrolling for it / fails. It goes ahead the moment it appears.
    step_wait_seconds: float = Field(10.0, alias="STEP_WAIT_SECONDS")
    # Before each action step, wait for the screen to stop changing and any loading indicator to
    # go (see app/services/screen_settle.py). False: act as soon as the element is there.
    settle_before_steps: bool = Field(True, alias="SETTLE_BEFORE_STEPS")
    # Black out account numbers, amounts, dates and the like in screenshots kept with run results.
    mask_screenshots: bool = Field(True, alias="MASK_SCREENSHOTS")
    # Longest a step waits for a loading indicator to go away before acting (some screens reload
    # data after a choice - e.g. picking a date reloads the leave form - and take a while).
    loading_max_seconds: float = Field(30.0, alias="LOADING_MAX_SECONDS")

    # ---- Live mirror ----
    # "mjpeg": UiAutomator2's built-in screen stream, proxied to the browser -
    # smooth and independent of Appium's command queue. "poll": the old
    # screenshot-per-request fallback (also used automatically if the stream
    # can't be opened).
    mirror_mode: str = Field("mjpeg", alias="MIRROR_MODE")
    mjpeg_server_port: int = Field(7810, alias="MJPEG_SERVER_PORT")
    mjpeg_framerate: int = Field(12, alias="MJPEG_FRAMERATE")
    mjpeg_quality: int = Field(60, alias="MJPEG_QUALITY")
    mjpeg_scaling_factor: int = Field(60, alias="MJPEG_SCALING_FACTOR")

    # ---- Storage / server ----
    database_path: str = Field("scenarios.db", alias="DATABASE_PATH")
    cors_origin: str = Field("http://localhost:3000", alias="CORS_ORIGIN")

    base_dir: Path = BASE_DIR

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        populate_by_name=True,
        extra="ignore",
    )


settings = Settings()
