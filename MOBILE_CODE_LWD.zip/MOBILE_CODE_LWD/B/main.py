from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from config import settings
from app.db.database import init_db
from app.routers import (config_router, session_router, scenarios_router, assist_router, runs_router,
                         settings_router, steps_router)


@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()
    yield


app = FastAPI(title="Mobile Automation API", lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=[settings.cors_origin],
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(config_router.router)
app.include_router(session_router.router)
app.include_router(scenarios_router.router)
app.include_router(assist_router.router)
app.include_router(runs_router.router)
app.include_router(settings_router.router)
app.include_router(steps_router.router)


@app.get("/api/health")
def health():
    return {"status": "ok"}
