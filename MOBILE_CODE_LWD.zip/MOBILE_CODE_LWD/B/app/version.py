# Bump on every change; the frontend compares its own copy so a stale browser bundle or
# a half-updated install is obvious instead of silently misbehaving.
API_VERSION = "2026.10.07-r48"
