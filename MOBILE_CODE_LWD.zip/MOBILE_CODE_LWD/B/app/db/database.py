from pathlib import Path

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, Session

from config import settings
from app.db.models import Base

DB_PATH = Path(settings.base_dir) / settings.database_path
DATABASE_URL = f"sqlite:///{DB_PATH}"

# check_same_thread=False: FastAPI's request handlers and any
# asyncio.to_thread-offloaded Appium calls can touch the DB from
# different threads - safe here because every call site opens and closes
# its own short-lived session rather than sharing one across threads.
engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(bind=engine, expire_on_commit=False)


def init_db():
    Base.metadata.create_all(bind=engine)
    _migrate_schema()


def _migrate_schema():
    """create_all() only creates tables that don't exist yet - it never
    alters an existing one. This project has no Alembic (deliberately, to
    stay simple), so for the rare column this project's history has added
    after the fact, add it by hand if an existing scenarios.db predates
    it - this is what lets a database file created before checked_target
    existed keep working instead of throwing "no such column" on first
    read."""
    added_later = {
        "steps": {"checked_target": "BOOLEAN", "redacted": "BOOLEAN", "check_kind": "VARCHAR",
                  "optional": "BOOLEAN", "continue_on_failure": "BOOLEAN", "disabled": "BOOLEAN",
                  "extra_json": "TEXT"},
        "scenarios": {"variables_json": "TEXT", "start_json": "TEXT"},
    }
    with engine.connect() as conn:
        for table, columns in added_later.items():
            existing_cols = {row[1] for row in conn.exec_driver_sql(f"PRAGMA table_info({table})").fetchall()}
            for column, sql_type in columns.items():
                if column not in existing_cols:
                    conn.exec_driver_sql(f"ALTER TABLE {table} ADD COLUMN {column} {sql_type}")
                    conn.commit()


def get_session() -> Session:
    return SessionLocal()
