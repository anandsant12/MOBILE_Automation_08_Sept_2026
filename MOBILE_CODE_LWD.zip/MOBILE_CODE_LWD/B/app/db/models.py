from datetime import datetime, timezone
from typing import Optional

from sqlalchemy import String, Integer, Float, Text, ForeignKey, DateTime, Boolean
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship


class Base(DeclarativeBase):
    pass


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


class Scenario(Base):
    __tablename__ = "scenarios"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    name: Mapped[str] = mapped_column(String, unique=True, index=True)
    # "basic" (Aim 1, recorded with no LLM involved) or "ai" (Aim 2,
    # recorded with LLM-classified descriptions + steps embedded in Chroma).
    mode: Mapped[str] = mapped_column(String, default="basic")
    android_app_package: Mapped[str] = mapped_column(String, default="")
    android_app_activity: Mapped[str] = mapped_column(String, default="")
    # Test data: {name: value} used as ${name} in typed text, options and expected values
    # (${env:NAME} reads an environment variable instead - for secrets).
    variables_json: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    # How a run starts (scenario_service.START_DEFAULTS): {"app": "as_is" | "restart" | "clear",
    # "setup_scenario_id": a scenario run first, e.g. Login, or null}.
    start_json: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=_utcnow)

    steps: Mapped[list["Step"]] = relationship(
        back_populates="scenario", cascade="all, delete-orphan", order_by="Step.order_index",
    )

    def to_summary_dict(self) -> dict:
        return {
            "id": self.id,
            "name": self.name,
            "mode": self.mode,
            "android_app_package": self.android_app_package,
            "android_app_activity": self.android_app_activity,
            "step_count": len(self.steps),
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }

    def to_full_dict(self) -> dict:
        import json
        d = self.to_summary_dict()
        d["variables"] = json.loads(self.variables_json) if self.variables_json else {}
        d["start"] = json.loads(self.start_json) if self.start_json else {}
        d["steps"] = [s.to_dict() for s in self.steps]
        return d


class RunRecord(Base):
    """A finished scenario run, kept after the backend restarts (app/services/run_history.py)."""
    __tablename__ = "runs"

    id: Mapped[str] = mapped_column(String, primary_key=True)
    scenario_id: Mapped[Optional[int]] = mapped_column(Integer, index=True, nullable=True)
    scenario_name: Mapped[str] = mapped_column(String, default="")
    status: Mapped[str] = mapped_column(String)            # passed | failed | stopped
    start_index: Mapped[int] = mapped_column(Integer, default=0)
    total_steps: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    created_at: Mapped[float] = mapped_column(Float)       # epoch seconds
    finished_at: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    failure_json: Mapped[Optional[str]] = mapped_column(Text, nullable=True)   # run_diagnosis result
    log_json: Mapped[str] = mapped_column(Text, default="[]")                  # per-step results


class Step(Base):
    __tablename__ = "steps"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    scenario_id: Mapped[int] = mapped_column(ForeignKey("scenarios.id"), index=True)
    order_index: Mapped[int] = mapped_column(Integer)
    # "tap" | "type" | "swipe" | "key" | "assert"
    action: Mapped[str] = mapped_column(String)
    description: Mapped[str] = mapped_column(String, default="")
    locator_json: Mapped[Optional[str]] = mapped_column(Text, nullable=True)  # {resource_id, content_desc, text, xpath}
    # Relative (0..1) coordinates - fallback when the locator can't be
    # resolved at replay time (a different device/resolution, or a
    # locator-less freeform tap). x2/y2 are swipe end-points only.
    x_pct: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    y_pct: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    x2_pct: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    y2_pct: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    text: Mapped[Optional[str]] = mapped_column(Text, nullable=True)  # "type"'s typed value; "swipe"'s direction; "key"'s key name
    # For a "tap" on a checkable control (Switch/CheckBox/RadioButton):
    # what its checked state should be AFTER this step. Lets replay skip
    # the tap when the control is already in that state, instead of
    # blindly flipping it - without this, running the same scenario twice
    # would toggle everything back off the second time.
    checked_target: Mapped[Optional[bool]] = mapped_column(Boolean, nullable=True)
    # True for a "type" step whose value was deliberately never recorded (a password/PIN/OTP
    # field). text is always empty for these; run_scenario needs a same-length value supplied
    # at RUN time (never persisted) or the step fails - see app/services/scenario_service.py.
    redacted: Mapped[Optional[bool]] = mapped_column(Boolean, nullable=True)
    # For an "assert" step: what to verify about the element (see scenario_service.CHECKS);
    # "text" holds the expected value for the text checks.
    check_kind: Mapped[Optional[str]] = mapped_column(String, nullable=True)
    # Step options: an optional step whose element doesn't appear is skipped (a popup the
    # app only sometimes shows); continue_on_failure reports a failure but runs on.
    optional: Mapped[Optional[bool]] = mapped_column(Boolean, nullable=True)
    continue_on_failure: Mapped[Optional[bool]] = mapped_column(Boolean, nullable=True)
    # A disabled step is kept but skipped by replay (e.g. a tap that landed on a loading mask).
    disabled: Mapped[Optional[bool]] = mapped_column(Boolean, nullable=True)
    # Other step fields, as JSON (scenario_service.EXTRA_FIELDS): e.g. the saved screens around it.
    extra_json: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=_utcnow)

    scenario: Mapped["Scenario"] = relationship(back_populates="steps")

    def to_dict(self) -> dict:
        import json
        return {
            **(json.loads(self.extra_json) if self.extra_json else {}),
            "order_index": self.order_index,
            "action": self.action,
            "description": self.description,
            "locator": json.loads(self.locator_json) if self.locator_json else {},
            "x_pct": self.x_pct, "y_pct": self.y_pct,
            "x2_pct": self.x2_pct, "y2_pct": self.y2_pct,
            "text": self.text,
            "checked_target": self.checked_target,
            "redacted": self.redacted,
            "check": self.check_kind,
            "optional": self.optional,
            "continue_on_failure": self.continue_on_failure,
            "disabled": self.disabled,
        }
