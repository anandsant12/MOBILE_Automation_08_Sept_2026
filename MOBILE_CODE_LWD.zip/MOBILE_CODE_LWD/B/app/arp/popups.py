"""Popup rules: interruptions answered automatically during a run, so they needn't be
recorded into every test -- "when the screen shows X, tap Y" (a rating prompt, an
"OPEN WIFI DETECTED" warning, "You have not registered beneficiaries"), and Android's
runtime-permission dialogs.

Rules are only looked for while a step is waiting for an element it can't find (the usual
sign something popped up over it), not before every step, so they cost nothing when no popup
shows. Stored in popup_rules.json next to the test cases.
"""

import json
from pathlib import Path

from appium.webdriver.common.appiumby import AppiumBy

from . import locator as locator_mod

PATH = Path("popup_rules.json")
DEFAULTS = {"allow_permissions": True, "rules": []}
# Android's permission dialog buttons, most limited grant first.
PERMISSION_BUTTONS = ("permission_allow_foreground_only_button", "permission_allow_one_time_button",
                      "permission_allow_button")


def load(path=PATH):
    try:
        data = json.loads(Path(path).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return json.loads(json.dumps(DEFAULTS))
    rules = [{"when": str(r.get("when") or "").strip(), "tap": str(r.get("tap") or "").strip()}
             for r in data.get("rules") or []]
    return {"allow_permissions": bool(data.get("allow_permissions", True)),
            "rules": [r for r in rules if r["when"] and r["tap"]]}


def save(config, path=PATH):
    Path(path).write_text(json.dumps(config, indent=2, ensure_ascii=False), encoding="utf-8")


def _shows(text):
    lit = locator_mod._xpath_literal(text)
    return f"contains(@text, {lit}) or contains(@content-desc, {lit})"


class PopupHandler:
    """Answers popups per the rules; `handle(driver)` returns what it did (empty: nothing)."""

    def __init__(self, config=None):
        self.config = config if config is not None else load()
        tests = [_shows(r["when"]) for r in self.config["rules"]]
        if self.config["allow_permissions"]:
            tests += [f"contains(@resource-id, {locator_mod._xpath_literal(b)})" for b in PERMISSION_BUTTONS]
        # One lookup tells whether any popup is showing at all.
        self.any_xpath = f"//*[{' or '.join(tests)}]" if tests else None

    def handle(self, driver):
        if not self.any_xpath:
            return []
        try:
            if not [e for e in driver.find_elements(AppiumBy.XPATH, self.any_xpath) if e.is_displayed()]:
                return []
        except Exception:  # noqa: BLE001 - the screen changed mid-read
            return []
        done = []
        if self.config["allow_permissions"]:
            for button in PERMISSION_BUTTONS:
                try:
                    found = driver.find_elements(AppiumBy.XPATH, f"//*[contains(@resource-id, '{button}')]")
                except Exception:  # noqa: BLE001
                    found = []
                if found:
                    found[0].click()
                    done.append("allowed an Android permission request")
                    break
        for rule in self.config["rules"]:
            try:
                if not any(e.is_displayed() for e in driver.find_elements(AppiumBy.XPATH, f"//*[{_shows(rule['when'])}]")):
                    continue
                lit = locator_mod._xpath_literal(rule["tap"])
                buttons = [e for e in driver.find_elements(
                    AppiumBy.XPATH, f"//*[normalize-space(@text)={lit} or normalize-space(@content-desc)={lit}]")
                    if e.is_displayed()]
                if buttons:
                    buttons[-1].click()   # the one drawn last: the popup's, not the page's behind it
                    done.append(f"popup rule: '{rule['when']}' -> tapped '{rule['tap']}'")
            except Exception:  # noqa: BLE001 - it closed by itself meanwhile
                continue
        return done
