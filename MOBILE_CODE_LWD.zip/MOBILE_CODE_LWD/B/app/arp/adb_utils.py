"""Thin wrappers around the `adb` command line tool."""

import re
import subprocess


def run(args, serial=None, adb_bin="adb", timeout=None):
    cmd = [adb_bin]
    if serial:
        cmd += ["-s", serial]
    cmd += args
    return subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)


def run_binary(args, serial=None, adb_bin="adb", timeout=None):
    """Like `run`, but returns raw bytes on stdout (for PNG/binary output)."""
    cmd = [adb_bin]
    if serial:
        cmd += ["-s", serial]
    cmd += args
    return subprocess.run(cmd, capture_output=True, text=False, timeout=timeout)


def list_devices(adb_bin="adb"):
    result = run(["devices", "-l"], adb_bin=adb_bin)
    devices = []
    for line in result.stdout.splitlines()[1:]:
        line = line.strip()
        if not line:
            continue
        parts = line.split()
        serial = parts[0]
        state = parts[1] if len(parts) > 1 else "unknown"
        devices.append({"serial": serial, "state": state})
    return devices


def get_input_devices(serial=None, adb_bin="adb"):
    """Return the input devices reported by `getevent -pl`, flagging the touchscreen."""
    result = run(["shell", "getevent", "-pl"], serial=serial, adb_bin=adb_bin)
    text = result.stdout
    blocks = re.split(r"(?=add device \d+: )", text)
    devices = []
    for block in blocks:
        match = re.search(r"add device \d+: (\S+)", block)
        if not match:
            continue
        path = match.group(1)
        name_match = re.search(r'name:\s*"([^"]*)"', block)
        name = name_match.group(1) if name_match else ""
        devices.append(
            {
                "path": path,
                "name": name,
                "is_touchscreen": "ABS_MT_POSITION_X" in block,
            }
        )
    return devices
