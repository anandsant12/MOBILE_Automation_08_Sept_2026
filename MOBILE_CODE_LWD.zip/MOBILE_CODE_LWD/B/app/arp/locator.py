"""Appium locators for elements reported by the recorder helper app.

The helper describes each element with the same attributes Appium's
UiAutomator2 page source uses (resource-id, content-desc, text, class,
bounds), plus its structural xpath from the window root, so a recorded
element can be found again with ordinary Appium strategies.
"""

import re


def parse_bounds(bounds_str):
    """"[x1,y1][x2,y2]" -> (x1, y1, x2, y2)."""
    inner = bounds_str.strip()
    if not (inner.startswith("[") and inner.endswith("]")):
        raise ValueError(f"Unexpected bounds format: {bounds_str!r}")
    x1y1, x2y2 = inner[1:-1].split("][")
    x1, y1 = (int(v) for v in x1y1.split(","))
    x2, y2 = (int(v) for v in x2y2.split(","))
    return x1, y1, x2, y2


def _xpath_literal(value):
    """A safe XPath 1.0 string literal, even if `value` contains both quote types."""
    if '"' not in value:
        return f'"{value}"'
    if "'" not in value:
        return f"'{value}'"
    parts = value.split('"')
    return "concat(" + ', \'"\', '.join(f'"{p}"' for p in parts) + ")"


GLYPHS = re.compile("[-​-‍﻿]")


def clean_text(value):
    """Text as a person reads it: icon-font glyphs (private-use characters, e.g. an app's
    icon font drawing a "table" icon as U+E0F2) and zero-width characters removed.
    None if nothing readable is left."""
    if value is None:
        return None
    value = GLYPHS.sub("", str(value)).strip()
    return value or None


def _known(count):
    """A count the helper reported (None when unknown: older helper, or it couldn't tell)."""
    return count if isinstance(count, int) and count > 0 else None


def plain_spaces(value):
    """Words separated by single spaces: a line break or a run of spaces becomes one space."""
    return " ".join(str(value or "").split())


def _spaced(raw):
    """Whether text as the app reports it has spacing a cleaned copy won't reproduce --
    leading/trailing spaces, line breaks, runs of spaces ("Self Accounts ", "\\nAbout ...").
    Exact matches on the cleaned copy can never find such an element."""
    return raw is not None and GLYPHS.sub("", str(raw)) != plain_spaces(GLYPHS.sub("", str(raw)))


def _equals(attr, raw, value):
    """XPath test that @attr shows `value`. Unchanged (an exact match) for ordinary text;
    compared with normalize-space() only for text whose spacing is irregular."""
    if _spaced(raw):
        return f"normalize-space(@{attr})={_xpath_literal(plain_spaces(value))}"
    return f"@{attr}={_xpath_literal(value)}"


# A state the app appends to an element's description ("ChequReq5, selected"): it changes
# with the element's state, so it is not part of the element's name.
# With or without a comma: "ChequReq5, selected", "NEFT tab selected".
STATE_SUFFIX = re.compile(r"(?:,\s*|\s+)(not selected|selected|not checked|unchecked|checked|expanded|collapsed)\s*$",
                          re.I)


def split_state(desc):
    """("ChequReq5", ", selected") for "ChequReq5, selected" ("NEFT tab", " selected" for "NEFT tab
    selected"); (desc, "") without a state."""
    m = STATE_SUFFIX.search(desc or "")
    if not m or not desc[:m.start()].strip():
        return desc, ""
    return desc[:m.start()].rstrip(), desc[m.start():]


# Values that differ from run to run: amounts, dates, times. An element is never found by
# them alone (tomorrow the balance or the clock reads differently).
_CURRENCY = re.compile(r"[₹$€£¥]|\b(?:rs|inr|usd|eur)\b\.?\s*\d", re.I)
# 45,230.00 -- not the "1.14" of a version number like 10.1.14.
_AMOUNT = re.compile(r"(?<![\d.])\d[\d,]*\.\d{2}(?![\d.])")
# 01-10-2026, 1/10/26, 2026-10-01, 01.10.2026 -- but not a version number like 10.1.14.
_DATE = re.compile(r"\b\d{1,2}[/-]\d{1,2}[/-]\d{2,4}\b|\b\d{4}[/-]\d{1,2}[/-]\d{1,2}\b|\b\d{1,2}\.\d{1,2}\.\d{4}\b")
MONTHS = re.compile(r"\b(?:Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|June?|July?|Aug(?:ust)?"
                    r"|Sep(?:t(?:ember)?)?|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?)\b", re.I)
_TEXT_DATE = re.compile(r"\b\d{1,2}(?:st|nd|rd|th)?\s+" + MONTHS.pattern + r",?\s+\d{2,4}\b|"
                        + MONTHS.pattern + r"\s+\d{1,2}(?:st|nd|rd|th)?,?\s+\d{4}\b", re.I)
_TIME = re.compile(r"\b\d{1,2}:\d{2}(?::\d{2})?\s*(?:am|pm)?\b", re.I)
_TEMPLATE = re.compile(r"\{\{[^{}]*\}\}")
_BALANCE = re.compile(r"\bbalance\s*:?\s*(?:₹|rs\.?|inr)?\s*[\d,]", re.I)


def volatile(text, choice=False):
    """Whether text shows a value that changes between runs (an amount, a date, a time).

    choice=True for a control the user picks (a calendar day "02 October 2026", a time
    slot): there the date or time *is* what was chosen, so only money counts as changing."""
    if text and _TEMPLATE.search(text):
        return True  # an unfilled template value ("Limit : ₹ {{amount}}"): it gets filled in some day
    if not text or not any(c.isdigit() for c in text):
        return False
    money =bool(_CURRENCY.search(text) or _AMOUNT.search(text) or _BALANCE.search(text))
    if choice:
        return money
    return money or bool(_DATE.search(text) or _TEXT_DATE.search(text) or _TIME.search(text))


def is_choice(node):
    """A control the user operates (tap, check): its text names what was picked."""
    return bool(node and (node.get("clickable") or node.get("checkable") or node.get("long_clickable")))


def stable_prefix(text):
    """The fixed words before a changing value ("Current Date & Time :" in
    "Current Date & Time : 01-10-2026 06:22 PM"), or None if too short to identify anything."""
    m = re.search(r"[\d₹$€£¥]|\{\{", text or "")
    prefix = plain_spaces(text[:m.start()]) if m else None
    return prefix if prefix and len(prefix) >= 4 and re.search(r"[A-Za-z]{3}", prefix) else None


# Ids that are only HTML tag names (an app rendering HTML gives every link the id "a"):
# they name a kind of element, not this one.
HTML_TAG_IDS = {"html", "body", "head", "div", "span", "p", "a", "li", "ul", "ol", "table", "tbody", "thead",
                "tr", "td", "th", "img", "strong", "b", "i", "em", "u", "br", "hr", "h1", "h2", "h3", "h4",
                "h5", "h6", "section", "article", "header", "footer", "nav", "main", "font", "small", "sup",
                "sub", "pre", "code", "blockquote"}

# The roots of every app window: "inside" them narrows nothing down.
FRAMEWORK_IDS = re.compile(r"^(android:id/content|android:id/list_container|.+:id/(action_bar_root|decor_content_parent))$")

# A candidate that finds the element by what it shows (its text or description), in any
# of the forms built here.
NAMES_ELEMENT = re.compile(r"@(text|content-desc)[)]?\s*=|normalize-space[(]@(text|content-desc)[)]")


def names_element(strategy, value):
    return strategy == "accessibility id" or bool(NAMES_ELEMENT.search(str(value)))


_NAME_TEST = re.compile(r"""(?<![\w(-])@(text|content-desc)=("[^"]*"|'[^']*')""")


def relaxed(strategy, value):
    """A looser form of a name-based candidate that found nothing: spacing ignored, and a
    state the app appends to the description ("…, selected") allowed. None when there's no
    looser form. Only ever tried after the exact form found nothing, so it can't change what
    an already-working locator finds."""
    if strategy == "accessibility id":
        base, _ = split_state(plain_spaces(value))
        lit = _xpath_literal(base)
        return ("xpath", f"//*[normalize-space(@content-desc)={lit} or "
                         f"starts-with(normalize-space(@content-desc), {_xpath_literal(base + ', ')}) or "
                         f"starts-with(normalize-space(@content-desc), {_xpath_literal(base + ' ')})]")
    if strategy != "xpath":
        return None

    def loose(m):
        return f"normalize-space(@{m.group(1)})={_xpath_literal(plain_spaces(m.group(2)[1:-1]))}"

    looser = _NAME_TEST.sub(loose, value)
    return ("xpath", looser) if looser != value else None


def locator_from_node(node, use_text=True):
    """Locator dict with an ordered `candidates` list of (strategy, value) pairs.

    Built from what identified the element *uniquely* on screen when it was
    touched -- the helper counts, at that moment, how many elements share its
    id, text, description and inner label (list rows and grid tiles share ids;
    the same "Pay" can appear in two sections). Known-unique locators come
    first; when none of the element's own attributes is unique, combinations
    are added: id + text, "inside <its uniquely-identified container>", "next
    to the label X". Shared ones stay only as a last resort. `unique` in the
    result is False when nothing was known to single the element out, so the
    step can be flagged for review.

    A text field's text is whatever was typed into it, so it's never used to
    find the field; pass use_text=False for elements whose text is a changing
    value (e.g. a dropdown showing its current choice).
    """
    resource_id = node.get("resource_id") or None
    if resource_id and ":id/" not in resource_id and resource_id.lower() in HTML_TAG_IDS:
        resource_id = None  # an HTML tag name ("a" on every link): names a kind of element, not this one
    raw_desc, raw_text = node.get("content_desc"), node.get("text")
    content_desc = clean_text(raw_desc)
    text = clean_text(raw_text)
    class_name = node.get("class_name") or None
    is_editable = bool(node.get("editable") or (class_name and class_name.endswith("EditText")))
    context = dict(node.get("context") or {})
    for key in ("inner_text", "sibling_text"):
        context[key] = [t for t in (clean_text(t) for t in context.get(key) or []) if t]
    if not use_text or is_editable:
        text = None
    # The description without a state the app appends to it ("ChequReq5, selected").
    desc_name, desc_state = split_state(content_desc) if content_desc else (None, "")
    # Text showing a value that changes between runs (a balance, the time): kept, but only
    # as a last resort -- the element is found by what around it stays the same.
    choice = is_choice(node)
    desc_changing = volatile(content_desc, choice)
    text_changing = volatile(text, choice)
    # A tile/row/button with no text of its own is named by the text inside it
    # (its label child) -- e.g. a service tile containing "Rupay NCMC Prepaid".
    # Also when its description is a changing value (an account row described with its balance).
    label = None
    label_count = _known(context.get("label_count"))
    if not text and (not content_desc or desc_changing) and use_text and not is_editable:
        inner = context.get("inner_text") or []
        if desc_changing:
            steady = [t for t in inner if not volatile(t)]
            if steady and inner and steady[0] != inner[0]:
                label_count = None  # the helper counted the first label, not this one
            inner = steady
        label = inner[0] if inner else None
    id_count = _known(node.get("id_count"))
    shared = (id_count or 1) > 1
    kind = class_name if class_name and re.fullmatch(r"[\w.$]+", class_name) else "*"
    rid = _xpath_literal(resource_id) if resource_id else None

    near = None  # for an element with no name: the label beside it
    beside = None  # for a changing value: the fixed label next to it
    ranked = []  # (strategy, value, unique: True / False / None when unknown, changing value)

    def add(strategy, value, count, changing=False):
        ranked.append((strategy, value, None if count is None else count == 1, changing))

    desc_count = _known(node.get("desc_count"))
    if content_desc and desc_state:
        # Found whatever state it's in ("ChequReq5", "ChequReq5, selected", "…, not selected").
        desc_test = (f"normalize-space(@content-desc)={_xpath_literal(plain_spaces(desc_name))} or "
                     f"starts-with(normalize-space(@content-desc), {_xpath_literal(plain_spaces(desc_name) + ', ')}) or "
                     f"starts-with(normalize-space(@content-desc), {_xpath_literal(plain_spaces(desc_name) + ' ')})")
    elif content_desc:
        desc_test = _equals("content-desc", raw_desc, content_desc)
    else:
        desc_test = None
    text_test = _equals("text", raw_text, text) if text else None

    # Appium's "id" strategy only matches package-qualified ids ("pkg:id/name");
    # web content inside a WebView reports bare HTML ids, which only xpath finds.
    if resource_id and ":id/" in resource_id:
        add("id", resource_id, id_count)
    if content_desc:
        # Appium's accessibility id is an exact match: the description exactly as the app has
        # it, spacing included ("Self Accounts " -- a trimmed copy would never match).
        exact = str(raw_desc) if _spaced(raw_desc) and not GLYPHS.search(str(raw_desc)) else content_desc
        add("accessibility id", exact, desc_count, desc_changing)
    if resource_id:
        add("xpath", f"//*[@resource-id={rid}]", id_count)
    if content_desc:
        add("xpath", f"//*[{desc_test}]", desc_count, desc_changing)
    if text:
        add("xpath", f"//{class_name or '*'}[{text_test}]", _known(node.get("text_count")), text_changing)
    # A value that changes: the fixed words before it, or the label next to it.
    value, attr = (text, "text") if text_changing else (
        (content_desc, "content-desc") if desc_changing and not text and not label else (None, None))
    if value:
        prefix = stable_prefix(value)
        if prefix:
            add("xpath", f"//{kind}[starts-with(normalize-space(@{attr}), {_xpath_literal(prefix)})]", None)
        for s in context.get("sibling_text") or []:
            if s != value and not volatile(s):
                beside = s
                lit = _xpath_literal(plain_spaces(s))
                add("xpath", f"//*[normalize-space(@text)={lit} or normalize-space(@content-desc)={lit}]"
                             f"/following-sibling::{kind}[1]", None)
                break
    # A text field: the hint it shows when empty ("Search keyword") stays the same, whatever is typed.
    hint = clean_text(node.get("hint")) if is_editable else None
    if hint and not volatile(hint):
        add("xpath", f"//{kind}[{_equals('hint', node.get('hint'), hint)}]", None)
    # A text field with no id or hint: the first field after its label in the form
    # ("Payee Account Number :" then the field's own box).
    field_label = None
    if is_editable and not resource_id:
        before = clean_text(context.get("preceding_text"))
        if before and not volatile(before) and not hint:
            field_label = before
            lit = _xpath_literal(plain_spaces(before))
            add("xpath", f"//*[normalize-space(@text)={lit} or normalize-space(@content-desc)={lit}]"
                         f"/following::{kind}[1]", None)
    if label:
        lit = _xpath_literal(label)
        if resource_id:
            add("xpath", f"//*[@resource-id={rid}][.//*[@text={lit} or @content-desc={lit}]]",
                1 if label_count == 1 or id_count == 1 else None)
        add("xpath", f"//*[@text={lit} or @content-desc={lit}]/ancestor::*[@clickable='true'][1]", label_count)

    # Nothing of its own is unique (e.g. two identical "Pay" buttons): combine
    # what it has, and scope it to the nearest container that is unique.
    if not any(unique and not changing for _, _, unique, changing in ranked):
        name = (text_test if text and not text_changing else
                desc_test if content_desc and not desc_changing else None)
        if resource_id and name:
            add("xpath", f"//*[@resource-id={rid}][{name}]", _known(node.get("id_text_count")))
        own = f"[{name}]" if name else (f"[@resource-id={rid}]" if resource_id else "")
        ancestors = context.get("ancestors") or []
        unique_ids = [a for a in ancestors if a.get("resource_id") and _known(a.get("id_count")) == 1]
        app_ids = [a for a in unique_ids if not FRAMEWORK_IDS.match(a["resource_id"])]
        if app_ids:
            add("xpath", f"//*[@resource-id={_xpath_literal(app_ids[0]['resource_id'])}]//{kind}{own}", None)
        else:
            # No container of the app's own with a unique id: one it describes ("Search
            # keyword, edit box" around a field), before the window's root, which every
            # screen has and so narrows nothing down.
            for a in ancestors:
                named = clean_text(a.get("content_desc"))
                # Not around a text field: such a container's description is usually the field's
                # content ("zero rupees, edit box", then "one hundred rupees only, edit box").
                if is_editable or (named and "edit box" in named.lower()):
                    break
                if named and not a.get("resource_id") and not volatile(named) and not split_state(named)[1]:
                    add("xpath", f"//*[{_equals('content-desc', a.get('content_desc'), named)}]//{kind}{own}", None)
                    break
            if unique_ids:
                add("xpath", f"//*[@resource-id={_xpath_literal(unique_ids[0]['resource_id'])}]//{kind}{own}", None)
        # An element with no name at all (an icon-only button) next to a label.
        if not (text or content_desc or label):
            near = (context.get("sibling_text") or [None])[0]
            for beside_text in (context.get("sibling_text") or [])[:2]:
                lit = _xpath_literal(beside_text)
                add("xpath", f"//*[@text={lit} or @content-desc={lit}]/..//{kind}"
                             f"{own}[not(@text={lit})]", None)

    # Known-unique first (keeping the preference order above), then unknown, then the ones
    # resting on a changing value, then known-shared.
    def rank(candidate):
        _, _, unique, changing = candidate
        if unique is False:
            return 3
        if changing:
            return 2
        return 0 if unique else 1

    ranked.sort(key=rank)
    # A changing value (a balance, the time) won't find the element on the next run, and
    # shouldn't be written into the test: dropped whenever something steady can find it.
    if any(changing for _, _, _, changing in ranked) and any(not changing for _, _, _, changing in ranked):
        ranked = [c for c in ranked if not c[3]]
    candidates = [(s, v) for s, v, _, _ in ranked]
    # The path from the window root -- unless the element was already detached
    # from the screen when read (a one-step path like "//android.widget.LinearLayout"
    # matches every such element), or it runs through a scrolling list, whose
    # slots are reused for other rows as it scrolls.
    xpath = node.get("xpath")
    if xpath and xpath.count("/") > 3 and not any(k in xpath for k in LIST_CLASSES):
        candidates.append(("xpath", xpath))
    if not candidates:
        return None
    # Flag it only when every way to find it is known to match several elements.
    if any(unique for _, _, unique, _ in ranked):
        unique = True
    elif ranked and all(u is False for _, _, u, _ in ranked):
        unique = False
    else:
        unique = None

    strategy, value = candidates[0]
    return {
        "strategy": strategy,
        "value": value,
        "candidates": candidates,
        "resource_id": resource_id,
        # Its name: without an appended state, and never a changing value (a balance).
        "content_desc": None if desc_changing else (desc_name if desc_state else content_desc),
        # A text field's text is what was typed (or its hint): only the hint names it.
        "text": (hint if is_editable and use_text else clean_text(node.get("text"))),
        "class_name": class_name,
        "bounds": node.get("bounds"),
        "window_package": node.get("package"),
        "label": label,
        "id_shared": shared,
        # False: nothing was unique on screen when recorded (None: not counted -- older helper).
        "unique": unique,
        "near": near,
        "beside": beside,
        "changing": bool(text_changing or desc_changing),
        "field_label": field_label,
    }


LIST_CLASSES = ("RecyclerView", "ListView", "GridView", "ViewPager")


def manual_locator(strategy, value):
    """A locator typed in by hand (e.g. copied from Appium Inspector)."""
    return {
        "strategy": strategy,
        "value": value,
        "candidates": [(strategy, value)],
        "resource_id": value if strategy == "id" else None,
        "content_desc": value if strategy == "accessibility id" else None,
        "text": None,
        "class_name": None,
        "bounds": None,
        "window_package": None,
    }


def is_identifiable(node):
    """Whether an element has something better than its position in the tree to find it by."""
    return bool(node and (node.get("resource_id") or node.get("content_desc") or node.get("text")))


def describe(locator_info):
    """Short human-readable name for the element a locator points at."""
    if locator_info.get("changing") and locator_info.get("beside"):
        return f'value next to "{locator_info["beside"]}"'
    if locator_info.get("field_label") and not locator_info.get("resource_id"):
        return f'the field after "{locator_info["field_label"]}"'
    if locator_info.get("changing"):
        prefix = stable_prefix(locator_info.get("text") or "")
        if prefix:
            return f'"{prefix} …"'  # not today's reading (the time, a balance)
    if locator_info.get("near") and not (locator_info.get("text") or locator_info.get("label")
                                         or locator_info.get("content_desc")):
        return f'icon next to "{locator_info["near"]}"'
    shown = locator_info.get("text") or locator_info.get("label")
    # A system id ("android:id/button1" on a dialog's OK) says less than the button's text.
    system_id = (locator_info.get("resource_id") or "").startswith("android:id/")
    if shown and (locator_info.get("id_shared") or not locator_info.get("resource_id") or system_id) \
            and not locator_info.get("content_desc"):
        return f'"{shown}"'
    if locator_info.get("id_shared") and locator_info.get("content_desc"):
        return locator_info["content_desc"]
    return (
        locator_info.get("resource_id")
        or locator_info.get("content_desc")
        or (f'"{locator_info["text"]}"' if locator_info.get("text") else None)
        or locator_info.get("class_name")
        or _shorten(locator_info.get("value"))
        or "element"
    )


def _shorten(value, limit=60):
    if not value:
        return None
    return value if len(value) <= limit else "…" + value[-(limit - 1):]
