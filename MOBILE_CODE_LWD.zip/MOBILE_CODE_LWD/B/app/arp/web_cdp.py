"""See web content inside an app's WebView, via Chrome DevTools Protocol.

Android's accessibility tree -- which both the recorder helper and Appium's
UiAutomator2 read -- doesn't always include web content: e.g. a web popup
(a Bootstrap modal) drawn over the page is missing from it, so a tap on its
"No" button looks like a tap on whatever is behind it. For apps that enable
WebView debugging (a `webview_devtools_remote_<pid>` socket exists), this
asks the page itself instead:

  - `element_at(x, y)`: the element really on top at a screen point
    (document.elementFromPoint, which respects popups and overlays), as a
    web locator: CSS selector + its text + the dialog it's in, if any;
  - `find(locator)`: whether that element is on screen, visible and on top,
    and where (screen pixels), so it can be tapped with a real touch.

All reads are plain JavaScript evaluated in the page; nothing is changed.
"""

import json
import threading
import time
import urllib.request

try:
    import websocket
except ImportError:  # [ours] recording works without it - just no web-page element lookup
    websocket = None

from . import adb_utils

# Installed into the page when missing or outdated; the functions only read the DOM.
HELPERS_VERSION = 21
_HELPERS = r"""
window.__arp = (() => {
  // Icon-font glyphs (private-use characters) and zero-width characters aren't text.
  const GLYPHS = /[\uE000-\uF8FF\u200B-\u200D\uFEFF]/g;
  const norm = s => (s || '').replace(GLYPHS, '').trim().replace(/\s+/g, ' ').slice(0, 80);
  // Text compared with its numbers ignored: counts, amounts, dates and times change between runs
  // ("GEMs 2 GEM Received" is the same card as "GEMs 3 GEM Received").
  const shape = s => (s || '').replace(/\d+([.,:\/]\d+)*/g, '#');
  // Only for text with words in it: "1" and "2" on a keypad are different keys.
  const wordy = s => /[^\d\W_]/.test(s || '');
  const sameText = (a, b) => a === b || (!!a && !!b && wordy(a) && wordy(b) && shape(a) === shape(b));
  // Recorded text with its numbers shown as "#" ("GEMs # GEM Received"): it matches any number.
  const stable = s => wordy(s) ? shape(s) : s;
  const textOf = e => norm(e.innerText || e.value || e.getAttribute('aria-label') || e.getAttribute('title') || e.getAttribute('alt'));
  // The whole text, for checks (textOf is shortened to 80 characters to keep locators readable).
  const fullText = e => (e.innerText || e.value || e.getAttribute('aria-label') || e.getAttribute('title') || '')
    .replace(GLYPHS, '').trim().replace(/\s+/g, ' ').slice(0, 2000);
  const DIALOG = '.modal, [role=dialog], [role=alertdialog], dialog, .swal2-popup, .popup, .alert';
  const context = e => { const d = e.closest(DIALOG); return d ? norm(d.innerText).slice(0, 60) : null; };
  // A popup's title: its heading element, else its first text ("Employee Contact", "Login Failed").
  const TITLE = 'h1, h2, h3, h4, h5, h6, .modal-title, [class*=title], [class*=heading], [class*=header]';
  const popupTitle = e => {
    const d = e.closest(DIALOG);
    if (!d) return null;
    for (const t of d.querySelectorAll(TITLE)) { const s = norm(t.innerText); if (s && s.length <= 60) return s; }
    return null;
  };
  // Ids a framework generates ("ember123", "react-select-5-input", "j_idt42") change between builds.
  const stableId = id => !!id && !/\d{3,}|^(ember|react|mui|ext-gen|j_idt|ng-|:r)|[-_:]\d+$/i.test(id);
  const INTERACTIVE = ['BUTTON', 'A', 'INPUT', 'SELECT', 'TEXTAREA', 'LABEL', 'SUMMARY', 'OPTION'];
  const clickable = e => {
    for (let a = e; a && a !== document.body; a = a.parentElement) {
      if (INTERACTIVE.includes(a.tagName) || a.hasAttribute('onclick') || a.getAttribute('role') === 'button'
          || a.getAttribute('role') === 'link' || a.getAttribute('role') === 'tab') return a;
    }
    return e;
  };
  // Utility/state classes say nothing about which element this is.
  const NOISE = /^(active|show|fade|in|open|disabled|selected|d-.*|p[xytbse]?-.*|m[xytbse]?-.*|col(-.*)?|row|text-.*|fw-.*|fs-.*|btn|btn-(primary|secondary|success|danger|warning|info|light|dark|link|sm|lg|outline.*)|align-.*|justify-.*|flex.*|border.*|rounded.*|bg-.*|shadow.*|w-.*|h-.*|position-.*|float-.*|mb-.*|mt-.*)$/;
  // Classes and attributes developers add as hooks for scripts and tests are the most stable.
  const HOOK = /(_h|-js|_js)$|^(js|qa|test|e2e|t)[-_]/i;
  const TEST_ATTRS = ['data-testid', 'data-test-id', 'data-test', 'data-qa', 'data-cy', 'data-automation-id'];
  // State classes change as the page is used ("non-active-icon" becomes "active-icon").
  const STATE = /(^|[-_])(non[-_]?|in|is[-_]|un)?(active|selected|current|open|opened|closed|expanded|collapsed|checked|hover|hovered|focus|focused|disabled|enabled|visible|hidden|shown|show|on|off)([-_]|$)/i;
  // A hook class is never a state class, even when it contains a state word ("show_rnr_dashboard_h").
  const plain = c => !NOISE.test(c) && (HOOK.test(c) || !STATE.test(c));
  const classesOf = e => [...e.classList].filter(plain).sort((a, b) => HOOK.test(b) - HOOK.test(a));
  const selector = e => {
    const tag = e.tagName.toLowerCase();
    for (const attr of TEST_ATTRS) {
      const v = e.getAttribute(attr);
      if (v) { const s = '[' + attr + '="' + CSS.escape(v) + '"]'; if (document.querySelectorAll(s).length === 1) return s; }
    }
    if (stableId(e.id) && document.querySelectorAll('#' + CSS.escape(e.id)).length === 1) return '#' + CSS.escape(e.id);
    const classes = classesOf(e);
    for (const c of classes) { const s = tag + '.' + CSS.escape(c); if (document.querySelectorAll(s).length === 1) return s; }
    if (e.name) { const s = tag + '[name="' + CSS.escape(e.name) + '"]'; if (document.querySelectorAll(s).length === 1) return s; }
    // No identity of its own (e.g. tab bar links): the tag plus its text, scoped to the nearest
    // ancestor that has one, as long as that pins down this one element.
    const text = textOf(e);
    const unique = css => text && [...document.querySelectorAll(css)].filter(x => textOf(x) === text).length === 1;
    const own = classes.length ? tag + '.' + CSS.escape(classes[0]) : tag;
    for (let a = e.parentElement; a && a !== document.body; a = a.parentElement) {
      let anchor = null;
      if (stableId(a.id) && document.querySelectorAll('#' + CSS.escape(a.id)).length === 1) anchor = '#' + CSS.escape(a.id);
      else for (const c of classesOf(a))
        if (document.querySelectorAll(a.tagName.toLowerCase() + '.' + CSS.escape(c)).length === 1) { anchor = a.tagName.toLowerCase() + '.' + CSS.escape(c); break; }
      if (anchor && unique(anchor + ' ' + own)) return anchor + ' ' + own;
    }
    // Text, dialog, or the card/row it's in (describe's scope) narrow it down; a position
    // path is only the last resort there.
    return own;
  };
  const positionPath = e => {
    const parts = [];
    for (let a = e; a && a.nodeType === 1 && a !== document.body; a = a.parentElement) {
      let i = 1; for (let s = a.previousElementSibling; s; s = s.previousElementSibling) if (s.tagName === a.tagName) i++;
      parts.unshift(a.tagName.toLowerCase() + ':nth-of-type(' + i + ')');
    }
    return 'body > ' + parts.join(' > ');
  };
  // A card's or row's title: its first piece of text (cards hold more text than fits a locator).
  const headOf = a => {
    let n = 0;
    for (const d of a.querySelectorAll('*')) {
      if (++n > 60) break;
      const own = [...d.childNodes].filter(c => c.nodeType === 3).map(c => c.textContent).join(' ');
      const t = norm(own);
      if (t && /[^\d\W_]/.test(t)) return t;
    }
    return null;
  };
  // Rendered and not hidden -- though maybe scrolled out of view.
  const shown = e => {
    const r = e.getBoundingClientRect();
    if (!r.width || !r.height) return false;
    const cs = getComputedStyle(e);
    return !(cs.visibility === 'hidden' || cs.display === 'none' || cs.opacity === '0');
  };
  const onTop = e => {
    if (!shown(e)) return false;
    const r = e.getBoundingClientRect();
    const cx = r.left + r.width / 2, cy = r.top + r.height / 2;
    if (cx < 0 || cy < 0 || cx > innerWidth || cy > innerHeight) return false;
    const top = document.elementFromPoint(cx, cy);
    return !!top && (top === e || e.contains(top) || top.contains(e));
  };
  const rect = e => { const r = e.getBoundingClientRect(); return [r.left, r.top, r.width, r.height]; };
  const isWithin = (e, w) => {
    for (let a = e.parentElement; a && a !== document.body; a = a.parentElement)
      if (a.matches(w.css) && (!w.text || (w.exact ? textOf(a) === w.text : sameText(textOf(a), w.text)))
          && (!w.head || sameText(headOf(a) || '', w.head))) return true;
    return false;
  };
  const matches = loc => {
    let els = [...document.querySelectorAll(loc.css)];
    if (loc.text) els = els.filter(e => loc.exact ? textOf(e) === loc.text : sameText(textOf(e), loc.text));
    if (loc.dialog) els = els.filter(e => sameText(popupTitle(e) || '', loc.dialog));
    if (loc.context) els = els.filter(e => shape(context(e) || '').startsWith(shape(loc.context).slice(0, 40)));
    if (loc.within) els = els.filter(e => isWithin(e, loc.within));
    return els;
  };
  // When a locator matches several elements (e.g. every tile's icon shares
  // "div.icon-bg"), scope it to the nearest ancestor that makes it unique: one
  // with a unique id/class, or a small one with its own text (the tile's label).
  const scope = (e, base) => {
    const area = innerWidth * innerHeight;
    for (let a = e.parentElement; a && a !== document.body; a = a.parentElement) {
      const tag = a.tagName.toLowerCase();
      const options = [];
      if (stableId(a.id) && document.querySelectorAll('#' + CSS.escape(a.id)).length === 1) options.push({css: '#' + CSS.escape(a.id)});
      const classes = classesOf(a);
      for (const c of classes)
        if (document.querySelectorAll(tag + '.' + CSS.escape(c)).length === 1) { options.push({css: tag + '.' + CSS.escape(c)}); break; }
      const raw = textOf(a), t = stable(raw), r = a.getBoundingClientRect();
      if (t && t.length <= 60 && r.width * r.height < 0.25 * area) {
        const css = classes.length ? tag + '.' + CSS.escape(classes[0]) : tag;
        options.push({css, text: t});
        // "Officer 1" vs "Officer 2": the number is what tells them apart -- keep it, matched exactly.
        if (t !== raw) options.push({css, text: raw, exact: true});
      }
      // A bigger card or row, named by its title ("the balance in the card titled Furniture").
      const head = headOf(a);
      if (head && head.length <= 60 && r.width * r.height < 0.4 * area)
        options.push({css: classes.length ? tag + '.' + CSS.escape(classes[0]) : tag, head: stable(head)});
      for (const within of options) if (matches({...base, within}).filter(shown).length === 1) return within;
    }
    return null;
  };
  // Things a finger is meant to tap: controls, elements with click/role/tab hints, and small
  // icons (which often get their click handler from a parent, so carry no hint themselves).
  const TAP_ROLES = ['button', 'link', 'tab', 'checkbox', 'radio', 'menuitem', 'option', 'switch'];
  const tappable = e => INTERACTIVE.includes(e.tagName) || e.hasAttribute('onclick')
    || TAP_ROLES.includes(e.getAttribute('role')) || (e.hasAttribute('tabindex') && e.tabIndex >= 0)
    || getComputedStyle(e).cursor === 'pointer'
    // Script-bound controls, marked by the app's hook classes or test attributes.
    || [...e.classList].some(c => HOOK.test(c)) || TEST_ATTRS.some(t => e.hasAttribute(t));
  const iconLike = e => {
    const r = e.getBoundingClientRect();
    return r.width > 0 && r.height > 0 && r.width <= 48 && r.height <= 48
      && (['I', 'SVG', 'IMG', 'svg'].includes(e.tagName) || /icon|ico-|fa-|material/i.test(String(e.className)) || !!e.id);
  };
  const distanceTo = (e, x, y) => {
    const r = e.getBoundingClientRect();
    return Math.hypot(Math.max(r.left - x, 0, x - r.right), Math.max(r.top - y, 0, y - r.bottom));
  };
  // Chrome doesn't need an exact hit: a tap a few pixels off a small control is
  // snapped to it ("touch adjustment"). So when the finger landed on something
  // that isn't tappable, credit a tappable element or icon under the
  // fingertip's contact area (its radius, reported by the touch; 12 page px if
  // unknown) -- the smallest such target, as a finger landing next to a tiny
  // icon and a wide field is aiming at the icon.
  const adjusted = (x, y, hit, radius) => {
    if (tappable(clickable(hit)) || iconLike(hit)) return hit;
    const reach = Math.min(Math.max(radius || 12, 6), 24);
    const found = new Set();
    for (let r = 3; r <= reach; r += 3)
      for (let a = 0; a < 16; a++) {
        const el = document.elementFromPoint(x + r * Math.cos(a * Math.PI / 8), y + r * Math.sin(a * Math.PI / 8));
        if (!el || el === hit || el.contains(hit)) continue;
        const target = tappable(clickable(el)) ? clickable(el) : (iconLike(el) ? el : null);
        if (target && distanceTo(target, x, y) <= reach) found.add(target);
      }
    const area = e => { const r = e.getBoundingClientRect(); return r.width * r.height; };
    const ranked = [...found].sort((a, b) => area(a) - area(b) || distanceTo(a, x, y) - distanceTo(b, x, y));
    return ranked[0] || hit;
  };
  // The text that names a control from outside it: its <label>, aria-labelledby, or a short
  // caption just before it (a form row's label, a tile's title).
  const labelOf = e => {
    if (e.labels && e.labels[0]) return textOf(e.labels[0]) || null;
    const by = e.getAttribute('aria-labelledby');
    if (by) { const l = document.getElementById(by.split(' ')[0]); if (l) return textOf(l) || null; }
    for (const s of [e.previousElementSibling, e.parentElement && e.parentElement.previousElementSibling]) {
      const t = s && textOf(s);
      if (t && t.length <= 40) return t;
    }
    return null;
  };
  const valueLike = e => e.tagName === 'SELECT' || e.tagName === 'TEXTAREA'
    || (e.tagName === 'INPUT' && !['submit', 'button', 'reset'].includes(e.type));
  // Everything kept about an element so it can be found again if its selector breaks
  // (self-healing); read at touch time, from the element itself.
  const fpOf = e => {
    const r = e.getBoundingClientRect();
    const attr = n => e.getAttribute(n) || null;
    return {tag: e.tagName.toLowerCase(), id: e.id || null, name: attr('name'), type: attr('type'),
            placeholder: attr('placeholder'), aria: attr('aria-label'), role: attr('role'),
            href: attr('href'), classes: classesOf(e).slice(0, 6),
            // A field's text is its value (typed, or the current choice), not its name.
            text: valueLike(e) ? null : (textOf(e) || null), label: labelOf(e), context: context(e),
            pos: [(r.left + r.width / 2) / innerWidth, (r.top + r.height / 2) / innerHeight]};
  };
  // Similarity of two strings, 0-1 (character-pair overlap), after normalising case and spaces.
  const sim = (a, b) => {
    a = norm(a).toLowerCase(); b = norm(b).toLowerCase();
    if (!a || !b) return 0;
    if (a === b) return 1;
    const [short, long] = a.length <= b.length ? [a, b] : [b, a];
    const at = long.indexOf(short);
    if (at >= 0) {
      const ratio = short.length / long.length;
      // A word or two added or dropped ("Log in" -> "Log in now") vs. a mere substring ("No" in "Note").
      const wordy = !/\w/.test(long[at - 1] || '') && !/\w/.test(long[at + short.length] || '');
      return wordy ? 0.6 + 0.4 * ratio : 0.85 * ratio + 0.1;
    }
    const pairs = s => { const m = new Map(); for (let i = 0; i < s.length - 1; i++) { const p = s.slice(i, i + 2); m.set(p, (m.get(p) || 0) + 1); } return m; };
    const pa = pairs(a), pb = pairs(b);
    let common = 0; for (const [p, n] of pa) common += Math.min(n, pb.get(p) || 0);
    return (2 * common) / (Math.max(a.length - 1, 1) + Math.max(b.length - 1, 1));
  };
  const idSim = (a, b) => {
    if (!a || !b) return 0;
    if (a === b) return 1;
    const tokens = s => new Set(s.split(/[_\-.\s]+|(?<=[a-z])(?=[A-Z])/).filter(Boolean).map(t => t.toLowerCase()));
    const ta = tokens(a), tb = tokens(b);
    const common = [...ta].filter(t => tb.has(t)).length;
    return Math.max(common / new Set([...ta, ...tb]).size, sim(a, b)) * 0.9;
  };
  // The control a touch operated. Buttons, links, onclick and ARIA roles are recognised
  // directly; otherwise (a script-bound <span> or card with an icon inside) the nearest
  // control-sized ancestor carrying a hook class or test attribute, an onclick, or a
  // pointer cursor -- so the step names the toggle, not the icon drawn in it.
  const control = hit => {
    const e = clickable(hit);
    if (e !== hit || INTERACTIVE.includes(e.tagName)) return e;
    const area = innerWidth * innerHeight;
    const small = a => { const r = a.getBoundingClientRect(); return r.width * r.height <= 0.3 * area; };
    for (let a = hit, depth = 0; a && a !== document.body && depth < 4 && small(a); a = a.parentElement, depth++)
      if ([...a.classList].some(c => HOOK.test(c)) || TEST_ATTRS.some(t => a.hasAttribute(t)) || a.hasAttribute('onclick'))
        return a;
    // A pointer cursor is inherited by everything inside a control; the control is where it starts.
    for (let a = hit, depth = 0; a && a !== document.body && depth < 4 && small(a); a = a.parentElement, depth++)
      if (getComputedStyle(a).cursor === 'pointer'
          && !(a.parentElement && getComputedStyle(a.parentElement).cursor === 'pointer')) return a;
    return hit;
  };
  const describe = hit => {
    const e = control(hit);
    const r = e.getBoundingClientRect();
    // A full-screen layer that isn't a control -- e.g. a loading mask: taps on it do nothing.
    const overlay = e === hit && !INTERACTIVE.includes(e.tagName) && !e.hasAttribute('onclick')
                    && r.width * r.height > 0.5 * innerWidth * innerHeight;
    // A field's text is its value (a <select>'s is every option) -- it changes, so it isn't used to find it.
    // The popup it's in narrows it down only when needed -- and then by the popup's title,
    // not its opening text, which often holds names, amounts or dates.
    const loc = {css: selector(e), text: valueLike(e) ? '' : stable(textOf(e)), context: null};
    // Uniqueness as playback sees it: only rendered elements count (a hidden twin -- e.g. a
    // menu button's open-state copy -- is never tapped).
    const live = l => matches(l).filter(shown);
    let count = live(loc).length;
    // Numbers are made generic ("#") only when that still singles the element out; when the
    // number is what tells it apart ("Casual Leave for Officer 1" vs "... 2"), keep it, exactly.
    const title = popupTitle(e);
    if (count > 1 && e.closest(DIALOG)) {
      if (title && live({...loc, dialog: stable(title)}).length < count) { loc.dialog = stable(title); count = live(loc).length; }
      if (count > 1 && live({...loc, context: context(e)}).length < count) { loc.context = context(e); count = live(loc).length; }
    }
    if (count > 1 && loc.text && loc.text !== textOf(e)) {
      const exact = {...loc, text: textOf(e), exact: true};
      const n = live(exact).length;
      if (n < count) { Object.assign(loc, exact); count = n; }
    }
    let within = null;
    if (count > 1) { within = scope(e, loc); if (within) count = 1; }
    // Nothing identifies it, even with the card or row it's in: its position, as a last resort.
    if (count > 1) { const path = positionPath(e); if (live({...loc, css: path}).length === 1) { loc.css = path; count = 1; } }
    return {...loc, exact: !!loc.exact, popup: title || (e.closest(DIALOG) ? context(e) : null), within, count, tag: e.tagName.toLowerCase(), id: e.id || null, rect: rect(e), tappable: tappable(e),
            in_dialog: !!e.closest(DIALOG), overlay, fp: fpOf(e), full_text: valueLike(e) ? '' : fullText(e)};
  };
  // Elements on the page that might be the fingerprinted one, best first: [{score, sims, rect, on_top, loc}].
  // The best one is scrolled into view if it isn't (as a tap on it would need).
  const heal = (fp, within, near) => {
    const pool = new Set();
    const add = els => { for (const e of els) if (pool.size < 800) pool.add(e); };
    if (fp.tag) add(document.getElementsByTagName(fp.tag));
    for (const c of fp.classes || []) add(document.getElementsByClassName(c));
    add(document.querySelectorAll('button, a, input, select, textarea, label, [onclick], [role], [tabindex]'));
    const scored = [];
    for (const e of pool) {
      if (!shown(e)) continue;
      const c = fpOf(e), w = {}, sims = {};
      const f = (k, weight, s) => { w[k] = weight; sims[k] = s; };
      if (fp.id) f('id', 3, idSim(fp.id, c.id));
      if (fp.text) f('text', 3, Math.max(sim(fp.text, c.text), sim(fp.text, c.aria)));
      if (fp.name) f('name', 2, fp.name === c.name ? 1 : idSim(fp.name, c.name));
      if (fp.placeholder) f('placeholder', 2, sim(fp.placeholder, c.placeholder));
      if (fp.aria) f('aria', 2, Math.max(sim(fp.aria, c.aria), sim(fp.aria, c.text)));
      // Text beside a field is its label; beside a button it's only a neighbour (see healing.py).
      const field = ['input', 'select', 'textarea'].includes(fp.tag) && !['submit', 'button', 'reset'].includes(fp.type);
      if (fp.label) f(field ? 'label' : 'nearby', field ? 2 : 1.5, sim(fp.label, c.label));
      if (within) f('within', 2, isWithin(e, within) ? 1 : 0);
      if (fp.context) f('context', 1.5, (c.context || '').startsWith(fp.context.slice(0, 40)) ? 1 : 0);
      if (fp.classes && fp.classes.length) {
        const common = fp.classes.filter(x => c.classes.includes(x)).length;
        f('classes', 1, common / new Set([...fp.classes, ...c.classes]).size);
      }
      if (fp.type) f('type', 1, fp.type === c.type ? 1 : 0);
      if (fp.tag) f('tag', 1, fp.tag === c.tag ? 1 : 0);
      const at = near ? [near[0] / innerWidth, near[1] / innerHeight] : fp.pos;
      if (at) f('position', 1, Math.max(0, 1 - Math.hypot(at[0] - c.pos[0], at[1] - c.pos[1]) / 0.5));
      let total = 0, sum = 0;
      for (const k in w) { total += w[k]; sum += w[k] * sims[k]; }
      if (total) scored.push({score: sum / total, sims, e});
    }
    // Classes only identify an element when no other element has (nearly) the same ones --
    // e.g. an icon's "view_hide_pwd icon-visibility", unlike every field's "form-control".
    const sameClasses = scored.filter(s => (s.sims.classes || 0) >= 0.75);
    if (sameClasses.length === 1) sameClasses[0].sims.unique_classes = 1;
    scored.sort((a, b) => b.score - a.score);
    if (scored[0] && !onTop(scored[0].e)) scored[0].e.scrollIntoView({block: 'center'});
    // A parent and its only child can score alike; keep the outermost of such pairs once.
    const out = [];
    for (const s of scored) {
      if (out.some(o => o.e.contains(s.e) || s.e.contains(o.e))) continue;
      out.push(s);
      if (out.length === 3) break;
    }
    return out.map(s => ({score: s.score, sims: s.sims, rect: rect(s.e), on_top: onTop(s.e), loc: describe(s.e)}));
  };
  return {
    describe,
    at(x, y) {
      const hit = document.elementFromPoint(x, y);
      return hit ? describe(adjusted(x, y, hit)) : null;
    },
    adjusted,
    heal,
    // Elements a check could look at: visible controls, and visible elements
    // showing their own short text (headings, messages, labels).
    listed() {
      const out = [], seen = new Set();
      for (const e of document.body.querySelectorAll('*')) {
        if (out.length >= 200) break;
        const own = [...e.childNodes].some(n => n.nodeType === 3 && n.textContent.trim());
        if (!(own || tappable(e)) || !onTop(e)) continue;
        const d = describe(e);
        const key = d.css + '|' + d.text + '|' + JSON.stringify(d.within);
        if (seen.has(key) || d.overlay) continue;
        seen.add(key);
        out.push(d);
      }
      return out;
    },
    find(loc, near) {
      const els = matches(loc);
      // Scrolled out of view (e.g. a button below a long form): scroll it in, as a user would.
      if (els.length && !els.some(onTop)) { const e = els.find(shown); if (e) e.scrollIntoView({block: 'center'}); }
      const visible = els.filter(onTop);
      // Several still match (old recordings): take the one nearest where the recording tapped.
      if (near && visible.length > 1) {
        const d = e => { const r = e.getBoundingClientRect(); return Math.hypot(r.left + r.width / 2 - near[0], r.top + r.height / 2 - near[1]); };
        visible.sort((a, b) => d(a) - d(b));
      }
      return {count: els.length, visible: visible.length, rect: visible[0] ? rect(visible[0]) : null,
              full_text: visible[0] ? fullText(visible[0]) : null,
              text: visible[0] ? textOf(visible[0]) : null};
    },
    viewport() { return [innerWidth, innerHeight, devicePixelRatio]; },
    v: HELPERS_VERSION,
  };
})();
true
""".replace("HELPERS_VERSION", str(HELPERS_VERSION))


# Records, at the moment a finger lands (touchstart, capture phase -- before
# the app's own handlers run), which element is on top there. Kept in
# sessionStorage so a tap that navigates to a new page isn't lost; installed
# into every new document of the page as well as the current one.
_TOUCH_LOGGER = r"""
(() => {
  if (window.__arpTouchLogger === 2) return true;
  window.__arpTouchLogger = 2;
  const KEY = '__arpTouches';
  // Whether the page changed within 1.2s of a touch (content, or the URL): a tap
  // that changed nothing on text that isn't a control was probably meant as a check.
  const watch = rec => {
    let mutated = 0;
    const href = location.href;
    const mo = new MutationObserver(ms => { mutated += ms.length; });
    mo.observe(document.documentElement, {subtree: true, childList: true, attributes: true, characterData: true});
    setTimeout(() => {
      mo.disconnect();
      rec.changed = mutated > 0 || location.href !== href;
      try {
        const log = JSON.parse(sessionStorage.getItem(KEY) || '[]');
        const r = log.find(x => x.t === rec.t && x.x === rec.x && x.y === rec.y);
        if (r) { r.changed = rec.changed; sessionStorage.setItem(KEY, JSON.stringify(log)); }
      } catch (e) {}
    }, 1200);
  };
  addEventListener('touchstart', ev => {
    try {
      const p = ev.touches && ev.touches[0];
      if (!p || !window.__arp) return;
      const hit = document.elementFromPoint(p.clientX, p.clientY);
      const rec = {t: Date.now(), x: p.clientX, y: p.clientY, el: hit ? window.__arp.describe(window.__arp.adjusted(p.clientX, p.clientY, hit, Math.max(p.radiusX || 0, p.radiusY || 0))) : null};
      let log = [];
      try { log = JSON.parse(sessionStorage.getItem(KEY) || '[]'); } catch (e) {}
      log.push(rec);
      try { sessionStorage.setItem(KEY, JSON.stringify(log.slice(-300))); }
      catch (e) { (window.__arpTouchBuffer = window.__arpTouchBuffer || []).push(rec); }
      watch(rec);
    } catch (e) {}
  }, {capture: true, passive: true});
  return true;
})()
"""

_DRAIN = r"""
(() => {
  // Touches younger than 1.5s stay until their "did the page change" result is in.
  const now = Date.now(), ready = r => now - r.t >= 1500 || r.changed !== undefined;
  let log = [];
  try {
    log = JSON.parse(sessionStorage.getItem('__arpTouches') || '[]');
    sessionStorage.setItem('__arpTouches', JSON.stringify(log.filter(r => !ready(r))));
  } catch (e) {}
  const buffer = window.__arpTouchBuffer || [];
  window.__arpTouchBuffer = buffer.filter(r => !ready(r));
  return log.concat(buffer).filter(ready);
})()
"""


class WebViewUnavailable(RuntimeError):
    pass


def _pid(package, serial, adb_bin):
    out = adb_utils.run(["shell", "pidof", package], serial, adb_bin).stdout.strip()
    return out.split()[0] if out else None


def devtools_socket(package, serial=None, adb_bin="adb"):
    """The app's WebView debugging socket name, or None if it has none (debugging off)."""
    pid = _pid(package, serial, adb_bin)
    if not pid:
        return None
    sockets = adb_utils.run(["shell", "cat", "/proc/net/unix"], serial, adb_bin).stdout
    name = f"webview_devtools_remote_{pid}"
    return name if f"@{name}" in sockets else None


class WebViewClient:
    """A connection to the visible page of one app's WebView. Reconnects if the app restarted."""

    def __init__(self, package, serial=None, adb_bin="adb"):
        self.package = package
        self.serial = serial
        self.adb_bin = adb_bin
        self._socket_name = None
        self._port = None
        self._ws = None
        self._ids = 0
        self._lock = threading.Lock()
        self.origin = (0, 0)  # the WebView's top-left corner on screen, in pixels
        self.scale = 1.0  # screen pixels per CSS pixel
        self.page_clock_offset = 0.0  # PC time.monotonic() minus the page's Date.now() in seconds
        self.log_touches = False  # install the touch logger (while recording)

    def _connect(self):
        name = devtools_socket(self.package, self.serial, self.adb_bin)
        if name is None:
            raise WebViewUnavailable(f"{self.package} has no debuggable WebView")
        if name != self._socket_name:
            self.close()
            out = adb_utils.run(["forward", "tcp:0", f"localabstract:{name}"], self.serial, self.adb_bin).stdout
            self._port, self._socket_name = int(out.strip()), name
        pages = json.load(urllib.request.urlopen(f"http://127.0.0.1:{self._port}/json", timeout=3))
        candidates = []
        for page in pages:
            if page.get("type") != "page":
                continue
            try:
                info = json.loads(page.get("description") or "{}")
            except ValueError:
                info = {}
            if info.get("attached", True) and info.get("visible", True) and not info.get("empty"):
                candidates.append((info.get("width", 0) * info.get("height", 0), page, info))
        if not candidates:
            raise WebViewUnavailable("no visible page in the WebView")
        _, page, info = max(candidates, key=lambda c: c[0])
        if websocket is None:  # [ours]
            raise WebViewUnavailable("websocket-client isn't installed (pip install -r requirements.txt)")
        self._ws = websocket.create_connection(page["webSocketDebuggerUrl"], timeout=5, suppress_origin=True)
        self._evaluate(_HELPERS)
        if self.log_touches:
            self._send("Page.addScriptToEvaluateOnNewDocument", {"source": _HELPERS + ";\n" + _TOUCH_LOGGER})
            self._evaluate(_TOUCH_LOGGER)
        before = time.monotonic()
        page_now = self._evaluate("Date.now()")
        self.page_clock_offset = (before + time.monotonic()) / 2 - page_now / 1000.0
        width, _height, dpr = self._evaluate("__arp.viewport()")
        self.origin = (info.get("screenX", 0), info.get("screenY", 0))
        self.scale = (info.get("width") / width) if info.get("width") and width else dpr

    def _send(self, method, params):
        self._ids += 1
        self._ws.send(json.dumps({"id": self._ids, "method": method, "params": params}))
        while True:
            reply = json.loads(self._ws.recv())
            if reply.get("id") == self._ids:
                return reply

    def _evaluate(self, expression):
        reply = self._send("Runtime.evaluate", {"expression": expression, "returnByValue": True})
        result = reply.get("result", {})
        if "exceptionDetails" in result:
            details = result["exceptionDetails"]
            description = (details.get("exception") or {}).get("description") or details.get("text")
            raise RuntimeError(f"JavaScript error in the page: {description or 'unknown'} "
                               f"(line {details.get('lineNumber')})")
        return result.get("result", {}).get("value")

    def call(self, expression):
        """Evaluate in the page, (re)connecting first if needed -- the app may have restarted."""
        with self._lock:
            for attempt in (1, 2):
                try:
                    if self._ws is None:
                        self._connect()
                    # A full page load drops the helpers; reinstall them whenever missing.
                    return self._evaluate(
                        f"if (!window.__arp || window.__arp.v !== {HELPERS_VERSION}) {{ {_HELPERS} }}\n{expression}")
                except WebViewUnavailable:
                    raise
                except Exception:  # noqa: BLE001 - stale connection/page; reconnect once
                    self._drop_ws()
                    if attempt == 2:
                        raise

    def to_css(self, x, y):
        return (x - self.origin[0]) / self.scale, (y - self.origin[1]) / self.scale

    def to_screen(self, rect):
        left, top, width, height = rect
        return (round(self.origin[0] + (left + width / 2) * self.scale),
                round(self.origin[1] + (top + height / 2) * self.scale))

    def element_at(self, x, y):
        """Web locator for the element on top at screen point (x, y), or None if it's not web content."""
        if self._ws is None:
            with self._lock:
                self._connect()
        cx, cy = self.to_css(x, y)
        if cx < 0 or cy < 0:
            return None
        found = self.call(f"__arp.at({cx}, {cy})")
        if not found:
            return None
        return _web_locator(found)

    def drain_touches(self):
        """Touches the page logged since the last call: [{"mono", "screen": (x, y), "el": web locator}]."""
        out = []
        for rec in self.call(_DRAIN) or []:
            el = rec.get("el")
            if not el:
                continue
            out.append({
                "mono": rec["t"] / 1000.0 + self.page_clock_offset,
                "screen": (round(self.origin[0] + rec["x"] * self.scale), round(self.origin[1] + rec["y"] * self.scale)),
                "el": _web_locator(el),
                "changed": rec.get("changed"),  # did the page change within 1.2s (None: unknown)
            })
        return out

    def find(self, web_locator, near=None):
        """{"count", "visible", "center": screen (x, y) or None} for a web locator, right now.

        `near` (screen x, y): if several elements match, prefer the one closest to it."""
        loc = {k: web_locator.get(k) for k in ("css", "text", "context", "within", "exact", "dialog")}
        near_css = list(self.to_css(*near)) if near else None
        found = self.call(f"__arp.find({json.dumps(loc)}, {json.dumps(near_css)})")
        found["center"] = self.to_screen(found["rect"]) if found.get("rect") else None
        return found

    def elements(self):
        """Web locators for the page's visible elements (for picking what a check should look at)."""
        return [_web_locator(found) for found in self.call("__arp.listed()") or []]

    def heal(self, web_locator, near=None):
        """Elements on screen now that might be the one `web_locator` was recorded on, best first:
        [{"score", "sims", "center", "loc"}] (see healing.py). Scored inside the page."""
        fp = dict(web_locator.get("fp") or {"tag": web_locator.get("tag"), "id": web_locator.get("id"),
                                            "text": web_locator.get("text")})
        fp["context"] = web_locator.get("context")
        near_css = list(self.to_css(*near)) if near else None
        out = []
        for cand in self.call(f"__arp.heal({json.dumps(fp)}, {json.dumps(web_locator.get('within'))}, "
                              f"{json.dumps(near_css)})") or []:
            loc = dict(_web_locator(cand["loc"]), package=web_locator.get("package"))
            loc.pop("overlay", None)
            out.append({"score": cand["score"], "sims": cand["sims"], "center": self.to_screen(cand["rect"]),
                        "on_top": cand["on_top"], "loc": loc})
        return out

    def _drop_ws(self):
        if self._ws is not None:
            try:
                self._ws.close()
            except Exception:  # noqa: BLE001
                pass
            self._ws = None

    def close(self):
        self._drop_ws()
        if self._port is not None:
            adb_utils.run(["forward", "--remove", f"tcp:{self._port}"], self.serial, self.adb_bin)
            self._port = self._socket_name = None


def _web_locator(found):
    return {"css": found["css"], "text": found["text"] or None, "context": found["context"],
            "within": found.get("within"), "matches": found.get("count", 1), "tag": found["tag"],
            "exact": bool(found.get("exact")),
            "dialog": found.get("dialog"),  # the popup's title, when needed to tell it apart
            "popup": found.get("popup"),  # the popup it's in, for naming the step only
            "id": found["id"], "in_dialog": found["in_dialog"], "overlay": bool(found.get("overlay")),
            "tappable": found.get("tappable"),
            "full_text": found.get("full_text") or None,
            "fp": found.get("fp")}


def describe(web_locator):
    text = web_locator.get("text")
    within = web_locator.get("within") or {}
    name = f'"{text}"' if text else web_locator.get("css")
    if not text and (within.get("text") or within.get("head")):
        name += f" in '{(within.get('text') or within.get('head'))[:30]}'"
    # Name the popup only when it's part of how the element is found; its heading or
    # opening text can be a person's name or an amount, which would make the step look
    # like it depends on them.
    popup = web_locator.get("dialog") or web_locator.get("context")
    if popup:
        name += f" in '{popup[:30]}'"
    elif web_locator.get("in_dialog"):
        name += " (in a popup)"
    return name

