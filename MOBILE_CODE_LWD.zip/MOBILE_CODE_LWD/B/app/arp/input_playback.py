"""Fallback playback using the high-level `adb shell input` command.

Some OEM builds (this project was hit by it on a Realme/ColorOS device) deny
`sendevent` writes to /dev/input/eventN for the `shell` user via SELinux, even
though `shell` is in the `input` group and reading via `getevent` works fine.
Recording still succeeds, but raw event playback (`player.py`) silently fails
with "Permission denied" on every event.

This module replays the *parsed* steps (taps/swipes/key presses) instead,
using `input tap` / `input swipe` / `input keyevent`, which goes through
Android's InputManager service rather than touching the device node directly,
so it works on locked-down devices too. It's lower fidelity than raw replay
(no true multi-touch, gestures collapsed to straight-line swipes, coordinates
rounded to whole screen pixels) but it's the only playback path that works
when sendevent is blocked.
"""

import re
import shlex
import subprocess
import time

from . import adb_utils
from . import locator as locator_mod

ANDROID_KEYEVENT_NAMES = {
    "VOLUME_DOWN": "KEYCODE_VOLUME_DOWN",
    "VOLUME_UP": "KEYCODE_VOLUME_UP",
    "POWER": "KEYCODE_POWER",
    "BACK": "KEYCODE_BACK",
    "HOME": "KEYCODE_HOME",
    "MENU": "KEYCODE_MENU",
    "ENTER": "KEYCODE_ENTER",
    "TAB": "KEYCODE_TAB",
    "SEARCH": "KEYCODE_SEARCH",
    "APP_SWITCH": "KEYCODE_APP_SWITCH",
    "ESCAPE": "KEYCODE_ESCAPE",
}


def get_screen_size(serial=None, adb_bin="adb"):
    result = adb_utils.run(["shell", "wm", "size"], serial=serial, adb_bin=adb_bin)
    match = re.search(r"(?:Override|Physical) size:\s*(\d+)x(\d+)", result.stdout)
    if not match:
        raise RuntimeError(f"Could not determine screen size from `wm size`: {result.stdout!r}")
    return int(match.group(1)), int(match.group(2))


def get_all_touch_bounds(serial=None, adb_bin="adb"):
    """{device_path: ((min_x, max_x), (min_y, max_y))} for every touchscreen's raw digitizer range."""
    result = adb_utils.run(["shell", "getevent", "-pl"], serial=serial, adb_bin=adb_bin)
    bounds = {}
    for block in re.split(r"(?=add device \d+: )", result.stdout):
        device = re.match(r"add device \d+: (\S+)", block)
        x_match = re.search(r"ABS_MT_POSITION_X\s*:.*?min\s+(-?\d+),\s*max\s+(-?\d+)", block)
        y_match = re.search(r"ABS_MT_POSITION_Y\s*:.*?min\s+(-?\d+),\s*max\s+(-?\d+)", block)
        if device and x_match and y_match:
            bounds[device.group(1)] = (
                (int(x_match.group(1)), int(x_match.group(2))),
                (int(y_match.group(1)), int(y_match.group(2))),
            )
    return bounds


def get_touch_bounds(device_path, serial=None, adb_bin="adb"):
    """Return ((min_x, max_x), (min_y, max_y)) for one touchscreen's raw digitizer range."""
    bounds = get_all_touch_bounds(serial, adb_bin)
    if device_path not in bounds:
        raise RuntimeError(f"Could not find ABS_MT_POSITION_X/Y range for {device_path} via `getevent -pl`")
    return bounds[device_path]


def _scale(value, src_range, dst_max):
    src_min, src_max = src_range
    if src_max == src_min:
        return 0
    fraction = (value - src_min) / (src_max - src_min)
    return max(0, min(dst_max, round(fraction * dst_max)))


class CoordinateMapper:
    """Maps a recording's raw digitizer coordinates onto the live device's screen pixels."""

    def __init__(self, serial=None, adb_bin="adb"):
        self.serial = serial
        self.adb_bin = adb_bin
        self._screen_size = None
        self._bounds_by_device = {}

    def _screen(self):
        if self._screen_size is None:
            self._screen_size = get_screen_size(self.serial, self.adb_bin)
        return self._screen_size

    def _bounds(self, device_path):
        if device_path not in self._bounds_by_device:
            self._bounds_by_device[device_path] = get_touch_bounds(device_path, self.serial, self.adb_bin)
        return self._bounds_by_device[device_path]

    def warm_up(self):
        """Look up the screen size and every touchscreen's range now, so the
        first `to_pixels` call during a recording doesn't wait on adb."""
        self._screen()
        self._bounds_by_device.update(get_all_touch_bounds(self.serial, self.adb_bin))
        return self

    def to_pixels(self, x, y, device_path):
        width, height = self._screen()
        x_range, y_range = self._bounds(device_path)
        return _scale(x, x_range, width - 1), _scale(y, y_range, height - 1)


def _run_shell(args, serial, adb_bin):
    cmd = [adb_bin]
    if serial:
        cmd += ["-s", serial]
    cmd += ["shell"] + args
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=15)
    output = ((result.stdout or "") + (result.stderr or "")).strip()
    if result.returncode != 0 or "denied" in output.lower() or "error" in output.lower():
        raise RuntimeError(f"`adb shell {' '.join(args)}` failed: {output or 'no output'}")


def play_steps(steps, serial=None, adb_bin="adb", speed=1.0, repeat=1, verbose=True):
    """Replay parsed steps (from steps.parse_events) via `adb shell input ...`."""
    if not steps:
        raise ValueError("No steps to play back")

    mapper = CoordinateMapper(serial=serial, adb_bin=adb_bin)

    for iteration in range(repeat):
        if verbose:
            print(f"Playback (input-command fallback) iteration {iteration + 1}/{repeat}: {len(steps)} steps")
        prev_end = 0.0
        for step in steps:
            gap = (step["time"] - prev_end) / speed
            if gap > 0:
                time.sleep(gap)

            kind = step["type"]
            if kind == "tap":
                x, y = mapper.to_pixels(step["start"][0], step["start"][1], step.get("device"))
                _run_shell(["input", "tap", str(x), str(y)], serial, adb_bin)
                prev_end = step["time"]
            elif kind == "long_press":
                x, y = mapper.to_pixels(step["start"][0], step["start"][1], step.get("device"))
                duration_ms = max(int(step["duration"] * 1000 / speed), 300)
                _run_shell(["input", "swipe", str(x), str(y), str(x), str(y), str(duration_ms)], serial, adb_bin)
                prev_end = step["time"] + step["duration"]
            elif kind == "swipe":
                x1, y1 = mapper.to_pixels(step["start"][0], step["start"][1], step.get("device"))
                x2, y2 = mapper.to_pixels(step["end"][0], step["end"][1], step.get("device"))
                duration_ms = max(int(step["duration"] * 1000 / speed), 50)
                _run_shell(["input", "swipe", str(x1), str(y1), str(x2), str(y2), str(duration_ms)], serial, adb_bin)
                prev_end = step["time"] + step["duration"]
            elif kind == "type":
                # No element access here: tap the field where it was recorded
                # and type into it (existing text is not cleared).
                x1, y1, x2, y2 = locator_mod.parse_bounds(step["locator"]["bounds"])
                _run_shell(["input", "tap", str((x1 + x2) // 2), str((y1 + y2) // 2)], serial, adb_bin)
                if step["text"]:
                    _run_shell(["input", "text", shlex.quote(step["text"].replace(" ", "%s"))], serial, adb_bin)
                prev_end = step["time"]
            elif kind == "select":
                # No element access here: tap the dropdown, then the option where
                # it was when recorded.
                for loc in (step["locator"], step.get("option_locator")):
                    if not loc:
                        raise RuntimeError(f"step {step['index']}: no recorded position for the option")
                    x1, y1, x2, y2 = locator_mod.parse_bounds(loc["bounds"])
                    _run_shell(["input", "tap", str((x1 + x2) // 2), str((y1 + y2) // 2)], serial, adb_bin)
                    time.sleep(0.8)
                prev_end = step["time"]
            elif kind == "key":
                keycode = ANDROID_KEYEVENT_NAMES.get(step.get("key"))
                if keycode:
                    _run_shell(["input", "keyevent", keycode], serial, adb_bin)
                prev_end = step["time"]

    if verbose:
        print("Playback complete (input-command fallback).")
