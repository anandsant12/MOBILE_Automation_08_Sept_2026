"""Talk to the recorder helper app on the phone (see helper_app/).

The helper is an Android accessibility service. Android tells it about every
click, focus change, text change and window change as it happens, together
with the element involved -- so recording needs no screen snapshots and no
Appium session. This module installs and enables it when needed, connects to
it through `adb forward`, and exposes:

  - `request(cmd, **args)` for on-demand questions ("which element is at x,y
    right now?", "list the elements on screen"), and
  - an `on_event(event)` callback for the pushed events.

Every message gets a "mono" field: the PC's time.monotonic() at which it
happened, converted from the phone's own event timestamp, so helper events
and raw `getevent` touches can be put in one timeline.
"""

import importlib.util
import itertools
import json
import re
import socket
import threading
import time
from pathlib import Path

from . import adb_utils

PACKAGE = "com.arp.helper"
SERVICE = f"{PACKAGE}/{PACKAGE}.RecorderService"
SOCKET_NAME = "arp_helper"
PROTOCOL = 1
MANIFEST_PATH = Path(__file__).resolve().parents[2] / "helper_app" / "AndroidManifest.xml"  # [ours] backend/helper_app
APK_PATH = MANIFEST_PATH.parent / "build" / "arp-helper.apk"
VERSION_PATH = APK_PATH.with_suffix(".version")


class HelperError(RuntimeError):
    pass


def _adb(args, serial, adb_bin, check=True):
    result = adb_utils.run(args, serial, adb_bin)
    if check and result.returncode != 0:
        raise HelperError(f"adb {' '.join(args)} failed: {(result.stderr or result.stdout).strip()}")
    return result.stdout.strip()


def installed_version(serial=None, adb_bin="adb"):
    """versionCode of the helper installed on the phone, or None if it isn't installed."""
    out = _adb(["shell", "dumpsys", "package", PACKAGE], serial, adb_bin, check=False)
    match = re.search(r"versionCode=(\d+)", out)
    return int(match.group(1)) if match else None


def bundled_version():
    """versionCode of the helper in this checkout (helper_app/AndroidManifest.xml)."""
    manifest = (MANIFEST_PATH).read_text(encoding="utf-8-sig")
    return int(re.search(r'android:versionCode="(\d+)"', manifest).group(1))


def _apk_version():
    """versionCode of the prebuilt APK (recorded by helper_app/build.py); 0 if unknown."""
    try:
        return int(VERSION_PATH.read_text(encoding="utf-8").strip())
    except (OSError, ValueError):
        return 0


def _build_apk():
    # helper_app/ isn't a Python package, so load its build script by path.
    spec = importlib.util.spec_from_file_location("arp_helper_build", MANIFEST_PATH.parent / "build.py")
    build = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(build)
    build.build()


def install(serial=None, adb_bin="adb"):
    if not APK_PATH.exists() or _apk_version() < bundled_version():
        _build_apk()  # needs a JDK and the Android SDK; the shipped APK normally avoids this
    result = adb_utils.run(["install", "-r", str(APK_PATH)], serial, adb_bin, timeout=180)
    out = (result.stdout + result.stderr).strip()
    if "INSTALL_FAILED_UPDATE_INCOMPATIBLE" in out:
        # Installed copy was signed with another key (built on another computer).
        _adb(["uninstall", PACKAGE], serial, adb_bin, check=False)
        result = adb_utils.run(["install", str(APK_PATH)], serial, adb_bin, timeout=180)
        out = (result.stdout + result.stderr).strip()
    if "Success" in out:
        return
    if "VERIFICATION_FAILURE" in out or "USER_RESTRICTED" in out:
        raise HelperError(
            "The phone blocked installing the recorder helper app. Watch the phone's screen and tap "
            "Install/Allow when it asks (some phones, e.g. Realme/Oppo, ask to confirm USB installs), "
            "then start recording again."
        )
    raise HelperError(f"Installing the recorder helper app failed: {out}")


def is_enabled(serial=None, adb_bin="adb"):
    enabled = _adb(["shell", "settings", "get", "secure", "enabled_accessibility_services"], serial, adb_bin)
    return SERVICE in enabled.split(":")


def enable(serial=None, adb_bin="adb"):
    """Turn the helper's accessibility service on, keeping any others the user has on."""
    current = _adb(["shell", "settings", "get", "secure", "enabled_accessibility_services"], serial, adb_bin)
    services = [s for s in current.split(":") if s and s != "null"]
    if SERVICE not in services:
        services.append(SERVICE)
        _adb(["shell", "settings", "put", "secure", "enabled_accessibility_services", ":".join(services)],
             serial, adb_bin)
    _adb(["shell", "settings", "put", "secure", "accessibility_enabled", "1"], serial, adb_bin)


def socket_listening(serial=None, adb_bin="adb"):
    return f"@{SOCKET_NAME}" in _adb(["shell", "cat", "/proc/net/unix"], serial, adb_bin, check=False)


def ensure_ready(serial=None, adb_bin="adb", timeout=8.0):
    """Install (or update) and enable the helper if needed, and wait until it's listening."""
    version = installed_version(serial, adb_bin)
    if version is not None and version >= bundled_version() and socket_listening(serial, adb_bin):
        return
    if version is None or version < bundled_version():
        install(serial, adb_bin)
    enable(serial, adb_bin)
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if socket_listening(serial, adb_bin):
            return
        time.sleep(0.3)
    raise HelperError(
        "The recorder helper is installed but Android hasn't started it. On the phone, open "
        "Settings > Accessibility > ARP Recorder Helper and turn it on (some phones block turning "
        "it on from the computer), then start recording again."
    )


class HelperClient:
    def __init__(self, serial=None, adb_bin="adb", on_event=None):
        self.serial = serial
        self.adb_bin = adb_bin
        self.on_event = on_event
        self._sock = None
        self._port = None
        self._ids = itertools.count(1)
        self._pending = {}
        self._pending_lock = threading.Lock()
        self._send_lock = threading.Lock()
        self._reader = None
        self._clock_offset = 0.0  # PC monotonic seconds minus phone uptime seconds
        self.closed = threading.Event()

    def connect(self):
        ensure_ready(self.serial, self.adb_bin)
        port = _adb(["forward", "tcp:0", f"localabstract:{SOCKET_NAME}"], self.serial, self.adb_bin)
        self._port = int(port)
        self._sock = socket.create_connection(("127.0.0.1", self._port), timeout=5)
        self._sock.settimeout(None)
        self._sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        self._reader = threading.Thread(target=self._read_loop, daemon=True)
        self._reader.start()
        self._sync_clock()
        return self

    def _sync_clock(self):
        """Estimate the phone-uptime -> PC-monotonic offset from the fastest of a few round trips."""
        best = None
        for _ in range(5):
            sent = time.monotonic()
            info = self.request("info")
            received = time.monotonic()
            if info.get("protocol") != PROTOCOL:
                raise HelperError(
                    f"The helper app on the phone speaks protocol {info.get('protocol')}, expected {PROTOCOL}: "
                    "reinstall it (python helper_app/build.py, then adb install -r)."
                )
            rtt = received - sent
            if best is None or rtt < best[0]:
                best = (rtt, (sent + received) / 2 - info["uptime"] / 1000.0)
        self._clock_offset = best[1]

    def to_mono(self, uptime_ms):
        return uptime_ms / 1000.0 + self._clock_offset

    def _read_loop(self):
        buffer = b""
        try:
            while True:
                chunk = self._sock.recv(65536)
                if not chunk:
                    break
                buffer += chunk
                while b"\n" in buffer:
                    line, buffer = buffer.split(b"\n", 1)
                    if line.strip():
                        self._dispatch(json.loads(line.decode("utf-8")))
        except OSError:
            pass
        finally:
            self.closed.set()
            with self._pending_lock:
                for waiter in self._pending.values():
                    waiter["event"].set()

    def _dispatch(self, message):
        if "event" in message:
            message["mono"] = self.to_mono(message["t"]) if "t" in message else time.monotonic()
            if self.on_event:
                try:
                    self.on_event(message)
                except Exception:  # noqa: BLE001 - a bad handler mustn't kill the connection
                    pass
            return
        with self._pending_lock:
            waiter = self._pending.get(message.get("id"))
        if waiter is not None:
            waiter["reply"] = message
            waiter["event"].set()

    def request(self, cmd, timeout=5.0, **args):
        if self._sock is None or self.closed.is_set():
            raise HelperError("Not connected to the recorder helper on the phone.")
        request_id = next(self._ids)
        waiter = {"event": threading.Event(), "reply": None}
        with self._pending_lock:
            self._pending[request_id] = waiter
        try:
            payload = (json.dumps({"id": request_id, "cmd": cmd, **args}) + "\n").encode("utf-8")
            with self._send_lock:
                self._sock.sendall(payload)
            if not waiter["event"].wait(timeout):
                raise HelperError(f"The recorder helper didn't answer '{cmd}' within {timeout:.0f}s.")
        finally:
            with self._pending_lock:
                self._pending.pop(request_id, None)
        reply = waiter["reply"]
        if reply is None:
            raise HelperError("The connection to the recorder helper on the phone was lost.")
        if not reply.get("ok"):
            raise HelperError(f"The recorder helper failed '{cmd}': {reply.get('error')}")
        result = reply.get("result") or {}
        if "t" in result:
            result["mono"] = self.to_mono(result["t"])
        return result

    def close(self):
        if self._sock is not None:
            try:
                self._sock.close()
            except OSError:
                pass
            self._sock = None
        if self._port is not None:
            _adb(["forward", "--remove", f"tcp:{self._port}"], self.serial, self.adb_bin, check=False)
            self._port = None
