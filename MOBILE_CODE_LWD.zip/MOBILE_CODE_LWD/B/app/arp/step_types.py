"""What a test step can be, how it's labelled, and test data substitution.

Recorded steps: tap, long_press, swipe, type, select, key.
Steps you add: assert (a check on an element), wait, launch_app, screenshot.

Common optional fields on any step:
  - "timeout": the most seconds to wait for the step's element (default 20); the
    step goes ahead as soon as the element appears
  - "continue_on_failure": a failure is reported but the test goes on
  - "optional": act on the element only if it appears (default wait 5s),
    otherwise skip the step -- for popups the app only sometimes shows
  - "disabled": skip the step
Text in "text", "option", "expected" and "package" may use ${name} for a
test case variable, or ${env:NAME} for an environment variable (keeps
secrets like passwords out of saved files). ${today}, ${today-30d},
${today+1d:dd-MM-yyyy} and ${now:HH:mm} are the date or time when the test runs
(default format dd/MM/yyyy) -- for date fields that must not hold the recording day.
"""

import datetime
import os
import re
import uuid

from . import locator as locator_mod

DEFAULT_TIMEOUT = 20.0
# How long an optional step waits for its element before skipping.
OPTIONAL_TIMEOUT = 5.0

CHECKS = {
    "visible": "is visible",
    "not_visible": "is not visible",
    "text_equals": "text is",
    "text_contains": "text contains",
    "text_matches": "text matches (regex)",
    "enabled": "is enabled",
    "disabled": "is disabled",
    "checked": "is checked",
    "unchecked": "is not checked",
    "selected": "is selected",
}
CHECKS_WITH_EXPECTED = {"text_equals", "text_contains", "text_matches"}

KEYS = ["BACK", "HOME", "ENTER", "TAB", "MENU", "SEARCH", "APP_SWITCH", "ESCAPE", "VOLUME_UP", "VOLUME_DOWN",
        "POWER"]

ICONS = {
    "tap": "👆", "long_press": "✋", "swipe": "👉", "key": "🔘", "type": "⌨️", "select": "🔽", "keypad": "🔢",
    "assert": "✅", "wait": "⏱️", "launch_app": "🚀", "screenshot": "📷", "run_case": "🔁", "pick_date": "📅",
    "capture": "📌",
}

# How a captured value / a text check's value is reduced before it's kept or compared.
NORMALIZE = {
    "raw": "exactly as shown",
    "trim": "trim spaces",
    "digits": "digits only",
    "number": "number (ignore ₹ and commas)",
}

_VAR = re.compile(r"\$\{([^}]+)\}")


class MissingVariable(KeyError):
    pass


# ${today}, ${today-30d}, ${today+2w:dd-MM-yyyy}, ${now:HH:mm} -- the run's date/time.
_DATE_VAR = re.compile(r"^(today|now)\s*(?:([+-])\s*(\d+)\s*([dwmy]?))?\s*(?::(.+))?$", re.I)
_DATE_TOKENS = [("yyyy", "%Y"), ("yy", "%y"), ("MMMM", "%B"), ("MMM", "%b"), ("MM", "%m"), ("dd", "%d"),
                ("HH", "%H"), ("hh", "%I"), ("mm", "%M"), ("ss", "%S"), ("a", "%p"), ("EEEE", "%A"), ("EEE", "%a")]


def is_date_variable(name):
    return bool(_DATE_VAR.match(name.strip()))


def _date_value(name, now=None):
    """The value of a date variable when the test runs (see the module docstring)."""
    m = _DATE_VAR.match(name.strip())
    base, sign, amount, unit, fmt = m.groups()
    now = now or datetime.datetime.now()
    if amount:
        n = int(amount) * (1 if sign == "+" else -1)
        unit = (unit or "d").lower()
        if unit == "d":
            now += datetime.timedelta(days=n)
        elif unit == "w":
            now += datetime.timedelta(weeks=n)
        else:   # months / years: same day, clamped to the month's length
            months = n * (12 if unit == "y" else 1)
            y, mo = divmod(now.month - 1 + months, 12)
            year, month = now.year + y, mo + 1
            for day in (now.day, 30, 29, 28):
                try:
                    now = now.replace(year=year, month=month, day=day)
                    break
                except ValueError:
                    continue
    fmt = fmt or ("dd/MM/yyyy" if base.lower() == "today" else "HH:mm")
    out, i = "", 0
    while i < len(fmt):
        for token, code in _DATE_TOKENS:
            if fmt.startswith(token, i):
                out += code
                i += len(token)
                break
        else:
            out += fmt[i].replace("%", "%%")
            i += 1
    return now.strftime(out)


_DATE_FORMATS = ("%d/%m/%Y", "%d-%m-%Y", "%Y-%m-%d", "%d.%m.%Y", "%d %B %Y", "%d %b %Y", "%A, %d %B %Y",
                 "%A %d %B %Y", "%B %d, %Y", "%d %B, %Y")


def parse_date(text):
    """A date written in any common way ("10/10/2026", "2026-10-10", "10 October 2026"), or None."""
    text = plain_spaces(text)
    for fmt in _DATE_FORMATS:
        try:
            return datetime.datetime.strptime(text, fmt).date()
        except ValueError:
            continue
    return None


def date_variable_for(text, today=None):
    """${today...} for a typed date relative to today (e.g. "03/09/2026" a month back), or None."""
    today = today or datetime.date.today()
    for fmt, java in (("%d/%m/%Y", "dd/MM/yyyy"), ("%d-%m-%Y", "dd-MM-yyyy"), ("%Y-%m-%d", "yyyy-MM-dd"),
                      ("%d.%m.%Y", "dd.MM.yyyy"), ("%d %b %Y", "dd MMM yyyy"), ("%d %B %Y", "dd MMMM yyyy"),
                      ("%A, %d %B %Y", "EEEE, dd MMMM yyyy")):
        try:
            day = datetime.datetime.strptime(text.strip(), fmt).date()
        except ValueError:
            continue
        delta = (day - today).days
        offset = "" if delta == 0 else f"{'+' if delta > 0 else '-'}{abs(delta)}d"
        suffix = "" if java == "dd/MM/yyyy" else f":{java}"
        return "${today" + offset + suffix + "}"
    return None


def plain_spaces(value):
    """Words separated by single spaces: line breaks and spacing aren't part of what text says."""
    return " ".join(str(value or "").split())


def same_text(actual, expected):
    return plain_spaces(actual) == plain_spaces(expected)


def text_check(text):
    """(check, expected) for verifying an element shows `text`: "text is" -- or, when the text
    holds a value that changes between runs (a balance, a date, the time), "text matches" the
    same words with any numbers, so the check holds tomorrow too."""
    plain = plain_spaces(text)
    if not locator_mod.volatile(plain):
        return "text_equals", text
    # Each number (1,99,95,464.00 as a whole) may be any number.
    number = r"\d[\d,]*(?:\.\d+)?"
    pattern = "".join(number if re.fullmatch(number, part) else re.escape(part)
                      for part in re.split(f"({number})", plain))
    pattern = pattern.replace(r"\ ", r"\s+")
    # Morning or afternoon, and any month, are the same check.
    pattern = re.sub(r"\b[AaPp][Mm]\b", "[AaPp][Mm]", pattern)
    pattern = locator_mod.MONTHS.sub("[A-Za-z]{3,9}", pattern)
    return "text_matches", r"^\s*" + pattern + r"\s*$"


def substitute(value, variables):
    """Replace ${name} and ${env:NAME} in a string."""
    if not isinstance(value, str) or "${" not in value:
        return value

    def repl(match):
        name = match.group(1).strip()
        if name.startswith("env:"):
            env_name = name[4:]
            if env_name not in os.environ:
                raise MissingVariable(f"environment variable {env_name} is not set")
            return os.environ[env_name]
        if name not in (variables or {}) and is_date_variable(name):
            return _date_value(name)
        if name not in (variables or {}):
            raise MissingVariable(f"test data variable '{name}' has no value")
        return str(variables[name])

    return _VAR.sub(repl, value)


def _data_strings(step):
    """Every string of a step that may hold ${variables}: typed text, options, expected values,
    and what finds its element (an account number picked from a list, as ${account})."""
    values = [step.get(f) for f in ("text", "option", "expected", "package")]
    loc = step.get("locator") or {}
    values += [v for _, v in loc.get("candidates") or []] + [loc.get("value"), loc.get("text"), loc.get("content_desc")]
    web = step.get("web") or {}
    values += [web.get("text"), web.get("full_text"), web.get("css")]
    return [v for v in values if isinstance(v, str)]


def variables_used(steps):
    names = set()
    for step in steps:
        for value in _data_strings(step):
            names.update(n.strip() for n in _VAR.findall(value)
                         if not n.strip().startswith("env:") and not is_date_variable(n))
    return sorted(names)


# A number that belongs to the account or user under test -- an account, customer or
# reference number (6+ digits): another login shows another one.
_DATA_NUMBER = re.compile(r"(?<![\d.,])\d{6,}(?![\d.,])")


def data_suggestions(steps):
    """[(index, value, name)]: steps that find their element by such a number (e.g. a tap on
    account 00000030002836619 in a list), which should be test data so the test runs with
    any account. Skips values already made ${variables}."""
    out = []
    for i, step in enumerate(steps):
        if step["type"] not in ("tap", "long_press", "select", "assert"):
            continue
        loc = step.get("locator") or {}
        names = [loc.get("text"), loc.get("content_desc"), loc.get("label"), step.get("option")]
        names += [v for s, v in loc.get("candidates") or [] if s == "accessibility id"]
        names.append((step.get("web") or {}).get("text"))
        for name in names:
            m = _DATA_NUMBER.search(name) if isinstance(name, str) and "${" not in name else None
            if m:
                out.append((i, m.group(0), _data_name(steps, i, m.group(0))))
                break
    return out


def date_suggestions(steps):
    """[(index, field, value, ${today...})]: dates typed into fields or expected by checks.
    Recorded as-is they're wrong the next day ("03/10/2026" in a date field); relative to the
    run's date they stay right ("${today}", "${today-30d}")."""
    out = []
    for i, step in enumerate(steps):
        for field in ("text", "expected", "date"):
            value = step.get(field)
            if isinstance(value, str) and "${" not in value:
                token = date_variable_for(value)
                if token:
                    out.append((i, field, value, token))
        # A day picked in a calendar ("03 October 2026"): the same day relative to the run.
        loc = step.get("locator") or {}
        if step["type"] in ("tap", "long_press", "assert") and loc:
            for name in [loc.get("content_desc"), loc.get("text")] + [v for s_, v in loc.get("candidates") or []
                                                                       if s_ == "accessibility id"]:
                token = date_variable_for(name) if isinstance(name, str) and "${" not in name else None
                if token:
                    out.append((i, "locator", name, token))
                    break
    return out


def use_date(step, field, value, token):
    """Put a ${today...} date in place of a recorded date (see date_suggestions)."""
    if field == "locator":
        name = token[2:-1]
        return make_data(step, value, name)
    step[field] = token
    return relabel(step)


def _data_name(steps, i, value):
    """A name for the variable: from the field just opened ("Select Beneficiary Account" ->
    beneficiary_account), else account_number / number."""
    for prev in reversed(steps[max(0, i - 2):i]):
        loc = prev.get("locator") or {}
        words = loc.get("text") or loc.get("label") or loc.get("content_desc") or ""
        words = re.sub(r"(?i)^(select|choose|pick|enter)\s+", "", words.strip())
        if re.search(r"[A-Za-z]{3}", words) and len(words) <= 40:
            name = re.sub(r"\W+", "_", words).strip("_").lower()
            if name:
                return name
    return "account_number" if len(value) >= 9 else "number"


def make_data(step, value, name):
    """Use ${name} in place of `value` wherever the step names or finds its element."""
    token = "${" + name + "}"
    loc = step.get("locator")
    if loc:
        loc = dict(loc)
        candidates = [(s, v.replace(value, token) if isinstance(v, str) else v) for s, v in loc.get("candidates") or []]
        # Only locators that use the value: the rest (the row's position in the list) would pick
        # whatever row is there -- another account -- when the test runs with other data.
        with_token = [c for c in candidates if isinstance(c[1], str) and token in c[1]]
        loc["candidates"] = with_token or candidates
        if with_token:
            loc["strategy"], loc["value"] = with_token[0]
        for key in ("text", "content_desc", "label"):
            if isinstance(loc.get(key), str):
                loc[key] = loc[key].replace(value, token)
        step["locator"] = loc
    if step.get("web"):
        step["web"] = {k: v.replace(value, token) if isinstance(v, str) else v for k, v in step["web"].items()}
    if step.get("fingerprint"):
        step["fingerprint"] = {k: v.replace(value, token) if isinstance(v, str) else v
                               for k, v in step["fingerprint"].items()}
    for key in ("option", "expected", "text"):
        if isinstance(step.get(key), str):
            step[key] = step[key].replace(value, token)
    return relabel(step)


def with_data(step, variables):
    """The step with ${variables} filled in where they find its element (locators, web
    locator, fingerprint). Typed text and expected values are filled in where they're used."""
    loc, web, fp = step.get("locator"), step.get("web"), step.get("fingerprint")
    parts = [v for _, v in (loc or {}).get("candidates") or []] + list((web or {}).values()) + list((fp or {}).values())
    if not any(isinstance(v, str) and "${" in v for v in parts):
        return step
    step = dict(step)
    if loc:
        loc = dict(loc)
        loc["candidates"] = [(s, substitute(v, variables)) for s, v in loc.get("candidates") or []]
        for key in ("value", "text", "content_desc", "label"):
            loc[key] = substitute(loc.get(key), variables)
        step["locator"] = loc
    if web:
        step["web"] = {k: substitute(v, variables) for k, v in web.items()}
    if fp:
        step["fingerprint"] = {k: substitute(v, variables) for k, v in fp.items()}
    return step


def new_uid():
    return uuid.uuid4().hex[:10]


def ensure_uids(steps):
    for step in steps:
        step.setdefault("uid", new_uid())
    return steps


def element_name(step, key="locator"):
    loc = step.get(key)
    if not loc and key == "locator" and step.get("web"):
        from .web_cdp import describe as describe_web  # noqa: PLC0415 - avoids importing websocket everywhere
        return describe_web(step["web"])
    return locator_mod.describe(loc) if loc else "element"


def label(step):
    """A plain-language description of a step, from its current fields."""
    kind = step["type"]
    if kind == "type":
        text = step.get("text") or ""
        if step.get("needs_value") and not text:
            return f"Type password into {element_name(step)} (enter the value before running)"
        if not text:
            return f"Clear {element_name(step)}"
        shown = text if "${" in text or not step.get("password") else "•" * len(text)
        return f"Type '{shown}' into {element_name(step)}"
    if kind == "select":
        return f"Select '{step.get('option')}' from {element_name(step)}"
    if kind == "keypad":
        text = step.get("text") or ""
        shown = text if "${" in text or not step.get("secret") else "•" * len(text)
        return f"Enter '{shown}' on {element_name(step) if step.get('locator') else 'the keypad'}"
    if kind == "assert":
        check = step.get("check", "visible")
        text = f"Check {element_name(step)} {CHECKS.get(check, check)}"
        if check in CHECKS_WITH_EXPECTED:
            expected = step.get("expected", "") or ""
            # Long texts (a whole alert message) are shortened in the name only; the check uses all of it.
            text += f" '{expected if len(expected) <= 70 else expected[:67] + '…'}'"
        return text
    if kind == "wait":
        return f"Wait {step.get('seconds', 1)}s"
    if kind == "launch_app":
        return f"{'Restart' if step.get('restart') else 'Open'} app {step.get('package')}"
    if kind == "screenshot":
        return f"Take screenshot{' ' + repr(step['name']) if step.get('name') else ''}"
    if kind == "key":
        return f"Key press: {step.get('key')}"
    if kind == "pick_date":
        where = f" in {element_name(step)}" if step.get("locator") else " in the open calendar"
        return f"Pick date {step.get('date')}{where}"
    if kind == "capture":
        how = NORMALIZE.get(step.get("normalize") or "raw")
        extra = f" ({how})" if step.get("normalize") and step.get("normalize") != "raw" else ""
        return f"Remember {element_name(step)} as ${{{step.get('var') or 'value'}}}{extra}"
    if kind == "run_case":
        return f"Run test case '{step.get('case')}' (its steps, in place of this one)"
    if kind in ("tap", "long_press") and step.get("web"):
        from .web_cdp import describe as describe_web  # noqa: PLC0415 - avoids importing websocket everywhere
        return f"{'Tap' if kind == 'tap' else 'Long press'} on {describe_web(step['web'])}"
    if kind in ("tap", "long_press") and step.get("locator"):
        text = f"{'Tap' if kind == 'tap' else 'Long press'} on {element_name(step)}"
        if step.get("checked_target") is not None:
            text += f" (to {'check' if step['checked_target'] else 'uncheck'} it -- skipped if it already is)"
        return text
    return step.get("label") or kind


def relabel(step):
    step["label"] = label(step)
    return step


def new_step(kind, **fields):
    step = {"uid": new_uid(), "index": 0, "type": kind, "time": 0.0, "duration": 0.0, **fields}
    return relabel(step)


def check_step(locator_info, check="visible", expected=None, timeout=DEFAULT_TIMEOUT, web=None):
    """A check on an element found by `locator_info`, or -- for web content -- by `web` in the page."""
    fields = {"locator": locator_info, "check": check, "timeout": timeout}
    if web:
        fields["web"] = web
    if check in CHECKS_WITH_EXPECTED:
        fields["expected"] = expected or ""
    return new_step("assert", **fields)


def element_label(node):
    """Short text describing an element from the helper's element list, for pickers."""
    if node.get("web"):
        web = node["web"]
        text = (web.get("text") or "").strip()
        return " · ".join(p for p in (f"🌐 '{text[:40]}'" if text else "🌐", web.get("css"),
                                     "in popup" if web.get("in_dialog") else None) if p)
    name = node.get("resource_id") or node.get("content_desc")
    text = (node.get("text") or "").strip().replace("\n", " ")
    cls = (node.get("class_name") or "").rsplit(".", 1)[-1]
    parts = [p for p in (f"'{text[:40]}'" if text else None, name, cls) if p]
    return " · ".join(parts)


def default_check_for(node):
    """A sensible first check for an element: its text if it shows some, else that it's visible."""
    if node.get("web"):
        text = node["web"].get("full_text") or node["web"].get("text") or ""
        return text_check(text) if text.strip() else ("visible", None)
    text = (node.get("value") if node.get("editable") else node.get("text")) or ""
    if text.strip():
        return text_check(text)
    return "visible", None
