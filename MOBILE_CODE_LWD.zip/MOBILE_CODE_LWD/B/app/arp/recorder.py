"""Record raw Linux input events from a live Android device via `adb shell getevent -t`."""

import json
import re
import subprocess
import threading
from pathlib import Path

# Example line: [   68762.965359] /dev/input/event1: 0003 0035 000001cf
LINE_RE = re.compile(
    r"^\[\s*(?P<ts>\d+\.\d+)\]\s+(?P<dev>\S+):\s+"
    r"(?P<type>[0-9a-fA-F]+)\s+(?P<code>[0-9a-fA-F]+)\s+(?P<value>[0-9a-fA-F]+)\s*$"
)


class RecordingSession:
    """Run a raw input capture that can be stopped by its owner."""

    def __init__(self, serial, output_path, adb_bin="adb", device=None, on_event=None):
        self.serial = serial
        self.output_path = Path(output_path)
        self.adb_bin = adb_bin
        self.device = device
        self.on_event = on_event
        self.process = None
        self._thread = None
        self._count = 0
        self._lock = threading.Lock()
        self._error = None

    @property
    def count(self):
        with self._lock:
            return self._count

    def start(self):
        cmd = [self.adb_bin]
        if self.serial:
            cmd += ["-s", self.serial]
        cmd += ["shell", "getevent", "-t"]
        if self.device:
            cmd.append(self.device)

        output = self.output_path.open("w", encoding="utf-8")
        try:
            self.process = subprocess.Popen(
                cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1
            )
        except Exception:
            output.close()
            raise

        self._thread = threading.Thread(target=self._capture, args=(output,), daemon=True)
        self._thread.start()
        return self

    def _capture(self, output):
        last_ts = None
        try:
            for line in self.process.stdout:
                match = LINE_RE.match(line.strip())
                if not match:
                    continue

                ts = float(match.group("ts"))
                delay = 0.0 if last_ts is None else max(ts - last_ts, 0.0)
                last_ts = ts
                event = {
                    "ts": ts,  # the device's own clock (seconds since boot) when the event happened
                    "delay": round(delay, 6),
                    "device": match.group("dev"),
                    "type": match.group("type"),
                    "code": match.group("code"),
                    "value": match.group("value"),
                }
                output.write(json.dumps(event) + "\n")
                with self._lock:
                    self._count += 1
                if self.on_event:
                    self.on_event(event)
        except Exception as exc:
            self._error = exc
        finally:
            output.close()

    def stop(self):
        if self.process and self.process.poll() is None:
            self.process.terminate()
            try:
                self.process.wait(timeout=3)
            except subprocess.TimeoutExpired:
                self.process.kill()
                self.process.wait()
        if self._thread:
            self._thread.join(timeout=3)
            if self._thread.is_alive():
                raise RuntimeError("Recording process did not stop cleanly")
        if self._error:
            raise RuntimeError(f"Recording failed: {self._error}") from self._error
        return self.count


def record(serial, output_path, adb_bin="adb", device=None, verbose=True):
    """Capture raw input events until interrupted (Ctrl+C) and save them as JSONL.

    Using `getevent -t` (no `-l`) gives raw hex type/code/value triples, which map
    directly onto the arguments `sendevent` expects during playback -- no lookup
    table of event-code names is needed.
    """
    session = RecordingSession(serial, output_path, adb_bin, device).start()

    if verbose:
        print("Recording started. Interact with the device now.")
        print("Press Ctrl+C here to stop.")

    try:
        while session._thread.is_alive():
            session._thread.join(timeout=0.25)
    except KeyboardInterrupt:
        pass
    finally:
        count = session.stop()

    if verbose:
        print(f"Recording stopped. {count} events saved to {session.output_path}")

    return count
