"""Screens seen while recording: the elements on the phone's screen around each step, saved so
checks can be added to a test case later -- on that step's element or anything else that was on
its screen -- without the phone being on that screen (or the app logged in) then.

Only used for picking what a check looks at; recording and playback never depend on them.
Stored by content (identical screens are kept once) in test_cases/screens/<id>.json, and a step
refers to them by id: "screen" (the screen it acted on) and "screen_after" (the one it led to).
"""

import hashlib
import json
from pathlib import Path

DIR = Path(__file__).resolve().parents[2] / "recordings" / "screens"  # [ours] backend/recordings/screens


def save(elements, directory=DIR):
    """Store a screen's elements; returns its id (None when there's nothing to keep)."""
    elements = [e for e in elements or [] if not e.get("web")]
    if not elements:
        return None
    data = json.dumps(elements, ensure_ascii=False, sort_keys=True)
    screen_id = hashlib.sha1(data.encode("utf-8")).hexdigest()[:16]
    directory = Path(directory)
    path = directory / f"{screen_id}.json"
    if not path.exists():
        directory.mkdir(parents=True, exist_ok=True)
        path.write_text(data, encoding="utf-8")
    return screen_id


def load(screen_id, directory=DIR):
    """A saved screen's elements ([] when it's missing)."""
    if not screen_id:
        return []
    try:
        return json.loads((Path(directory) / f"{screen_id}.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return []


def assign(steps, captures, t0):
    """Point each step at the screens around it. `captures`: [(mono, screen_id)] in time order,
    each taken once the screen had settled; steps carry "time" (seconds since `t0`)."""
    if not captures:
        return steps
    times = [t0 + s.get("time", 0.0) for s in steps]
    for i, step in enumerate(steps):
        mono = times[i]
        later = next((t for t in times[i + 1:] if t > mono), float("inf"))
        before = [sid for t, sid in captures if t <= mono]
        after = [sid for t, sid in captures if mono < t <= later]
        if before:
            step["screen"] = before[-1]
        if after:
            step["screen_after"] = after[-1]
    return steps
