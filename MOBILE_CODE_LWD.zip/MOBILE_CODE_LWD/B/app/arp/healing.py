"""Element fingerprints, and finding an element again when its locators break ("self-healing").

Recording keeps, for each element a step acts on, a *fingerprint*: its own
attributes (id, text, description, hint, class, flags, where it was) plus
what surrounded it at the moment it was touched -- the text beside it (a
field's label), the text inside it (a button's caption), the nearest named
ancestors (the card or list row it's in). It comes from the helper app's
touch/click/focus events, not from screen snapshots.

At playback, when none of a step's locators match for a while, a few
targeted Appium queries built from the fingerprint (same id name, same or
similar text, "the Button next to the label 'Employee code'"...) collect
possible matches; each is scored against the fingerprint, and the best one
is used only if it's a confident, clear winner. Otherwise the step fails as
before, listing the near-misses (what a future LLM tier would choose from).
A healed step passes, marked 🩹, with a new locator that can be saved into
the test case.

Web content in a WebView is healed the same way inside the page (see
web_cdp `heal`).
"""

import difflib
import re

from appium.webdriver.common.appiumby import AppiumBy

from . import locator as locator_mod

# A healed element must score at least this (0-1) ...
ACCEPT = 0.6
# ... and beat the runner-up by this much.
MARGIN = 0.1
# How long a step's own locators get before healing is tried, and how often after that.
HEAL_AFTER = 4.0
HEAL_EVERY = 2.0
MAX_CANDIDATES = 15
# Features that can identify an element on their own; position and class can't.
STRONG = ("id", "text", "desc", "hint", "label", "inner", "name", "placeholder", "aria", "within",
          "unique_classes")

NATIVE_KEYS = ("resource_id", "text", "content_desc", "class_name", "hint", "package", "bounds",
               "clickable", "checkable", "editable", "password", "scrollable")
GENERIC_CLASSES = {"android.view.View", "android.view.ViewGroup", "android.widget.FrameLayout",
                   "android.widget.LinearLayout", "android.widget.RelativeLayout"}


# ---------------------------------------------------------------- capture ---

def fingerprint(node, window=None, use_text=True):
    """Fingerprint of an element the helper reported (see RecorderService.nodeJson).

    use_text=False for elements whose text is a value, not a name (a text
    field's typed text, a dropdown's current choice)."""
    if not node:
        return None
    fp = {k: node.get(k) for k in NATIVE_KEYS if node.get(k) not in (None, "", False)}
    if not use_text or node.get("editable"):
        fp.pop("text", None)
    # A changing value (a balance, the time) can't recognise the element on a later run, and
    # isn't written into the test.
    for key in ("text", "content_desc"):
        if locator_mod.volatile(fp.get(key), locator_mod.is_choice(node)):
            fp.pop(key)
    context = node.get("context") or {}
    for key in ("ancestors", "inner_text", "sibling_text"):
        if context.get(key):
            values = context[key]
            if key != "ancestors":
                values = [t for t in values if not locator_mod.volatile(t)]
            else:
                values = [{k: v for k, v in a.items() if not (k == "content_desc" and locator_mod.volatile(v))}
                          for a in values]
            if values:
                fp[key] = values
    for key in ("labeled_by", "index", "sibling_count", "parent_class"):
        if context.get(key) not in (None, ""):
            fp[key] = context[key]
    if window:
        fp["window"] = {k: window.get(k) for k in ("title", "type") if window.get(k)}
        if window.get("bounds") and node.get("bounds"):
            fp["screen"] = _size(window["bounds"])
    return fp


def fingerprint_from_locator(locator_info, use_text=True):
    """A thinner fingerprint for steps recorded before fingerprints existed."""
    if not locator_info:
        return None
    keys = ("resource_id", "text", "content_desc", "class_name", "bounds") if use_text else \
        ("resource_id", "content_desc", "class_name", "bounds")
    fp = {k: locator_info.get(k) for k in keys if locator_info.get(k)}
    return fp if set(fp) - {"class_name", "bounds"} else None


def _size(bounds):
    x1, y1, x2, y2 = locator_mod.parse_bounds(bounds)
    return [x2, y2] if x1 == 0 and y1 == 0 else [x2 - x1, y2 - y1]


# ---------------------------------------------------------------- scoring ---

def _norm(s):
    return re.sub(r"\s+", " ", str(s or "")).strip().casefold()


def text_similarity(a, b):
    a, b = _norm(a), _norm(b)
    if not a or not b:
        return 0.0
    if a == b:
        return 1.0
    short, long_ = sorted((a, b), key=len)
    if short in long_:
        ratio = len(short) / len(long_)
        # A word or two added or dropped ("Log in" -> "Log in now") vs. a mere substring ("No" in "Note").
        if re.search(rf"(?<!\w){re.escape(short)}(?!\w)", long_):
            return 0.6 + 0.4 * ratio
        return 0.85 * ratio + 0.1
    return difflib.SequenceMatcher(None, a, b).ratio()


def _id_name(resource_id):
    return (resource_id or "").rsplit(":id/", 1)[-1]


def _tokens(name):
    return {t for t in re.split(r"[_\-.\s]+|(?<=[a-z])(?=[A-Z])", name or "") if t}


def id_similarity(a, b):
    a, b = _id_name(a), _id_name(b)
    if not a or not b:
        return 0.0
    if a == b:
        return 1.0
    ta, tb = {t.lower() for t in _tokens(a)}, {t.lower() for t in _tokens(b)}
    jaccard = len(ta & tb) / len(ta | tb) if ta and tb else 0.0
    return max(jaccard, difflib.SequenceMatcher(None, a.lower(), b.lower()).ratio()) * 0.9


def _center(bounds):
    x1, y1, x2, y2 = locator_mod.parse_bounds(bounds)
    return (x1 + x2) / 2, (y1 + y2) / 2


def score_native(fp, cand, screen):
    """(score 0-1, {feature: similarity}) of a candidate element against a fingerprint.

    `cand` holds the candidate's attributes plus "anchors": the context
    features (label/inner/ancestor) whose targeted query found it."""
    weights, sims = {}, {}

    def feature(name, weight, similarity):
        weights[name], sims[name] = weight, similarity

    if fp.get("resource_id"):
        feature("id", 3, id_similarity(fp["resource_id"], cand.get("resource_id")))
    if fp.get("text"):
        feature("text", 3, max(text_similarity(fp["text"], cand.get("text")),
                               text_similarity(fp["text"], cand.get("content_desc"))))
    if fp.get("content_desc"):
        feature("desc", 2, max(text_similarity(fp["content_desc"], cand.get("content_desc")),
                               text_similarity(fp["content_desc"], cand.get("text"))))
    if fp.get("hint"):
        feature("hint", 2, max(text_similarity(fp["hint"], cand.get("hint")),
                               text_similarity(fp["hint"], cand.get("text"))))
    if fp.get("sibling_text") or fp.get("labeled_by"):
        # Text beside a field is its label, which names it; beside a button it's only a
        # neighbour, which all its siblings share -- context, not identity.
        field = fp.get("editable") or fp.get("labeled_by")
        feature("label" if field else "nearby", 2 if field else 1.5, 1.0 if "label" in cand["anchors"] else 0.0)
    if fp.get("inner_text"):
        # Some frameworks (Compose) merge a button's label into the button itself.
        own = [cand.get("text"), cand.get("content_desc")]
        merged = max((text_similarity(t, o) for t in fp["inner_text"][:3] for o in own), default=0.0)
        feature("inner", 2, 1.0 if "inner" in cand["anchors"] else merged)
    if fp.get("ancestors"):
        feature("ancestor", 1.5, 1.0 if "ancestor" in cand["anchors"] else 0.0)
    if fp.get("class_name"):
        feature("class", 1, 1.0 if fp["class_name"] == cand.get("class_name") else 0.0)
    if fp.get("bounds") and cand.get("bounds") and screen:
        (fx, fy), (cx, cy) = _center(fp["bounds"]), _center(cand["bounds"])
        rec_w, rec_h = fp.get("screen") or screen
        dx, dy = fx / rec_w - cx / screen[0], fy / rec_h - cy / screen[1]
        feature("position", 1, max(0.0, 1 - (dx * dx + dy * dy) ** 0.5 / 0.5))
    total = sum(weights.values())
    if not total:
        return 0.0, sims
    return sum(weights[k] * sims[k] for k in weights) / total, sims


def pick(scored):
    """The confident winner among [(score, sims, candidate)], or None.

    Needs ACCEPT overall, a clear MARGIN over the runner-up, and at least one
    identifying feature (not just "a Button near the same spot")."""
    if not scored:
        return None
    scored = sorted(scored, key=lambda s: -s[0])
    best = scored[0]
    runner_up = scored[1][0] if len(scored) > 1 else 0.0
    strong = any(best[1].get(k, 0) >= 0.8 for k in STRONG)
    if best[0] >= ACCEPT and best[0] - runner_up >= MARGIN and strong:
        return best
    return None


def matched_features(sims):
    return [k for k, v in sorted(sims.items(), key=lambda kv: -kv[1]) if v >= 0.8]


# ------------------------------------------------------------ native heal ---

def _lit(value):
    return locator_mod._xpath_literal(value)


_UPPER = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"


def _ci(attr, value):
    """Case-insensitive XPath 1.0 equality on an attribute."""
    return f"translate(normalize-space(@{attr}), '{_UPPER}', '{_UPPER.lower()}')={_lit(_norm(value))}"


def native_queries(fp):
    """Targeted queries for elements that might be the fingerprinted one: [(xpath, anchor or None)].

    Cheapest and most specific first; each returns a handful of elements, never the whole screen."""
    cls = fp.get("class_name")
    kind = cls if cls and cls not in GENERIC_CLASSES and re.fullmatch(r"[\w.$]+", cls) else "*"
    queries = []
    name = _id_name(fp.get("resource_id"))
    if name:
        queries.append((f"//*[contains(@resource-id, {_lit('/' + name if ':id/' in fp['resource_id'] else name)})]",
                        None))
    for attr, key in (("text", "text"), ("content-desc", "content_desc"), ("hint", "hint")):
        value = fp.get(key)
        if value and len(value) <= 80:
            queries.append((f"//*[{_ci(attr, value)} or {_ci('text' if attr != 'text' else 'content-desc', value)}]",
                            None))
            words = sorted((w for w in re.findall(r"\w+", value) if len(w) >= 4), key=len, reverse=True)
            if words:
                queries.append((f"//*[contains(translate(@{attr}, '{_UPPER}', '{_UPPER.lower()}'), "
                                f"{_lit(words[0].casefold())})]", None))
    # Labels are compared with spacing normalized: the helper reports them that way, and an
    # app's own text may carry line breaks or a trailing space ("Self Accounts ").
    def shows(text):
        lit = _lit(" ".join(text.split()))
        return f"normalize-space(@text)={lit} or normalize-space(@content-desc)={lit}"

    for text in (fp.get("inner_text") or [])[:2]:
        ancestor = kind if kind != "*" else "*[@clickable='true']"
        queries.append((f"//*[{shows(text)}]/ancestor::{ancestor}[1]", "inner"))
    labels = ([fp["labeled_by"]] if fp.get("labeled_by") else []) + (fp.get("sibling_text") or [])[:3]
    for text in dict.fromkeys(labels):
        queries.append((f"//*[{shows(text)}]/..//{kind}"
                        f"[not(normalize-space(@text)={_lit(' '.join(text.split()))})]", "label"))
    for ancestor in (fp.get("ancestors") or [])[:2]:
        if ancestor.get("resource_id"):
            queries.append((f"//*[@resource-id={_lit(ancestor['resource_id'])}]//{kind}", "ancestor"))
        elif ancestor.get("content_desc"):
            queries.append((f"//*[normalize-space(@content-desc)={_lit(' '.join(ancestor['content_desc'].split()))}]"
                            f"//{kind}", "ancestor"))
    if kind != "*":
        queries.append((f"//{kind}", None))
    return queries


def _attr(el, name):
    try:
        value = el.get_attribute(name)
    except Exception:  # noqa: BLE001 - went stale; treat as missing
        return None
    return None if value in (None, "", "null") else value


def _read(el, want_hint):
    r = el.rect
    cand = {
        "resource_id": _attr(el, "resource-id"), "text": _attr(el, "text"),
        "content_desc": _attr(el, "content-desc"), "class_name": _attr(el, "class"),
        "bounds": f"[{r['x']},{r['y']}][{r['x'] + r['width']},{r['y'] + r['height']}]",
    }
    if want_hint:
        cand["hint"] = _attr(el, "hint")
    return cand


class NativeHealer:
    """Finds a step's element by its fingerprint when its locators no longer match.

    `attempt()` may be called repeatedly while waiting; `result` holds the
    healed match once one is accepted, `near_misses` the best candidates of
    the last attempt otherwise."""

    def __init__(self, driver, fp, use_text=True):
        self.driver = driver
        self.fp = fp
        self.use_text = use_text
        self.result = None
        self.near_misses = []
        self._screen = None

    def attempt(self):
        if not self.fp:
            return None
        if self._screen is None:
            size = self.driver.get_window_size()
            self._screen = (size["width"], size["height"])
        found = {}  # element id -> [element, query, position in its results, anchors]
        for xpath, anchor in native_queries(self.fp):
            if len(found) >= MAX_CANDIDATES:
                break
            try:
                elements = self.driver.find_elements(AppiumBy.XPATH, xpath)
            except Exception:  # noqa: BLE001 - query the driver can't run; try the others
                continue
            for i, el in enumerate(elements[:MAX_CANDIDATES]):
                entry = found.setdefault(el.id, [el, xpath, i, set()])
                if anchor:
                    entry[3].add(anchor)
                if len(found) >= MAX_CANDIDATES:
                    break
        scored = []
        for el, xpath, position, anchors in found.values():
            try:
                cand = _read(el, bool(self.fp.get("hint")))
            except Exception:  # noqa: BLE001 - gone from screen meanwhile
                continue
            cand.update(anchors=anchors, element=el, query=(xpath, position))
            score, sims = score_native(self.fp, cand, self._screen)
            scored.append((score, sims, cand))
        scored.sort(key=lambda s: -s[0])
        self.near_misses = [_summary(s) for s in scored[:3]]
        best = pick(scored)
        if best is None:
            return None
        score, sims, cand = best
        try:
            if not cand["element"].is_displayed():
                return None
        except Exception:  # noqa: BLE001
            return None
        self.result = {
            "score": round(score, 2),
            "matched": matched_features(sims),
            "element": _element_name(cand),
            "locator": self._unique(healed_locator(cand, self.use_text), cand["element"]),
        }
        return cand["element"]

    def _unique(self, loc, element):
        """Keep only the locator candidates that find exactly this element (list rows often share
        an id); the query that found it, with its position, always does."""
        keep = []
        for strategy, value in loc["candidates"][:-1]:
            by = {"id": AppiumBy.ID, "accessibility id": AppiumBy.ACCESSIBILITY_ID}.get(strategy, AppiumBy.XPATH)
            try:
                found = self.driver.find_elements(by, value)
            except Exception:  # noqa: BLE001
                continue
            if len(found) == 1 and found[0].id == element.id:
                keep.append((strategy, value))
        keep.append(loc["candidates"][-1])
        return dict(loc, candidates=keep, strategy=keep[0][0], value=keep[0][1])


def _element_name(cand):
    """How the report names an element: its text or description first (ids are often shared)."""
    shown = cand.get("text") or cand.get("content_desc")
    name = locator_mod.describe({k: cand.get(k) for k in ("resource_id", "class_name")})
    return f'"{shown[:40]}" ({name})' if shown else name


def _summary(scored):
    score, sims, cand = scored
    return {"score": round(score, 2), "element": _element_name(cand), "matched": matched_features(sims),
            "bounds": cand.get("bounds")}


def healed_locator(cand, use_text=True):
    """A locator for the healed element: its own id/description/text, then the query that found it."""
    node = {k: cand.get(k) for k in ("resource_id", "content_desc", "text", "class_name", "bounds")}
    loc = locator_mod.locator_from_node(node, use_text=use_text) or {
        "resource_id": None, "content_desc": None, "text": None, "class_name": cand.get("class_name"),
        "bounds": cand.get("bounds"), "window_package": None, "candidates": [],
    }
    xpath, position = cand["query"]
    query = xpath if position == 0 else f"({xpath})[{position + 1}]"
    candidates = list(loc["candidates"]) + [("xpath", query)]
    return dict(loc, candidates=candidates, strategy=candidates[0][0], value=candidates[0][1])


def near_miss_text(near_misses):
    if not near_misses:
        return ""
    parts = [f"{m['element']} ({m['score']:.2f}" + (f", same {'/'.join(m['matched'])}" if m["matched"] else "") + ")"
             for m in near_misses]
    return "; self-healing found no confident match -- closest: " + ", ".join(parts)


# ------------------------------------------------------- applying results ---

def apply_healed(steps, report):
    """Put the locators healed in a run into the steps: the new locator first, the old ones
    kept after it. Returns how many steps changed."""
    by_uid = {r["uid"]: r["healed"] for r in report if r.get("healed") and r.get("uid")}
    changed = 0
    for step in steps:
        healed = by_uid.get(step.get("uid"))
        if not healed:
            continue
        if healed.get("web"):
            old = step.get("web") or {}
            step["web"] = dict(old, **{k: v for k, v in healed["web"].items() if k != "fp"},
                               fp=old.get("fp") or healed["web"].get("fp"))
        else:
            key = healed.get("key", "locator")
            old = step.get(key) or {}
            new = healed["locator"]
            seen = {tuple(c) for c in new["candidates"]}
            candidates = [tuple(c) for c in new["candidates"]] + [
                tuple(c) for c in old.get("candidates", []) if tuple(c) not in seen]
            step[key] = dict(new, candidates=candidates, strategy=candidates[0][0], value=candidates[0][1])
        step.pop("locator_warning", None)
        changed += 1
    return changed
