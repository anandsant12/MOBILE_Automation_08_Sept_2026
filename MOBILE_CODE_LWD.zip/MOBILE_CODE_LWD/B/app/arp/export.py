"""Export test cases and results for use outside this tool.

  - `junit_xml(results)`: JUnit XML for CI systems (Jenkins, GitHub Actions,
    GitLab, Azure DevOps all read it).
  - `pytest_script(metadata)`: a standalone pytest + Appium-Python-Client
    test with the same steps, to run or extend in any Appium setup.
"""

import re
import xml.etree.ElementTree as ET

from . import step_types


def junit_xml(results, suite_name="android-record-playback"):
    """`results`: run results as returned by testcases.run_and_record."""
    suite = ET.Element("testsuite", name=suite_name, tests=str(len(results)),
                       failures=str(sum(r["status"] == "failed" for r in results)),
                       errors=str(sum(r["status"] == "error" for r in results)),
                       time=f"{sum(r.get('elapsed') or 0 for r in results):.2f}")
    for r in results:
        case = ET.SubElement(suite, "testcase", classname=suite_name, name=r["name"], time=f"{r.get('elapsed') or 0:.2f}")
        failed_steps = [s for s in (r.get("report") or []) if s["status"] == "failed"]
        if r["status"] == "failed":
            first = failed_steps[0] if failed_steps else {}
            failure = ET.SubElement(case, "failure", message=f"Step {first.get('index')}: {first.get('error')}")
            failure.text = "\n".join(f"Step {s['index']} ({s['label']}): {s['error']}" for s in failed_steps)
        elif r["status"] == "error":
            ET.SubElement(case, "error", message=r.get("error") or "error")
        lines = [f"[{'HEALED' if s.get('healed') else s['status'].upper()}] {s['index']}. {s['label']} -- "
                 f"{s['method'] or s.get('error') or ''}" for s in r.get("report") or []]
        healed = [s for s in r.get("report") or [] if s.get("healed")]
        if healed:
            # Passed, but only because self-healing found elements whose locators broke.
            properties = ET.Element("properties")
            ET.SubElement(properties, "property", name="healed_steps", value=",".join(str(s["index"]) for s in healed))
            case.insert(0, properties)
        if lines:
            ET.SubElement(case, "system-out").text = "\n".join(lines)
    ET.indent(suite)
    return ET.tostring(suite, encoding="unicode", xml_declaration=True)


_PREAMBLE = '''"""{title}

Exported from android-record-playback. Needs: pip install Appium-Python-Client pytest
and a running Appium server with the uiautomator2 driver:  pytest {filename}
Test data can be overridden with environment variables of the same name.
"""
import os
import re
import time

import pytest
from appium import webdriver
from appium.options.android import UiAutomator2Options
from appium.webdriver.common.appiumby import AppiumBy

APPIUM_URL = os.environ.get("APPIUM_URL", "http://127.0.0.1:4723")
DEVICE = os.environ.get("ANDROID_SERIAL", {serial!r})
DATA = {{k: os.environ.get(k, v) for k, v in {variables!r}.items()}}
BY = {{"id": AppiumBy.ID, "accessibility id": AppiumBy.ACCESSIBILITY_ID, "xpath": AppiumBy.XPATH}}
DATE_TOKENS = [("yyyy", "%Y"), ("yy", "%y"), ("MMMM", "%B"), ("MMM", "%b"), ("MM", "%m"), ("dd", "%d"),
               ("HH", "%H"), ("hh", "%I"), ("mm", "%M"), ("ss", "%S"), ("a", "%p"), ("EEE", "%a")]


def run_date(spec):
    """The date/time of this run, for today, today-30d, today+1d:dd-MM-yyyy, now:HH:mm."""
    import datetime
    m = re.match(r"^(today|now)\\s*(?:([+-])\\s*(\\d+)\\s*([dwmy]?))?\\s*(?::(.+))?$", spec.strip(), re.I)
    base, sign, amount, unit, fmt = m.groups()
    now = datetime.datetime.now()
    if amount:
        n = int(amount) * (1 if sign == "+" else -1)
        unit = (unit or "d").lower()
        if unit in ("d", "w"):
            now += datetime.timedelta(days=n * (7 if unit == "w" else 1))
        else:
            y, mo = divmod(now.month - 1 + n * (12 if unit == "y" else 1), 12)
            for day in (now.day, 30, 29, 28):
                try:
                    now = now.replace(year=now.year + y, month=mo + 1, day=day)
                    break
                except ValueError:
                    continue
    fmt = fmt or ("dd/MM/yyyy" if base.lower() == "today" else "HH:mm")
    out, i = "", 0
    while i < len(fmt):
        for token, code in DATE_TOKENS:
            if fmt.startswith(token, i):
                out, i = out + code, i + len(token)
                break
        else:
            out, i = out + fmt[i].replace("%", "%%"), i + 1
    return now.strftime(out)


@pytest.fixture
def driver():
    options = UiAutomator2Options()
    options.udid = DEVICE
    options.no_reset = True
    options.set_capability("appium:autoLaunch", False)
    drv = webdriver.Remote(APPIUM_URL, options=options)
    drv.update_settings({{"enableMultiWindows": True}})
    yield drv
    drv.quit()


NAMES = re.compile(r"@(text|content-desc)[)]?\\s*=|normalize-space[(]@(text|content-desc)[)]")
NAME_TEST = re.compile(r"""(?<![\\w(-])@(text|content-desc)=("[^"]*"|'[^']*')""")
STATE = re.compile(r",\\s*(not selected|selected|not checked|unchecked|checked|expanded|collapsed)\\s*$", re.I)


def plain(text):
    """Words separated by single spaces: line breaks and spacing aren't part of what text says."""
    return " ".join((text or "").split())


def literal(value):
    if '"' not in value:
        return '"' + value + '"'
    if "'" not in value:
        return "'" + value + "'"
    return "concat(" + ", '\\"', ".join('"' + p + '"' for p in value.split('"')) + ")"


def relaxed(strategy, value):
    """A looser form of a locator naming the element that found nothing: spacing ignored, and
    a state the app appends to a description (", selected") allowed. None if there's none."""
    if strategy == "accessibility id":
        base = STATE.sub("", plain(value)) or plain(value)
        return ("xpath", "//*[normalize-space(@content-desc)=" + literal(base) + " or starts-with("
                "normalize-space(@content-desc), " + literal(base + ", ") + ")]")
    looser = NAME_TEST.sub(lambda m: "normalize-space(@" + m.group(1) + ")=" + literal(plain(m.group(2)[1:-1])),
                           value) if strategy == "xpath" else value
    return ("xpath", looser) if looser != value else None


def match(driver, candidates, relax=False):
    """The element the locators point at now, or None: the first locator matching exactly one
    element wins; one matching several (e.g. list rows sharing an id) is only a fallback, and
    not even that when a locator naming the element by text/description finds nothing.
    With relax, a locator naming the element that finds nothing is retried in its looser form."""
    fallback, named_missing = None, False
    for strategy, value in candidates:
        found = driver.find_elements(BY[strategy], value)
        named = strategy == "accessibility id" or bool(NAMES.search(value))
        if not found and relax and named:
            looser = relaxed(strategy, value)
            if looser:
                found = driver.find_elements(BY[looser[0]], looser[1])
        if len(found) == 1:
            return found[0]
        if found and fallback is None:
            fallback = found[0]
        if not found and named:
            named_missing = True
    return None if named_missing else fallback


def find(driver, candidates, timeout=10):
    """The element matched by the locators (see match), waiting up to `timeout` seconds."""
    started = time.monotonic()
    deadline = started + timeout
    while True:
        el = match(driver, candidates, relax=time.monotonic() - started >= 1.0)
        if el is not None:
            return el
        if time.monotonic() > deadline:
            raise AssertionError(f"element not found by any of {{candidates}}")
        time.sleep(0.25)


def web_tap(driver, css, text=None, timeout=20, optional=False):
    """Tap web content inside the app's WebView through Appium's WEBVIEW context
    (needs chromedriver: start Appium with --allow-insecure chromedriver_autodownload)."""
    native = driver.current_context
    deadline = time.monotonic() + timeout
    try:
        while True:
            webviews = [c for c in driver.contexts if c.startswith("WEBVIEW")]
            if webviews:
                driver.switch_to.context(webviews[-1])
                for el in driver.find_elements(AppiumBy.CSS_SELECTOR, css):
                    if el.is_displayed() and (text is None or el.text.strip() == text):
                        el.click()
                        return True
                driver.switch_to.context(native)
            if time.monotonic() > deadline:
                if optional:
                    return False
                raise AssertionError(f"web element {{css}} {{text!r}} not found")
            time.sleep(0.25)
    finally:
        driver.switch_to.context(native)


def web_text(driver, css, text=None, context=None):
    """Text of the visible web element matching css (and text), or None -- via the WEBVIEW context."""
    native = driver.current_context
    try:
        webviews = [c for c in driver.contexts if c.startswith("WEBVIEW")]
        if not webviews:
            return None
        driver.switch_to.context(webviews[-1])
        for el in driver.find_elements(AppiumBy.CSS_SELECTOR, css):
            if el.is_displayed() and (not text or el.text.strip() == text):
                return el.text.strip()
        return None
    finally:
        driver.switch_to.context(native)


def _present(driver, candidates, timeout):
    """Whether an optional element (e.g. a popup) shows up within `timeout` seconds."""
    try:
        find(driver, candidates, timeout)
        return True
    except AssertionError:
        return False


DATE_FORMATS = ("%d/%m/%Y", "%d-%m-%Y", "%Y-%m-%d", "%d.%m.%Y", "%d %B %Y", "%d %b %Y", "%A, %d %B %Y")


def parse_date(text):
    import datetime
    for fmt in DATE_FORMATS:
        try:
            return datetime.datetime.strptime(" ".join(text.split()), fmt).date(), fmt
        except ValueError:
            continue
    return None, None


def pick_in_calendar(driver, date_text, timeout=10):
    """Pick a date in Android's standard date picker: move to its month, tap the day, OK."""
    target, _ = parse_date(date_text)
    assert target, f"not a date: {{date_text!r}}"
    expect(lambda: driver.find_elements(AppiumBy.ID, "android:id/datePicker"), timeout, "no calendar opened")
    for _ in range(240):
        days = driver.find_elements(AppiumBy.XPATH, "//*[@resource-id='android:id/month_view']/*")
        shown, fmt = parse_date(days[0].get_attribute("content-desc") or "") if days else (None, None)
        assert shown, "the calendar's days have no readable dates"
        diff = (target.year * 12 + target.month) - (shown.year * 12 + shown.month)
        if diff == 0:
            break
        driver.find_element(AppiumBy.ID, "android:id/next" if diff > 0 else "android:id/prev").click()
        time.sleep(0.3)
    label = target.strftime(fmt)
    driver.find_element(AppiumBy.XPATH, f"//*[@content-desc='{{label}}']").click()
    driver.find_element(AppiumBy.ID, "android:id/button1").click()


def checked_state(el):
    """Whether a checkbox / switch (the element or the one inside it) is checked; None if unknown."""
    try:
        if el.get_attribute("checkable") != "true":
            inner = el.find_elements(AppiumBy.XPATH, ".//*[@checkable='true']")
            if len(inner) != 1:
                return None
            el = inner[0]
        return el.get_attribute("checked") == "true"
    except Exception:
        return None


def text_of(el):
    if el.text:
        return el.text
    desc = el.get_attribute("content-desc")
    return "" if desc in (None, "null") else desc


def in_view(driver, candidates):
    """Whether the element is on screen now (its center inside the screen)."""
    size = driver.get_window_size()
    el = match(driver, candidates)
    if el is None or not el.is_displayed():
        return False
    r = el.rect
    cx, cy = r["x"] + r["width"] / 2, r["y"] + r["height"] / 2
    return 0 <= cx < size["width"] and 0.03 * size["height"] <= cy <= 0.97 * size["height"]


def scroll_to(driver, candidates, swipes, max_swipes=12):
    """Swipe as recorded (fractions of the screen) until the element is in view; no swipe if it already is."""
    size = driver.get_window_size()
    w, h = size["width"], size["height"]
    for n in range(max_swipes):
        if in_view(driver, candidates):
            return
        x1, y1, x2, y2, ms = swipes[n % len(swipes)]
        driver.swipe(int(x1 * w), int(y1 * h), int(x2 * w), int(y2 * h), max(ms, 400))
        time.sleep(0.4)


def expect(condition, timeout, message):
    """Re-check `condition()` until it holds or `timeout` runs out."""
    deadline = time.monotonic() + timeout
    while True:
        try:
            if condition():
                return
        except Exception:
            pass
        if time.monotonic() > deadline:
            raise AssertionError(message)
        time.sleep(0.25)


def select_option(driver, dropdown, option, timeout=10):
    xpath = f'//*[@text="{{option}}" or @content-desc="{{option}}"]'
    before = {{tuple(e.rect.values()) for e in driver.find_elements(AppiumBy.XPATH, xpath)}}
    dropdown.click()
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        new = [e for e in driver.find_elements(AppiumBy.XPATH, xpath) if tuple(e.rect.values()) not in before]
        if new:
            new[0].click()
            return
        time.sleep(0.25)
    raise AssertionError(f"option {{option!r}} not found")


def test_{func}(driver):
'''


def _data_expr(value):
    """Python expression for a step string that may reference ${name} / ${env:NAME}."""
    if not isinstance(value, str) or "${" not in value:
        return repr(value)
    parts = re.split(r"\$\{([^}]+)\}", value)
    out = []
    for i, part in enumerate(parts):
        if i % 2 == 0:
            if part:
                out.append(repr(part))
        elif part.startswith("env:"):
            out.append(f"os.environ[{part[4:]!r}]")
        elif step_types.is_date_variable(part):
            out.append(f"run_date({part!r})")
        else:
            out.append(f"DATA[{part!r}]")
    return " + ".join(out) if out else "''"


def _cands(loc):
    candidates = [tuple(c) for c in (loc.get("candidates") or [(loc["strategy"], loc["value"])])]
    if not any(isinstance(v, str) and "${" in v for _, v in candidates):
        return repr(candidates)
    # Test data in a locator (an account picked as ${account}): filled in from DATA / the environment.
    return "[" + ", ".join(f"({s!r}, {_data_expr(v)})" for s, v in candidates) + "]"


def _step_code(step):
    kind, loc = step["type"], step.get("locator")
    timeout = float(step.get("timeout") or step_types.DEFAULT_TIMEOUT)
    if kind in ("tap", "long_press") and step.get("web"):
        web = step["web"]
        wait = float(step.get("timeout") or (step_types.OPTIONAL_TIMEOUT if step.get("optional") else timeout))
        return [f"web_tap(driver, {web['css']!r}, {web.get('text')!r}, {wait:g}, optional={bool(step.get('optional'))})"]
    if kind == "pick_date":
        lines = [f"find(driver, {_cands(loc)}, {timeout:g}).click()"] if loc else []
        return lines + [f"pick_in_calendar(driver, {_data_expr(step.get('date', ''))})"]
    if kind in ("tap", "long_press") and loc:
        if kind == "tap":
            if step.get("tap_at"):
                fx, fy = step["tap_at"]
                # a tap on a container's empty part: the same spot within it, not its middle
                return [f"r = find(driver, {_cands(loc)}, {timeout:g}).rect",
                        f"driver.tap([(r['x'] + round(r['width'] * {fx}), r['y'] + round(r['height'] * {fy}))])"]
            if any("android.webkit.WebView" in str(v) for _, v in loc.get("candidates") or []):
                # web content reacts to real touches, not Appium's accessibility click()
                return [f"r = find(driver, {_cands(loc)}, {timeout:g}).rect",
                        "driver.tap([(r['x'] + r['width'] // 2, r['y'] + r['height'] // 2)])"]
            if step.get("checked_target") is not None:
                want = bool(step["checked_target"])
                # a checkbox / switch: tapped only if it isn't already the way it should end up
                return [f"el = find(driver, {_cands(loc)}, {timeout:g})",
                        f"if checked_state(el) is not {want}:",
                        "    el.click()"]
            return [f"find(driver, {_cands(loc)}, {timeout:g}).click()"]
        return [f"el = find(driver, {_cands(loc)}, {timeout:g})",
                "r = el.rect",
                "driver.tap([(r['x'] + r['width'] // 2, r['y'] + r['height'] // 2)], 1000)"]
    if kind in ("tap", "long_press"):
        x, y = step.get("pixel_start") or step.get("start")
        return [f"driver.tap([({x}, {y})]{', 1000' if kind == 'long_press' else ''})  # no locator was recorded"]
    if kind == "swipe":
        (x1, y1), (x2, y2) = step.get("pixel_start") or step["start"], step.get("pixel_end") or step["end"]
        return [f"driver.swipe({x1}, {y1}, {x2}, {y2}, {max(int(step.get('duration', 0.3) * 1000), 50)})"]
    if kind == "type":
        if step.get("text"):
            return [f"find(driver, {_cands(loc)}, {timeout:g}).send_keys({_data_expr(step['text'])})"]
        return [f"find(driver, {_cands(loc)}, {timeout:g}).clear()"]
    if kind == "select":
        return [f"select_option(driver, find(driver, {_cands(loc)}, {timeout:g}), {_data_expr(step['option'])})"]
    if kind == "keypad":
        scope = f"//*[@resource-id={loc['resource_id']!r}]" if loc and loc.get("resource_id") else ""
        lines = [f"find(driver, {_cands(loc)}, {timeout:g})  # the keypad"] if loc else []
        return lines + [f"for key in {_data_expr(step.get('text') or '')}:  # pressed by the character on each key",
                        f"    find(driver, [('xpath', f\"{scope}//*[@text='{{key}}' or @content-desc='{{key}}']\")], 5)"
                        ".click()"]
    if kind == "key":
        return [f"driver.execute_script('mobile: pressKey', {{'keycode': {_KEYCODES.get(step.get('key'), 4)}}})"
                f"  # {step.get('key')}"]
    if kind == "wait":
        return [f"time.sleep({float(step.get('seconds', 1)):g})"]
    if kind == "launch_app":
        package = _data_expr(step["package"])
        lines = [f"driver.terminate_app({package})"] if step.get("restart") else []
        return lines + [f"driver.activate_app({package})"]
    if kind == "screenshot":
        return [f"driver.get_screenshot_as_file('step_{step['index']:02d}.png')"]
    if kind == "assert" and step.get("web") and not loc:
        web, check, msg = step["web"], step.get("check", "visible"), repr(step["label"])
        css = repr(web["css"])
        text = repr(web.get("text") or None)
        expected = _data_expr(step.get("expected", ""))
        condition = {
            "visible": f"web_text(driver, {css}, {text}) is not None",
            "not_visible": f"web_text(driver, {css}, {text}) is None",
            "text_equals": f"plain(web_text(driver, {css})) == plain({expected})",
            "text_contains": f"plain({expected}) in plain(web_text(driver, {css}))",
            "text_matches": f"re.search({expected}, web_text(driver, {css}) or '')",
        }.get(check, "True")
        return [f"expect(lambda: {condition}, {timeout:g}, {msg})  # web content"]
    if kind == "assert":
        check = step.get("check", "visible")
        cands = _cands(loc)
        msg = repr(step["label"])
        if check == "visible":
            return [f"find(driver, {cands}, {timeout:g})"]
        if check == "not_visible":
            return [f"expect(lambda: not any(driver.find_elements(BY[s], v) for s, v in {cands}), {timeout:g}, {msg})"]
        getter = f"find(driver, {cands}, 1)"
        expected = _data_expr(step.get("expected", ""))
        condition = {
            "text_equals": f"plain(text_of({getter})) == plain({expected})",
            "text_contains": f"plain({expected}) in plain(text_of({getter}))",
            "text_matches": f"re.search({expected}, text_of({getter}))",
            "enabled": f"{getter}.is_enabled()",
            "disabled": f"not {getter}.is_enabled()",
            "checked": f"{getter}.get_attribute('checked') == 'true'",
            "unchecked": f"{getter}.get_attribute('checked') != 'true'",
            "selected": f"{getter}.is_selected()",
        }.get(check, "True")
        return [f"expect(lambda: {condition}, {timeout:g}, {msg})"]
    return [f"# unsupported step: {step.get('label')}"]


_KEYCODES = {"BACK": 4, "HOME": 3, "ENTER": 66, "TAB": 61, "MENU": 82, "SEARCH": 84, "APP_SWITCH": 187,
             "ESCAPE": 111, "VOLUME_UP": 24, "VOLUME_DOWN": 25, "POWER": 26}


def _scroll_target(steps, i):
    from .appium_playback import _scroll_target as target  # noqa: PLC0415
    return target(steps, i)


def _swipe_fractions(step, steps):
    """(x1, y1, x2, y2, ms) with coordinates as fractions of the recording's screen."""
    from .appium_playback import _recorded_screen  # noqa: PLC0415 - keeps export importable without Appium
    (x1, y1), (x2, y2) = step.get("pixel_start") or step["start"], step.get("pixel_end") or step["end"]
    w, h = _recorded_screen(step, steps) or (1080, 2400)
    return (round(x1 / w, 3), round(y1 / h, 3), round(x2 / w, 3), round(y2 / h, 3),
            int(step.get("duration", 0.3) * 1000))


def pytest_script(metadata):
    func = re.sub(r"\W+", "_", metadata["name"]).strip("_").lower() or "recorded"
    filename = f"test_{func}.py"
    steps, called_data = metadata["steps"], {}
    if any(s.get("type") == "run_case" for s in steps):
        from . import testcases  # noqa: PLC0415 - only for test cases that call others
        steps, called_data = testcases.expand_steps(steps, seen=(metadata["name"],))
    variables = {**called_data, **(metadata.get("variables") or {})}
    out = [_PREAMBLE.format(title=metadata.get("display_name") or metadata["name"], filename=filename,
                            serial=metadata.get("serial"), variables=variables, func=func)]
    covered = set()  # swipes folded into a scroll_to
    for i, step in enumerate(steps):
        if step.get("disabled") or i in covered:
            continue
        out.append(f"    # {step['index']}. {step['label']}")
        body = _step_code(step)
        if step["type"] == "swipe":
            end, target = _scroll_target(steps, i)
            if target is not None:
                covered.update(range(i + 1, end))
                if target.get("web") and not target.get("locator"):
                    out.append("    # (swipes skipped: web_tap scrolls its element into view)")
                    continue
                swipes = [_swipe_fractions(s, steps) for s in steps[i:end]]
                body = [f"scroll_to(driver, {_cands(target['locator'])}, {swipes!r})"
                        f"  # swipe until step {target['index']}'s element is in view"]
        if step.get("optional") and step.get("locator") and step["type"] != "assert":
            wait = float(step.get("timeout") or step_types.OPTIONAL_TIMEOUT)
            out.append(f"    if _present(driver, {_cands(step['locator'])}, {wait:g}):  # optional step")
            out += [f"        {line}" for line in body]
        elif step.get("continue_on_failure"):
            out.append("    try:")
            out += [f"        {line}" for line in body]
            out.append("    except AssertionError as exc:")
            out.append("        print(f'continuing after failure: {exc}')")
        else:
            out += [f"    {line}" for line in body]
    return filename, "\n".join(out) + "\n"
