﻿"""Recording engine from android-record-playback (see its README). Copied as-is except where marked "[ours]"."""
