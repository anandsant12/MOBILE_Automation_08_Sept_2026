"""Turn a raw recorded event stream back into a human-readable list of steps.

This is display-only for the raw-event path -- raw playback always replays
the events verbatim. `GestureDetector` groups touch events between a
tracking-id assignment and its release into a single "tap"/"swipe"/
"long_press" step, and translates a handful of common hardware key codes.

It's written as an incremental, feed-one-event-at-a-time class (rather than a
single batch function) so the same detection logic can also run *live* while
a recording is in progress -- `helper_recorder.py` feeds it events as they
arrive and gets a callback at each touch-down, which is the moment it asks
the phone which element is under the finger.
"""

import json
from pathlib import Path

EV_SYN = "0000"
EV_KEY = "0001"
EV_ABS = "0003"

ABS_MT_TRACKING_ID = "0039"
ABS_MT_POSITION_X = "0035"
ABS_MT_POSITION_Y = "0036"
SYN_REPORT = "0000"

TRACKING_ID_RELEASE = "ffffffff"

# Common evdev hardware key codes that show up on physical buttons.
KEY_NAMES = {
    "0072": "VOLUME_DOWN",
    "0073": "VOLUME_UP",
    "0074": "POWER",
    "009e": "BACK",
    "0066": "HOME",
    "008b": "MENU",
}

TAP_MAX_DISTANCE = 24
TAP_MAX_DURATION = 0.4
# Android's standard touch slop is 8dp; 24px covers it up to ~480dpi screens.
TAP_MAX_DISTANCE_PX = 24


def _load_events(path):
    events = []
    with Path(path).open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                events.append(json.loads(line))
    return events


class GestureDetector:
    """Feed it raw events one at a time; it accumulates human-readable steps.

    Callbacks (all optional):
      - on_gesture_start(time, device): fired the instant a new touch-down is
        seen, before its coordinates are necessarily known yet.
      - on_touch_down(time, device, x, y): fired at the end of the touch-down's
        first event frame, once its raw coordinates are known.
      - on_step(step): fired when a tap/swipe/long_press/key step is finalized.
    """

    def __init__(self, on_gesture_start=None, on_step=None, on_touch_down=None):
        self.on_gesture_start = on_gesture_start
        self.on_touch_down = on_touch_down
        self.on_step = on_step
        self._awaiting_down_frame = False
        self.steps = []

        self.t = 0.0
        self._gesture_active = False
        self._gesture_start_t = 0.0
        self._gesture_device = None
        self._cur_x = self._cur_y = None
        self._start_x = self._start_y = None

    def _flush_gesture(self, end_t):
        if not self._gesture_active or self._start_x is None:
            self._gesture_active = False
            return
        duration = end_t - self._gesture_start_t
        cur_x, cur_y = self._cur_x, self._cur_y
        start_x, start_y = self._start_x, self._start_y
        dx = (cur_x - start_x) if cur_x is not None else 0
        dy = (cur_y - start_y) if cur_y is not None else 0
        distance = (dx * dx + dy * dy) ** 0.5
        end_x = cur_x if cur_x is not None else start_x
        end_y = cur_y if cur_y is not None else start_y
        if distance <= TAP_MAX_DISTANCE and duration <= TAP_MAX_DURATION:
            label = f"Tap at ({start_x}, {start_y})"
            kind = "tap"
        elif distance <= TAP_MAX_DISTANCE:
            label = f"Long press at ({start_x}, {start_y}) for {duration:.2f}s"
            kind = "long_press"
        else:
            label = f"Swipe from ({start_x}, {start_y}) to ({end_x}, {end_y})"
            kind = "swipe"
        step = {
            "index": len(self.steps) + 1,
            "type": kind,
            "label": label,
            "time": round(self._gesture_start_t, 3),
            "duration": round(duration, 3),
            "device": self._gesture_device,
            "start": [start_x, start_y],
            "end": [end_x, end_y],
        }
        self.steps.append(step)
        self._gesture_active = False
        if self.on_step:
            self.on_step(step)

    def feed(self, event):
        self.t += event.get("delay", 0.0)
        etype = event["type"]
        code = event["code"]
        value = event["value"]

        if etype == EV_ABS and code == ABS_MT_TRACKING_ID:
            if value == TRACKING_ID_RELEASE:
                self._flush_gesture(self.t)
            else:
                if self._gesture_active:
                    self._flush_gesture(self.t)
                self._gesture_active = True
                self._gesture_start_t = self.t
                self._gesture_device = event.get("device")
                self._start_x = None
                self._start_y = None
                self._awaiting_down_frame = True
                if self.on_gesture_start:
                    self.on_gesture_start(self._gesture_start_t, self._gesture_device)
        elif etype == EV_SYN and code == SYN_REPORT and self._awaiting_down_frame:
            self._awaiting_down_frame = False
            # evdev only reports axes that changed, so a touch-down at the same
            # x (or y) as the previous touch carries no event for it.
            if self._start_x is None:
                self._start_x = self._cur_x
            if self._start_y is None:
                self._start_y = self._cur_y
            if self.on_touch_down and self._start_x is not None and self._start_y is not None:
                self.on_touch_down(self._gesture_start_t, self._gesture_device, self._start_x, self._start_y)
        elif etype == EV_ABS and code == ABS_MT_POSITION_X:
            self._cur_x = int(value, 16)
            if self._gesture_active and self._start_x is None:
                self._start_x = self._cur_x
        elif etype == EV_ABS and code == ABS_MT_POSITION_Y:
            self._cur_y = int(value, 16)
            if self._gesture_active and self._start_y is None:
                self._start_y = self._cur_y
        elif etype == EV_KEY:
            name = KEY_NAMES.get(code)
            if name and value == "00000001":
                step = {
                    "index": len(self.steps) + 1,
                    "type": "key",
                    "label": f"Key press: {name}",
                    "time": round(self.t, 3),
                    "duration": 0.0,
                    "key": name,
                }
                self.steps.append(step)
                if self.on_step:
                    self.on_step(step)

    def finish(self):
        self._flush_gesture(self.t)
        return self.steps


def parse_events(path_or_events):
    """Return a list of step dicts describing a recording in plain language."""
    events = path_or_events if isinstance(path_or_events, list) else _load_events(path_or_events)
    detector = GestureDetector()
    for event in events:
        detector.feed(event)
    return detector.finish()


def _classify(distance, duration, max_distance):
    if distance <= max_distance:
        return "tap" if duration <= TAP_MAX_DURATION else "long_press"
    return "swipe"


def reclassify_in_pixels(steps, to_pixels):
    """Redo tap/long_press/swipe classification in screen pixels.

    `GestureDetector` only sees raw touchscreen units, which on many devices
    are far finer than display pixels (e.g. 17279 units across a 1080px
    screen), so its raw threshold turns ordinary finger jitter on a tap into
    a "swipe". `to_pixels(x, y, device)` maps raw units to screen pixels.
    """
    for step in steps:
        if step["type"] not in ("tap", "long_press", "swipe"):
            continue
        sx, sy = to_pixels(step["start"][0], step["start"][1], step.get("device"))
        ex, ey = to_pixels(step["end"][0], step["end"][1], step.get("device"))
        distance = ((ex - sx) ** 2 + (ey - sy) ** 2) ** 0.5
        kind = _classify(distance, step["duration"], TAP_MAX_DISTANCE_PX)
        step["type"] = kind
        step["pixel_start"] = [sx, sy]
        step["pixel_end"] = [ex, ey]
        if kind == "tap":
            step["label"] = f"Tap at ({sx}, {sy})"
        elif kind == "long_press":
            step["label"] = f"Long press at ({sx}, {sy}) for {step['duration']:.2f}s"
        else:
            step["label"] = f"Swipe from ({sx}, {sy}) to ({ex}, {ey})"
    return steps


def renumber(steps):
    for i, step in enumerate(steps, start=1):
        step["index"] = i
    return steps


def _tap_lands_in(tap, field_bounds):
    point = tap.get("pixel_start")
    if not point or not field_bounds:
        return False
    x1y1, x2y2 = field_bounds.strip("[]").split("][")
    x1, y1 = (int(v) for v in x1y1.split(","))
    x2, y2 = (int(v) for v in x2y2.split(","))
    return x1 <= point[0] <= x2 and y1 <= point[1] <= y2


def drop_taps_before_typing(steps, renumber_steps=True):
    """Remove taps that only focused a field which the next step types into.

    Replay sets the field's text directly on the located element, which
    needs neither focus nor the keyboard, so the tap is a wasted action.
    """
    result = []
    for step in steps:
        if step["type"] == "type":
            bounds = step["locator"].get("bounds")
            while result and result[-1]["type"] == "tap" and _tap_lands_in(result[-1], bounds):
                result.pop()
        result.append(step)
    return renumber(result) if renumber_steps else result


def summarize(path_or_events):
    steps = parse_events(path_or_events)
    counts = {}
    for s in steps:
        counts[s["type"]] = counts.get(s["type"], 0) + 1
    return steps, counts
