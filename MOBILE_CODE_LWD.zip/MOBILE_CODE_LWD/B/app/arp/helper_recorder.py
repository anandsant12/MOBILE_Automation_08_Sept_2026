"""Record interactions as locator-based steps, using the helper app on the phone.

Two sources, both live:

  - `adb getevent` says *when* and *where* each touch happens (Android
    doesn't report raw touches to anything else without taking over the
    touchscreen);
  - the helper app (an accessibility service, see helper_app/) says *what*
    was touched and typed:
      * at each touch-down, the element under the finger is looked up on the
        phone right then (~20ms), before the app has reacted to the touch;
      * click events report the element the app itself handled the click on
        (native views; web content inside a WebView doesn't send them);
      * text fields report their value on every change and once more when
        focus leaves them, read from the field itself;
      * window changes show popups (dropdown lists, menus, dialogs) opening
        and closing, and which window is the keyboard.

No screen snapshots and no Appium session are involved in recording.
"""

import json
import re
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from . import healing, screens, step_types
from . import locator as locator_mod
from . import steps as steps_mod
from . import web_cdp
from .helper_client import HelperClient, HelperError
from .input_playback import CoordinateMapper
from .recorder import RecordingSession
from .web_cdp import WebViewClient, WebViewUnavailable

MASK_CHARS = set("•*●∙·")
KEYBOARD = "input_method"
# A click event belongs to a touch if it arrives within this long after touch-down.
CLICK_WINDOW_SECONDS = 1.5
# A click reported this soon after a touch that landed on nothing tappable is
# credited to it even if its element has moved (see _click_for).
MOVED_CLICK_SECONDS = 0.5
# How long a dropdown list may stay open after its option was tapped.
POPUP_CLOSE_TIMEOUT = 4.0
# How often to retry connecting to an app's web page while recording.
WEB_RETRY_SECONDS = 1.0


def _area(bounds):
    x1, y1, x2, y2 = locator_mod.parse_bounds(bounds)
    return max(x2 - x1, 0) * max(y2 - y1, 0)


def _contains(bounds, x, y):
    if not bounds:
        return False
    x1, y1, x2, y2 = locator_mod.parse_bounds(bounds)
    return x1 <= x <= x2 and y1 <= y <= y2


def _field_key(node):
    return node.get("resource_id") or node.get("xpath") or node.get("bounds")


def foreground_package(windows):
    """Package of the app the user is looking at: the active application window."""
    apps = [w for w in windows if w.get("type") == "application" and w.get("package")]
    active = [w for w in apps if w.get("active")]
    return (active or apps or [{}])[0].get("package")


# A screen is saved for adding checks (see screens.py) once no finger has been on it this long.
INPUT_SETTLE = 0.8


class HelperRecordingSession:
    def __init__(self, serial, output_path, adb_bin="adb"):
        self.serial = serial
        self.adb_bin = adb_bin
        self._detector = steps_mod.GestureDetector(on_touch_down=self._on_touch_down)
        self.raw_session = RecordingSession(serial, output_path, adb_bin, on_event=self._on_raw_event)
        self._down_ts = None  # device time of the latest touch-down
        self.helper = HelperClient(serial, adb_bin, on_event=self._on_helper_event)
        self.mapper = CoordinateMapper(serial=serial, adb_bin=adb_bin)
        self._lock = threading.Lock()
        self._touches = []  # {"t", "mono", "px", "hit", "error", "after_opener"}
        self._events = []  # helper events, in arrival order
        self._web_touches = []  # touches the app's web page logged itself (see web_cdp)
        self._known_windows = set()
        self._popup_reads = {}  # popup window id -> what its opener showed once it closed
        self._stopping = threading.Event()
        self._added = []  # (mono, step) -- checks/waits added while recording
        self._pool = ThreadPoolExecutor(max_workers=3)
        self._followups = []
        self._final_focus = None
        self._t0 = None
        self.start_package = None
        self.app_package = None  # the app the recorded steps act on (see resolve_steps)
        self.web = None  # the app's WebView page, when it allows debugging (see web_cdp)
        self._web_attempt = float("-inf")
        self.keyboard_taps = 0
        # The screen once it settles after each touch, for adding checks later (see screens.py).
        self._captures = []  # (mono, screen id)
        self._screen_wake = threading.Event()
        self._last_touch = float("-inf")
        self._last_input = float("-inf")  # latest raw touch report (finger down, move or up)
        self._screen_thread = None

    # ---------------------------------------------------------- lifecycle ---

    def start(self):
        self.mapper.warm_up()
        self.helper.connect()
        try:
            windows = self.helper.request("windows")["windows"]
            self._known_windows = {w.get("id") for w in windows}
            self.start_package = foreground_package(windows)
            self._connect_web()
            self._t0 = time.monotonic()
            self.raw_session.start()
        except Exception:
            self.helper.close()
            raise
        self._screen_thread = threading.Thread(target=self._keep_screens, daemon=True)
        self._screen_thread.start()
        return self

    def stop(self):
        count = self.raw_session.stop()
        self._pool.shutdown(wait=True)
        # Let watchers of popups that just closed finish reading; a popup still
        # open when recording stops isn't waited for beyond this.
        deadline = time.monotonic() + 2.0
        for thread in list(self._followups):
            thread.join(timeout=max(deadline - time.monotonic(), 0.05))
        self._stopping.set()
        self._screen_wake.set()
        if self._screen_thread is not None:
            self._screen_thread.join(timeout=6)
        # The page reports whether it changed 1.2s after each touch; wait for the last one.
        with self._lock:
            last = max((_when(t) for t in self._touches), default=None)
        if last is not None and self.web is not None:
            time.sleep(min(max(last + 1.4 - time.monotonic(), 0), 1.5))
        try:
            focused = self.helper.request("focused")
            self._final_focus = focused.get("node")
        except HelperError:
            pass
        self._drain_web_touches()
        self._write_debug()
        self.helper.close()
        if self.web is not None:
            self.web.close()
        return count

    @property
    def debug_path(self):
        return debug_path_for(self.output_path)

    def _write_debug(self):
        """Save what the recorder saw -- every touch, what was looked up for it, and the helper's
        window/click/field events -- so a wrongly recorded step can be traced afterwards."""
        def node(n):
            if not n:
                return None
            out = {k: n.get(k) for k in ("resource_id", "text", "value", "class_name", "bounds", "window_id")}
            for key in ("text", "value"):
                if locator_mod.volatile(out.get(key)):
                    out[key] = re.sub(r"\d", "#", out[key])  # a balance or the time: not kept
            return out

        with self._lock:
            touches = [{
                "t": t["t"], "mono": t["mono"], "down_mono": t.get("down_mono"), "lag": t.get("lag"), "px": t["px"],
                "error": t.get("error"), "web": t.get("web"), "web_error": t.get("web_error"),
                "window": {k: ((t.get("hit") or {}).get("window") or {}).get(k) for k in ("id", "type", "title")},
                "keyboard": bool((t.get("hit") or {}).get("keyboard")), "handled": (t.get("hit") or {}).get("handled"),
                "node": node((t.get("hit") or {}).get("node")), "target": node((t.get("hit") or {}).get("target")),
                "opener_after": node((t.get("opener_after") or {}).get("node")),
            } for t in self._touches]
            events = [{
                "event": e["event"], "mono": e["mono"], "node": node(e.get("node")), "original": e.get("original"),
                "windows": [{k: w.get(k) for k in ("id", "type", "title", "bounds")} for w in e.get("windows", [])]
                           or None,
            } for e in self._events]
            web_touches = list(self._web_touches)
        try:
            self.debug_path.write_text(json.dumps({
                "t0": self._t0, "start_package": self.start_package, "web_connected": self.web is not None,
                "touches": touches, "events": events, "web_touches": web_touches,
            }, indent=1, default=str), encoding="utf-8")
        except OSError:
            pass

    def _connect_web(self, package=None):
        """Also watch the app's web content directly, if its WebView allows debugging: Android's
        accessibility tree can miss web popups, so a tap on one would be credited to what's behind.

        Tried at the start and again (at most every few seconds) whenever a touch lands in a WebView
        while there's no connection -- e.g. recording started before the app's page existed."""
        package = package or self.start_package
        if not package or time.monotonic() - self._web_attempt < WEB_RETRY_SECONDS:
            return
        self._web_attempt = time.monotonic()
        web = WebViewClient(package, self.serial, self.adb_bin)
        web.log_touches = True
        try:
            web.call("true")
        except Exception:  # noqa: BLE001 - no debuggable WebView: accessibility tree only
            web.close()
            return
        old, self.web = self.web, web
        if old is not None:
            old.close()

    def close_driver(self):
        """Nothing to close: recording no longer uses an Appium session."""

    @property
    def output_path(self):
        return self.raw_session.output_path

    @property
    def count(self):
        return self.raw_session.count

    @property
    def located_count(self):
        with self._lock:
            return sum(1 for t in self._touches if t.get("hit") and t["hit"].get("node"))

    @property
    def typed_count(self):
        with self._lock:
            return sum(
                1 for e in self._events
                if e["event"] == "field_blur" and (e.get("node") or {}).get("value") != e.get("original")
            )

    @property
    def max_touch_lag(self):
        """How late (seconds) the slowest touch report reached the PC, or None if unknown."""
        with self._lock:
            lags = [t["lag"] for t in self._touches if t.get("lag") is not None]
        return max(lags) if lags else None

    @property
    def helper_error(self):
        if self.helper.closed.is_set() and self.raw_session.process and self.raw_session.process.poll() is None:
            return "Lost the connection to the recorder helper on the phone -- taps from here on get no locators."
        with self._lock:
            errors = [t["error"] for t in self._touches if t.get("error")]
        return errors[-1] if errors else None

    def elements_on_screen(self):
        """Elements currently on screen (for picking what a check should look at): Android's
        view of the app, plus the app's web page's own elements when it can be inspected
        (web popups are often missing from Android's view)."""
        elements = self.helper.request("elements")["elements"]
        if self.web is not None:
            try:
                elements += [{"web": dict(w, package=self.web.package)} for w in self.web.elements()]
            except Exception:  # noqa: BLE001 - page gone; Android's view only
                pass
        return elements

    def _keep_screens(self):
        """Save the screen's elements once it settles after each touch (and at the start and the
        end), on a connection of its own: the helper answers one connection's requests in turn, so
        reading a whole screen there could delay the lookups of touches."""
        client = None
        try:
            client = HelperClient(self.serial, self.adb_bin).connect()
            self._capture_screen(client)
            while not self._stopping.is_set():
                self._screen_wake.wait()
                self._screen_wake.clear()
                if not self._stopping.is_set():
                    self._capture_screen(client)
            with self._lock:
                last = self._captures[-1][0] if self._captures else float("-inf")
            if self._last_touch > last:
                self._capture_screen(client, final=True)   # what the last step led to
        except Exception:  # noqa: BLE001 - an extra: recording goes on without it
            pass
        finally:
            if client is not None:
                client.close()

    def _capture_screen(self, client, final=False):
        touched = self._last_touch
        # The app reacts once the finger lifts, and only then does the screen change: right after
        # a touch the old screen is still there and looks settled. So wait for the finger to be
        # off the screen a moment before waiting for the screen to settle.
        while time.monotonic() - self._last_input < INPUT_SETTLE:
            if (self._stopping.is_set() and not final) or self._last_touch != touched:
                return
            time.sleep(0.05)
        deadline = time.monotonic() + 4.0
        while time.monotonic() < deadline:   # wait for it to settle (screen change, loading)
            if (self._stopping.is_set() and not final) or self._last_touch != touched:
                return   # touched again: this screen was only passed through
            try:
                state = client.request("quiet")
            except HelperError:   # an older helper: give the screen a moment instead
                if self._stopping.wait(0.8) and not final:
                    return
                break
            if state.get("quiet_ms", 10**9) >= 400 and not state.get("busy"):
                break
            time.sleep(0.1)
        started = time.monotonic()
        elements = client.request("elements", timeout=8)["elements"]
        if self._last_touch != touched:
            return   # touched while it was being read: maybe half old, half new
        screen_id = screens.save(elements)
        if screen_id:
            with self._lock:
                self._captures.append((started, screen_id))

    def add_step(self, step):
        """Insert a step (a check, a wait...) at this point of the recording."""
        with self._lock:
            self._added.append((time.monotonic(), dict(step)))

    # ------------------------------------------------------------- inputs ---

    def _on_helper_event(self, event):
        new_windows = []
        with self._lock:
            self._events.append(event)
            if event["event"] == "windows":
                ids = {w.get("id") for w in event["windows"]}
                new_windows = [w for w in event["windows"]
                               if w.get("id") not in self._known_windows and w.get("type") == "application"]
                self._known_windows = ids
        for window in new_windows:
            thread = threading.Thread(target=self._watch_popup, args=(window, event["mono"]), daemon=True)
            self._followups.append(thread)
            thread.start()

    def _watch_popup(self, window, opened_mono):
        """When a popup window (dropdown list, menu, dialog) closes, read what the element tapped to
        open it now shows -- a dropdown shows the chosen option. Driven by the phone's window events,
        so it works however late the touch reports reach the computer."""
        try:
            while not self._stopping.is_set():
                if window.get("id") not in {w.get("id") for w in self.helper.request("windows")["windows"]}:
                    break
                self._stopping.wait(0.15)
            else:
                return
            time.sleep(0.3)  # let the opener redraw with its new value
            with self._lock:
                opener = next((t for t in reversed(self._touches)
                               if _when(t) < opened_mono and t.get("hit") and not t["hit"].get("keyboard")), None)
            if opener is None:
                return
            after = self.helper.request("hit", x=opener["px"][0], y=opener["px"][1])
            with self._lock:
                self._popup_reads[window.get("id")] = {"opener_t": opener["t"], "shown": _shown_text(after) or ""}
        except HelperError:
            pass

    def _on_raw_event(self, event):
        self._last_input = time.monotonic()
        if event["type"] == steps_mod.EV_ABS and event["code"] == steps_mod.ABS_MT_TRACKING_ID                 and event["value"] != steps_mod.TRACKING_ID_RELEASE:
            self._down_ts = event.get("ts")
        self._detector.feed(event)

    def _on_touch_down(self, t, device, raw_x, raw_y):
        x, y = self.mapper.to_pixels(raw_x, raw_y, device)
        arrived = time.monotonic()
        touch = {"t": round(t, 3), "mono": arrived, "px": (x, y), "hit": None, "error": None}
        if self._down_ts is not None:
            # When the finger actually landed, from the device's own clock -- the
            # report can reach the PC later than that.
            touch["down_mono"] = self.helper.to_mono(self._down_ts * 1000)
            touch["lag"] = round(arrived - touch["down_mono"], 3)
        with self._lock:
            previous = next((p for p in reversed(self._touches) if p.get("hit") and not p["hit"].get("keyboard")),
                            None)
            self._touches.append(touch)
        self._last_touch = touch.get("down_mono", arrived)
        self._screen_wake.set()
        self._pool.submit(self._resolve_touch, touch, previous)

    def _resolve_touch(self, touch, previous):
        try:
            touch["hit"] = self.helper.request("hit", x=touch["px"][0], y=touch["px"][1], timeout=3)
        except HelperError as exc:
            touch["error"] = str(exc)
            return
        self._resolve_web(touch)
        # A tap in a window that wasn't there at the previous tap may be an
        # option in a dropdown list that tap opened. Watch for the list to
        # close, then read what the opener shows (a dropdown shows the choice).
        window = touch["hit"].get("window") or {}
        if previous and window and window.get("type") != KEYBOARD:
            opened_since = window.get("id") not in {w.get("id") for w in previous["hit"].get("windows", [])}
            if opened_since:
                thread = threading.Thread(target=self._read_opener_after_close,
                                          args=(touch, previous, window["id"]), daemon=True)
                self._followups.append(thread)
                thread.start()

    def _resolve_web(self, touch):
        """The web element really on top at a touch inside the app's WebView."""
        node = touch["hit"].get("node") or {}
        if "android.webkit.WebView" not in (node.get("xpath") or ""):
            return
        if self.web is None or node.get("package") != self.web.package:
            self._connect_web(node.get("package"))
            if self.web is None or node.get("package") != self.web.package:
                return
        try:
            touch["web"] = self.web.element_at(*touch["px"])
            self._drain_web_touches()
        except WebViewUnavailable:
            pass
        except Exception as exc:  # noqa: BLE001 - recorded as a note; the native locator still stands
            touch["web_error"] = str(exc).splitlines()[0] if str(exc) else repr(exc)

    def _drain_web_touches(self):
        if self.web is None:
            return
        try:
            logged = self.web.drain_touches()
        except Exception:  # noqa: BLE001 - WebView gone (app closed); nothing more to collect
            return
        with self._lock:
            self._web_touches.extend(logged)

    def _web_touch_for(self, touch):
        """The element the page itself saw the finger land on, for this touch."""
        record = self._web_touch_record(touch)
        return record["el"] if record else None

    def _web_touch_record(self, touch):
        """What the page logged for this touch: {"el", "changed", ...}, or None."""
        when = touch.get("down_mono", touch["mono"])
        x, y = touch["px"]
        with self._lock:
            near = [w for w in self._web_touches
                    if abs(w["mono"] - when) <= 1.0 and abs(w["screen"][0] - x) <= 60 and abs(w["screen"][1] - y) <= 60]
        # A page that was open before an update can log each touch twice (old and new
        # logger); prefer the entry that knows whether the page changed.
        return min(near, key=lambda w: (round(abs(w["mono"] - when), 1), w.get("changed") is None)) if near else None

    def _read_opener_after_close(self, touch, opener, window_id):
        deadline = time.monotonic() + POPUP_CLOSE_TIMEOUT
        try:
            while time.monotonic() < deadline:
                windows = self.helper.request("windows")["windows"]
                if window_id not in {w.get("id") for w in windows}:
                    time.sleep(0.3)  # let the opener redraw with the new value
                    touch["opener_after"] = self.helper.request("hit", x=opener["px"][0], y=opener["px"][1])
                    return
                time.sleep(0.15)
        except HelperError:
            pass

    # ------------------------------------------------------------ results ---

    def resolve_steps(self):
        raw_steps = self._detector.finish()
        steps_mod.reclassify_in_pixels(raw_steps, self.mapper.to_pixels)
        with self._lock:
            touches = {t["t"]: t for t in self._touches}
            events = list(self._events)
            added = list(self._added)

        # getevent times count from the first raw event; place them on the PC clock.
        offsets = [t["mono"] - t["t"] for t in touches.values()]
        offset = sum(offsets) / len(offsets) if offsets else self._t0
        clicks = [e for e in events if e["event"] in ("click", "long_click") and e.get("node")]

        timeline = []  # (mono, step, touch)
        self.keyboard_taps = 0
        for step in raw_steps:
            touch = touches.get(round(step["time"], 3))
            mono = touch["mono"] if touch else step["time"] + offset
            if step["type"] == "key":
                timeline.append((mono, step, None))
                continue
            if step["type"] == "swipe":
                # So the swipe can be scaled to another phone's screen at playback.
                step["screen"] = list(self.mapper._screen())
            hit = (touch or {}).get("hit") or {}
            if hit.get("keyboard"):
                self.keyboard_taps += 1
                continue
            if step["type"] in ("tap", "long_press"):
                self._locate(step, touch, clicks)
            timeline.append((mono, step, touch))

        windows_events = sorted((e for e in events if e["event"] == "windows"), key=lambda e: e["mono"])
        with self._lock:
            popup_reads = dict(self._popup_reads)
        timeline = merge_selections(timeline, windows_events, clicks, popup_reads)
        timeline = [(mono, tap_as_check(step, touch, windows_events, self._web_touch_record(touch) if touch else None),
                     touch) for mono, step, touch in timeline]
        timeline += [(mono, step, None) for mono, step in typed_steps(events, self._final_focus, touches.values())]
        timeline += [(mono, step, None) for mono, step in added]
        timeline.sort(key=lambda item: item[0])

        steps = []
        for mono, step, _ in timeline:
            step["time"] = round(max(mono - self._t0, 0.0), 3)
            steps.append(step)
        steps = merge_keypad(steps)
        steps = merge_date_picks(steps)
        steps = reuse_tap_locators(steps)
        with self._lock:
            captures = list(self._captures)
        screens.assign(steps, captures, self._t0)
        self.app_package = steps_package(steps) or self.start_package
        return steps_mod.drop_taps_before_typing(steps)

    def _locate(self, step, touch, clicks):
        x, y = step["pixel_start"]
        if touch is None or touch.get("error"):
            step["locator_error"] = (touch or {}).get("error") or "touch wasn't seen by the recorder helper"
            return
        hit = touch["hit"]
        # The element the app reported handling the click on, when it did.
        with self._lock:
            next_when = min((_when(t) for t in self._touches if _when(t) > _when(touch)), default=None)
        click = _click_for(touch, clicks, x, y, hit, next_when)
        step["_clicked"] = click is not None
        element = click["node"] if click else choose_element(hit)
        loc = locator_mod.locator_from_node(element) if element is not None else None
        # What the page logged at the instant the finger landed, for web content; the
        # lookup made when the touch report arrived may already see the result of the
        # tap (a popup closed, a loading overlay shown).
        web = self._web_touch_for(touch) or touch.get("web")
        if loc is None and not web:
            step["locator_error"] = ("no element at this point (e.g. a game or drawing surface)" if element is None
                                     else "element has no usable locator")
            return
        # Android's view may offer nothing usable (a big unnamed container) while the page
        # knows exactly what was tapped: the step then rests on the page's locator alone.
        element = element or {}
        verb = "Tap" if step["type"] == "tap" else "Long press"
        window = hit.get("window") or {}
        if loc is not None:
            step["locator"] = loc
            # Attributes and surroundings, for finding it again if the locators break (healing.py).
            step["fingerprint"] = healing.fingerprint(element, hit.get("window"))
            # A checkbox / switch (or a row holding one): the state the tap was meant to give it,
            # read just before the finger landed. A radio button or list choice selects, so it's
            # always tapped.
            box = next((n for n in (hit.get("node"), hit.get("target"), element)
                        if n and n.get("checkable")), None)
            if box is not None and not re.search(r"Radio|CheckedTextView", box.get("class_name") or ""):
                step["checked_target"] = not bool(box.get("checked"))
            step["label"] = f"{verb} on {locator_mod.describe(loc)}"
            if loc.get("unique") is False:
                step["locator_warning"] = ("nothing about this element was unique on screen when you tapped it (e.g. "
                                           "several identical items), so playback may find another one -- check "
                                           "this step, or add a check after it")
            if not click and not hit.get("target") and element.get("bounds") and window.get("bounds")                     and _area(element["bounds"]) > 0.1 * _area(window["bounds"]):
                # Nothing that handles touches was under the finger, only a big container
                # (a list's empty part, a panel). Its middle may be a row or a button, so
                # replay the tap at the same spot within it (as fractions of its size).
                x1, y1, x2, y2 = locator_mod.parse_bounds(element["bounds"])
                if x2 > x1 and y2 > y1:
                    step["tap_at"] = [round((x - x1) / (x2 - x1), 3), round((y - y1) / (y2 - y1), 3)]
            if element.get("bounds") and window.get("bounds")                     and _area(element["bounds"]) > 0.5 * _area(window["bounds"]) and not web:
                # Tapping "the whole page" replays as a tap in its middle -- almost
                # never what was tapped. Usually the real control isn't exposed.
                step["locator_warning"] = ("this tap resolved to a screen-sized container, so replaying it won't "
                                           "hit what you tapped -- the control isn't visible to Android's "
                                           "accessibility; check this step, or add a check after it")
        # On web content the page's own record wins, even over Android's click report:
        # Android's view of web pages is unreliable (popups can be missing from it), and
        # its "click" isn't a real touch -- a page listening for touches may ignore it,
        # while the web step is replayed as a real tap. Android's element stays only as a
        # fallback, when it's plausibly the same element (below).
        if web:
            web = dict(web, package=self.web.package)
            step["web"] = web
            step["label"] = f"{verb} on {web_cdp.describe(web)}"
            native_text = locator_mod.clean_text(element.get("text") or element.get("content_desc")) \
                or (locator_mod.clean_text(((element.get("context") or {}).get("inner_text") or [None])[0]))
            same_text = bool(native_text and web.get("text") and native_text == web["text"])
            control_sized = bool(element.get("bounds") and window.get("bounds")
                                 and _area(element["bounds"]) < 0.1 * _area(window["bounds"]))
            if web.get("in_dialog") or not (same_text or control_sized):
                # Keep Android's element as a fallback only if it's plausibly the same one
                # (same text, or control-sized): in a web popup Android's view shows whatever
                # is behind it, and a big container or another panel would be tapped in its
                # middle. The page's own locator is what finds this element.
                step.pop("locator", None)
                step.pop("fingerprint", None)
            if web.get("matches", 1) > 1:
                step["locator_warning"] = (f"this web locator matches {web['matches']} elements on the page; "
                                           "playback picks the one nearest where you tapped")
            if web.pop("overlay", False):
                # The finger landed on a full-screen layer that isn't a control
                # (typically the app's loading mask), so the app ignored it.
                step["disabled"] = True
                step["locator_warning"] = ("this tap landed on a full-screen overlay (e.g. the app's loading "
                                           "mask), which ignores taps -- so it's disabled; re-enable it if it "
                                           "did something")


# A tap is taken as meant-to-be-a-check if nothing opened or closed this long after it.
CHECK_QUIET_SECONDS = 1.5


def tap_as_check(step, touch, windows_events, web_record):
    """A check instead of a tap, when the tap was on text that isn't a control and did nothing.

    People tap a message or heading to verify it, not to act on it. Only when
    it's certain the tap did nothing:
      - app screens: the element and everything around it aren't tappable
        (Android delivers no click then), no click was reported, and no
        window opened or closed;
      - web content: the page says it isn't a control, and the page itself
        didn't change at all within 1.2s of the touch (so elements that react
        through hidden click handlers stay taps).
    The original tap is kept in "as_tap", to turn it back with one click."""
    clicked = step.pop("_clicked", False)
    if step.get("type") != "tap" or touch is None or step.get("disabled") or not (step.get("locator") or step.get("web")):
        return step
    web = step.get("web")
    if web:
        # The whole text: web locators carry a shortened one (80 characters).
        text = (web.get("full_text") or web.get("text") or "").strip()
        if not text or web.get("tappable") is not False or (web_record or {}).get("changed") is not False:
            return step
    else:
        hit = touch.get("hit") or {}
        node = hit.get("node") or {}
        text = (node.get("text") or "").strip()
        if (not text or clicked or hit.get("target") or node.get("clickable") or node.get("long_clickable")
                or node.get("editable") or node.get("checkable")
                # A link in HTML an app renders (id "a"): it opens something though Android
                # doesn't call it clickable.
                or (node.get("resource_id") or "").lower() == "a"):
            return step
    before = _windows_at(windows_events, _when(touch))
    after = _windows_at(windows_events, _when(touch) + CHECK_QUIET_SECONDS)
    if before is not None and after is not None and {w.get("id") for w in before} != {w.get("id") for w in after}:
        return step
    if len(text) > 2000:
        return step
    # "text is" -- or, for a value that changes between runs (a balance, the time), "text matches".
    kind, expected = step_types.text_check(text)
    check = step_types.check_step(step.get("locator") if not web else None, kind, expected, web=web)
    for key in ("index", "time", "pixel_start", "fingerprint"):
        if step.get(key) is not None:
            check[key] = step[key]
    check["as_tap"] = {k: v for k, v in step.items() if k != "uid"}
    return step_types.relabel(check)


def _broken(bounds):
    """Bounds of a view reported mid-layout (moved or being hidden): empty or upside down."""
    if not bounds:
        return True
    x1, y1, x2, y2 = locator_mod.parse_bounds(bounds)
    return x2 <= x1 or y2 <= y1


def _click_for(touch, clicks, x, y, hit=None, next_when=None):
    """The click event the app reported for this touch, if any.

    Normally the clicked element contains the touch point. But a click that
    also switches the screen -- e.g. the last digit of a PIN, which logs in --
    is reported while its view is already moving away (a keypad sliding down)
    or being hidden (broken bounds), and the lookup at touch time may already
    see the next screen. So when the touch landed on nothing tappable, a click
    reported right after it (and before the next touch) by an element at the
    same horizontal spot is taken as this touch's."""
    near = [c for c in clicks if _when(touch) - 0.05 <= c["mono"] <= _when(touch) + CLICK_WINDOW_SECONDS
            and locator_mod.is_identifiable(c["node"])]
    inside = next((c for c in near if _contains(c["node"].get("bounds"), x, y)), None)
    if inside:
        return inside
    target = (hit or {}).get("target")
    window = (hit or {}).get("window") or {}
    missed = target is None or (target.get("bounds") and window.get("bounds")
                                and _area(target["bounds"]) > 0.5 * _area(window["bounds"]))
    for c in near:
        bounds = c["node"].get("bounds")
        if next_when is not None and c["mono"] > next_when:
            break
        if bounds:
            x1, _, x2, _ = locator_mod.parse_bounds(bounds)
            if x2 > x1 and not x1 <= x <= x2:
                continue
        if _broken(bounds) or (missed and c["mono"] <= _when(touch) + MOVED_CLICK_SECONDS):
            return c
    return None


def _keypad_key(step):
    """(keypad identity, container node, key text) if a tap is on a key of an on-screen keypad."""
    if step.get("type") != "tap" or step.get("web") or step.get("disabled") or not step.get("locator"):
        return None
    loc, fp = step["locator"], step.get("fingerprint") or {}
    text = (loc.get("text") or loc.get("content_desc") or "").strip()
    if len(text) != 1 or not fp:
        return None
    # The nearest named container (the keypad itself, e.g. "keyboard"), else the row class.
    container = next((a for a in fp.get("ancestors") or [] if a.get("resource_id")), None)
    identity = (container or {}).get("resource_id") or (fp.get("parent_class"), loc.get("class_name"))
    return identity, container, text


def _weak(loc):
    """A locator resting only on the element's position in the screen's layout."""
    first = (loc or {}).get("value") or ""
    return not loc or str(first).startswith("//android.widget.FrameLayout/") or str(first).count("/") > 6


def reuse_tap_locators(steps, lookback=3):
    """A typing step built from the field's focus event can lack what the tap on that same field
    knew (its label in the form): such a step takes the tap's locator when that one is stronger."""
    for i, step in enumerate(steps):
        if step.get("type") not in ("type", "keypad") or not _weak(step.get("locator")):
            continue
        bounds = (step.get("locator") or {}).get("bounds")
        for prev in reversed(steps[max(0, i - lookback):i]):
            loc = prev.get("locator")
            if prev.get("type") == "tap" and loc and loc.get("bounds") == bounds and not _weak(loc):
                step["locator"] = dict(loc)
                if prev.get("fingerprint") and not step.get("fingerprint"):
                    step["fingerprint"] = prev["fingerprint"]
                step_types.relabel(step)
                break
    return steps


# Android's standard date picker: ids of its parts, and of its containers (which a tap's
# fingerprint lists as ancestors). A tap belonging to any of these is calendar navigation -
# move the month, pick the year, open the year list - that only matters on the recording day.
_PICKER_IDS = {"android:id/prev", "android:id/next", "android:id/date_picker_header_year",
               "android:id/date_picker_header_date", "android:id/month_view", "android:id/text1",
               "android:id/button1", "android:id/button2"}
_PICKER_ANCESTORS = {"android:id/datePicker", "android:id/date_picker_day_picker", "android:id/date_picker_header",
                     "android:id/date_picker_year_picker", "android:id/day_picker_view_pager",
                     "android:id/month_view", "android:id/animator"}


def _ids(step):
    return {v for s, v in (step.get("locator") or {}).get("candidates") or [] if s == "id"}


def _in_date_picker(step):
    """Whether a tap is inside Android's standard date picker (by its id, or an ancestor's)."""
    if step.get("type") != "tap":
        return False
    loc = step.get("locator") or {}
    if (loc.get("resource_id") or "") in _PICKER_IDS or (_ids(step) & _PICKER_IDS):
        return True
    ancestors = {a.get("resource_id") for a in (step.get("fingerprint") or {}).get("ancestors") or []}
    return bool(ancestors & _PICKER_ANCESTORS)


def _picked_day(step):
    """The full date of a calendar day tap (its description is "29 October 2020"), else None."""
    if step.get("type") != "tap":
        return None
    loc = step.get("locator") or {}
    return step_types.parse_date(loc.get("content_desc") or "") if loc.get("content_desc") else None


def merge_date_picks(steps):
    """"Tap the date field, move the calendar around, tap a day (, OK)" -> one "pick_date" step:
    the date is then data (fixed, ${today+7d}, ${start_date}), and playback moves the calendar
    to whatever month it needs instead of replaying taps that only fit the recording day.

    The day tap's description carries the whole date ("29 October 2020"), so every tap and
    swipe in between - next/prev month, the year header, scrolling the year list, picking a
    year - is just navigation and is dropped. No OK tap is required (some pickers confirm on
    the day; playback taps OK itself when there is one)."""
    out, i = [], 0
    while i < len(steps):
        step = steps[i]
        # A tap that opens the picker (a date field), or the picker already open at this step.
        opens = step.get("type") == "tap" and not _picked_day(step) and not _in_date_picker(step)
        j = i + 1 if opens else i
        picked, last = None, None
        while j < len(steps):
            s = steps[j]
            if s.get("type") == "swipe":
                # A scroll inside the picker (the year list): kept only if a picker tap follows.
                if j + 1 < len(steps) and _in_date_picker(steps[j + 1]):
                    j += 1
                    continue
                break
            if _picked_day(s) or _in_date_picker(s):
                if _picked_day(s):
                    picked = _picked_day(s)
                last = j
                j += 1
                continue
            break
        if picked is None or last is None:
            out.append(step)
            i += 1
            continue
        field = step if opens else None
        merged = {
            "index": step["index"], "type": "pick_date", "time": step["time"], "duration": 0.0,
            "date": picked.strftime("%d/%m/%Y"),
            "locator": field.get("locator") if field else None,
            "fingerprint": field.get("fingerprint") if field else None,
            "pixel_start": (field or step).get("pixel_start"),
        }
        out.append(step_types.relabel({k: v for k, v in merged.items() if v is not None or k == "locator"}))
        i = last + 1   # resume after the last picker tap (the day, or OK)
    return out


def merge_keypad(steps):
    """Fold consecutive taps on the keys of an app's own on-screen keypad (a PIN pad,
    a calculator) into one "Enter ... on the keypad" step.

    Such keypads aren't the system keyboard, so nothing is "typed": each key is a
    tap on a view showing one character, all inside one container. They're
    replayed by the character on each key, not by the key's id or position, as
    PIN pads are often shuffled."""
    out = []
    i = 0
    while i < len(steps):
        first = _keypad_key(steps[i])
        j = i + 1
        while first and j < len(steps):
            key = _keypad_key(steps[j])
            if not key or key[0] != first[0]:
                break
            j += 1
        if first and j - i >= 2:
            text = "".join(_keypad_key(s)[2] for s in steps[i:j])
            container = first[1]
            step = {
                "index": steps[i]["index"], "type": "keypad", "time": steps[i]["time"], "duration": 0.0,
                "text": text,
                # Digits entered on a keypad are nearly always a PIN or OTP.
                "secret": text.isdigit(),
                "key_class": steps[i]["locator"].get("class_name"),
            }
            if container:
                step["locator"] = locator_mod.locator_from_node(container, use_text=False)
            step["label"] = keypad_label(step)
            out.append(step)
            i = j
            continue
        out.append(steps[i])
        i += 1
    return out


def keypad_label(step):
    text = step.get("text") or ""
    shown = text if "${" in text or not step.get("secret") else "•" * len(text)
    where = locator_mod.describe(step["locator"]) if step.get("locator") else "the keypad"
    return f"Enter '{shown}' on {where}"


def steps_package(steps):
    """The app most recorded steps act on (not whatever was in front when recording started)."""
    counts = {}
    for step in steps:
        package = (step.get("fingerprint") or {}).get("package") or (step.get("locator") or {}).get("window_package")
        if package:
            counts[package] = counts.get(package, 0) + 1
    return max(counts, key=counts.get) if counts else None


def choose_element(hit):
    """Which of the elements under the finger a step should target.

    The clickable element (a button, a row) is what the user operated; the
    smallest element (often its label) may be easier to identify. Prefer the
    clickable one when it can be found by id/text/description and isn't a
    screen-sized container, else the smallest one.
    """
    node, target = hit.get("node"), hit.get("target")
    window = hit.get("window") or {}
    if target and locator_mod.is_identifiable(target):
        if not window.get("bounds") or _area(target["bounds"]) < 0.25 * _area(window["bounds"]):
            return target
    if node and locator_mod.is_identifiable(node):
        return node
    return target or node


def _shown_text(hit):
    for key in ("node", "target"):
        text = (hit.get(key) or {}).get("text")
        if text:
            return text.strip()
    return None


def _control_locator(hit):
    """Locator for a dropdown itself, never by the text it shows (that's its current value)."""
    control = hit.get("control") or hit.get("target") or hit.get("node")
    return locator_mod.locator_from_node(control, use_text=False) if control else None


def debug_path_for(recording_path):
    path = Path(recording_path)
    return path.with_name(path.stem + "_debug.json")


def _when(touch):
    """When the finger landed (device clock), or when the report arrived if that's unknown."""
    return touch.get("down_mono", touch["mono"])


def _windows_at(windows_events, t):
    """The on-screen windows at time t, from the helper's window-change events (None if unknown)."""
    current = None
    for event in windows_events:
        if event["mono"] > t:
            break
        current = event["windows"]
    return current


def _popup_for(opener, option, windows_events):
    """The popup window (dropdown list, menu) the option tap landed in, if any.

    Decided from the helper's window-change events, stamped with the phone's
    own clock -- not from what was on screen when the tap was looked up, which
    can be after a fast tap already closed the list: a window that wasn't
    there at the opener tap, was open where and when the option tap landed,
    and closed soon after it."""
    x, y = option["px"]
    before = _windows_at(windows_events, _when(opener)) or (opener.get("hit") or {}).get("windows") or []
    before_ids = {w.get("id") for w in before}
    during = _windows_at(windows_events, _when(option))
    hit_window = (option.get("hit") or {}).get("window") or {}
    if during is None:
        during = [hit_window] if hit_window else []
    for window in during:
        if window.get("id") in before_ids or window.get("type") in (KEYBOARD, "system")                 or not _contains(window.get("bounds"), x, y):
            continue
        after = [e for e in windows_events if _when(option) < e["mono"] <= _when(option) + POPUP_CLOSE_TIMEOUT]
        if not after or any(window.get("id") not in {w.get("id") for w in e["windows"]} for e in after):
            return window
    return None


def merge_selections(timeline, windows_events=(), clicks=(), popup_reads=None):
    """Fold "tap a dropdown, tap an option in the list it opened" into one select step.

    The second tap must have landed in a popup window that opened after the
    first tap and closed after it (see _popup_for). It's a selection -- not,
    say, "OK" in a confirmation dialog -- when the first element is a
    dropdown (a web <select> or an Android Spinner), or it then shows the
    tapped option's text. Swipes inside the list (scrolling) are folded in.
    """
    result = []
    for mono, step, touch in timeline:
        if step["type"] == "tap" and touch is not None:
            opener_index = next(
                (i for i in range(len(result) - 1, -1, -1)
                 if result[i][1]["type"] == "tap" and result[i][2] is not None), None,
            )
            if opener_index is not None and all(s["type"] == "swipe" for _, s, _ in result[opener_index + 1:]):
                opener_mono, opener_step, opener_touch = result[opener_index]
                popup = _popup_for(opener_touch, touch, windows_events)
                selection = popup and _as_selection(opener_step, opener_touch, step, touch, popup, clicks,
                                                    (popup_reads or {}).get(popup.get("id")))
                if selection:
                    del result[opener_index:]
                    result.append((opener_mono, selection, None))
                    continue
        result.append((mono, step, touch))
    return result


def _as_selection(opener_step, opener_touch, option_step, option_touch, popup, clicks, popup_read=None):
    control = _control_locator(opener_touch["hit"])
    if control is None:
        return None
    opener_node = opener_touch["hit"].get("target") or opener_touch["hit"].get("node") or {}
    # A dropdown is a control, never the screen itself: a picker (clock face, calendar) opened
    # from an unnamed spot would otherwise become "select from android:id/content".
    window = (opener_touch["hit"].get("window") or {}).get("bounds")
    if locator_mod.FRAMEWORK_IDS.match(control.get("resource_id") or "") or (
            window and opener_node.get("bounds") and _area(opener_node["bounds"]) > 0.5 * _area(window)):
        return None
    hit_in_popup = ((option_touch.get("hit") or {}).get("window") or {}).get("id") == popup.get("id")
    # What the dropdown shows once the list closed: the click Android reports on
    # it when the choice is applied, or the follow-up read of it.
    shown_after = None
    for click in clicks:
        node = click["node"]
        if _when(option_touch) <= click["mono"] <= _when(option_touch) + 2.0 and (
                (control.get("resource_id") and node.get("resource_id") == control["resource_id"])
                or node.get("bounds") == opener_node.get("bounds")):
            shown_after = (node.get("text") or "").strip()
            break
    if shown_after is None and popup_read and popup_read["opener_t"] == opener_touch["t"]:
        shown_after = popup_read["shown"]
    if shown_after is None and option_touch.get("opener_after") is not None:
        shown_after = _shown_text(option_touch["opener_after"]) or ""
    option_text = _shown_text(option_touch["hit"]) if hit_in_popup else shown_after
    if not option_text:
        return None
    is_dropdown = ((opener_step.get("web") or {}).get("tag") == "select"
                   or "Spinner" in (opener_node.get("class_name") or "")
                   or (shown_after is not None and option_text in shown_after))
    if not is_dropdown:
        return None
    option_locator = option_step.get("locator") if hit_in_popup else None
    if option_locator:
        # Rows in a list usually share one id; the text is what identifies an option.
        candidates = sorted(option_locator["candidates"], key=lambda c: not re.search(r"@text[)]?=", c[1]))
        option_locator = dict(option_locator, candidates=candidates,
                              strategy=candidates[0][0], value=candidates[0][1])
    return {
        "index": opener_step["index"],
        "type": "select",
        "label": f"Select '{option_text}' from {locator_mod.describe(control)}",
        "time": opener_step["time"],
        "duration": 0.0,
        "locator": control,
        "fingerprint": healing.fingerprint(
            opener_touch["hit"].get("control") or opener_touch["hit"].get("target") or opener_touch["hit"].get("node"),
            opener_touch["hit"].get("window"), use_text=False),
        "option": option_text,
        "option_locator": option_locator,
        "pixel_start": opener_step.get("pixel_start"),
    }


def _app_cleared(started, value, until, touches):
    """What the user typed, when the app emptied the field in reaction to a tap elsewhere.

    A search box clears itself once a result is picked: its value when focus
    leaves is empty, though the user typed "ad" to get that result. Replaying
    "type 'ad'" and then the tap reproduces the clearing too.
    """
    typed = started.get("typed")
    if value or not typed:
        return None
    bounds = started["node"].get("bounds")
    for touch in touches:
        hit = touch.get("hit") or {}
        if hit.get("keyboard") or not touch.get("px"):
            continue
        if started["typed_mono"] < _when(touch) < until and not _contains(bounds, *touch["px"]):
            return typed
    return None


def typed_steps(events, final_focus=None, touches=()):
    """(mono, step) for each field whose value changed while it had focus.

    The value is what the field held when focus left it (read from the field
    at that moment), placed at the time focus began -- right after whatever
    focused the field. Except when a tap elsewhere made the app empty the
    field (a search box cleared once a result is picked): then it's what was
    typed before that tap.
    """
    out = []
    current = None  # {"mono", "node", "original"}
    touches = list(touches)

    def close(node, until=float("inf")):
        nonlocal current
        started, current = current, None
        if started is None:
            return
        value = node.get("value") or ""
        typed = _app_cleared(started, value, until, touches)
        if typed is not None:
            node, value = dict(node, value=typed), typed
        if value == started["original"]:
            return
        focus_node = started["node"]
        loc = locator_mod.locator_from_node(dict(node, xpath=node.get("xpath") or focus_node.get("xpath")))
        if loc is None:
            return
        password = bool(node.get("password") or focus_node.get("password"))
        masked = password and value and all(ch in MASK_CHARS for ch in value)
        name = locator_mod.describe(loc)
        step = {
            "index": 0,
            "type": "type",
            "time": 0.0,
            "duration": 0.0,
            "text": "" if masked else value,
            "password": password,
            "locator": loc,
            "fingerprint": healing.fingerprint(dict(node, context=node.get("context") or focus_node.get("context")),
                                               use_text=False),
        }
        if masked:
            step["needs_value"] = True
            step["label"] = f"Type password into {name} (the phone hid it -- enter the value before running)"
        elif not value:
            step["label"] = f"Clear {name}"
        else:
            step["label"] = f"Type '{'•' * len(value) if password else value}' into {name}"
        out.append((started["mono"], step))

    for event in events:
        kind, node = event["event"], event.get("node") or {}
        if kind == "field_focus":
            if current is not None:
                close(current["last"])
            current = {"mono": event["mono"], "node": node, "last": node, "original": node.get("value") or ""}
        elif kind == "field_text" and current is not None and _field_key(node) == _field_key(current["node"]):
            current["last"] = node
            if node.get("value"):
                current["typed"], current["typed_mono"] = node["value"], event["mono"]
        elif kind == "field_blur":
            if current is None:
                current = {"mono": event["mono"], "node": node, "last": node,
                           "original": event.get("original") or ""}
            close(node, event["mono"])
    if current is not None:
        if final_focus and _field_key(final_focus) == _field_key(current["node"]):
            close(final_focus)
        else:
            close(current["last"])
    return out
