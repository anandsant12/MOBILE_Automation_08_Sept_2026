"""
Everything that talks directly to the Appium/UiAutomator2 driver. Kept as
plain functions (driver passed in explicitly) rather than a class, since
there is exactly one shared driver (session_manager.session.driver) and
nothing here needs to hold state between calls.

Coordinate hit-testing (tap -> element) and the tap/type/swipe primitives
below are adapted from Appium Inspector's own approach: parse the
accessibility-tree XML once, find the smallest element whose bounds
contain the tapped point (preferring one that's actually clickable), then
resolve a live element handle for it via one targeted XPath lookup.
"""

import base64
import re
import time
import xml.etree.ElementTree as ET
from io import BytesIO
from typing import Optional

from PIL import Image
from selenium.webdriver.common.by import By
from selenium.webdriver.common.actions.action_builder import ActionBuilder
from selenium.webdriver.common.actions.pointer_input import PointerInput

from config import settings
from app.arp import locator as locator_mod

# Attributes worth keeping off every node - enough to build a locator and
# a human-readable description without dragging in Android's full,
# noisy attribute set (package, index, focusable, ...).
CAPTURED_ATTRS = {
    "class", "resource-id", "text", "content-desc", "hint", "bounds",
    "clickable", "long-clickable", "checkable", "checked", "selected",
    "scrollable", "displayed", "enabled", "password", "index", "focused", "package",
}


# ---------------------------------------------------------------------
# Screen / page source
# ---------------------------------------------------------------------

class RunStopped(Exception):
    """Raised inside a long device operation (a scroll search) when the user
    pressed Stop, so it can bail out instead of finishing first."""


_display_cache: dict = {}


def get_window_size(driver) -> dict:
    """The size element bounds and the mirrored frame are expressed in. The
    driver's "window size" can exclude system bars on some phones, which would
    shrink every click's vertical position (up to a full row off near the
    bottom); UiAutomator2's deviceInfo reports the real display size. Asked
    once per session; falls back to the window size if unavailable."""
    key = getattr(driver, "session_id", None) or id(driver)
    if key not in _display_cache:
        size = None
        try:
            m = re.match(r"\s*(\d+)\s*x\s*(\d+)", str(driver.execute_script("mobile: deviceInfo").get("realDisplaySize", "")))
            if m:
                size = {"width": int(m.group(1)), "height": int(m.group(2))}
        except Exception:
            pass
        if size is None:
            win = driver.get_window_size()
            size = {"width": win["width"], "height": win["height"]}
        _display_cache[key] = size
    return dict(_display_cache[key])


def get_screenshot_b64(driver) -> str:
    """Downscaled, JPEG-recompressed screenshot (base64, no data-url
    prefix). A raw device screenshot is a full-resolution PNG - often
    1-3 MB - which is the single biggest source of a laggy-feeling mirror
    once you're polling it repeatedly. Shrinking it to a sensible display
    width and re-encoding as JPEG cuts that to tens of KB with no visible
    quality loss at mirror size, without touching Appium's own capture
    time. Falls back to the raw screenshot (still PNG) if Pillow can't
    decode it for some reason - better a slow frame than a broken one."""
    raw_b64 = driver.get_screenshot_as_base64()
    try:
        image = Image.open(BytesIO(base64.b64decode(raw_b64)))
        if image.mode != "RGB":
            image = image.convert("RGB")
        max_width = settings.screenshot_max_width
        if image.width > max_width:
            ratio = max_width / image.width
            image = image.resize((max_width, max(1, int(image.height * ratio))), Image.LANCZOS)
        buf = BytesIO()
        image.save(buf, format="JPEG", quality=settings.screenshot_jpeg_quality, optimize=True)
        return base64.b64encode(buf.getvalue()).decode("ascii")
    except Exception:
        return raw_b64


def get_page_source(driver) -> str:
    return driver.page_source


def current_package(driver) -> str:
    try:
        return driver.current_package or ""
    except Exception:
        return ""



def current_activity(driver) -> str:
    try:
        return driver.current_activity or ""
    except Exception:
        return ""


def wake_and_unlock(driver):
    """Best-effort screen wake + unlock. Android's own screen-timeout can
    lock the device between actions (recording paused while you read the
    screen, a scenario run kicked off a while after the last interaction,
    etc.) - without this, activate_app() on a locked device just wakes the
    screen onto the lockscreen and leaves it there, which looks like "Run
    locked my phone" even though nothing but the OS's own timeout did
    that. Silently does nothing if the driver/session doesn't support the
    lock APIs, or the device is already unlocked.
    """
    try:
        if driver.is_locked():
            driver.unlock()
            time.sleep(0.4)  # let the unlock animation settle before the next command
    except Exception:
        pass


def ensure_foreground(driver, package: str):
    """Wake+unlock, then bring `package` to the front - idempotent, so
    calling this when the app is already open and unlocked is a harmless
    no-op, and calling it when it's backgrounded (or the screen locked
    itself in the meantime) brings it back without the caller needing to
    know which case it is."""
    wake_and_unlock(driver)
    if not package:
        return
    try:
        current = driver.current_package
    except Exception:
        current = None
    if current != package:
        try:
            driver.activate_app(package)
            time.sleep(0.5)  # let the app finish coming to the foreground
        except Exception:
            pass


_ICON_GLYPHS = re.compile("[-]+")   # Unicode private-use area: icon-font glyphs


def _sanitize(s: Optional[str]) -> str:
    """Text as a label or locator. Icon-font glyphs (an eye icon drawn as the character
    U+E0EC) are dropped: they aren't words, and name nothing a person would read."""
    if not s:
        return ""
    s = _ICON_GLYPHS.sub("", re.sub(r"[\r\n\t]+", " ", s)).strip()
    return "" if s.lower() == "null" else s


_LONG_NUMBER = re.compile(r"\d{5,}")                      # account / employee numbers
_NUMBERS_ONLY = re.compile(r"^[\d\s,.:/+\-%()]+$")


def looks_dynamic(text: Optional[str], choice: bool = False) -> bool:
    """Text that's probably DATA rather than a fixed label - a balance, an amount, an
    account/employee number, a date or time, a count, an unfilled {{template}}. It differs
    per person and per run, so it must never be what finds an element (the next run wouldn't
    see the same value); such an element is found by its id, or by the fixed label next to
    it, instead. Amounts, dates and times are judged by app/arp/locator.volatile.

    choice=True for a control the user picks (a calendar day "12 October 2026", a time
    slot): there the date or time IS what was chosen, so only money counts as changing."""
    text = (text or "").strip()
    if locator_mod.volatile(text, choice):
        return True
    if not text or not any(c.isdigit() for c in text):
        return False
    return bool(_LONG_NUMBER.search(text) or (not choice and _NUMBERS_ONLY.match(text)))


def parse_page_source(xml_str: str) -> list[dict]:
    """One page_source call already returns every node's attributes in a single
    response - far cheaper than find_elements('//*') plus one get_attribute()
    round trip per element per attribute. Each node also records `_i` (its
    position) and `_end` (the position of its last descendant): the dump is
    depth-first, so everything between the two is what's INSIDE that node -
    which is how a text-less clickable row is told apart from its neighbours."""
    try:
        root = ET.fromstring(xml_str)
    except ET.ParseError:
        return []
    nodes: list[dict] = []

    def visit(el):
        attrs = {k: v for k, v in el.attrib.items() if k in CAPTURED_ATTRS}
        recorded = "bounds" in attrs
        if recorded:
            if "class" not in attrs:
                attrs["class"] = el.tag
            attrs["_i"] = len(nodes)
            nodes.append(attrs)
        for child in el:
            visit(child)
        if recorded:
            attrs["_end"] = len(nodes) - 1

    visit(root)
    return nodes


def parse_bounds(bounds_str: str):
    """Android bounds look like "[59,988][299,1251]" -> (x1, y1, x2, y2)."""
    try:
        x1, y1, x2, y2 = (int(p) for p in bounds_str.replace("][", ",").strip("[]").split(","))
        return x1, y1, x2, y2
    except Exception:
        return None


def _is_actionable(attrs: dict) -> bool:
    return attrs.get("clickable") == "true" or attrs.get("long-clickable") == "true" or attrs.get("checkable") == "true"


def find_attrs_at_point(driver, x: int, y: int) -> Optional[dict]:
    """Convenience wrapper for callers that only need the point lookup
    (see pick_attrs_at_point for the pure version used when the same
    parsed node list is also needed afterward, e.g. for locator indexing)."""
    return pick_attrs_at_point(parse_page_source(get_page_source(driver)), x, y)


def _contains_point(attrs: dict, x: int, y: int) -> bool:
    b = parse_bounds(attrs.get("bounds", ""))
    return bool(b) and b[0] <= x <= b[2] and b[1] <= y <= b[3] and (b[2] - b[0]) * (b[3] - b[1]) > 0


def _has_content(nodes: list, attrs: dict) -> bool:
    """It, or something inside it, shows a label or can be operated - i.e. it isn't just an
    empty layer (a dimmed backdrop, a transparent wrapper)."""
    if _own_label(attrs) or _is_actionable(attrs) or is_editable(attrs):
        return True
    return any(n.get("displayed") != "false" and (_own_label(n) or _is_actionable(n)) for n in descendants(nodes, attrs))


def visible_at(nodes: list, x: int, y: int) -> list:
    """The elements under (x, y) that aren't covered by something drawn on top of them.

    Everything containing the point is in the dump - including the page BEHIND a dialog
    (a web app's dialog is part of the same page). What's drawn later is on top, so an
    element is hidden at this point when a later element that isn't inside it also covers
    the point and has content of its own: a dialog over the form it hides. Without this a
    tap on the dialog's title resolved to the form field underneath."""
    here = [n for n in nodes if n.get("displayed") != "false" and _contains_point(n, x, y)]
    covers = [m for m in here if m.get("_i") is not None and _has_content(nodes, m)]

    def hidden(n):
        end = n.get("_end")
        return end is not None and any(m["_i"] > end for m in covers)

    return [n for n in here if not hidden(n)]


def pick_attrs_at_point(nodes: list[dict], x: int, y: int) -> Optional[dict]:
    """Returns the smallest element's attribute dict containing (x, y),
    preferring an actionable element over a static label/container that
    happens to be smaller (e.g. a permission dialog's message text
    sitting exactly under the Allow button). Only elements actually visible
    there count - not the page behind a dialog (see visible_at)."""
    best, best_area = None, None
    best_actionable, best_actionable_area = None, None
    screen_area = max((_area(n) for n in nodes if n.get("displayed") != "false"), default=0)
    for attrs in visible_at(nodes, x, y):
        area = _area(attrs)
        if best_area is None or area < best_area:
            best, best_area = attrs, area
        if _is_actionable(attrs) and (best_actionable_area is None or area < best_actionable_area):
            best_actionable, best_actionable_area = attrs, area
    return choose_target(best, best_actionable, screen_area)


def _area(attrs: Optional[dict]) -> int:
    b = parse_bounds((attrs or {}).get("bounds", "")) if attrs else None
    return max(b[2] - b[0], 0) * max(b[3] - b[1], 0) if b else 0


def choose_target(smallest: Optional[dict], actionable: Optional[dict], screen_area: int) -> Optional[dict]:
    """Which of the elements under a touch it operated: the clickable one around it (a
    button, a row) rather than its label - except
      - a page-sized clickable wrapper (web/hybrid apps often make the whole page
        tappable, to dismiss the keyboard): it names nothing, so the smallest element
        is the better answer;
      - an icon inside a text field that isn't clickable itself (show password)."""
    if actionable is None or smallest is None or smallest is actionable:
        return actionable or smallest
    if screen_area and _area(actionable) > 0.5 * screen_area:
        return smallest
    if (is_editable(actionable) and not is_editable(smallest)
            and _sanitize(smallest.get("content-desc")) and not _sanitize(smallest.get("text"))):
        return smallest
    return actionable


def _match_index(nodes: list[dict], target_attrs: dict, key: str) -> int:
    """0-based position of target_attrs among all nodes sharing the same
    value for `key` (resource-id / content-desc / text), in page_source
    document order. This matters a lot in practice: Android reuses the
    exact same resource-id across every row of a list, a settings screen,
    or (notoriously) every SwitchPreference's toggle - which all share
    the literal id "switchWidget" - so "find by resource-id" alone can't
    tell three different toggles apart. Storing which occurrence this was
    lets replay pick the Nth match instead of always the first."""
    value = target_attrs.get(key)
    if not value:
        return 0
    target_bounds = target_attrs.get("bounds")
    idx = 0
    for node in nodes:
        if node.get(key) != value:
            continue
        if node.get("bounds") == target_bounds:
            return idx
        idx += 1
    return 0


def nearby_label(nodes: list[dict], target_attrs: dict, max_lookback: int = 6) -> str:
    """Heuristic: in Android's page_source dump (depth-first document
    order), a list/settings row is typically emitted as [...label
    TextView, control widget...] - so the closest PRECEDING node with
    visible text/content-desc is almost always that row's own label. Used
    to give an otherwise-unlabelled control (a bare Switch/CheckBox with
    no text of its own) a meaningful description - e.g. so three identical
    switchWidget toggles show up as three different, readable steps
    instead of three copies of "switchWidget"."""
    target_bounds = target_attrs.get("bounds")
    target_index = next((i for i, n in enumerate(nodes) if n.get("bounds") == target_bounds), None)
    if target_index is None:
        return ""
    for i in range(target_index - 1, max(-1, target_index - 1 - max_lookback), -1):
        candidate = nodes[i]
        if is_sensitive_field(candidate, nodes):
            continue   # a password/PIN/OTP field's OWN typed value must never leak into some
                       # OTHER element's description via this "borrow the nearby label" path
        label = _sanitize(candidate.get("text")) or _sanitize(candidate.get("content-desc"))
        if label:
            return label
    return ""


def resolve_element_handle(driver, attrs: dict):
    """One targeted XPath lookup for the live WebElement matching the
    attrs dict already picked out by find_attrs_at_point - bounds (+
    resource-id when present) is a reliable enough disambiguator since
    two on-screen elements sharing the exact same pixel rect would be
    indistinguishable to tap anyway."""
    bounds = attrs.get("bounds", "")
    resource_id = attrs.get("resource-id") or ""
    try:
        xpath = f'//*[@resource-id="{resource_id}" and @bounds="{bounds}"]' if resource_id else f'//*[@bounds="{bounds}"]'
        found = driver.find_elements(By.XPATH, xpath)
        return found[0] if found else None
    except Exception:
        return None


# ---------------------------------------------------------------------
# Locators - extraction (for recording) and resolution (for replay)
# ---------------------------------------------------------------------

def _xpath_literal(value: str) -> str:
    if '"' not in value:
        return f'"{value}"'
    if "'" not in value:
        return f"'{value}'"
    parts = value.split('"')
    return "concat(" + ', \'"\', '.join(f'"{p}"' for p in parts) + ")"


def _center(attrs: dict) -> tuple:
    b = parse_bounds(attrs.get("bounds", "")) or (0, 0, 0, 0)
    return (b[0] + b[2]) // 2, (b[1] + b[3]) // 2


def _inside(node: dict, container: dict) -> bool:
    i, ci, cend = node.get("_i"), container.get("_i"), container.get("_end")
    return None not in (i, ci, cend) and ci < i <= cend


def _scroll_parent(nodes: list, node: dict):
    """Innermost scrollable ancestor (ancestors come first in the dump, deeper ones later)."""
    found = None
    for s in nodes:
        if s.get("scrollable") == "true" and _inside(node, s):
            found = s
    return found


def _list_position(nodes: list, node: dict, attr: str, value: str, screen: Optional[dict]) -> dict:
    """Marks a target inside the list being scrolled, with its position among the list's
    own matches - so a dropdown option isn't confused with the same text showing behind
    the list (the field displaying the current choice)."""
    if not screen:
        return {}
    container = find_scroll_container(nodes, screen)
    if container is None or not _inside(node, container):
        return {}
    same = [n for n in nodes if _inside(n, container) and n.get("displayed") != "false" and _sanitize(n.get(attr)) == value]
    return {"in_list": True, "list_index": next((i for i, n in enumerate(same) if n is node), 0)}


def offset_from_center(attrs: dict, point: tuple, screen: dict) -> dict:
    """Where `point` is relative to the element's centre, as fractions of the screen."""
    cx, cy = _center(attrs)
    return {"dx": round((point[0] - cx) / (screen.get("width") or 1), 4),
            "dy": round((point[1] - cy) / (screen.get("height") or 1), 4)}


def _anchor_locator(anchor: dict, nodes: list, point: tuple, screen: dict) -> dict:
    """Find a visible label by its text, then tap at a fixed offset from it. For a
    target whose own attributes can't identify it: an icon/card with no text or id
    (captioned by the label under it), or a field whose text is a changing VALUE
    (a dropdown showing its current choice, under a static label)."""
    attr_name = "text" if _sanitize(anchor.get("text")) else "content-desc"
    key = "text" if attr_name == "text" else "content_desc"
    value = _sanitize(anchor.get(attr_name))
    loc = {key: value, key + "_index": _match_index(nodes, anchor, attr_name),
           "tap_offset": offset_from_center(anchor, point, screen), "anchor": True}
    loc.update(_list_position(nodes, anchor, attr_name, value, screen))
    return loc


def anchored_tap_locator(nodes: list, point: tuple, screen: dict) -> Optional[dict]:
    """For a touch that landed on no identifiable element (only a big container
    answered): anchor it to the nearest label, if one is close enough."""
    anchor = spatial_label_node(nodes, point=point)
    return _anchor_locator(anchor, nodes, point, screen) if anchor is not None else None


def extract_locator(attrs: dict, nodes: list, point: Optional[tuple] = None, screen: Optional[dict] = None) -> dict:
    """Best-effort set of stable locators, tried in priority order at replay
    (see resolve_locator). Empty is valid: replay falls back to coordinates.

    Identity comes from the element itself where it has any (resource-id,
    content-desc, text). A settings row / list item usually has NONE - it's a
    clickable container whose label lives in a child - so it is identified by
    the first label inside it (its title, not the volatile summary under it).
    And when its resource-id is shared by every sibling row, that label beats
    the id, since "the 3rd row with this id" changes as the list scrolls.

    With `screen` given (taps), two more cases are anchored to a label instead
    (see _anchor_locator): a field showing its current value under a static
    label (a dropdown), and an element with nothing at all to identify it."""
    loc: dict = {}
    resource_id = _sanitize(attrs.get("resource-id"))
    if resource_id and ":id/" not in resource_id and resource_id.lower() in locator_mod.HTML_TAG_IDS:
        resource_id = ""   # an HTML tag name ("a" on every link): names a kind of element, not this one
    # A state the app appends to the description ("Home, selected") changes with the element's
    # state: it isn't part of its name.
    content_desc, desc_state = locator_mod.split_state(_sanitize(attrs.get("content-desc")))
    content_desc = content_desc or ""
    if len(content_desc) > 120:
        content_desc = ""
    cls = attrs.get("class", "")
    is_input = "EditText" in cls
    text = "" if is_input else _sanitize(attrs.get("text"))
    if len(text) > 80:
        text = ""
    # A balance, an amount, an account number, a date: data that differs per person and per
    # run - never what finds the element (see looks_dynamic). Except the date on a control
    # the user picks (a calendar day): that IS what was chosen.
    choice = any(attrs.get(k) == "true" for k in ("clickable", "checkable", "long-clickable"))
    dynamic = looks_dynamic(text, choice) or looks_dynamic(content_desc, choice)
    if looks_dynamic(text, choice):
        text = ""
    if looks_dynamic(content_desc, choice):
        content_desc = ""
    shared_id = bool(resource_id) and sum(1 for n in nodes if _sanitize(n.get("resource-id")) == resource_id) > 1

    if screen and not is_input and ((text or content_desc) and _is_actionable(attrs) and "Button" not in cls or dynamic):
        # "Select Clients" above a field showing "SBI Preprod 3": that text is the CURRENT
        # CHOICE, which differs next run - the label above is what identifies the field.
        # Same for any value shown under a fixed label ("Available balance" / "₹ 45,230.00").
        ctx = context_label_node(nodes, attrs)
        if ctx is not None and _scroll_parent(nodes, ctx) is _scroll_parent(nodes, attrs):
            return _anchor_locator(ctx, nodes, _center(attrs), screen)

    child = None
    if not (content_desc or text) and not is_input and (not resource_id or shared_id):
        labelled = [n for n in child_labels(nodes, attrs, limit=3)
                    if len(_own_label(n)) <= 80 and not looks_dynamic(_own_label(n))]
        if labelled:
            child = labelled[0]

    if resource_id and child is None:
        loc["resource_id"] = resource_id
        loc["resource_id_index"] = _match_index(nodes, attrs, "resource-id")
    if content_desc:
        loc["content_desc"] = content_desc
        loc["content_desc_index"] = _match_index(nodes, attrs, "content-desc")
    if text:
        loc["text"] = text
        loc["text_index"] = _match_index(nodes, attrs, "text")
    if text or content_desc:
        attr_name = "text" if text else "content-desc"
        loc.update(_list_position(nodes, attrs, attr_name, text or content_desc, screen))

    conds = []
    if "resource_id" in loc:
        conds.append(f"@resource-id={_xpath_literal(resource_id)}")
    if content_desc and desc_state:
        # Found whatever state it's in ("Home", "Home, selected", "Home, not selected").
        base = locator_mod.plain_spaces(content_desc)
        conds.append(f"(normalize-space(@content-desc)={_xpath_literal(base)} or "
                     f"starts-with(normalize-space(@content-desc), {_xpath_literal(base + ', ')}) or "
                     f"starts-with(normalize-space(@content-desc), {_xpath_literal(base + ' ')}))")
    elif content_desc:
        # Exact for ordinary text; spacing normalised for text the app reports with irregular
        # spacing (" Home ", "Report \nFraudulent"), which an exact match on it would never find.
        conds.append(locator_mod._equals("content-desc", attrs.get("content-desc"), content_desc))
    if text:
        conds.append(locator_mod._equals("text", attrs.get("text"), text))
    if cls and conds:
        loc["xpath"] = f"//{cls}[{' and '.join(conds)}]"

    if child is not None:
        attr_name = "text" if _sanitize(child.get("text")) else "content-desc"
        key = "text" if attr_name == "text" else "content_desc"
        value = _sanitize(child.get(attr_name))
        lit = _xpath_literal(value)
        loc[key] = value
        loc[key + "_index"] = _match_index(nodes, child, attr_name)
        if cls:
            loc["xpath"] = f"//{cls}[.//*[@{attr_name}={lit}]]"
        if _first_checkable(nodes, attrs) is not None:
            # The label being tapped has no checked state; the switch behind it does.
            loc["state_xpath"] = f'(//*[@{attr_name}={lit}]/following::*[@checkable="true"])[1]'
        loc.update(_list_position(nodes, child, attr_name, value, screen))
    elif resource_id and shared_id:
        # A bare control whose id every sibling shares (each row's switch is "switchWidget").
        label = nearby_label(nodes, attrs)
        if label:
            lit = _xpath_literal(label)
            loc["label_xpath"] = (f"(//*[@text={lit} or @content-desc={lit}]"
                                  f"/following::*[@resource-id={_xpath_literal(resource_id)}])[1]")

    if screen and not is_input and not any(loc.get(k) for k in ("resource_id", "content_desc", "text", "xpath", "label_xpath")):
        # Nothing identifies it (an icon tab, a card drawn without text of its own): anchor
        # it to the caption beside/under it rather than replaying a bare coordinate.
        near = spatial_label_node(nodes, attrs)
        if near is not None and _scroll_parent(nodes, near) is _scroll_parent(nodes, attrs):
            return _anchor_locator(near, nodes, point or _center(attrs), screen)
    return loc


def element_own_text(attrs: dict) -> str:
    return _sanitize(attrs.get("text")) or _sanitize(attrs.get("content-desc"))


def is_editable(attrs: dict) -> bool:
    return "EditText" in (attrs.get("class") or "")


def is_checkable(attrs: dict) -> bool:
    return attrs.get("checkable") == "true"


def desired_checked_state(attrs: dict, nodes: Optional[list] = None) -> Optional[bool]:
    """For a TOGGLE (Switch/CheckBox): what its checked state should be after this
    tap, so replay can skip a tap that would flip it back. Tapping a settings
    row's label toggles the switch inside it, so when the tapped element isn't
    checkable itself, the first checkable inside it stands in.

    A RadioButton / CheckedTextView (a picker's list item) returns None on
    purpose: tapping it SELECTS - and in a picker dialog that tap is also what
    closes the dialog - so replay must always tap it, even when it is already
    the selected one. "Already in the desired state, skip" would leave the
    dialog open and derail every step after it."""
    target = attrs
    if not is_checkable(attrs):
        target = _first_checkable(nodes, attrs) if nodes is not None else None
        if target is None:
            return None
    cls = target.get("class") or ""
    if "Radio" in cls or "CheckedTextView" in cls:
        return None
    return target.get("checked") != "true"


def is_element_checked(element) -> Optional[bool]:
    try:
        value = element.get_attribute("checked")
    except Exception:
        return None
    if value is None:
        return None
    return value == "true"


def relative_bounds(attrs: dict, screen: dict) -> dict:
    b = parse_bounds(attrs.get("bounds", "")) or (0, 0, 0, 0)
    x1, y1, x2, y2 = b
    w, h = screen.get("width") or 1, screen.get("height") or 1
    return {
        "x_pct": round(x1 / w, 4), "y_pct": round(y1 / h, 4),
        "w_pct": round((x2 - x1) / w, 4), "h_pct": round((y2 - y1) / h, 4),
    }


last_match: Optional[dict] = None   # how the most recent lookup found its element (see resolve_locator)


def locator_strategies(locator: dict) -> list:
    """Every way this locator can find its element, in the order replay tries them:
    [{"strategy", "value", "index"}]. The first is the MAIN way; anything later that
    succeeds is a backup (reported, so the locator can be updated - self-healing).
    frontend/src/components/StepEditor.tsx lists the same order for display."""
    out: list = []

    def add(strategy: str, value, index: int = 0):
        if value and not any(s["strategy"] == strategy and s["value"] == value for s in out):
            out.append({"strategy": strategy, "value": value, "index": index})

    prefer = locator.get("prefer")
    if prefer:
        add(prefer[0], prefer[1], prefer[2] if len(prefer) > 2 else 0)   # promoted after an earlier run healed
    for strategy, value in locator.get("candidates") or []:   # recorded on the phone, in its order
        add(strategy, value)
    add("xpath", locator.get("label_xpath"))
    add("id", locator.get("resource_id"), locator.get("resource_id_index", 0))
    add("content-desc", locator.get("content_desc"), locator.get("content_desc_index", 0))
    add("text", locator.get("text"), locator.get("text_index", 0))
    add("xpath", locator.get("xpath"))
    return out


def _find_by(driver, strategy: str, value: str) -> list:
    if strategy == "id":
        return driver.find_elements(By.ID, value)
    if strategy == "accessibility id":
        return driver.find_elements("accessibility id", value)
    if strategy == "xpath":
        return driver.find_elements(By.XPATH, value)
    if strategy in ("content-desc", "text"):
        return driver.find_elements(By.XPATH, f"//*[@{strategy}={_xpath_literal(value)}]")
    return []


def main_strategy(locator: dict) -> Optional[tuple]:
    """(strategy, value) replay relies on first: one promoted after healing, else the
    element's text / content-desc (searched for on screen, scrolling if needed), else the
    first of locator_strategies."""
    if locator.get("prefer"):
        return locator["prefer"][0], locator["prefer"][1]
    _, attr, value = _semantic_target(locator)
    if value is not None:
        return attr, value
    strategies = locator_strategies(locator)
    return (strategies[0]["strategy"], strategies[0]["value"]) if strategies else None


def note_match(locator: dict, strategy: str, value: str):
    """Record which strategy found the element: `primary` is False when it wasn't the main
    one - the step still ran, but its main locator no longer works (self-healing)."""
    global last_match
    main = main_strategy(locator)
    last_match = {"strategy": strategy, "value": value, "primary": main is None or main == (strategy, value)}


def _names_element(strategy: str, value: str) -> bool:
    """Whether a strategy finds the element by what it shows (its text / description) -
    if that finds nothing, the element isn't on screen, only others sharing its id."""
    return strategy in ("content-desc", "text") or locator_mod.names_element(strategy, value)


def _relaxed(strategy: str, value: str) -> Optional[tuple]:
    """A looser form of a strategy naming the element (spacing ignored, an appended state like
    ", selected" allowed) - see app/arp/locator.relaxed. None when there's none."""
    if strategy in ("content-desc", "text"):
        attr = strategy
        base = locator_mod.plain_spaces(value)
        if attr == "content-desc":
            base = locator_mod.split_state(base)[0]
            lit = _xpath_literal(base)
            return ("xpath", f"//*[normalize-space(@content-desc)={lit} or "
                             f"starts-with(normalize-space(@content-desc), {_xpath_literal(base + ', ')}) or "
                             f"starts-with(normalize-space(@content-desc), {_xpath_literal(base + ' ')})]")
        return ("xpath", f"//*[normalize-space(@text)={_xpath_literal(base)}]")
    return locator_mod.relaxed(strategy, value)


def _on_screen(el, screen: dict) -> bool:
    try:
        r = el.rect
    except Exception:
        return False
    x, y = r["x"] + r["width"] / 2, r["y"] + r["height"] / 2
    return r["width"] > 0 and r["height"] > 0 and 0 <= x < screen["width"] and 0 <= y < screen["height"]


def _one_of_duplicates(driver, found: list) -> list:
    """Several matches that are really one element to the user: the same button on screens an
    app keeps alive under the current one. All at the very same spot -> the one drawn last (on
    top); otherwise, if only one of them is actually on screen, that one."""
    try:
        rects = {str(el.rect) for el in found}
    except Exception:
        return found
    if len(rects) == 1:
        return found[-1:]
    try:
        screen = driver.get_window_size()
    except Exception:
        return found
    shown = [el for el in found if _on_screen(el, screen)]
    return shown if len(shown) == 1 else found


def resolve_locator(driver, locator: dict, relax: bool = False):
    """The element the locator points at now, or None (caller falls back to stored relative
    coordinates - see step replay in scenario_service.py).

    Strategies are tried in order (locator_strategies). The first that matches EXACTLY ONE
    element wins: ids are often shared (every row of a list has the same "title" id), so a
    strategy matching several is only a fallback - picking the occurrence index recorded
    alongside it (see extract_locator) - and not even that when a strategy naming the
    element by its text or description finds nothing: then the element isn't on screen,
    just others with the same id. A few matches of a name at the very same spot (or only one
    of them on screen) count as one - see _one_of_duplicates.

    With `relax` (a step that has waited a moment), a strategy naming the element that finds
    nothing is tried once more in a looser form - spacing ignored, ", selected" allowed.
    last_match says which strategy it was."""
    global last_match
    last_match = None
    if not locator:
        return None
    fallback, named_missing = None, False
    for s in locator_strategies(locator):
        strategy, value = s["strategy"], s["value"]
        try:
            found = _find_by(driver, strategy, value)
        except Exception:
            continue   # e.g. an xpath this page can't evaluate - try the next
        named = _names_element(strategy, value)
        if not found and relax and named:
            looser = _relaxed(strategy, value)
            if looser:
                try:
                    found = _find_by(driver, *looser)
                except Exception:
                    found = []
                if found:
                    s = dict(s, strategy=looser[0], value=looser[1])
        if 1 < len(found) <= 6 and named and not s["index"]:
            found = _one_of_duplicates(driver, found)
        if len(found) == 1:
            note_match(locator, s["strategy"], s["value"])
            return found[0]
        if found and fallback is None:
            fallback = (s, found[s["index"]] if s["index"] < len(found) else found[0])
        if not found and _names_element(s["strategy"], s["value"]):
            named_missing = True
    if fallback is None or named_missing:
        return None
    s, element = fallback
    note_match(locator, s["strategy"], s["value"])
    return element


RELAX_AFTER_S = 1.0      # a step waits this long before name strategies are also tried loosely
SCROLL_SETTLE_S = 0.35   # let a list stop moving before it is read
STEP_POLL_S = 0.4        # re-read interval while waiting for a step's target to appear
last_search_pages = 0    # pages the most recent search scrolled - reported in the run log


class PointTarget:
    """A target known only by where it is on screen right now. Found by reading the
    hierarchy (one dump per page) instead of re-querying Appium by XPath, which
    would dump it again for every attempt."""

    def __init__(self, driver, attrs: dict, pages: int = 0):
        self._driver, self._attrs, self.pages_scrolled = driver, attrs, pages
        b = parse_bounds(attrs.get("bounds", "")) or (0, 0, 0, 0)
        self.rect = {"x": b[0], "y": b[1], "width": b[2] - b[0], "height": b[3] - b[1]}

    def click(self):
        tap_coords(self._driver, int(self.rect["x"] + self.rect["width"] / 2), int(self.rect["y"] + self.rect["height"] / 2))

    def get_attribute(self, name: str):
        return self._attrs.get(name)


def _semantic_target(locator: dict):
    prefer = locator.get("prefer")
    if prefer and prefer[0] not in ("text", "content-desc"):
        return None, None, None   # promoted to another strategy: that's what replay uses first
    for key, attr in (("text", "text"), ("content_desc", "content-desc")):
        if locator.get(key):
            return key, attr, locator[key]
    return None, None, None


def _scroll_anchor(locator: dict):
    """What a list is scrolled to in order to bring a tap target into view: the element's own
    text / description (see _semantic_target), or - for a row/tile tapped as a whole whose own
    text is empty - a steady label from inside it (an account row named by its account number),
    so such a row is scrolled to and tapped by its number instead of a brittle fixed position."""
    _, attr, value = _semantic_target(locator)
    if value is not None:
        return attr, value
    label = locator.get("label")
    return ("label", label) if label else (None, None)


def match_locator_in_nodes(nodes: list, locator: dict, screen: Optional[dict] = None):
    """The on-screen node a text/content-desc locator refers to, judged from an
    already-parsed hierarchy (no Appium round trip)."""
    key, attr, value = _semantic_target(locator)
    if value is not None:
        # Spacing compared loosely: a long paragraph can come back with its spaces or line
        # breaks differing from when it was recorded.
        want = " ".join(value.split())
        if attr == "content-desc":
            # A state the app appends to a description ("Home, selected") isn't part of its name.
            want = locator_mod.split_state(want)[0]
            shown = lambda n: locator_mod.split_state(" ".join(_sanitize(n.get(attr)).split()))[0]  # noqa: E731
        else:
            shown = lambda n: " ".join(_sanitize(n.get(attr)).split())  # noqa: E731
        matches = [n for n in nodes if n.get("displayed") != "false" and shown(n) == want]
    else:
        # No own text/description: a whole row or tile tapped as one, found by a steady text
        # inside it (an account row named by its account number). The label may be drawn as
        # text or as a description; tapping the matched node lands inside the row, which is
        # what receives the tap.
        label = locator.get("label")
        if not label:
            return None
        key = "label"
        want = " ".join(label.split())
        want_desc = locator_mod.split_state(want)[0]
        matches = [n for n in nodes if n.get("displayed") != "false"
                   and (" ".join(_sanitize(n.get("text")).split()) == want
                        or locator_mod.split_state(" ".join(_sanitize(n.get("content-desc")).split()))[0] == want_desc)]
    if not matches:
        return None
    # Not one hidden behind a dialog: tapping it would hit the dialog instead.
    showing = [n for n in matches if any(v is n for v in visible_at(nodes, *_center(n)))]
    matches = showing or matches
    if locator.get("in_list") and screen:
        # Recorded inside a list (a dropdown's options): the same text can also be showing
        # behind it (the field displaying the current choice) - only the list's copy counts.
        container = find_scroll_container(nodes, screen)
        inside = [n for n in matches if container is not None and _inside(n, container)]
        if inside:
            idx = locator.get("list_index", 0)
            return inside[idx] if idx < len(inside) else inside[0]
    idx = locator.get(key + "_index", 0)
    return matches[idx] if idx < len(matches) else matches[0]


def _plain_key(s: str) -> str:
    return s.casefold()


def _stripped_key(s: str) -> str:
    import unicodedata
    return "".join(c for c in unicodedata.normalize("NFKD", s) if not unicodedata.combining(c)).casefold()


def infer_direction(target: str, labels: list) -> Optional[str]:
    """Which way to scroll, judged from what is visible: if the visible labels are
    in order (alphabetical, either way), the target's place in that order says
    whether it is further on ("forward"), earlier ("back"), or - when it falls
    INSIDE the visible range yet isn't there - not in the list at all ("absent").
    None means the list isn't ordered (or too little is visible to tell)."""
    if len(labels) < 3:
        return None
    for key in (_plain_key, _stripped_key):   # plain first: pickers often sort accented names after z
        ks, t = [key(l) for l in labels], key(target)
        ascending = all(a <= b for a, b in zip(ks, ks[1:]))
        descending = all(a >= b for a, b in zip(ks, ks[1:]))
        if ascending == descending:   # neither ordered, or all equal (no information)
            continue
        lo, hi = (ks[0], ks[-1]) if ascending else (ks[-1], ks[0])
        if t < lo:
            return "back" if ascending else "forward"
        if t > hi:
            return "forward" if ascending else "back"
        return "absent"
    return None


def find_scroll_container(nodes: list, screen: dict):
    """The list being scrolled: the smallest big-enough vertically scrollable
    node with at least two labelled items - so a dialog's list wins over the
    full-screen page behind it."""
    best, best_area = None, None
    for n in nodes:
        if n.get("scrollable") != "true" or n.get("displayed") == "false":
            continue
        b = parse_bounds(n.get("bounds", ""))
        if not b:
            continue
        w, h = b[2] - b[0], b[3] - b[1]
        if h < 0.2 * screen["height"] or w < 0.3 * screen["width"] or len(child_labels(nodes, n, limit=2)) < 2:
            continue
        if best_area is None or w * h < best_area:
            best, best_area = n, w * h
    return best


def _bounds_of(container, screen: dict) -> tuple:
    b = parse_bounds(container.get("bounds", "")) if container is not None else None
    return b or (int(0.05 * screen["width"]), int(0.2 * screen["height"]), int(0.95 * screen["width"]), int(0.85 * screen["height"]))


def _container_labels(nodes: list, container) -> list:
    if container is None:
        return [_own_label(n) for n in nodes if _own_label(n) and n.get("displayed") != "false"]
    return [_own_label(n) for n in child_labels(nodes, container, limit=10 ** 6)]


def _comfortably_visible(hit: dict, bounds: tuple, nodes: list, container) -> bool:
    """False for a row sitting on the list's edge: it is reported with only its
    visible sliver, and tapping the middle of that lands outside the list."""
    b = parse_bounds(hit.get("bounds", ""))
    if not b or container is None or not _inside(hit, container):
        return True   # fixed on screen (a toolbar, a bottom tab bar) - scrolling the list can't move it
    if not (bounds[1] <= (b[1] + b[3]) // 2 <= bounds[3]):
        return False
    heights = sorted((s[3] - s[1]) for s in (parse_bounds(n.get("bounds", "")) for n in child_labels(nodes, container, limit=10 ** 6)
                                             if n.get("class") == hit.get("class")) if s)
    return not (len(heights) >= 3 and (b[3] - b[1]) < 0.6 * heights[len(heights) // 2])


def _scroll_page(driver, bounds: tuple, forward: bool, fraction: float):
    x1, y1, x2, y2 = bounds
    cx, mid, dist = (x1 + x2) // 2, (y1 + y2) // 2, max(120, int((y2 - y1) * fraction))
    if forward:   # reveal later items: the finger moves up
        swipe_coords(driver, cx, mid + dist // 2, cx, mid - dist // 2, duration_ms=500)
    else:
        swipe_coords(driver, cx, mid - dist // 2, cx, mid + dist // 2, duration_ms=500)


def _as_target(driver, locator: dict, hit: dict, scrolled: bool, need_element: bool, pages: int):
    # Typing needs a real element. A tap goes where the matched node is right now: a
    # second Appium lookup could pick a different match (a dropdown's option vs. the
    # same text on the field behind it) and costs another hierarchy dump.
    if need_element:
        element = resolve_locator(driver, locator)
        if element is not None:
            return element
    return PointTarget(driver, hit, pages)


def _has_identity(locator: dict) -> bool:
    return any(locator.get(k) for k in ("label_xpath", "resource_id", "content_desc", "text", "xpath", "candidates"))


def resolve_with_scroll_search(driver, locator: dict, max_scroll_attempts: Optional[int] = None,
                               should_stop=None, need_element: bool = False, wait_s: Optional[float] = None,
                               also_look=None, while_waiting=None):
    """Find a recorded tap/type target, scrolling to it if it is not on screen.

    Judged from the live screen each time, never by replaying the swipes recorded on
    the way (a picker opens on its CURRENT selection, which differs run to run):
      1. on screen already -> use it;
      2. otherwise scroll THE LIST a page at a time - the way the visible order implies
         when the list is sorted, else to one end and then the other - stopping when a
         page doesn't move or the visible range shows it can't be there;
      3. a row cut off at the list's edge is nudged fully into view;
      4. before tapping a row that was reached by scrolling, re-read until it has
         stopped moving, so the tap lands where the row is NOW, not where it was.
    While it waits, `while_waiting(seconds waited)` may clear what's in the way (an open
    keyboard, a popup) and returns True when it did, to look again at once. A strategy naming
    the element that finds nothing is retried in a looser form once it has waited RELAX_AFTER_S.
    Returns None when the target is not found - callers must treat that as a failure."""
    global last_search_pages
    last_search_pages = 0
    started = time.time()

    def waited() -> float:
        return time.time() - started

    def cleared() -> bool:
        return bool(while_waiting is not None and while_waiting(waited()))

    def check():
        if should_stop is not None and should_stop():
            raise RunStopped()

    def reread():
        time.sleep(SCROLL_SETTLE_S)
        return parse_page_source(get_page_source(driver))

    global last_match
    last_match = None
    deadline = time.time() + (settings.step_wait_seconds if wait_s is None else wait_s)
    target_attr, target = _scroll_anchor(locator)
    if target is None:
        # resource-id / xpath only - nothing to search for by text, but the screen may still be loading
        if not _has_identity(locator):
            return None
        while True:
            check()
            element = resolve_locator(driver, locator, relax=waited() >= RELAX_AFTER_S)
            if element is not None or time.time() >= deadline:
                return element
            if cleared():
                continue
            time.sleep(STEP_POLL_S)

    check()
    screen = get_window_size(driver)
    max_pages = max_scroll_attempts or settings.scroll_search_max_pages
    nodes = parse_page_source(get_page_source(driver))

    # Wait for it before scrolling for it: right after a login or a screen change the
    # target often just hasn't been drawn yet, and scrolling a half-loaded screen fails.
    # Scrolling starts once a list is showing and two reads in a row look the same.
    previous = None
    while match_locator_in_nodes(nodes, locator, screen) is None and time.time() < deadline:
        # Somewhere else to look while waiting (the app's web page - a web popup can be
        # missing from Android's view): found there, nothing needs scrolling.
        extra = also_look() if also_look is not None else None
        if extra is not None:
            return extra
        if cleared():
            nodes = parse_page_source(get_page_source(driver))
            continue
        labels = _labels_now(nodes, screen)
        if labels == previous and find_scroll_container(nodes, screen) is not None:
            break
        previous = labels
        check()
        time.sleep(STEP_POLL_S)
        nodes = parse_page_source(get_page_source(driver))

    forward, flips, nudges, pages, confirms, confirmed_at = None, 0, 0, 0, 0, None

    while True:
        check()
        container = find_scroll_container(nodes, screen)
        bounds = _bounds_of(container, screen)
        hit = match_locator_in_nodes(nodes, locator, screen)
        sorted_known, stride = False, 1

        if hit is not None:
            if container is None or nudges >= 3 or _comfortably_visible(hit, bounds, nodes, container):
                if pages == 0 or confirms >= 6 or confirmed_at == hit.get("bounds"):
                    last_search_pages = pages
                    # Found by the label means found by its main (label-anchored) locator, not a
                    # backup - record it as primary so the run log doesn't read "main didn't match".
                    if target_attr == "label":
                        note_match(locator, *(main_strategy(locator) or ("label", target)))
                    else:
                        note_match(locator, target_attr, target)
                    return _as_target(driver, locator, hit, pages > 0, need_element, pages)
                confirmed_at, confirms = hit.get("bounds"), confirms + 1   # same position twice in a row = settled
                nodes = reread()
                continue
            hb = parse_bounds(hit["bounds"])
            forward, fraction, nudges = (hb[1] + hb[3]) // 2 > (bounds[1] + bounds[3]) // 2, 0.25, nudges + 1
        else:
            fraction = 0.8   # ~2 rows of overlap with the previous page, so nothing can be jumped over
            labels = _container_labels(nodes, container)
            verdict = infer_direction(target, labels)
            if verdict == "absent":
                break
            if verdict is not None:
                forward, sorted_known = verdict == "forward", True
                stride = _stride(target, labels, forward)
            elif forward is None:
                forward = True

        if pages >= max_pages:
            break
        before = tuple(_container_labels(nodes, container))
        for _ in range(stride):
            if pages >= max_pages:
                break
            check()
            _scroll_page(driver, bounds, forward, fraction)
            pages += 1
        confirmed_at = None
        nodes = reread()
        if hit is None and _labels_now(nodes, screen) == before:
            nodes = reread()   # a dump can lag the scroll it follows: only a second identical read means "end of list"
            if _labels_now(nodes, screen) == before:
                if sorted_known or flips >= 1:
                    break
                forward, flips = not forward, flips + 1

    last_search_pages = pages
    if target_attr == "label":
        # A row identified only by a label inside it (an account number) that scrolling never
        # found: fail rather than let a brittle fixed-position candidate tap a different row.
        return None
    return resolve_locator(driver, locator, relax=True)   # last resort: Appium's own lookup


# ---------------------------------------------------------------------
# Action primitives
# ---------------------------------------------------------------------

def tap_coords(driver, x: int, y: int):
    try:
        driver.execute_script("mobile: clickGesture", {"x": x, "y": y})
        return
    except Exception:
        pass
    pointer = PointerInput("touch", "finger")
    actions = ActionBuilder(driver, mouse=pointer)
    actions.pointer_action.move_to_location(x, y)
    actions.pointer_action.pointer_down()
    actions.pointer_action.pause(0.05)
    actions.pointer_action.pointer_up()
    actions.perform()


def in_webview(locator: Optional[dict]) -> bool:
    """Whether a native locator points at web content inside a WebView (its path runs through one)."""
    return any("android.webkit.WebView" in str(value) for _, value in (locator or {}).get("candidates") or [])


# Android's own dropdown/dialog internals: a row in the OPEN list (android:id/text1), or the
# dialog container that only exists while the list is open. A dropdown's opener (the field you
# tap to open it) can never be found by these - they appear only after it's already open.
_DIALOG_INTERNAL_IDS = ("android:id/custom", "android:id/select_dialog_listview",
                        "android:id/text1", "android:id/text2")


def opener_in_open_list(locator: Optional[dict]) -> bool:
    """Whether a Select step's opener locator actually points inside the opened list/dialog, so
    it could only match once the dropdown is already open - a mis-capture. Such a dropdown is
    opened by its screen position instead (the option is still picked by its text)."""
    if not locator:
        return False
    if (locator.get("resource_id") or "") in _DIALOG_INTERNAL_IDS:
        return True
    for _, value in locator.get("candidates") or []:
        if any(f'"{i}"' in str(value) for i in _DIALOG_INTERNAL_IDS):
            return True
    return False


def tap_element(driver, element, offset: Optional[dict] = None, screen: Optional[dict] = None,
                locator: Optional[dict] = None):
    """`offset` (see offset_from_center) taps beside the element instead of on it: the
    icon a label captions, or a password field's show/hide icon.

    With `locator`: a tap recorded on a big container's empty part (its "tap_at", as
    fractions of the element's size) lands on the same spot within it, not its middle
    (which may be a row or a button); and web content inside a WebView gets a real tap -
    a page listening for touches ignores Appium's accessibility click()."""
    tap_at = (locator or {}).get("tap_at")
    if offset and screen:
        rect = element.rect
        tap_coords(driver, int(rect["x"] + rect["width"] / 2 + offset.get("dx", 0) * screen["width"]),
                   int(rect["y"] + rect["height"] / 2 + offset.get("dy", 0) * screen["height"]))
        return
    if tap_at:
        rect = element.rect
        tap_coords(driver, int(rect["x"] + rect["width"] * tap_at[0]), int(rect["y"] + rect["height"] * tap_at[1]))
        return
    if in_webview(locator):
        rect = element.rect
        tap_coords(driver, int(rect["x"] + rect["width"] / 2), int(rect["y"] + rect["height"] / 2))
        return
    try:
        element.click()
    except Exception:
        rect = element.rect
        tap_coords(driver, int(rect["x"] + rect["width"] / 2), int(rect["y"] + rect["height"] / 2))


def _text_box(element):
    """The text box itself: the element when it's an EditText, else the one EditText inside it
    (a field found by its label or wrapper - React Native draws "Password" around the box).
    Only ever a real element we can send_keys to - a coordinate-only PointTarget (no send_keys,
    no find_elements) is not one, so it's typed into via the focused box after a tap instead."""
    if not hasattr(element, "find_elements"):
        return element if hasattr(element, "send_keys") else None
    try:
        if "EditText" in (element.get_attribute("class") or element.get_attribute("className") or ""):
            return element
    except Exception:
        return None
    try:
        inner = element.find_elements(By.XPATH, ".//*[contains(@class, 'EditText')]")
    except Exception:
        return None
    return inner[0] if len(inner) == 1 else None


def _focused_text_box(driver):
    try:
        found = driver.find_elements(By.XPATH, "//*[@focused='true'][contains(@class, 'EditText')]")
    except Exception:
        return None
    return found[0] if found else None


def type_into_element(driver, element, text: str):
    """Type into a text field. A field found by its wrapper or label (not the box itself) is
    typed into through the box inside it, or the one that has focus once it's tapped -
    typing into a wrapper is silently ignored, which made such steps "pass" with nothing typed.
    Without any box to find, the text is typed on the keyboard into whatever has focus."""
    box = _text_box(element)
    try:
        (box or element).click()
    except Exception:
        pass
    if box is None:
        time.sleep(0.3)   # the tap moves focus to the field
        box = _focused_text_box(driver)
    if box is None or not hasattr(box, "send_keys"):
        driver.execute_script("mobile: type", {"text": text})
        return
    try:
        box.clear()
    except Exception:
        pass
    box.send_keys(text)


def type_at_coords(driver, x: int, y: int, text: str):
    tap_coords(driver, x, y)
    driver.execute_script("mobile: type", {"text": text})


def swipe_coords(driver, x1: int, y1: int, x2: int, y2: int, duration_ms: int = 400):
    finger = PointerInput("touch", "finger")
    actions = ActionBuilder(driver, mouse=finger, duration=duration_ms)
    actions.pointer_action.move_to_location(x1, y1)
    actions.pointer_action.pointer_down()
    actions.pointer_action.pause(0.05)
    actions.pointer_action.move_to_location(x2, y2)
    actions.pointer_action.pause(0.15)
    actions.pointer_action.pointer_up()
    actions.perform()


def swipe_direction(driver, screen: dict, direction: str, percent: float = 0.7):
    """Screen-relative swipe (up/down/left/right) rather than literal
    recorded pixel coordinates - robust across devices with different
    screen sizes/resolutions than the one a scenario was recorded on."""
    w, h = screen["width"], screen["height"]
    cx, cy = w // 2, h // 2
    dy, dx = int(h * percent / 2), int(w * percent / 2)
    if direction == "up":
        swipe_coords(driver, cx, cy + dy // 2, cx, cy - dy // 2)
    elif direction == "down":
        swipe_coords(driver, cx, cy - dy // 2, cx, cy + dy // 2)
    elif direction == "left":
        swipe_coords(driver, cx + dx // 2, cy, cx - dx // 2, cy)
    else:
        swipe_coords(driver, cx - dx // 2, cy, cx + dx // 2, cy)


_KEYCODES = {"back": 4, "home": 3, "enter": 66, "recents": 187, "menu": 82,
             "volume_up": 24, "volume_down": 25, "power": 26}


def long_press_coords(driver, x: int, y: int, duration_ms: int = 1000):
    try:
        driver.execute_script("mobile: longClickGesture", {"x": x, "y": y, "duration": duration_ms})
        return
    except Exception:
        pass
    pointer = PointerInput("touch", "finger")
    actions = ActionBuilder(driver, mouse=pointer)
    actions.pointer_action.move_to_location(x, y)
    actions.pointer_action.pointer_down()
    actions.pointer_action.pause(duration_ms / 1000)
    actions.pointer_action.pointer_up()
    actions.perform()


def screen_signature(driver) -> tuple:
    """Every visible label on screen, in order - to tell when the screen has changed."""
    return tuple(_own_label(n) for n in parse_page_source(get_page_source(driver))
                 if n.get("displayed") != "false" and _own_label(n))


def wait_for_change(driver, before: tuple, timeout: float = 3.0) -> bool:
    deadline = time.time() + timeout
    while time.time() < deadline:
        time.sleep(0.25)
        if screen_signature(driver) != before:
            return True
    return False


def press_key(driver, key: str):
    code = _KEYCODES.get(key)
    if code is None:
        raise ValueError(f"Unsupported key '{key}' - use one of {list(_KEYCODES)}")
    driver.press_keycode(code)


_NAV_IDS = {"back": "back", "home": "home", "recent_apps": "recents"}
_NAV_DESCS = {"back": "back", "home": "home", "recent apps": "recents", "recents": "recents", "overview": "recents"}
_nav_cache: dict = {}


def nav_buttons(driver) -> list:
    """The on-screen navigation bar's buttons ([{"key", "bounds"}]), read once per session.

    The nav bar belongs to System UI, not the app, so the normal page source never
    contains it - a touch on Back (or on "hide keyboard", which is the same button
    while a keyboard is up) would otherwise resolve to empty space and be lost. One
    multi-window dump finds the buttons; empty with gesture navigation (no buttons)."""
    key = getattr(driver, "session_id", None) or id(driver)
    if key not in _nav_cache:
        found = []
        try:
            driver.update_settings({"enableMultiWindows": True})
            try:
                xml = driver.page_source
            finally:
                driver.update_settings({"enableMultiWindows": False})
            for n in parse_page_source(xml):
                if n.get("package") != "com.android.systemui":
                    continue
                name = nav_key_for(n.get("resource-id"), n.get("content-desc"))
                b = parse_bounds(n.get("bounds", ""))
                if name and b and b[2] > b[0] and b[3] > b[1] and not any(f["key"] == name for f in found):
                    found.append({"key": name, "bounds": b})
        except Exception:
            pass
        _nav_cache[key] = found
    return list(_nav_cache[key])


def nav_key_for(resource_id: Optional[str], content_desc: Optional[str]) -> Optional[str]:
    """"back" / "home" / "recents" for a System UI navigation-bar button, else None."""
    return (_NAV_IDS.get((resource_id or "").rsplit("/", 1)[-1])
            or _NAV_DESCS.get(_sanitize(content_desc).lower()))


def nav_button_at(buttons: list, x: int, y: int) -> Optional[str]:
    return next((b["key"] for b in buttons
                 if b["bounds"][0] <= x <= b["bounds"][2] and b["bounds"][1] <= y <= b["bounds"][3]), None)


# ---------------------------------------------------------------------
# Condensed element list - fed to the LLM for AI-assisted planning
# ---------------------------------------------------------------------

def condensed_elements(driver, max_elements: int = 60) -> tuple[str, dict]:
    """Short text block + {ref: attrs} map of the on-screen, labelled
    elements - deliberately lean (label + class + resource-id only), the
    same idea as an Appium Inspector element list. Only elements with
    some text/content-desc/hint are included; a pure decorative container
    is never something the AI would be asked to tap by description."""
    nodes = parse_page_source(get_page_source(driver))
    lines, ref_map = [], {}
    idx = 0
    for attrs in nodes:
        if attrs.get("displayed") == "false":
            continue
        label = _sanitize(attrs.get("text")) or _sanitize(attrs.get("content-desc")) or _sanitize(attrs.get("hint"))
        if not label:
            continue
        ref = f"E{idx}"
        ref_map[ref] = attrs
        cls_short = (attrs.get("class") or "").rsplit(".", 1)[-1]
        rid = (attrs.get("resource-id") or "").rsplit("/", 1)[-1]
        flags = "clickable" if _is_actionable(attrs) else ""
        lines.append(f"[{ref}] <{cls_short} id='{rid}' {flags}>{label[:60]}</{cls_short}>")
        idx += 1
        if idx >= max_elements:
            break
    return "\n".join(lines), ref_map


def image_b64_to_bytes(image_b64: str) -> bytes:
    return base64.b64decode(image_b64)


def apply_performance_settings(driver, mjpeg: bool):
    """Tune UiAutomator2 for interactive use. Out of the box it waits up to
    10 s for the app to go "idle" before EVERY command, which on any screen
    with a spinner or animation makes each tap and page-source dump crawl.
    Each setting is applied on its own so one the installed driver doesn't
    recognise can't stop the rest."""
    wanted = {"waitForIdleTimeout": 300, "actionAcknowledgmentTimeout": 300, "waitForSelectorTimeout": 500}
    if mjpeg:
        wanted.update({
            "mjpegServerFramerate": settings.mjpeg_framerate,
            "mjpegServerScreenshotQuality": settings.mjpeg_quality,
            "mjpegScalingFactor": settings.mjpeg_scaling_factor,
        })
    for name, value in wanted.items():
        try:
            driver.update_settings({name: value})
        except Exception:
            pass


# ---------------------------------------------------------------------
# What's inside an element (a settings row's label, a checkable control)
# ---------------------------------------------------------------------

def descendants(nodes: list, attrs: dict) -> list:
    i, end = attrs.get("_i"), attrs.get("_end")
    if i is None or end is None:
        return []
    return nodes[i + 1: end + 1]


def _own_label(n: dict) -> str:
    return _sanitize(n.get("text")) or _sanitize(n.get("content-desc"))


def child_labels(nodes: list, attrs: dict, limit: int = 3) -> list:
    """Visible nodes inside this one that carry a label, in reading order. An
    EditText is skipped: its "text" is whatever was typed (or its hint), not a label."""
    out = []
    for n in descendants(nodes, attrs):
        if n.get("displayed") == "false" or "EditText" in (n.get("class") or ""):
            continue
        if _own_label(n):
            out.append(n)
            if len(out) >= limit:
                break
    return out


def element_label(attrs: dict, nodes: list):
    """(label, source node): the element's own text, else the first label inside
    it - so a clickable row with no text of its own is still named for its title."""
    own = element_own_text(attrs)
    if own:
        return own, None
    kids = child_labels(nodes, attrs, limit=1)
    if kids:
        return _own_label(kids[0]), kids[0]
    return "", None


def _first_checkable(nodes: Optional[list], attrs: dict):
    for n in descendants(nodes or [], attrs):
        if is_checkable(n):
            return n
    return None


def is_selection_control(element) -> bool:
    try:
        cls = element.get_attribute("class") or ""
    except Exception:
        return False
    return "Radio" in cls or "CheckedTextView" in cls


def read_checked_state(driver, element, locator: dict) -> Optional[bool]:
    """Current checked state of what a replayed tap will toggle, or None when it
    isn't a toggle. A row's label has no state of its own (a plain view always
    reports checked="false"), so the switch inside the row is read instead
    (state_xpath). A radio/list-choice item is a selection, not a toggle: None,
    so the tap always happens (this also protects scenarios recorded before
    radio items stopped carrying a desired state)."""
    target = element
    xp = locator.get("state_xpath")
    if xp:
        try:
            found = driver.find_elements(By.XPATH, xp)
            if found:
                target = found[0]
        except Exception:
            pass
    if is_selection_control(target):
        return None
    return is_element_checked(target)


def _stride(target: str, labels: list, forward: bool) -> int:
    """How many pages to scroll before re-reading, in a list known to be ordered: the
    further the target's initial is from the visible edge, the more pages it is safe
    to cover blind. Overshoot is harmless - the next read says which way to come back."""
    if not labels:
        return 1
    edge = labels[-1] if forward else labels[0]
    try:
        gap = abs(ord(_plain_key(target)[0]) - ord(_plain_key(edge)[0]))
    except (IndexError, TypeError):
        return 1
    return 3 if gap >= 4 else 2 if gap >= 2 else 1


def _labels_now(nodes: list, screen: dict) -> tuple:
    return tuple(_container_labels(nodes, find_scroll_container(nodes, screen)))


def context_label(nodes: list, attrs: dict, max_gap_px: int = 40) -> str:
    node = context_label_node(nodes, attrs, max_gap_px)
    return _own_label(node) if node is not None else ""


def context_label_node(nodes: list, attrs: dict, max_gap_px: int = 40) -> Optional[dict]:
    """A short static label sitting immediately above this element - e.g. a form
    field's title ("Select Clients") above its current value ("SBI Preprod 3").
    Deliberately tighter than nearby_label (which looks back up to 6 nodes for
    ANY bare control with no label at all): only the single IMMEDIATELY preceding
    node counts, and only when it sits just above and roughly left-aligned - so an
    ordinary button that merely happens to follow some unrelated text isn't
    mistaken for a labelled field."""
    idx = next((i for i, n in enumerate(nodes) if n.get("bounds") == attrs.get("bounds")), None)
    if not idx:
        return None
    prev = nodes[idx - 1]
    label = _own_label(prev)
    # A genuine field label is a plain static caption, never itself something you'd
    # tap - excluding one that IS clickable/checkable is what tells "Select Clients"
    # (a label) apart from "Log In" (a button that simply happens to sit nearby).
    # A sensitive field's own typed value is excluded for the same reason nearby_label
    # excludes it: it must never leak into some OTHER element's description this way.
    if (not label or "EditText" in (prev.get("class") or "") or _is_actionable(prev)
            or is_sensitive_field(prev, nodes) or looks_dynamic(label)):
        return None
    tb, pb = parse_bounds(attrs.get("bounds", "")), parse_bounds(prev.get("bounds", ""))
    if not tb or not pb:
        return None
    gap = tb[1] - pb[3]
    return prev if (-10 <= gap <= max_gap_px and pb[0] <= tb[0] + 20) else None


def spatial_label_node(nodes: list, attrs: Optional[dict] = None, point: Optional[tuple] = None) -> Optional[dict]:
    """The caption a person would read as this control's name, judged by position on
    screen rather than order in the dump: an icon tab's "Transaction" under it, a card's
    "Payslip". (nearby_label only looks BACKWARDS in document order, so a caption drawn
    after its icon was missed and an unrelated earlier text - a badge count - borrowed.)
    Pass `point` instead of attrs to search around a bare touch position."""
    if attrs is not None:
        b = parse_bounds(attrs.get("bounds", ""))
    elif point is not None:
        b = (point[0], point[1], point[0], point[1])
    else:
        return None
    if not b:
        return None
    w, h = b[2] - b[0], b[3] - b[1]
    reach = min(200, max(80, int(0.6 * max(w, h)) + 24))
    best, best_score = None, None
    for n in nodes:
        if n is attrs or n.get("displayed") == "false":
            continue
        label = _own_label(n)
        if (not label or len(label) > 60 or "EditText" in (n.get("class") or "")
                or is_sensitive_field(n, nodes) or looks_dynamic(label)):
            continue   # an anchor must be fixed text - not a field, a secret, or a value
        nb = parse_bounds(n.get("bounds", ""))
        if not nb:
            continue
        n_area = (nb[2] - nb[0]) * (nb[3] - nb[1])
        if nb[0] <= b[0] and nb[1] <= b[1] and nb[2] >= b[2] and nb[3] >= b[3] and n_area > max(4 * w * h, 200_000):
            continue   # a big labelled container around it (a screen, a section) names nothing in particular
        dx = max(nb[0] - b[2], b[0] - nb[2], 0)
        dy = max(nb[1] - b[3], b[1] - nb[3], 0)
        dist = (dx * dx + dy * dy) ** 0.5
        if dist > reach:
            continue
        # An icon's caption sits under or beside it, and text above it is more often a
        # heading - but a text field's label is above it.
        above = nb[3] <= b[1] and not (attrs is not None and is_editable(attrs))
        score = dist + (reach / 2 if above else 0)
        if best_score is None or score < best_score:
            best, best_score = n, score
    return best


def is_trailing_icon_tap(attrs: dict, nodes: list, x: int, y: int) -> bool:
    """A touch on the right end of a password field, where its show/hide icon sits. Many
    apps draw that icon inside the field without an accessibility node of its own, so the
    touch resolves to the field itself and used to be mistaken for "tapping back into the
    field being typed in" - never recorded."""
    if not is_editable(attrs) or not is_sensitive_field(attrs, nodes):
        return False
    b = parse_bounds(attrs.get("bounds", ""))
    if not b:
        return False
    w, h = b[2] - b[0], b[3] - b[1]
    if w < 3 * h:
        return False   # too narrow to hold text and an icon side by side
    return x >= b[2] - min(int(1.2 * h), w // 4)


def field_icon_at(nodes: list, attrs: Optional[dict], x: int, y: int) -> Optional[dict]:
    """The text field whose icon (show/hide password, clear) this touch hit, or None.
    Either something smaller than the field is drawn over it at that point (an icon of
    its own - often an icon-font glyph that isn't even clickable), or the touch landed on
    a password field's right end, where the icon is drawn as part of the field itself."""
    fields = [n for n in visible_at(nodes, x, y) if is_editable(n)]
    if not fields:
        return None
    field = min(fields, key=_area)
    if attrs is not None and attrs.get("bounds") != field.get("bounds") and 0 < _area(attrs) < _area(field):
        return field
    return field if is_trailing_icon_tap(field, nodes, x, y) else None


# ---------------------------------------------------------------------
# Checks (assert steps): what to verify, and reading it back on replay
# ---------------------------------------------------------------------

CHECKS = {
    "visible": "is visible", "not_visible": "is not visible",
    "text_equals": "text is", "text_contains": "text contains", "text_matches": "text matches (regex)",
    "enabled": "is enabled", "disabled": "is disabled",
    "checked": "is checked", "unchecked": "is not checked", "selected": "is selected",
    # Screen-level: about the whole screen, no element picked.
    "screen_has_text": "screen shows text", "screen_lacks_text": "screen doesn't show text",
    "toast": "toast message appears", "on_screen": "app / screen is",
    "dialog_shown": "a popup is open", "no_dialog": "no popup is open",
    "keyboard_shown": "keyboard is shown", "keyboard_hidden": "keyboard is hidden",
}
TEXT_CHECKS = ("text_equals", "text_contains", "text_matches", "screen_has_text", "screen_lacks_text", "on_screen", "toast")
SCREEN_CHECKS = ("screen_has_text", "screen_lacks_text", "toast", "on_screen", "dialog_shown", "no_dialog",
                 "keyboard_shown", "keyboard_hidden")


def screen_texts(driver) -> list:
    """Every piece of visible text on screen (text, content-desc and hints)."""
    out = []
    for n in parse_page_source(get_page_source(driver)):
        if n.get("displayed") == "false":
            continue
        for attr in ("text", "content-desc", "hint"):
            value = _sanitize(n.get(attr))
            if value and value not in out:
                out.append(value)
    return out


def toast_texts(driver) -> list:
    """Android toasts on screen right now. UiAutomator2 exposes them as android.widget.Toast
    for as long as they show (~2-3 s)."""
    try:
        return [_sanitize(el.get_attribute("text") or el.text) for el in
                driver.find_elements(By.XPATH, "//android.widget.Toast")]
    except Exception:
        return []


def app_window_count(driver, package: str) -> int:
    """How many windows of `package` are on screen: more than one means a popup (a dialog,
    a dropdown's list, a menu) is open over the app's page. Needs a multi-window dump."""
    try:
        driver.update_settings({"enableMultiWindows": True})
        try:
            xml = driver.page_source
        finally:
            driver.update_settings({"enableMultiWindows": False})
        root = ET.fromstring(xml)
    except Exception:
        return 0
    return sum(1 for w in root if w.get("package") == package)


def keyboard_shown(driver) -> Optional[bool]:
    try:
        return bool(driver.is_keyboard_shown())
    except Exception:
        return None


def hide_keyboard(driver) -> bool:
    """Close the on-screen keyboard if it's open (it can cover or shift the next element).
    True when it was open and was closed."""
    try:
        if driver.is_keyboard_shown():
            driver.hide_keyboard()
            time.sleep(0.4)
            return True
    except Exception:   # some keyboards refuse: carry on
        pass
    return False


# Screenshots of banking / HR apps show account numbers, balances, dates and names: those are
# blacked out before a screenshot is kept in a run's results (MASK_SCREENSHOTS in .env).
_SPELLED_DIGITS = re.compile(r"(?:\b(?:zero|one|two|three|four|five|six|seven|eight|nine)\b[ ,]*){4,}", re.I)
_DATA_NUMBER = re.compile(r"(?<![\d.,])\d{6,}(?![\d.,])")


def sensitive_text(text: Optional[str]) -> bool:
    """An amount, a date or time, an account / ID number - also one spelled out for
    accessibility ("one two three four...")."""
    text = text or ""
    return bool(locator_mod.volatile(text) or _DATA_NUMBER.search(text) or _SPELLED_DIGITS.search(text))


def mask_screenshot_b64(image_b64: str, nodes: list, screen_width: int) -> str:
    """The screenshot with every element showing sensitive text blacked out (never one covering
    a quarter of the screen or more - that would hide the whole page). `screen_width`: the
    width element bounds are in (screenshots are downscaled - see get_screenshot_b64)."""
    from PIL import ImageDraw
    boxes = []
    for n in nodes:
        if n.get("displayed") == "false":
            continue
        if sensitive_text(n.get("text")) or sensitive_text(n.get("content-desc")):
            b = parse_bounds(n.get("bounds", ""))
            if b:
                boxes.append(b)
    if not boxes:
        return image_b64
    try:
        image = Image.open(BytesIO(base64.b64decode(image_b64)))
        image = image.convert("RGB")
    except Exception:
        return image_b64
    sx = image.width / screen_width if screen_width else 1.0
    draw = ImageDraw.Draw(image)
    for x1, y1, x2, y2 in boxes:
        if (x2 - x1) * (y2 - y1) * sx * sx < 0.25 * image.width * image.height:
            draw.rectangle([x1 * sx, y1 * sx, x2 * sx, y2 * sx], fill="black")
    out = BytesIO()
    image.save(out, format="JPEG", quality=80)
    return base64.b64encode(out.getvalue()).decode("ascii")


def element_for_check(nodes: list, x: int, y: int) -> Optional[dict]:
    """The element a check picked at (x, y) is about: a text field there (its value), else
    the smallest element showing text (a heading, a value - not the clickable row around
    it, which is what a TAP wants), else whatever a tap would pick."""
    here = visible_at(nodes, x, y)
    fields = [n for n in here if is_editable(n)]
    if fields:
        return min(fields, key=_area)
    labelled = [n for n in here if _own_label(n)]
    if labelled:
        return min(labelled, key=_area)
    return pick_attrs_at_point(nodes, x, y)


def element_state(attrs) -> dict:
    """What a check can verify about an element (a parsed node dict, a PointTarget or a
    live WebElement - all answer get_attribute)."""
    get = attrs.get if isinstance(attrs, dict) else attrs.get_attribute

    def flag(name):
        value = get(name)
        return str(value).lower() == "true" if value is not None else None

    return {"text": _sanitize(get("text")) or _sanitize(get("content-desc")),
            "enabled": flag("enabled"), "checked": flag("checked"), "checkable": flag("checkable"),
            "selected": flag("selected")}


def find_for_check(driver, locator: dict, screen: dict):
    """One look (no waiting, no scrolling) for a check's element. A locator anchored to a
    label (a dropdown found via "Select Clients") resolves to the element AT the anchored
    point, not the label - that's the thing whose value is being checked."""
    _, _, target = _semantic_target(locator)
    if target is None:
        return resolve_locator(driver, locator) if _has_identity(locator) else None
    nodes = parse_page_source(get_page_source(driver))
    hit = match_locator_in_nodes(nodes, locator, screen)
    if hit is None:
        return None
    return check_target(driver, PointTarget(driver, hit), locator, screen, nodes)


def check_target(driver, element, locator: dict, screen: dict, nodes: Optional[list] = None):
    offset = locator.get("tap_offset")
    if not offset or element is None:
        return element
    rect = element.rect
    x = int(rect["x"] + rect["width"] / 2 + offset.get("dx", 0) * screen["width"])
    y = int(rect["y"] + rect["height"] / 2 + offset.get("dy", 0) * screen["height"])
    nodes = nodes if nodes is not None else parse_page_source(get_page_source(driver))
    attrs = element_for_check(nodes, x, y)
    return PointTarget(driver, attrs) if attrs is not None else None


def field_icon_description(nodes: list, field: dict) -> str:
    name = field_name(nodes, field)
    return f"Show/hide password in {name}" if is_sensitive_field(field, nodes) else f"Icon in {name} field"


def field_name(nodes: list, attrs: dict, default: str = "the field") -> str:
    """A text field's name. Its own hint comes first: many apps (Material's floating
    label) draw the "Password" label as the field's hint, with no text element of its
    own - so the text before it in the dump is the PREVIOUS field's label ("PF Index")."""
    return (_sanitize(attrs.get("hint")) or context_label(nodes, attrs)
            or _humanize_id(attrs.get("resource-id")) or nearby_label(nodes, attrs) or default)


def _humanize_id(resource_id: Optional[str]) -> str:
    """"com.x:id/employeePassword" -> "Employee password"; "" for an obfuscated one ("g")."""
    name = (resource_id or "").rsplit("/", 1)[-1]
    if len(name) <= 2:
        return ""
    words = re.sub(r"([a-z0-9])([A-Z])", r"\1 \2", name).replace("_", " ").replace("-", " ").split()
    return " ".join(words).capitalize()


def keyboard_likely(nodes: list, screen: dict, y: int) -> bool:
    """The on-screen keyboard is its own window, never in the app's page source - a key
    press looks like a touch on whatever app content lies underneath. It's up when a text
    field has focus, and it covers the lower part of the screen."""
    focused = any(is_editable(n) and n.get("focused") == "true" for n in nodes)
    return focused and y >= 0.45 * (screen.get("height") or 0)


_SENSITIVE_KEYWORDS = ("password", "pwd", "passcode", "pass code", "pin", "cvv", "otp", "mpin", "secret")
# Whole-word only - a naive substring check would flag "Pinch to zoom" (contains "pin") or
# "Spinner" as sensitive, which is exactly the kind of false positive that silently swallows
# an unrelated field's real label.
_SENSITIVE_RE = re.compile(r"\b(" + "|".join(re.escape(k) for k in _SENSITIVE_KEYWORDS) + r")\b", re.IGNORECASE)


def _has_sensitive_keyword(text: Optional[str]) -> bool:
    if not text:
        return False
    # Ids join words without spaces - "employeePassword", "user_pin": split them first.
    words = re.sub(r"([a-z0-9])([A-Z])", r"\1 \2", text).replace("_", " ").replace("/", " ")
    return bool(_SENSITIVE_RE.search(words))


def is_sensitive_field(n: dict, nodes: list) -> bool:
    """True for a field whose VALUE should never be captured. The Android
    password="true" accessibility flag is the strongest signal when present,
    but not every app's field sets it (a custom keypad, some cross-platform
    frameworks) - so this also checks the field's own hint/content-desc/
    resource-id, and the immediately preceding label, for password-like
    keywords. That preceding check is a single direct hop to the raw node -
    deliberately NOT through context_label/nearby_label, which both call
    THIS function to decide what they're allowed to use as a label; going
    through them here would make the two recurse into each other."""
    if n.get("password") == "true":
        return True
    if _has_sensitive_keyword(" ".join(filter(None, [n.get("hint"), n.get("content-desc"), n.get("resource-id")]))):
        return True
    idx = next((i for i, node in enumerate(nodes) if node.get("bounds") == n.get("bounds")), None)
    if idx:
        prev = nodes[idx - 1]
        if not _is_actionable(prev) and "EditText" not in (prev.get("class") or ""):
            if _has_sensitive_keyword(_own_label(prev)):
                return True
    return False


def field_relative_label(nodes: list, attrs: dict) -> str:
    """For an unlabelled icon-like control (a password show/hide toggle, a
    clear-field 'x') sitting inside or right beside a text field, borrow
    that field's own label for context - clearer than the generic
    "tapped element" fallback when nothing directly identifies the icon
    itself."""
    b = parse_bounds(attrs.get("bounds", ""))
    if not b:
        return ""
    for n in nodes:
        if "EditText" not in (n.get("class") or "") or n.get("bounds") == attrs.get("bounds"):
            continue
        nb = parse_bounds(n.get("bounds", ""))
        if not nb or not (b[1] < nb[3] and b[3] > nb[1]):   # must vertically overlap the field
            continue
        gap = max(nb[0] - b[2], b[0] - nb[2], 0)
        if gap <= 2 * max(b[2] - b[0], 1):                  # close enough horizontally to belong to it
            label = context_label(nodes, n) or nearby_label(nodes, n) or _sanitize(n.get("hint"))
            if label:
                return f"icon in {label} field"
    return ""
