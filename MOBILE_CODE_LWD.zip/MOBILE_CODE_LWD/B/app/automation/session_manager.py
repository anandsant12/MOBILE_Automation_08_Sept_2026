"""
Owns the single live Appium/UiAutomator2 driver session for the connected
device. Only one session is supported at a time (matches the UI: one
phone mirrored on screen) - simplest thing that works for a single tester
driving one device.
"""

import socket
import threading
import time
from pathlib import Path
from typing import Optional
from urllib.parse import urlparse

from config import settings


def _server_reachable(url: str, timeout: float = 1.5) -> bool:
    try:
        parsed = urlparse(url)
        with socket.create_connection((parsed.hostname or "127.0.0.1", parsed.port or 4723), timeout=timeout):
            return True
    except OSError:
        return False


_DEAD_SESSION_MARKERS = (
    "instrumentation process is not running",
    "cannot be proxied to uiautomator2",
    "session is either terminated or not started",
    "invalid session id",
    "nosuchdriver",
    "could not proxy command",
    "max retries exceeded",
    "connection refused",
)


def is_dead_session_error(exc: BaseException) -> bool:
    """True for the family of errors meaning the Appium session (or the
    UiAutomator2 server on the phone behind it) is gone, as opposed to an
    ordinary failure like an element not being found. Only the former can
    be fixed by reconnecting."""
    text = str(exc).lower()
    return any(marker in text for marker in _DEAD_SESSION_MARKERS)


# Session start: Appium's server apps can need (re)installing on a phone, and some phones
# wait for an on-screen tap on "Install" (see build_options in AppiumSession.connect).
INSTALL_TIMEOUT_MS = 120_000
ADB_EXEC_TIMEOUT_MS = 60_000

SERVER_MISMATCH_HELP = (
    "Appium's two server apps on the phone don't match (usually an update that was interrupted, e.g. an "
    "install confirmation on the phone wasn't accepted in time). Fix: run\n"
    "  adb{serial} uninstall io.appium.uiautomator2.server\n"
    "  adb{serial} uninstall io.appium.uiautomator2.server.test\n"
    "then connect again and watch the phone - tap Install on both prompts if it asks."
)


def explain_session_error(exc: BaseException, serial: Optional[str] = None) -> Optional[str]:
    """A clearer message for session-start failures with a known fix, else None."""
    text = str(exc)
    serial_arg = f" -s {serial}" if serial else ""
    if "NoSuchMethodError" in text or "instrumentation process cannot be initialized" in text:
        return SERVER_MISMATCH_HELP.format(serial=serial_arg)
    if "uiautomator2ServerInstallTimeout" in text or ("install" in text.lower() and "timed out" in text.lower()):
        return ("Installing Appium's server app on the phone timed out - the phone is probably waiting for "
                "you to confirm the install on screen. Tap Install on the phone and connect again.\n\n"
                + SERVER_MISMATCH_HELP.format(serial=serial_arg))
    if "device" in text.lower() and ("not found" in text.lower() or "unauthorized" in text.lower()):
        return ("The phone isn't available to adb - check the USB cable, that USB debugging is on, and accept "
                "the \"Allow USB debugging?\" prompt on the phone. (" + text.splitlines()[0][:200] + ")")
    return None


def _activate_and_verify(driver, package: str, timeout: int):
    """Session-start capabilities only make a single best-effort attempt
    to launch the app - this polls current_package and retries
    activate_app until it sticks, raising a clear error instead of
    silently leaving the session on whatever screen happened to load."""
    deadline = time.time() + timeout
    last_seen = None
    while time.time() < deadline:
        try:
            current = driver.current_package
        except Exception:
            current = None
        last_seen = current
        if current == package:
            return
        try:
            driver.activate_app(package)
        except Exception:
            pass
        time.sleep(0.5)
    raise RuntimeError(
        f"Could not bring '{package}' to the foreground within {timeout}s "
        f"(last seen foreground package: '{last_seen}'). Check ANDROID_APP_PACKAGE / "
        f"ANDROID_APP_ACTIVITY are correct (adb shell dumpsys window | grep mCurrentFocus), "
        f"and that the app doesn't force-close itself when it detects automation."
    )


class AppiumSession:
    def __init__(self):
        self.driver = None
        self._appium_service = None
        self._we_started_appium = False
        self.package = ""
        self.activity = ""
        # The phone this session drives - chosen in the UI (auto-detected over adb), else
        # ANDROID_UDID from .env, else None (adb/Appium use the only phone plugged in).
        self.udid: Optional[str] = None
        self.platform_version: Optional[str] = None
        # Appium/UiAutomator2 does not support two commands in flight on
        # the same session at once - the mirror's own screenshot polling,
        # a scenario replay, and AI-assisted execution can all want the
        # device at overlapping moments, and without serializing them the
        # session gets confused (commands appear to hang or interleave),
        # which is exactly what running a scenario alongside live mirror
        # polling looked like before this lock existed. Every module that
        # touches self.driver acquires this around each bounded unit of
        # work (one screenshot, one step) - never around a whole run, so
        # everything still gets a fair, if serialized, turn.
        self.command_lock = threading.RLock()
        self.recovery_count = 0
        self.mjpeg_active = False  # True when the live screen stream is running for this session

    @property
    def is_connected(self) -> bool:
        return self.driver is not None

    def connect(self, package: str = "", activity: str = "", udid: Optional[str] = None,
                platform_version: Optional[str] = None):
        if self.driver is not None:
            return  # already connected - the UI only ever offers Connect when disconnected
        package = package or settings.android_app_package
        activity = activity or settings.android_app_activity
        udid = udid or settings.android_udid or None
        platform_version = platform_version or settings.android_platform_version or None
        self._ensure_appium_server()

        from appium import webdriver as appium_webdriver
        from appium.options.android import UiAutomator2Options

        def build_options(with_mjpeg: bool):
            options = UiAutomator2Options()
            options.device_name = udid or settings.android_device_name
            options.automation_name = "UiAutomator2"
            options.platform_name = "Android"
            options.no_reset = settings.android_no_reset
            options.new_command_timeout = settings.android_new_command_timeout
            options.auto_grant_permissions = True
            # UiAutomator2 otherwise switches every other accessibility service off while
            # the session runs - including the recorder helper (app/automation/helper_client.py).
            options.set_capability("appium:disableSuppressAccessibilityService", True)
            # Appium's server apps may need (re)installing; phones that ask on screen to
            # confirm installs over USB (OPPO, Realme, Vivo, Xiaomi) need time for a tap on Install.
            options.set_capability("appium:uiautomator2ServerInstallTimeout", INSTALL_TIMEOUT_MS)
            options.set_capability("appium:adbExecTimeout", ADB_EXEC_TIMEOUT_MS)
            # Skip UiAutomator2's device-initialization burst right after the server installs: on
            # ColorOS (Realme/OPPO) that is where the OS kills the freshly started server, which
            # surfaces as "instrumentation process is not running (probably crashed)". The server
            # is still (re)installed and verified - only the extra init/mock-location setup is
            # skipped, matching the reference android-record-playback session.
            options.set_capability("appium:skipDeviceInitialization", True)
            options.set_capability("appium:autoLaunch", bool(package))
            if udid:
                options.udid = udid
            if platform_version:
                options.platform_version = platform_version
            if package:
                options.app_package = package
            if activity:
                options.app_activity = activity
            if with_mjpeg:
                options.set_capability("appium:mjpegServerPort", settings.mjpeg_server_port)
            return options

        def create(options):
            if settings.android_fast_session:
                fast = UiAutomator2Options().load_capabilities(options.to_capabilities())
                fast.set_capability("appium:skipServerInstallation", True)
                fast.set_capability("appium:skipDeviceInitialization", True)
                try:
                    return appium_webdriver.Remote(settings.appium_server_url, options=fast)
                except Exception:
                    pass
            try:
                return appium_webdriver.Remote(settings.appium_server_url, options=options)
            except Exception as e:
                help_text = explain_session_error(e, udid)
                if help_text:
                    raise RuntimeError(help_text) from e
                raise

        with self.command_lock:
            self.mjpeg_active = False
            if settings.mirror_mode == "mjpeg":
                try:
                    self.driver = create(build_options(True))
                    self.mjpeg_active = True
                except Exception:
                    # e.g. the stream's port is already taken - a session without live
                    # streaming (snapshot mirror) beats no session at all.
                    self.driver = None
            if self.driver is None:
                self.driver = create(build_options(False))

            from app.automation import mobile_control as mc
            mc.apply_performance_settings(self.driver, mjpeg=self.mjpeg_active)
            mc.wake_and_unlock(self.driver)  # a screen that timed out and locked itself shouldn't block startup

            if package:
                _activate_and_verify(self.driver, package, settings.android_launch_verify_timeout)

        self.package = package
        self.activity = activity
        self.udid = udid
        self.platform_version = platform_version

    def recover(self):
        """Throw away the current (dead or half-dead) driver and open a
        fresh session on the same device/app. The UiAutomator2 server on
        the phone can die on its own (the phone killing it under battery
        pressure, the screen locking, another tool grabbing the device);
        Appium then answers every command with "instrumentation process is
        not running" forever, so without this a single crash leaves the
        whole tool permanently dead until someone restarts the backend."""
        with self.command_lock:
            package, activity = self.package, self.activity
            old, self.driver = self.driver, None
            if old is not None:
                try:
                    old.quit()
                except Exception:
                    pass
            self.connect(package, activity, self.udid, self.platform_version)   # the same phone
            self.recovery_count += 1

    def ensure_healthy(self) -> bool:
        """Cheap liveness probe; reconnects if (and only if) the session is
        dead. Returns True when it had to recover. Any other kind of
        failure is left for the real operation to report on its own."""
        with self.command_lock:
            driver = self.require_driver()
            try:
                driver.get_window_size()
                return False
            except Exception as e:
                if not is_dead_session_error(e):
                    return False
            self.recover()
            return True

    def call_with_recovery(self, fn):
        """Run fn(); if it fails because the session is dead, recover and
        run it once more. fn must fetch session.driver itself (not close
        over an old reference) so the retry uses the new session."""
        seen = self.driver
        try:
            return fn()
        except Exception as e:
            if not is_dead_session_error(e):
                raise
        with self.command_lock:
            if self.driver is seen:  # another thread may already have recovered
                self.recover()
        return fn()

    def _ensure_appium_server(self):
        if _server_reachable(settings.appium_server_url):
            return
        if not settings.auto_start_appium_server:
            raise RuntimeError(
                f"No Appium server reachable at {settings.appium_server_url} and "
                f"AUTO_START_APPIUM_SERVER=false. Start one yourself (`appium`) or "
                f"enable auto-start in .env."
            )
        from appium.webdriver.appium_service import AppiumService

        parsed = urlparse(settings.appium_server_url)
        self._appium_service = AppiumService()
        log_path = str(Path(settings.base_dir) / settings.appium_log_file)
        self._appium_service.start(
            args=["--address", parsed.hostname or "127.0.0.1", "--port", str(parsed.port or 4723),
                  "--log", log_path, "--log-timestamp"],
            timeout_ms=settings.appium_server_startup_timeout * 1000,
        )
        self._we_started_appium = True
        deadline = time.time() + settings.appium_server_startup_timeout
        while time.time() < deadline:
            if _server_reachable(settings.appium_server_url):
                return
            time.sleep(0.3)
        raise RuntimeError(
            f"Appium server did not come up within {settings.appium_server_startup_timeout}s. "
            f"Check Node.js + `npm install -g appium` + `appium driver install uiautomator2` are done."
        )

    def disconnect(self):
        if self.driver:
            try:
                self.driver.quit()
            except Exception:
                pass
            self.driver = None
        if self._we_started_appium and self._appium_service:
            try:
                self._appium_service.stop()
            except Exception:
                pass
        self._we_started_appium = False
        self.package = ""
        self.activity = ""
        self.udid = None
        self.platform_version = None

    def require_driver(self):
        if self.driver is None:
            raise RuntimeError("No active device session - connect first (POST /api/session/connect).")
        return self.driver


# Single shared instance - see module docstring.
session = AppiumSession()


def device_serial() -> Optional[str]:
    """The phone everything talks to over adb (touch capture, the helper app, the web page):
    the one connected in the UI, else ANDROID_UDID from .env, else None (the only one plugged in)."""
    return session.udid or settings.android_udid or None
