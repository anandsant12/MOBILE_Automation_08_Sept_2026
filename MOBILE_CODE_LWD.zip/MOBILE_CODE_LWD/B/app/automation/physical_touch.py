"""
Captures REAL physical touches on the connected Android device's own
touchscreen - raw evdev events read via `adb shell getevent` - as a second
input source for recording, alongside tapping the mirror in the web UI.

Why raw evdev: a programmatic tap (adb `input tap`, and Appium's own touch
injection, which uses the same framework path) never appears on the
touchscreen's own event device - only a genuine finger does. So this can run
at the same time as mirror recording without ever mistaking one for the other.

Pipeline: `adb shell getevent -lt` (background subprocess) -> parse
ABS_MT_POSITION_X/Y + BTN_TOUCH + ABS_MT_TRACKING_ID for the ONE touchscreen
node (auto-detected, never hardcoded) -> buffer points between finger-down and
finger-up -> classify tap / long_press / swipe -> PhysicalGesture in SCREEN
pixels on a thread-safe queue. Nothing here talks to Appium; see
app/services/physical_capture_service.py for turning gestures into steps.

Scope: single-finger tap/long-press/swipe. A second simultaneous finger
(pinch/zoom) drops the whole gesture. Android only.
"""

import os
import queue
import re
import shutil
import subprocess
import threading
import time
from dataclasses import dataclass
from typing import Optional

# A tapping finger drifts: 27-33px was seen on a real tap (1080px-wide screen), which used to
# turn it into a "Swipe left". A deliberate scroll or swipe moves far more.
_TAP_MAX_DISPLACEMENT_PX = 60
_LONG_PRESS_MIN_DURATION_S = 0.45
# Some touch controllers report a finger LIFT as two rapid, near-identical
# down/up cycles (a release "bounce"); a second gesture this close in time and
# position to the last is that bounce, not a deliberate second tap.
_DEBOUNCE_WINDOW_S = 0.4
_DEBOUNCE_MAX_DISPLACEMENT_PX = 40

_EVENT_LINE_RE = re.compile(
    r"^(?:\[\s*[\d.]+\]\s*)?(/dev/input/event\d+):\s+(EV_\w+)\s+(\S+)\s+(\S+)\s*$"
)


def resolve_adb() -> str:
    """Finds adb: ADB_PATH from .env, then PATH, then ANDROID_HOME /
    ANDROID_SDK_ROOT. Appium finds adb through ANDROID_HOME on its own, so
    adb being missing from PATH is common on Windows - and would otherwise
    make physical capture fail with a bare "file not found"."""
    from config import settings

    candidates = []
    if settings.adb_path:
        candidates.append(settings.adb_path)
    found = shutil.which("adb")
    if found:
        candidates.append(found)
    exe = "adb.exe" if os.name == "nt" else "adb"
    for var in ("ANDROID_HOME", "ANDROID_SDK_ROOT"):
        root = os.environ.get(var)
        if root:
            candidates.append(os.path.join(root, "platform-tools", exe))
    for candidate in candidates:
        if candidate and os.path.isfile(candidate):
            return candidate
    raise RuntimeError(
        "Could not find `adb`. Add Android platform-tools to PATH, set ANDROID_HOME, or set "
        "ADB_PATH in backend/.env (e.g. ADB_PATH=C:\\Users\\you\\AppData\\Local\\Android\\Sdk\\platform-tools\\adb.exe)."
    )


def new_stats() -> dict:
    return {"lines": 0, "touch_down": 0, "gestures": 0, "multitouch_dropped": 0, "debounced": 0}


@dataclass
class PhysicalGesture:
    kind: str   # "tap" | "long_press" | "swipe"
    x1: int
    y1: int
    x2: int
    y2: int
    duration_s: float
    t_down: float = 0.0   # wall-clock time (epoch seconds) the finger went down


def _run_adb(serial: Optional[str], *args, timeout: float = 10):
    cmd = [resolve_adb()] + (["-s", serial] if serial else []) + list(args)
    return subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)


def find_touchscreen_device(serial: Optional[str]):
    """One-off probe (`adb shell getevent -pl`) for the touchscreen input node:
    the device reporting INPUT_PROP_DIRECT with both ABS_MT_POSITION_X and _Y.
    Returns (node, raw_max_x, raw_max_y). Raises RuntimeError with the reason -
    callers treat that as non-fatal (mirror recording still works)."""
    result = _run_adb(serial, "shell", "getevent", "-pl")
    if result.returncode != 0:
        raise RuntimeError(f"`adb shell getevent -pl` failed: {(result.stderr or result.stdout or '').strip()}")

    blocks = re.split(r"(?=^add device \d+: )", result.stdout, flags=re.MULTILINE)
    for block in blocks:
        node_m = re.search(r"^add device \d+:\s+(/dev/input/event\d+)", block)
        if not node_m or "INPUT_PROP_DIRECT" not in block:
            continue
        x_m = re.search(r"ABS_MT_POSITION_X\s*:\s*value\s+-?\d+,\s*min\s+-?\d+,\s*max\s+(\d+)", block)
        y_m = re.search(r"ABS_MT_POSITION_Y\s*:\s*value\s+-?\d+,\s*min\s+-?\d+,\s*max\s+(\d+)", block)
        if not x_m or not y_m:
            continue
        return node_m.group(1), int(x_m.group(1)), int(y_m.group(1))

    raise RuntimeError(
        "No touchscreen input device found via `adb shell getevent -pl` (none reported "
        "INPUT_PROP_DIRECT with X/Y position axes) - physical-touch recording isn't available on "
        "this device; mirror recording still works."
    )


def _safe_hex(value: str) -> int:
    try:
        return int(value, 16)
    except ValueError:
        return 0


class PhysicalTouchListener:
    def __init__(self, serial: Optional[str], screen_width: int, screen_height: int):
        if not screen_width or not screen_height:
            raise RuntimeError("Screen size unknown - can't scale raw touch coordinates.")
        node, raw_max_x, raw_max_y = find_touchscreen_device(serial)
        self._serial = serial
        self._node = node
        self._raw_max_x = raw_max_x
        self._raw_max_y = raw_max_y
        self._screen_w = screen_width
        self._screen_h = screen_height
        self.gestures: "queue.Queue[PhysicalGesture]" = queue.Queue()
        self.touch_starts: "queue.Queue[tuple]" = queue.Queue()  # (x, y, t_down) at finger-down
        self.stats = new_stats()
        self.ended = False
        self._proc: Optional[subprocess.Popen] = None
        self._thread: Optional[threading.Thread] = None
        self._stop_flag = threading.Event()
        self._last_end_time: Optional[float] = None
        self._last_end_xy: Optional[tuple] = None

    @property
    def node(self) -> str:
        return self._node

    @property
    def screen_size(self) -> dict:
        return {"width": self._screen_w, "height": self._screen_h}

    def start(self):
        cmd = [resolve_adb()] + (["-s", self._serial] if self._serial else []) + ["shell", "getevent", "-lt"]
        self._proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True, bufsize=1)
        self._thread = threading.Thread(target=self._read_loop, daemon=True)
        self._thread.start()

    def stop(self):
        self._stop_flag.set()
        if self._proc is not None:
            try:
                self._proc.terminate()
            except Exception:
                pass
        self._proc = None

    def is_alive(self) -> bool:
        return self._proc is not None and self._proc.poll() is None

    def _to_screen(self, raw_x: int, raw_y: int):
        sx = round(raw_x / (self._raw_max_x + 1) * self._screen_w)
        sy = round(raw_y / (self._raw_max_y + 1) * self._screen_h)
        return sx, sy

    def _read_loop(self):
        try:
            self._read_events()
        finally:
            self.ended = True

    def _read_events(self):
        active = False           # a finger is currently down (slot 0)
        multi = False            # a second slot appeared during this gesture - drop it
        slot = 0
        start_time = None
        start_wall = 0.0
        first_xy = None
        cur_x = cur_y = None
        last_xy = None

        proc = self._proc
        if proc is None or proc.stdout is None:
            return

        for line in proc.stdout:
            if self._stop_flag.is_set():
                break
            m = _EVENT_LINE_RE.match(line.rstrip("\n"))
            if not m:
                continue
            node, ev_type, code, value = m.groups()
            if node != self._node:
                continue
            self.stats["lines"] += 1

            if ev_type == "EV_ABS" and code == "ABS_MT_SLOT":
                slot = _safe_hex(value)
                if slot != 0:
                    multi = True
                continue

            if slot != 0:
                continue

            if ev_type == "EV_ABS" and code == "ABS_MT_TRACKING_ID":
                if _safe_hex(value) == 0xFFFFFFFF:
                    self._finalize(active, multi, start_time, first_xy, last_xy, start_wall)
                    active = multi = False
                    start_time = first_xy = last_xy = None
                    cur_x = cur_y = None
                else:
                    active, multi = True, False
                    start_time = time.monotonic()
                    start_wall = time.time()
                    first_xy = last_xy = None
                    cur_x = cur_y = None
                continue

            if ev_type == "EV_KEY" and code == "BTN_TOUCH":
                if value == "UP":
                    self._finalize(active, multi, start_time, first_xy, last_xy, start_wall)
                    active = multi = False
                    start_time = first_xy = last_xy = None
                    cur_x = cur_y = None
                continue

            if not active:
                continue

            if ev_type == "EV_ABS" and code == "ABS_MT_POSITION_X":
                cur_x = _safe_hex(value)
                continue
            if ev_type == "EV_ABS" and code == "ABS_MT_POSITION_Y":
                cur_y = _safe_hex(value)
                continue

            if ev_type == "EV_SYN" and code == "SYN_REPORT" and cur_x is not None and cur_y is not None:
                sx, sy = self._to_screen(cur_x, cur_y)
                if first_xy is None:
                    first_xy = (sx, sy)
                    self.stats["touch_down"] += 1
                    self.touch_starts.put((sx, sy, start_wall))   # start_wall == the gesture's t_down
                last_xy = (sx, sy)

    def _finalize(self, active, multi, start_time, first_xy, last_xy, start_wall=0.0):
        if active and multi:
            self.stats["multitouch_dropped"] += 1
        if not active or multi or first_xy is None or start_time is None:
            return
        end_time = time.monotonic()
        duration = end_time - start_time
        x1, y1 = first_xy
        x2, y2 = last_xy or first_xy

        if self._last_end_time is not None and self._last_end_xy is not None:
            since_last = end_time - self._last_end_time
            if since_last <= _DEBOUNCE_WINDOW_S:
                lx, ly = self._last_end_xy
                from_last = ((x1 - lx) ** 2 + (y1 - ly) ** 2) ** 0.5
                if from_last <= _DEBOUNCE_MAX_DISPLACEMENT_PX:
                    self._last_end_time = end_time
                    self._last_end_xy = (x2, y2)
                    self.stats["debounced"] += 1
                    return

        displacement = ((x2 - x1) ** 2 + (y2 - y1) ** 2) ** 0.5
        if displacement > _TAP_MAX_DISPLACEMENT_PX:
            kind = "swipe"
        elif duration >= _LONG_PRESS_MIN_DURATION_S:
            kind = "long_press"
        else:
            kind = "tap"

        self._last_end_time = end_time
        self._last_end_xy = (x2, y2)
        self.stats["gestures"] += 1
        self.gestures.put(PhysicalGesture(kind, x1, y1, x2, y2, duration, start_wall))
