"""
The recorder helper app's client (app/arp/helper_client.py, from android-record-playback),
with this backend's adb lookup filled in - plus as_attrs(), which turns a helper element
into the page-source attribute shape mobile_control works with.

Appium's UiAutomator2 session suppresses other accessibility services unless it's
created with disableSuppressAccessibilityService (see session_manager) - without that
the helper goes silent as soon as a session exists.
"""

import subprocess
from typing import Optional

from app.arp import helper_client as arp
from app.automation.physical_touch import resolve_adb

HelperError = arp.HelperError


class HelperClient(arp.HelperClient):
    def __init__(self, serial: Optional[str] = None, on_event=None):
        super().__init__(serial, resolve_adb(), on_event)


def _adb(args, serial: Optional[str], check: bool = True, timeout: float = 30) -> str:
    cmd = [resolve_adb()] + (["-s", serial] if serial else []) + list(args)
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
    if check and result.returncode != 0:
        raise HelperError(f"adb {' '.join(args)} failed: {(result.stderr or result.stdout).strip()}")
    return result.stdout.strip()


def as_attrs(node: Optional[dict]) -> Optional[dict]:
    """A helper node in the page-source attribute shape the rest of the backend uses."""
    if not node:
        return None
    flag = lambda k: "true" if node.get(k) else "false"  # noqa: E731
    return {
        "class": node.get("class_name") or "", "resource-id": node.get("resource_id") or "",
        "text": node.get("text") or "", "content-desc": node.get("content_desc") or "",
        "hint": node.get("hint") or "", "bounds": node.get("bounds") or "", "package": node.get("package") or "",
        "clickable": flag("clickable"), "long-clickable": flag("long_clickable"), "checkable": flag("checkable"),
        "checked": flag("checked"), "selected": flag("selected"), "enabled": flag("enabled"),
        "focused": flag("focused"), "password": flag("password"), "scrollable": flag("scrollable"),
        "displayed": "true",
    }
