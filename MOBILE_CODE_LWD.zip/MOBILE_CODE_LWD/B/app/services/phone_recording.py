"""
Recording touches made on the phone itself - android-record-playback's engine
(app/arp/helper_recorder.py), run as-is, with its steps converted to this app's
step format when recording stops.

How it records (see app/arp/helper_recorder.py for the detail):
  - `adb getevent` says when and where each touch happens;
  - the recorder helper app on the phone says what was touched, at the moment
    the finger lands (before the app reacts), which window it was in (the
    keyboard, the navigation bar, a dropdown's popup), and what each text field
    holds when focus leaves it;
  - for apps with a debuggable WebView, the web page itself says which element
    was touched;
  - when recording stops it all comes together: taps on the keyboard are
    dropped, typing becomes one "type" step per field, "tap a dropdown, tap an
    option in the list it opened" becomes one "select" step.

So phone steps appear when recording STOPS (a select step needs to see the
option that followed). Steps from clicking the mirror are recorded separately
(recording_service) and show up at once; the UI merges both by time.

If the helper can't be started (USE_RECORDER_HELPER=false, or the phone refused
it), this falls back to physical_capture_service's snapshot-based recording.
"""

import copy
import re
import threading
import time
import types
from pathlib import Path
from typing import Optional

from config import settings
from app.arp import locator as locator_mod
from app.arp.helper_recorder import HelperRecordingSession
from app.automation import mobile_control as mc
from app.automation.physical_touch import resolve_adb
from app.automation.session_manager import device_serial
from app.services import physical_capture_service as fallback
from app.services import recording_service, screen_events

RECORDINGS_DIR = Path(settings.base_dir) / "recordings"

PREVIEW_EVERY_S = 0.7

_lock = threading.Lock()
_session: Optional[HelperRecordingSession] = None
_wall_at_t0 = 0.0
_mode = "basic"
_using_fallback = False
_error: Optional[str] = None
_live: list = []                  # draft steps so far (see _preview), replaced on every refresh
_final: Optional[list] = None     # the finished recording's steps, until the UI has taken them
_generation = 0                   # retires a previous recording's preview thread
_starting = False                 # the helper is connecting (the first couple of seconds)
_messages: list = []


KEEP_RECORDINGS = 20


def _prune_recordings():
    """Only the latest KEEP_RECORDINGS recordings' files are kept."""
    for pattern in ("phone_*_debug.json", "phone_*.jsonl"):
        for old in sorted(RECORDINGS_DIR.glob(pattern), key=lambda p: p.stat().st_mtime)[:-KEEP_RECORDINGS]:
            try:
                old.unlink()
            except OSError:
                pass


def _note(message: str):
    _messages.insert(0, f"{time.strftime('%H:%M:%S')}  {message}")
    del _messages[12:]


def start(mode: str) -> dict:
    global _session, _wall_at_t0, _mode, _using_fallback, _error, _live, _final, _generation, _starting
    stop()
    _mode, _error, _using_fallback, _live, _final = mode, None, False, [], None
    _starting = True   # the helper takes a couple of seconds to connect - not a failure yet
    _messages.clear()
    _note("connecting to the phone to capture touches...")
    if settings.use_recorder_helper:
        try:
            RECORDINGS_DIR.mkdir(parents=True, exist_ok=True)
            _prune_recordings()
            # One file per recording: its <name>_debug.json (every touch, what was looked up for
            # it, the helper's window/click/field events) traces a wrongly recorded step later -
            # and tools/lookup_accuracy.py measures the recorder across all of them.
            path = RECORDINGS_DIR / f"phone_{time.strftime('%Y%m%d-%H%M%S')}.jsonl"
            session = HelperRecordingSession(device_serial(), path, adb_bin=resolve_adb()).start()
            with _lock:
                _session = session
                _starting = False
                # The session's clock is time.monotonic(); steps carry wall-clock "ts" for the UI.
                _wall_at_t0 = time.time() - (time.monotonic() - session._t0)
            fallback._reveal_passwords(True)
            _generation += 1
            threading.Thread(target=_preview_loop, args=(session, _generation), daemon=True).start()
            _note("recording touches on the phone - steps show up as you go, and are tidied up when you stop"
                  + ("; the app's web page is connected too" if session.web is not None else ""))
            return status()
        except Exception as e:
            _error = f"recorder helper unavailable ({e}) - using screen snapshots instead"
            _note(_error)
    _starting = False
    _using_fallback = True
    fallback.start(mode, use_helper=False)
    return status()


def stop(flush: bool = False):
    """Ends the recording; with flush, the engine's full clean-up runs once and its steps
    replace the drafts shown while recording."""
    global _session, _generation, _final
    with _lock:
        session, _session = _session, None
        _generation += 1   # the preview thread stops at its next turn
    if _using_fallback:
        fallback.stop(flush=flush)
        return
    if session is None:
        return
    try:
        session.stop()
        if flush:
            steps = to_our_steps(session.resolve_steps(), session)
            _final = steps
            _note(f"recorded {len(steps)} step{'s' if len(steps) != 1 else ''} from the phone"
                  + (f"; {session.keyboard_taps} keyboard taps left out" if session.keyboard_taps else "")
                  + f"; diagnostics in recordings/{session.debug_path.name}")
    except Exception as e:
        _note(f"working out the phone's steps failed: {e}")
    finally:
        fallback._reveal_passwords(False)


def pending_steps() -> tuple:
    """(steps, replace). replace=True: `steps` is this recording's whole list of phone
    steps so far (drafts while recording, the final list once, after it stops) - it
    replaces whatever phone steps the UI shows. replace=False: new steps to add (the
    snapshot fallback delivers them one by one)."""
    global _final
    if _using_fallback:
        return fallback.drain_pending_steps(), False
    if _final is not None:
        steps, _final = _final, None
        return steps, True
    if _session is not None:
        return list(_live), True
    return [], False


def _preview_loop(session: HelperRecordingSession, gen: int):
    global _live
    while gen == _generation:
        time.sleep(PREVIEW_EVERY_S)
        try:
            # A tap that just triggered a page load momentarily resolves to the loading mask on
            # top; the page's own touch log (the real element) arrives a tick later. Don't flash
            # that overlay draft - leave the step out until it resolves to the real element, which
            # it does on the next tick (and always on the final list when recording stops).
            steps = [dict(s, draft=True) for s in to_our_steps(_preview(session), session, embed=False)
                     if not _resolving_overlay(s)]
        except Exception as e:  # a draft is only a preview - never let it break recording
            _note(f"live preview failed: {e}")
            continue
        if gen == _generation:
            _live = steps


def _resolving_overlay(step: dict) -> bool:
    """A draft tap that landed on a loading-mask overlay - transient while the page loads."""
    return bool(step.get("disabled") and "overlay" in (step.get("locator") or {}).get("warning", "").lower())


def _preview(session: HelperRecordingSession) -> list:
    """The engine's own step-building (HelperRecordingSession.resolve_steps) on what's been
    recorded so far, run on a copy so the live recording is untouched: gestures that have
    finished and whose touch the helper has already identified. A dropdown pair merges into
    a select as soon as its list has closed; typing shows while the field still has focus."""
    with session._lock:
        known = {t["t"] for t in session._touches if t.get("hit") is not None or t.get("error")}
    raw = [copy.deepcopy(s) for s in list(session._detector.steps)
           if s["type"] == "key" or round(s["time"], 3) in known]
    view = copy.copy(session)
    view._detector = types.SimpleNamespace(finish=lambda: raw)
    view._final_focus = None
    return HelperRecordingSession.resolve_steps(view)


def status() -> dict:
    if _using_fallback:
        return dict(fallback.status(), helper=False, helper_error=_error, starting=False)
    session = _session
    alive = session is not None and session.raw_session.process is not None \
        and session.raw_session.process.poll() is None
    error = session.helper_error if session is not None else None
    return {
        # starting: the helper is still connecting (the first couple of seconds) - not a failure.
        "available": alive or _final is not None, "error": error, "adb": resolve_adb_quiet(),
        "starting": _starting and session is None, "touch_device": None,
        "stats": {"seen": len(session._touches) if session else 0,
                  "recorded": session.located_count if session else 0,
                  "skipped": session.keyboard_taps if session else 0},
        "recent": list(_messages), "helper": True, "helper_error": None,
        "fields_typed": session.typed_count if session else 0,
    }


def resolve_adb_quiet() -> Optional[str]:
    try:
        return resolve_adb()
    except Exception:
        return None


# ---------------------------------------------------------------------
# android-record-playback steps -> this app's steps
# ---------------------------------------------------------------------

def to_our_locator(loc: Optional[dict], step: Optional[dict] = None) -> dict:
    """Their locator: an ordered list of (strategy, value) candidates - ranked by how
    uniquely each identified the element when it was touched - plus the element's
    id / description / text. Kept whole (resolve_locator tries the candidates in their
    order), with the fields our replay's scroll search matches on, and from the step:
    its fingerprint (for self-healing) and where within a big container it was tapped."""
    out: dict = {}
    if loc:
        candidates = [list(c) for c in loc.get("candidates") or [(loc.get("strategy"), loc.get("value"))]]
        out["candidates"] = candidates
        if loc.get("resource_id"):
            out["resource_id"] = loc["resource_id"]
        # The recorder already left a changing value (a balance, the time - see
        # locator.volatile) out of the candidates whenever something steady finds the element;
        # it's never used as the element's text / description here, which replay searches by.
        changing = bool(loc.get("changing"))
        content_desc = mc._sanitize(loc.get("content_desc"))
        if content_desc and not changing:
            out["content_desc"] = content_desc
        # Their text is kept as a way to find it only when a candidate searches by THIS exact
        # text (never a field's typed value, and never a dropdown's current value like "Select",
        # which some candidate's nearby-label match would otherwise smuggle in).
        text = mc._sanitize(loc.get("text"))
        if text and not changing and _candidate_names_text(candidates, text):
            out["text"] = text
        xpaths = [value for strategy, value in candidates if strategy == "xpath"]
        if xpaths:
            out["xpath"] = xpaths[-1]
        if loc.get("class_name"):
            out["class_name"] = loc["class_name"]
        # How it was told apart: the text inside it (a tile's caption), the label beside an
        # unnamed icon or a changing value, the label before a field, whether its id is
        # shared, and whether anything was unique at all.
        for key in ("label", "near", "beside", "field_label"):
            if loc.get(key):
                out[key] = loc[key]
        if changing:
            out["changing"] = True
        if loc.get("id_shared"):
            out["id_shared"] = True
        if loc.get("unique") is not None:
            out["unique"] = loc["unique"]
    for key in ("fingerprint", "tap_at"):
        if (step or {}).get(key):
            out[key] = step[key]
    return out


# A candidate naming the element by its text, exactly or with spacing normalised.
_TEXT_TEST = re.compile(r"@text\)?\s*=|normalize-space\(@text\)")


def _candidate_names_text(candidates: list, text: str) -> bool:
    """Whether a candidate finds the element by THIS exact text (not by a nearby label that
    happens to appear in a scoped xpath). A dropdown's own text is its current value."""
    lit = mc._xpath_literal(text)
    return any(f"@text={lit}" in str(v) or f"normalize-space(@text)={lit}" in str(v) for _, v in candidates)


def _name(loc: Optional[dict], web: Optional[dict] = None) -> str:
    if web:
        return mc._sanitize(web.get("text")) or web.get("css") or "web element"
    loc = loc or {}
    if loc.get("changing") and loc.get("beside"):
        return f'value next to "{loc["beside"]}"'
    if loc.get("field_label") and not loc.get("resource_id"):
        return f'the field after "{loc["field_label"]}"'
    if loc.get("changing"):
        prefix = locator_mod.stable_prefix(loc.get("text") or "")
        return f'"{prefix} …"' if prefix else ""
    return (mc._sanitize(loc.get("text")) or mc._sanitize(loc.get("content_desc"))
            or mc._humanize_id(loc.get("resource_id")) or mc._sanitize(loc.get("label")) or "")


def _inside(point, bounds: Optional[str]) -> bool:
    b = mc.parse_bounds(bounds or "")
    return bool(point and b and b[0] <= point[0] <= b[2] and b[1] <= point[1] <= b[3])


def _background_tap(s: dict, screen: tuple) -> bool:
    """A tap on a big unnamed background (a decorative image behind a header, a page's
    backdrop): nothing there responds to taps, and only its position in the layout could find
    it again - which at replay may be another element (a small icon), tapped by mistake."""
    loc = s.get("locator") or {}
    if s.get("type") != "tap" or s.get("web") or not loc:
        return False
    if any(loc.get(k) for k in ("resource_id", "content_desc", "text", "label")):
        return False
    b = mc.parse_bounds(loc.get("bounds") or "")
    return bool(b and (b[2] - b[0]) * (b[3] - b[1]) > 0.4 * screen[0] * screen[1])


def _warned(step: dict, s: dict) -> dict:
    """Carry the engine's doubts about a step (nothing unique on screen, a page-sized
    container, a loading mask) into it, for the step list to show."""
    warning = s.get("locator_warning") or s.get("locator_error")
    if warning:
        step["approximate"] = True
        step["locator"] = dict(step.get("locator") or {}, warning=warning)
    if s.get("disabled"):
        step["disabled"] = True   # landed on a full-screen overlay the app ignores (a loading mask)
    return step


def to_our_steps(steps: list, session: HelperRecordingSession, embed: bool = True) -> list:
    width, height = session.mapper._screen()
    pct = lambda p: (round(p[0] / width, 4), round(p[1] / height, 4)) if p else (None, None)  # noqa: E731
    # Password fields typed into during the recording - an unnamed icon inside one is its eye.
    password_fields = [s["locator"] for s in steps if s["type"] == "type" and s.get("locator")
                       and (s.get("password") or mc._has_sensitive_keyword(s["locator"].get("resource_id")))]
    out = []
    for s in steps:
        kind = s["type"]
        ts = round(_wall_at_t0 + s.get("time", 0.0), 3)
        base = {"ts": ts, "source": "physical", "screenshot": None}
        loc, web = s.get("locator"), s.get("web")

        if kind in ("tap", "long_press"):
            rid = (loc or {}).get("resource_id") or ""
            nav = mc.nav_key_for(rid, (loc or {}).get("content_desc")) if rid.startswith("com.android.systemui") else None
            if nav in ("back", "home"):
                out.append(dict(base, action="key", description=f"Press {nav}", locator={}, text=nav))
                continue
            x, y = pct(s.get("pixel_start"))
            ours = to_our_locator(loc, s)
            if web:
                ours["web"] = web
            name = _name(loc, web)
            eye = next((f for f in password_fields if _inside(s.get("pixel_start"), f.get("bounds"))), None)
            if eye is not None and not name:
                name = f"Show/hide password in {_name(eye) or 'the password field'}"
            verb = "Long press" if kind == "long_press" else ""
            description = f"{verb} {name}".strip() if name else ("Long press" if verb else "Tap here")
            step = dict(base, action=kind, description=description, locator=ours, x_pct=x, y_pct=y)
            if _background_tap(s, (width, height)):
                step["disabled"] = True
                step["description"] = "Tap on the background"
                s = dict(s, locator_warning=(
                    "this tap landed on a large background with nothing that responds to taps (e.g. a logo or "
                    "picture drawn behind the page), and only its place in the layout could find it again - "
                    "which may be another element when it runs - so it's disabled; re-enable it if it did something"))
            if s.get("checked_target") is not None:
                # A checkbox / switch: the state the tap was meant to give it (replay skips the
                # tap when it's already that way).
                step["checked_target"] = bool(s["checked_target"])
            out.append(_warned(step, s))

        elif kind == "pick_date":
            # "Tap the date field, move the calendar, tap a day, OK" merged into one step: the
            # date is data (fixed, ${today+7d}...), and replay moves the calendar as needed.
            x, y = pct(s.get("pixel_start"))
            ours = to_our_locator(loc, s)
            where = _name(loc) if loc else ""
            out.append(dict(base, action="pick_date", locator=ours, x_pct=x, y_pct=y, text=s.get("date") or "",
                            description=f"Pick date {s.get('date')}" + (f" in {where}" if where else "")))

        elif kind == "assert":
            # A tap on text that isn't a control and changed nothing: meant as a check of that
            # text (see helper_recorder.tap_as_check). The tap is kept, to turn it back.
            x, y = pct(s.get("pixel_start"))
            ours = to_our_locator(loc, s)
            if web:
                ours["web"] = web
            check, expected = s.get("check") or "visible", s.get("expected") or ""
            if s.get("as_tap"):
                tap = to_our_steps([s["as_tap"]], session, embed=False)
                if tap:
                    ours["as_tap"] = {k: tap[0].get(k) for k in ("action", "description", "locator", "x_pct", "y_pct")}
            # A text showing a value that changes (a balance, the time) is checked as a pattern
            # with any numbers there - named by the text as it was seen.
            seen = ""
            if check == "text_matches":
                tap_loc = (s.get("as_tap") or {}).get("locator") or {}
                seen = ((web or {}).get("full_text") or (web or {}).get("text") or tap_loc.get("text")
                        or tap_loc.get("content_desc") or "")
            seen = " ".join(str(seen).split())
            # Long texts (a whole alert message) are shortened in the name only; the check uses all of it.
            label_text = seen or expected
            shown = label_text if len(label_text) <= 60 else label_text[:57] + "…"
            name, what = _name(loc, web), mc.CHECKS.get(check, check)
            if seen:
                description = f'Check text is like "{shown}" (numbers, dates and times may differ)'
            elif check in mc.TEXT_CHECKS:
                same = not name or len(name) > 40 or " ".join(name.split()) == " ".join(expected.split())
                description = f'Check {"" if same else name + " "}{what} "{shown}"'
            else:
                description = f"Check {name or 'it'} {what}"
            out.append(_warned(dict(base, action="assert", description=description, locator=ours, x_pct=x, y_pct=y,
                                    check=check, text=expected), s))

        elif kind == "keypad":
            # Taps on the keys of the app's own keypad (a PIN pad), entered by each key's character.
            ours = to_our_locator(loc)
            if s.get("key_class"):
                ours["key_class"] = s["key_class"]
            where = _name(dict(loc or {}, text=None)) if loc else ""
            out.append(dict(base, action="keypad", description=f"Enter '{s.get('text') or ''}' on {where or 'the keypad'}",
                            locator=ours, text=s.get("text") or ""))

        elif kind == "swipe":
            (x1, y1), (x2, y2) = pct(s.get("pixel_start")), pct(s.get("pixel_end"))
            direction = recording_service._infer_direction((x2 or 0) - (x1 or 0), (y2 or 0) - (y1 or 0))
            out.append(dict(base, action="swipe", description=f"Swipe {direction}", locator={},
                            x_pct=x1, y_pct=y1, x2_pct=x2, y2_pct=y2, text=direction))

        elif kind == "key":
            key = {"BACK": "back", "HOME": "home", "MENU": "menu", "APP_SWITCH": "recents",
                   "VOLUME_UP": "volume_up", "VOLUME_DOWN": "volume_down", "POWER": "power"}.get(s.get("key"))
            if key:
                out.append(dict(base, action="key", description=f"Press {key.replace('_', ' ')}", locator={}, text=key))

        elif kind == "type":
            ours = to_our_locator(loc, s)
            text = s.get("text") or ""
            key = (loc or {}).get("resource_id") or (loc or {}).get("bounds") or ""
            if text and screen_events.was_typed_by_mirror(key, text):
                continue   # typed through the mirror - already recorded there
            b = mc.parse_bounds((loc or {}).get("bounds") or "")
            x, y = pct(((b[0] + b[2]) // 2, (b[1] + b[3]) // 2) if b else None)
            # (A field's locator text is its hint - "Search keyword" - never what was typed.)
            name = _name(dict(loc or {}, text=None)) or mc._sanitize((loc or {}).get("text")) or "the text field"
            step = dict(base, action="type", description=name, locator=ours, x_pct=x, y_pct=y, text=text,
                        field_key=key)
            if s.get("needs_value"):
                step.update(redacted=True, text="", description=f"{name} (value not saved - provide it before running)")
            out.append(step)

        elif kind == "select":
            ours = to_our_locator(s.get("locator"), s)
            if mc.opener_in_open_list(ours):
                # The dropdown field was captured as a row inside the list it opened (a native
                # Spinner's dialog): that can't be found before the list is open, so open it by
                # its screen position instead. The option is still picked by its text.
                ours = {}
            name = "the dropdown" if not ours else (_name(dict(s.get("locator") or {}, text=None)) or "the dropdown")
            x, y = pct(s.get("pixel_start"))
            out.append(dict(base, action="select", description=f"Select '{s.get('option')}' from {name}",
                            locator=ours, text=s.get("option"), x_pct=x, y_pct=y))

    # The screens around each step (saved once the screen settled - see app/arp/screens.py),
    # for adding checks later without the phone on that screen. Steps line up with `steps`
    # except where one was dropped above, so they're matched by time.
    by_ts = {round(_wall_at_t0 + s.get("time", 0.0), 3): s for s in steps}
    for step in out:
        src = by_ts.get(step["ts"])
        for key in ("screen", "screen_after"):
            if src is not None and src.get(key):
                step[key] = src[key]

    for step in out if embed else []:   # drafts aren't embedded - only the final steps are
        if step["action"] not in ("select", "assert", "keypad", "pick_date"):
            recording_service._embed_if_ai(_mode, step["description"], step["action"], step.get("locator") or {})
    return out
