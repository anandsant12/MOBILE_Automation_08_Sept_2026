"""
Phones plugged in over USB, found with `adb devices -l` - so the UI can show them, pick
one automatically, and connect as soon as one is plugged in (nothing to fill in by hand:
the serial is the UDID, and the Android version is read off the phone itself).

State is what adb reports: "device" (ready), "unauthorized" (USB debugging not yet
allowed on the phone), "offline" (still starting up, or a bad cable).
"""

import subprocess
import threading
from typing import Optional

from app.automation.physical_touch import resolve_adb

# What a phone says about itself never changes while it's plugged in: read it once per serial.
_props_cache: dict = {}
_lock = threading.Lock()

PROPS = {
    "manufacturer": "ro.product.manufacturer",
    "model": "ro.product.model",
    "android_version": "ro.build.version.release",
    "sdk": "ro.build.version.sdk",
}


def _adb(args: list, serial: Optional[str] = None, timeout: float = 8) -> str:
    cmd = [resolve_adb()] + (["-s", serial] if serial else []) + args
    return subprocess.run(cmd, capture_output=True, text=True, timeout=timeout).stdout


def _props(serial: str) -> dict:
    with _lock:
        if serial in _props_cache:
            return _props_cache[serial]
    # One adb call for all of them.
    script = "; ".join(f"getprop {p}" for p in PROPS.values())
    lines = _adb(["shell", script], serial).splitlines()
    values = dict(zip(PROPS, (line.strip() for line in lines)))
    if all(values.get(k) for k in ("model", "android_version")):
        with _lock:
            _props_cache[serial] = values
    return values


def list_devices() -> dict:
    """{"devices": [...], "error": message or None}. Each device:
    {serial, state, manufacturer, model, android_version, sdk, label}."""
    try:
        out = _adb(["devices", "-l"], timeout=6)
    except Exception as e:   # adb missing, or hung
        return {"devices": [], "error": str(e)}
    devices = []
    # Devices are listed after this header; adb may print "* daemon started" notices before it.
    lines = out.splitlines()
    start = next((i + 1 for i, line in enumerate(lines) if line.startswith("List of devices")), 0)
    for line in lines[start:]:
        parts = line.split()
        if len(parts) < 2 or parts[0].startswith("*"):
            continue
        serial, state = parts[0], parts[1]
        extra = dict(p.split(":", 1) for p in parts[2:] if ":" in p)   # model:SM_A546E device:a54x ...
        device = {"serial": serial, "state": state, "manufacturer": "", "model": extra.get("model", "").replace("_", " "),
                  "android_version": "", "sdk": ""}
        if state == "device":
            try:
                device.update({k: v for k, v in _props(serial).items() if v})
            except Exception:
                pass
        device["label"] = _label(device)
        devices.append(device)
    return {"devices": devices, "error": None}


def _label(d: dict) -> str:
    name = " ".join(x for x in (d["manufacturer"].capitalize(), d["model"]) if x) or d["serial"]
    if d["state"] == "unauthorized":
        return f"{name} - allow USB debugging on the phone"
    if d["state"] != "device":
        return f"{name} ({d['state']})"
    return f"{name} · Android {d['android_version']}" if d["android_version"] else name
