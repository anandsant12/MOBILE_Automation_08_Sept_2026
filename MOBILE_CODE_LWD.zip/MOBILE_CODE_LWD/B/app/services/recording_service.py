"""
One function per gesture (tap / type / swipe / key), each used by BOTH
Aim 1 ("basic" mode - no LLM call, ever) and Aim 2 ("ai" mode - adds an
LLM description + a ChromaDB embedding). The `mode` argument is the only
thing that changes: the gesture is performed identically either way, so
the live mirror always reflects what actually happened on the device.
"""

import asyncio
import time
import uuid
from typing import Optional

from config import settings
from app.arp import step_types, web_cdp
from app.automation import mobile_control as mc
from app.automation.physical_touch import resolve_adb
from app.automation.session_manager import session, device_serial
from app.llm.factory import get_provider
from app.services import screen_events
from app.vector_store import chroma_store


def _check_mode(mode: str):
    if mode not in ("basic", "ai"):
        raise ValueError("mode must be 'basic' or 'ai'")
    if mode == "ai" and not settings.enable_llm_assisted:
        raise RuntimeError("AI-assisted mode is disabled (ENABLE_LLM_ASSISTED=false in .env).")

CLASSIFY_SYSTEM_PROMPT = (
    "You are helping build a mobile UI-automation step from a single tapped "
    "element's attributes. Respond with ONLY a JSON object of the shape "
    '{"description": "<short, plain-English name a person would use for this '
    'element, e.g. \'the Send button\' or \'the phone number field\'>"}. '
    "No other keys, no extra prose."
)


async def _classify(own_text: str, hint: str, cls: str, nearby: str = "", context: str = "") -> str:
    provider = get_provider()
    user_prompt = f"Element text/content: {own_text!r}\nElement type: {cls}"
    if hint:
        user_prompt += f"\nPlaceholder/hint text for this field: {hint!r}"
    if context:
        user_prompt += f"\nStatic field label directly above it: {context!r}"
    if nearby:
        user_prompt += f"\nNearby label in the same row (likely what this control is for): {nearby!r}"
    try:
        result = await provider.chat_json(CLASSIFY_SYSTEM_PROMPT, user_prompt, timeout=8.0)
        return (result.get("description") or "").strip() or (own_text or nearby or "the tapped element")
    except Exception:
        return own_text or nearby or "the tapped element"


async def _describe(attrs: dict, nodes: list[dict], mode: str) -> str:
    # The element's OWN text/content-desc (a dropdown's current value, a button's
    # caption) gets a short static field label above it prefixed on, when there is
    # one ("Select Clients: SBI Preprod 3") - distinct from a text-less clickable
    # container (a settings row) borrowing a CHILD's label, which is never
    # prefixed this way (that borrowed text already IS the identity, not a value
    # under a separate heading).
    if mc.is_editable(attrs):
        attrs = dict(attrs, text="")   # a field is named for what it's for, never what's typed in it
    own = mc.element_own_text(attrs)
    if own:
        ctx = mc.context_label(nodes, attrs)
        label = f"{ctx}: {own}" if ctx and ctx != own else own
        nearby, context = "", ctx
    else:
        label, _ = mc.element_label(attrs, nodes)
        if not label and mc.is_editable(attrs):
            label = mc.field_name(nodes, attrs, default="")   # its hint, or the label above it
        if not label:
            label = mc.context_label(nodes, attrs)   # a field's label directly above it
        if not label:
            # The caption beside/under it on screen (an icon tab's "Transaction"), before
            # falling back to whatever text precedes it in the dump.
            caption = mc.spatial_label_node(nodes, attrs)
            label = mc.element_own_text(caption) if caption is not None else ""
        nearby = "" if label else mc.nearby_label(nodes, attrs)
        context = ""
    fallback = nearby or mc.field_relative_label(nodes, attrs)
    if mode != "ai":
        rid = (attrs.get("resource-id") or "").rsplit("/", 1)[-1]
        if len(rid) <= 2:
            rid = ""   # an obfuscated id ("g") names nothing
        return label or fallback or rid or "tapped element"
    return await _classify(own or label, attrs.get("hint", ""), attrs.get("class", ""), fallback, context)


def _embed_if_ai(mode: str, description: str, action: str, locator: dict):
    if mode == "ai":
        chroma_store.add_step(str(uuid.uuid4()), description, session.package, session.activity, action, locator)


def _screenshot_if_needed(driver):
    # With the live stream running the browser already shows what an action did,
    # so skip the extra (slow) screenshot round trip.
    return None if session.mjpeg_active else mc.get_screenshot_b64(driver)


_web_clients: dict = {}   # app package -> WebViewClient, kept while recording


def _web_on_top(driver, nodes: list, x: int, y: int) -> Optional[dict]:
    """What the app's web page itself has on top at (x, y) - a web locator - or None when the
    point isn't on web content (or the page can't be inspected: WebView debugging off).

    Web popups (a Bootstrap modal: "Alert - PF Index can't be blank") are often missing from
    Android's view of the screen, which then reports whatever is BEHIND them (the password
    field, Select Clients). The page knows what's really there."""
    if not any(n.get("class") == "android.webkit.WebView" and mc._contains_point(n, x, y) for n in nodes):
        return None
    package = session.package or mc.current_package(driver)
    if not package:
        return None
    client = _web_clients.get(package)
    if client is None:
        client = _web_clients[package] = web_cdp.WebViewClient(package, device_serial(), resolve_adb())
    try:
        web = client.element_at(x, y)
    except Exception:
        _web_clients.pop(package, None)
        try:
            client.close()
        except Exception:
            pass
        return None
    if not web:
        return None
    web = dict(web, package=package)
    web.pop("overlay", None)
    return web


def _prefer_web(attrs: dict, locator: dict, web: Optional[dict], screen: dict) -> tuple:
    """(locator, web wins). The page's own record wins over Android's view: Android's element
    is kept as a fallback only when it's plausibly the same one (same text, or control-sized)
    and not in a web popup - there Android shows what's behind it. Same rule as recording on
    the phone (app/arp/helper_recorder._locate)."""
    if not web:
        return locator, False
    native_text = " ".join(mc.element_own_text(attrs).split())
    web_text = " ".join((web.get("text") or "").split())
    same_text = bool(native_text and web_text and native_text == web_text)
    b = mc.parse_bounds(attrs.get("bounds", ""))
    control_sized = bool(b and (b[2] - b[0]) * (b[3] - b[1]) < 0.1 * screen["width"] * screen["height"])
    if web.get("in_dialog") or not (same_text or control_sized):
        return {"web": web}, True
    return dict(locator, web=web), False


def _web_name(web: dict) -> str:
    text = " ".join((web.get("full_text") or web.get("text") or "").split())
    return (text[:60] + "…" if len(text) > 60 else text) or web.get("css") or "web element"


def _tap_on_device(x_pct: float, y_pct: float) -> dict:
    with session.command_lock:
        driver = session.require_driver()
        screen = mc.get_window_size(driver)
        x, y = int(x_pct * screen["width"]), int(y_pct * screen["height"])

        # The mirror shows the navigation bar too; it isn't part of the app's page source.
        nav_key = mc.nav_button_at(mc.nav_buttons(driver), x, y)
        if nav_key in ("back", "home"):
            mc.press_key(driver, nav_key)
            screen_events.notify_screen_changed()
            return {"nav_key": nav_key, "screenshot": _screenshot_if_needed(driver)}

        nodes = mc.parse_page_source(mc.get_page_source(driver))
        attrs = mc.pick_attrs_at_point(nodes, x, y)
        if attrs is None:
            raise RuntimeError("No element found at that point - try tapping more precisely on the target.")
        # Asked before the tap: a popup the tap closes would be gone by then.
        web = _web_on_top(driver, nodes, x, y)
        field = mc.field_icon_at(nodes, attrs, x, y) if not (web and web.get("in_dialog")) else None
        icon = field is not None
        web_only = False
        if icon:   # a text field's icon (show/hide password): the field, plus where on it
            attrs = field
            locator = dict(mc.extract_locator(field, nodes), tap_offset=mc.offset_from_center(field, (x, y), screen))
        else:
            locator = mc.extract_locator(attrs, nodes, point=(x, y), screen=screen)
            locator, web_only = _prefer_web(attrs, locator, web, screen)

        # Tap exactly where the mouse clicked. Looking the element up again by XPath
        # first (which makes Appium re-dump the whole UI tree) and then clicking its
        # centre was two extra slow round trips for the same result.
        mc.tap_coords(driver, x, y)
        screen_events.notify_screen_changed()
        return {"attrs": attrs, "nodes": nodes, "locator": locator, "icon": icon, "web": web if web_only else None,
                "screenshot": _screenshot_if_needed(driver)}


async def record_tap(x_pct: float, y_pct: float, mode: str) -> dict:
    _check_mode(mode)
    ts = time.time()  # lets the UI order these against steps captured from the phone itself
    # Appium calls block for seconds. They run in a worker thread so the event
    # loop keeps serving the mirror stream, status polls and Stop meanwhile.
    done = await asyncio.to_thread(session.call_with_recovery, lambda: _tap_on_device(x_pct, y_pct))

    if "nav_key" in done:
        key = done["nav_key"]
        description = f"Press {key}"
        await asyncio.to_thread(_embed_if_ai, mode, description, "key", {})
        return {"action": "key", "description": description, "locator": {}, "text": key,
                "screenshot": done["screenshot"], "ts": ts}

    attrs, nodes, locator, web = done["attrs"], done["nodes"], done["locator"], done.get("web")
    if web:
        # On the app's web page (a popup Android's view misses): named by what the page shows.
        description = _web_name(web)
    elif done["icon"]:
        description = mc.field_icon_description(nodes, attrs)
    else:
        description = await _describe(attrs, nodes, mode)
    await asyncio.to_thread(_embed_if_ai, mode, description, "tap", locator)

    return {
        "action": "tap", "description": description, "locator": locator,
        "x_pct": round(x_pct, 4), "y_pct": round(y_pct, 4),
        # (Android's element was what's behind a web popup: never "type into" that.)
        "is_editable": mc.is_editable(attrs) and not done["icon"] and not web,
        "checked_target": None if done["icon"] or web else mc.desired_checked_state(attrs, nodes),
        "screenshot": done["screenshot"],
        "ts": ts,
    }


def _inspect_on_device(x_pct: float, y_pct: float) -> dict:
    with session.command_lock:
        driver = session.require_driver()
        screen = mc.get_window_size(driver)
        x, y = int(x_pct * screen["width"]), int(y_pct * screen["height"])
        nodes = mc.parse_page_source(mc.get_page_source(driver))
        web = _web_on_top(driver, nodes, x, y)
    attrs = mc.element_for_check(nodes, x, y)
    if attrs is None and web is None:
        raise RuntimeError("No element found at that point - click on the text or control to check.")
    locator = mc.extract_locator(attrs, nodes, point=(x, y), screen=screen) if attrs is not None else {}
    locator, web_only = _prefer_web(attrs or {}, locator, web, screen)
    if web_only:
        # A web popup Android's view misses (it reports what's behind): check what the page shows.
        text = " ".join((web.get("full_text") or web.get("text") or "").split())
        attrs = {"class": f"web <{web.get('tag') or 'element'}>", "text": text, "resource-id": web.get("id") or "",
                 "content-desc": "", "enabled": "true", "bounds": "", "_web": True}
    return {"attrs": attrs, "nodes": nodes, "locator": locator}


async def inspect_element(x_pct: float, y_pct: float) -> dict:
    """What a check (assert step) picked on the mirror: the element, how to find it again,
    and its current state - to suggest a check. Nothing is tapped."""
    found = await asyncio.to_thread(session.call_with_recovery, lambda: _inspect_on_device(x_pct, y_pct))
    attrs, nodes = found["attrs"], found["nodes"]
    state = mc.element_state(attrs)
    if mc.is_editable(attrs) and state["text"] == mc._sanitize(attrs.get("hint")):
        state["text"] = ""   # an empty field shows its hint as its text
    suggested = "text_equals" if state["text"] else ("checked" if state["checkable"] and state["checked"]
                                                     else "unchecked" if state["checkable"] else "visible")
    expected = state["text"]
    if state["text"]:
        # A text with a value that changes between runs (a balance, the time): checked as the
        # same words with any numbers - "text matches" - so the check holds tomorrow too.
        suggested, expected = step_types.text_check(state["text"])
    locator = found["locator"]
    on_web = bool(attrs.get("_web"))
    return {
        "description": _web_name(locator["web"]) if on_web else await _describe(attrs, nodes, "basic"),
        "locator": locator, "x_pct": round(x_pct, 4), "y_pct": round(y_pct, 4),
        **state, "suggested_check": suggested, "suggested_expected": expected,
        # For the Inspector: everything Android reports about it, where it sits, and how
        # replay would find it (in the order it tries).
        "attributes": {k: v for k, v in attrs.items() if not k.startswith("_")},
        "path": [_brief(n) for n in nodes if n.get("_i") is not None and attrs.get("_i") is not None
                 and n["_i"] < attrs["_i"] <= n.get("_end", -1)],
        "strategies": mc.locator_strategies(locator),
        "dynamic": mc.looks_dynamic(attrs.get("text")) or mc.looks_dynamic(attrs.get("content-desc")),
    }


def _brief(n: dict) -> str:
    cls = (n.get("class") or "").rsplit(".", 1)[-1]
    rid = (n.get("resource-id") or "").rsplit("/", 1)[-1]
    label = mc._own_label(n)
    return cls + (f"#{rid}" if rid else "") + (f' "{label[:30]}"' if label else "")


def _type_on_device(x_pct: float, y_pct: float, text: str):
    with session.command_lock:
        driver = session.require_driver()
        screen = mc.get_window_size(driver)
        x, y = int(x_pct * screen["width"]), int(y_pct * screen["height"])

        nodes = mc.parse_page_source(mc.get_page_source(driver))
        attrs = mc.pick_attrs_at_point(nodes, x, y)
        if attrs is None:
            raise RuntimeError("No field found at that point - try tapping more precisely on the target.")
        locator = mc.extract_locator(attrs, nodes)

        element = mc.resolve_element_handle(driver, attrs)
        if element is not None:
            mc.type_into_element(driver, element, text)
        else:
            mc.type_at_coords(driver, x, y, text)
        screen_events.note_mirror_typed(attrs, text)
        screen_events.notify_screen_changed()
        return attrs, nodes, locator, _screenshot_if_needed(driver)


async def record_type(x_pct: float, y_pct: float, text: str, mode: str) -> dict:
    _check_mode(mode)
    ts = time.time()  # lets the UI order these against steps captured from the phone itself
    attrs, nodes, locator, screenshot = await asyncio.to_thread(
        session.call_with_recovery, lambda: _type_on_device(x_pct, y_pct, text))

    description = await _describe(attrs, nodes, mode)
    await asyncio.to_thread(_embed_if_ai, mode, description, "type", locator)

    return {
        "action": "type", "description": description, "locator": locator,
        "x_pct": round(x_pct, 4), "y_pct": round(y_pct, 4), "text": text,
        "screenshot": screenshot,
        "ts": ts,
    }


def _infer_direction(dx: float, dy: float) -> str:
    if abs(dx) >= abs(dy):
        return "right" if dx > 0 else "left"
    return "down" if dy > 0 else "up"


def _swipe_on_device(x1_pct: float, y1_pct: float, x2_pct: float, y2_pct: float):
    with session.command_lock:
        driver = session.require_driver()
        screen = mc.get_window_size(driver)
        x1, y1 = int(x1_pct * screen["width"]), int(y1_pct * screen["height"])
        x2, y2 = int(x2_pct * screen["width"]), int(y2_pct * screen["height"])
        if abs(x2 - x1) < 4 and abs(y2 - y1) < 4:
            raise RuntimeError("That drag was too short to register as a swipe - try a longer gesture.")
        mc.swipe_coords(driver, x1, y1, x2, y2)
        screen_events.notify_screen_changed()
        return _screenshot_if_needed(driver)


async def record_swipe(x1_pct: float, y1_pct: float, x2_pct: float, y2_pct: float, mode: str) -> dict:
    _check_mode(mode)
    ts = time.time()  # lets the UI order these against steps captured from the phone itself
    screenshot = await asyncio.to_thread(
        session.call_with_recovery, lambda: _swipe_on_device(x1_pct, y1_pct, x2_pct, y2_pct))

    direction = _infer_direction(x2_pct - x1_pct, y2_pct - y1_pct)
    description = f"Swipe {direction}"
    await asyncio.to_thread(_embed_if_ai, mode, description, "swipe", {})

    # Stored as a direction (not the literal coordinates) so replay uses a
    # robust screen-relative swipe on whatever device runs it later.
    return {
        "action": "swipe", "description": description, "locator": {},
        "x_pct": round(x1_pct, 4), "y_pct": round(y1_pct, 4),
        "x2_pct": round(x2_pct, 4), "y2_pct": round(y2_pct, 4),
        "text": direction,
        "screenshot": screenshot,
        "ts": ts,
    }


def _key_on_device(key: str):
    with session.command_lock:
        driver = session.require_driver()
        mc.press_key(driver, key)
        screen_events.notify_screen_changed()
        return _screenshot_if_needed(driver)


async def record_key(key: str, mode: str) -> dict:
    _check_mode(mode)
    ts = time.time()  # lets the UI order these against steps captured from the phone itself
    screenshot = await asyncio.to_thread(session.call_with_recovery, lambda: _key_on_device(key))

    description = f"Press {key}"
    await asyncio.to_thread(_embed_if_ai, mode, description, "key", {})
    return {
        "action": "key", "description": description, "locator": {}, "text": key,
        "screenshot": screenshot,
        "ts": ts,
    }
