"""
"Execute this scenario" for Aim 2. One instruction is carried out over a
bounded number of steps (AI_MAX_STEPS): each iteration shows the LLM the
current on-screen elements plus similar elements retrieved from Chroma
for this app package (recorded earlier - see recording_service.py), asks
for exactly the next single action, resolves its target (ref match ->
fuzzy text match -> vision fallback), executes it for real, and repeats
until the model says the instruction is done (or fails, or the step
budget runs out).
"""

import asyncio
import difflib
import threading

from config import settings
from app.automation import mobile_control as mc
from app.automation.session_manager import session
from app.llm.factory import get_provider
from app.services import runs_registry
from app.vector_store import chroma_store

PLAN_SYSTEM_PROMPT = (
    "You control an Android app one step at a time toward a user's goal. "
    "You are given the goal, the actions already taken this run, the "
    "on-screen elements (each tagged like [E3]), and similar elements seen "
    "before in this same app (may or may not apply to the current screen). "
    "Decide the SINGLE next action. Respond with ONLY a JSON object:\n"
    '{"action": "tap|type|swipe|key|finish|fail", '
    '"target_ref": "<one of the [E#] tags above, or null>", '
    '"target_description": "<plain-English target if target_ref is null>", '
    '"text": "<only for action=type>", '
    '"direction": "<up|down|left|right, only for action=swipe>", '
    '"key": "<back|home, only for action=key>", '
    '"reasoning": "<one short sentence>"}\n'
    'Use "finish" the moment the goal is satisfied. Use "fail" only if the '
    "goal clearly cannot be achieved from the current screen."
)

VISION_LOCATE_SYSTEM_PROMPT = (
    "You are looking at a screenshot of a mobile app screen. Find the "
    "described UI element and return its center point as a fraction of the "
    "image width/height (each 0.0-1.0). Respond with ONLY a JSON object: "
    '{"found": true|false, "x_pct": 0.0, "y_pct": 0.0}'
)

_FUZZY_MIN_SCORE = 0.45


def _fuzzy_best_ref(description: str, ref_map: dict):
    if not description:
        return None
    desc_low = description.lower()
    best_ref, best_score = None, 0.0
    for ref, attrs in ref_map.items():
        label = (mc.element_own_text(attrs) or attrs.get("hint", "")).lower()
        if not label:
            continue
        score = difflib.SequenceMatcher(None, desc_low, label).ratio()
        if score > best_score:
            best_ref, best_score = ref, score
    return best_ref if best_score >= _FUZZY_MIN_SCORE else None


async def _vision_locate(screenshot: str, description: str):
    provider = get_provider()
    try:
        result = await provider.vision_json(
            VISION_LOCATE_SYSTEM_PROMPT, f"Find: {description}", screenshot, timeout=20.0,
        )
    except Exception:
        return None
    if not result.get("found"):
        return None
    try:
        return float(result["x_pct"]), float(result["y_pct"])
    except (KeyError, TypeError, ValueError):
        return None


async def _execute_planned_step(plan: dict, ref_map: dict) -> str:
    """Executes one planned action; returns a short description of what
    was actually acted on (for the run log and next iteration's history).
    Holds the device lock only around device calls - never across an LLM
    call, which can take many seconds and would freeze the mirror meanwhile."""
    action = plan.get("action")
    target_ref = plan.get("target_ref")
    target_description = (plan.get("target_description") or "").strip()

    if action in ("tap", "type"):
        attrs = ref_map.get(target_ref) if target_ref else None
        if attrs is None and target_description:
            ref = _fuzzy_best_ref(target_description, ref_map)
            if ref:
                attrs = ref_map[ref]

        with session.command_lock:
            driver = session.require_driver()
            element = mc.resolve_element_handle(driver, attrs) if attrs else None
            if element is not None:
                if action == "tap":
                    mc.tap_element(driver, element)
                else:
                    mc.type_into_element(driver, element, plan.get("text") or "")
                return target_description or mc.element_own_text(attrs) or "the tapped element"
            screenshot = mc.get_screenshot_b64(driver)
            screen = mc.get_window_size(driver)

        located = await _vision_locate(screenshot, target_description or "the described element")
        if located is None:
            raise RuntimeError(
                f"Could not locate '{target_description or target_ref}' on screen "
                f"(no matching element, and vision fallback found nothing)."
            )
        x, y = int(located[0] * screen["width"]), int(located[1] * screen["height"])
        with session.command_lock:
            driver = session.require_driver()
            if action == "tap":
                mc.tap_coords(driver, x, y)
            else:
                mc.type_at_coords(driver, x, y, plan.get("text") or "")
        return target_description or "the described element"

    if action == "swipe":
        direction = plan.get("direction") or "up"
        with session.command_lock:
            driver = session.require_driver()
            mc.swipe_direction(driver, mc.get_window_size(driver), direction)
        return f"swipe {direction}"

    if action == "key":
        key = plan.get("key") or "back"
        with session.command_lock:
            mc.press_key(session.require_driver(), key)
        return f"press {key}"

    raise ValueError(f"Unknown planned action '{action}'")


def start_assist_run(instruction: str) -> str:
    """Starts the AI-assisted loop in a background thread (its own fresh
    asyncio event loop, since the async LLM/Appium calls need one) and
    returns immediately - same run_id/poll/stop mechanism as scenario
    replay (see app/services/runs_registry.py)."""
    run = runs_registry.create_run("assist", total_steps=settings.ai_max_steps)
    thread = threading.Thread(target=_execute_assist_run_sync, args=(run, instruction), daemon=True)
    thread.start()
    return run.id


def _execute_assist_run_sync(run: runs_registry.Run, instruction: str):
    try:
        asyncio.run(_execute_instruction_loop(run, instruction))
    except Exception as e:
        run.append({"status": "error", "error": str(e)})
        run.finish("failed")


async def _execute_instruction_loop(run: runs_registry.Run, instruction: str):
    session.ensure_healthy()
    driver = session.require_driver()
    with session.command_lock:
        mc.ensure_foreground(driver, session.package)
    provider = get_provider()
    history: list[str] = []

    for step_num in range(settings.ai_max_steps):
        if run.stop_requested:
            run.finish("stopped")
            return

        session.ensure_healthy()
        driver = session.require_driver()
        with session.command_lock:
            elements_text, ref_map = mc.condensed_elements(driver)
        similar = chroma_store.query_similar(instruction, session.package, k=settings.ai_retrieval_k)
        similar_text = "\n".join(f"- {s['description']} ({s['action']})" for s in similar) or "(none recorded yet)"

        user_prompt = (
            f"Goal: {instruction}\n\n"
            f"Actions taken so far this run:\n" + ("\n".join(history) or "(none yet)") + "\n\n"
            f"Elements currently on screen:\n{elements_text or '(none labelled)'}\n\n"
            f"Similar elements seen before in this app (context, may not apply here):\n{similar_text}"
        )

        try:
            plan = await provider.chat_json(PLAN_SYSTEM_PROMPT, user_prompt, timeout=25.0)
        except Exception as e:
            run.append({"step": step_num, "status": "error", "error": f"Planning call failed: {e}"})
            run.finish("failed")
            return

        action = plan.get("action")
        reasoning = plan.get("reasoning", "")

        if action == "finish":
            run.append({"step": step_num, "action": "finish", "reasoning": reasoning, "status": "ok"})
            run.finish("passed")
            return
        if action == "fail":
            run.append({
                "step": step_num, "action": "fail", "reasoning": reasoning, "status": "error",
                "error": plan.get("target_description") or "The model reported this goal can't be done from here.",
            })
            run.finish("failed")
            return

        if run.stop_requested:
            run.finish("stopped")
            return

        try:
            acted_on = await _execute_planned_step(plan, ref_map)
            with session.command_lock:
                screenshot = mc.get_screenshot_b64(session.require_driver())
        except Exception as e:
            run.append({"step": step_num, "action": action, "reasoning": reasoning, "status": "error", "error": str(e)})
            run.finish("failed")
            return

        run.append({
            "step": step_num, "action": action, "target": acted_on, "reasoning": reasoning,
            "status": "ok", "screenshot": screenshot,
        })
        history.append(f"{step_num + 1}. {action} -> {acted_on}" + (f" ({reasoning})" if reasoning else ""))

    run.append({"status": "stopped", "error": f"Reached the {settings.ai_max_steps}-step limit (AI_MAX_STEPS)."})
    run.finish("stopped")
