import json
import re
import threading
import time
from typing import Optional

from config import settings

from app.arp import healing, step_types, web_cdp
from app.automation import mobile_control as mc
from app.automation.physical_touch import resolve_adb
from app.automation.session_manager import session, is_dead_session_error, device_serial
from app.db.database import get_session
from app.db.models import Scenario, Step
from app.services import popup_handlers, run_diagnosis, run_history, runs_registry
from app.services.screen_settle import ScreenSettle, needs_settle


def _variables_json(variables: Optional[dict]) -> Optional[str]:
    """Test data as stored: names to plain values. A secret belongs in ${env:NAME}, never here."""
    clean = {str(k).strip(): "" if v is None else str(v) for k, v in (variables or {}).items() if str(k).strip()}
    return json.dumps(clean) if clean else None


# How a run starts. "app": "as_is" (whatever screen the app is on), "restart" (closed and opened
# again - its first screen, still logged in or not as before), "clear" (its data cleared first:
# logged out, as just installed). "setup_scenario_id": a scenario run first (e.g. Login).
START_DEFAULTS = {"app": "as_is", "setup_scenario_id": None}


def _start_json(start: Optional[dict]) -> Optional[str]:
    if not start:
        return None
    app = start.get("app") if start.get("app") in ("as_is", "restart", "clear") else "as_is"
    setup = start.get("setup_scenario_id")
    clean = {"app": app, "setup_scenario_id": int(setup) if setup not in (None, "", 0) else None}
    return None if clean == START_DEFAULTS else json.dumps(clean)


def save_scenario(name: str, mode: str, package: str, activity: str, steps: list[dict],
                  variables: Optional[dict] = None, start: Optional[dict] = None) -> dict:
    db = get_session()
    try:
        existing = db.query(Scenario).filter(Scenario.name == name).first()
        if existing:
            raise ValueError(f"A scenario named '{name}' already exists - pick a different name.")

        scenario = Scenario(name=name, mode=mode, android_app_package=package, android_app_activity=activity,
                            variables_json=_variables_json(variables), start_json=_start_json(start))
        db.add(scenario)
        db.flush()  # assigns scenario.id
        for i, step in enumerate(steps):
            db.add(_step_row(scenario.id, i, step))
        db.commit()
        return scenario.to_full_dict()
    finally:
        db.close()


def _step_row(scenario_id: int, index: int, step: dict) -> Step:
    return Step(
        scenario_id=scenario_id, order_index=index,
        action=step["action"], description=step.get("description", ""),
        locator_json=json.dumps(step.get("locator") or {}),
        x_pct=step.get("x_pct"), y_pct=step.get("y_pct"),
        x2_pct=step.get("x2_pct"), y2_pct=step.get("y2_pct"),
        text=step.get("text"),
        checked_target=step.get("checked_target"),
        redacted=step.get("redacted"),
        check_kind=step.get("check"),
        optional=step.get("optional") or None,
        continue_on_failure=step.get("continue_on_failure") or None,
        disabled=step.get("disabled") or None,
        extra_json=json.dumps({k: step[k] for k in EXTRA_FIELDS if step.get(k)}) if any(
            step.get(k) for k in EXTRA_FIELDS) else None,
    )


# Step fields kept as they are, beside the columns: the saved screens the step acted on and
# led to (recorded on the phone - see app/arp/screens.py), for adding checks later; the name
# a "capture" step stores its read value under ("var"); and how a captured value / a text
# check's value is normalized before it's kept or compared ("normalize").
EXTRA_FIELDS = ("screen", "screen_after", "var", "normalize")


def update_scenario(scenario_id: int, name: str, steps: list[dict], variables: Optional[dict] = None,
                    start: Optional[dict] = None) -> dict:
    """The Steps editor's save: a new name and step list replace the old ones (and the
    test data, when given)."""
    db = get_session()
    try:
        scenario = db.get(Scenario, scenario_id)
        if not scenario:
            raise LookupError(f"Scenario {scenario_id} not found")
        name = name.strip()
        if not name:
            raise ValueError("Give the scenario a name.")
        clash = db.query(Scenario).filter(Scenario.name == name, Scenario.id != scenario_id).first()
        if clash:
            raise ValueError(f"A scenario named '{name}' already exists - pick a different name.")
        scenario.name = name
        if variables is not None:
            scenario.variables_json = _variables_json(variables)
        if start is not None:
            if start.get("setup_scenario_id") and int(start["setup_scenario_id"]) == scenario_id:
                raise ValueError("A scenario can't run itself before it starts.")
            scenario.start_json = _start_json(start)
        scenario.steps.clear()   # delete-orphan cascade removes the old rows
        db.flush()
        for i, step in enumerate(steps):
            scenario.steps.append(_step_row(scenario_id, i, step))
        db.commit()
        db.refresh(scenario)
        return scenario.to_full_dict()
    finally:
        db.close()


def prefer_locator(scenario_id: int, order_index: int, strategy: str, value: str, index: int = 0,
                   locator_fix: Optional[dict] = None, web: Optional[dict] = None) -> dict:
    """Self-healing, accepted: a run found this step by a backup strategy - make it the one
    replay tries first from now on. With `locator_fix` (the element was found by its
    fingerprint): its id / text / description replace the old ones, and its candidates go
    first with the old ones kept after them. With `web`: the page's new locator for it."""
    db = get_session()
    try:
        step = db.query(Step).filter(Step.scenario_id == scenario_id, Step.order_index == order_index).first()
        if step is None:
            raise LookupError(f"Step {order_index + 1} of scenario {scenario_id} not found")
        locator = json.loads(step.locator_json or "{}")
        if web:
            old = locator.get("web") or {}
            locator["web"] = dict(old, **{k: v for k, v in web.items() if k != "fp"},
                                  fp=old.get("fp") or web.get("fp"))
        elif locator_fix:
            new = [list(c) for c in locator_fix.get("candidates") or []]
            locator["candidates"] = new + [list(c) for c in locator.get("candidates") or [] if list(c) not in new]
            for key in ("resource_id", "content_desc", "text"):
                locator.pop(f"{key}_index", None)
                if locator_fix.get(key):
                    locator[key] = locator_fix[key]
                else:
                    locator.pop(key, None)   # its old text / description is what stopped matching
            locator.pop("prefer", None)
        else:
            locator["prefer"] = [strategy, value, index]
        locator.pop("warning", None)
        step.locator_json = json.dumps(locator)
        db.commit()
        return step.to_dict()
    finally:
        db.close()


def import_scenario(data: dict) -> dict:
    """A scenario from an exported JSON file (see export_service), saved under its own name -
    or "<name> (imported)", "<name> (imported 2)"... if that's taken."""
    from app.services import export_service
    parsed = export_service.parse_scenario_json(data)
    taken = {s["name"] for s in list_scenarios()}
    name, n = parsed["name"], 1
    while name in taken:
        name = f"{parsed['name']} (imported{'' if n == 1 else f' {n}'})"
        n += 1
    return save_scenario(name, parsed["mode"], parsed["android_app_package"], parsed["android_app_activity"],
                         parsed["steps"], parsed["variables"])


def list_scenarios() -> list[dict]:
    db = get_session()
    try:
        scenarios = [s.to_summary_dict() for s in db.query(Scenario).order_by(Scenario.created_at.desc()).all()]
    finally:
        db.close()
    recent = run_history.recent_statuses()
    for s in scenarios:
        s["recent_runs"] = recent.get(s["id"], [])   # latest runs' statuses, newest first
    return scenarios


def get_scenario(scenario_id: int) -> dict:
    db = get_session()
    try:
        scenario = db.get(Scenario, scenario_id)
        if not scenario:
            raise ValueError(f"Scenario {scenario_id} not found")
        return scenario.to_full_dict()
    finally:
        db.close()


def delete_scenario(scenario_id: int):
    db = get_session()
    try:
        scenario = db.get(Scenario, scenario_id)
        if not scenario:
            raise ValueError(f"Scenario {scenario_id} not found")
        db.delete(scenario)
        db.commit()
    finally:
        db.close()
    run_history.delete_for_scenario(scenario_id)


# ---------------------------------------------------------------------
# Replay
# ---------------------------------------------------------------------

def _leads_to_locatable_target(steps: list, swipe_index: int) -> bool:
    """True when this swipe is only scrolling toward a labelled tap/type target, so the
    search at that step can do the scrolling itself. Only UP/DOWN swipes qualify, and
    only when every swipe between here and the target does: a sideways swipe is
    navigation (Android's Back gesture, a tab or carousel switch) - skipping it leaves
    the app on the wrong screen, which is exactly what a skipped Back swipe did."""
    j = swipe_index
    while j < len(steps) and steps[j]["action"] == "swipe":
        if (steps[j].get("text") or "up") not in ("up", "down"):
            return False
        j += 1
    if j >= len(steps):
        return False
    target = steps[j]
    if target["action"] not in ("tap", "long_press", "type", "select", "pick_date"):
        return False
    locator = target.get("locator") or {}
    return bool(locator.get("text") or locator.get("content_desc"))


_IDENTITY_KEYS = ("resource_id", "content_desc", "text", "xpath", "label_xpath", "candidates")


def _require_target(step: dict, element, healer=None):
    """A step that knows WHAT to tap must find it. Tapping its recorded coordinates
    instead lands on whatever is there now - a different row, a dialog's backdrop -
    and then reports success. Only a step with nothing to identify it by, or with
    ALLOW_COORDINATE_FALLBACK on, may fall back to coordinates."""
    if element is not None:
        return
    locator = step.get("locator") or {}
    if settings.allow_coordinate_fallback or not any(locator.get(k) for k in _IDENTITY_KEYS):
        return
    pages = mc.last_search_pages
    where = f" after scrolling {pages} page{'s' if pages != 1 else ''}" if pages else ""
    misses = healing.near_miss_text(healer.near_misses) if healer is not None else ""
    raise LookupError(f"Could not find '{step.get('description') or 'the target'}' on screen{where}{misses}.")


def _heal_native(driver, step: dict, use_text: bool = True):
    """(element, healer): the step's element found by its recorded fingerprint (see
    app/arp/healing.py) when none of its locators matched - only a confident, clear winner.
    (None, healer-or-None) otherwise. Never for optional steps: their element is MEANT to
    be missing sometimes."""
    locator = step.get("locator") or {}
    if step.get("optional") or not _options["heal"]:
        return None, None
    fp = locator.get("fingerprint") or healing.fingerprint_from_locator(locator, use_text)
    if not fp:
        return None, None
    healer = healing.NativeHealer(driver, fp, use_text)
    try:
        return healer.attempt(), healer
    except Exception:
        return None, healer


def _healed_result(healer) -> dict:
    result = healer.result
    loc = result["locator"]
    return {"strategy": loc["strategy"], "value": loc["value"], "index": 0, "score": result["score"],
            "matched": result["matched"], "element": result["element"],
            "locator": {"candidates": [list(c) for c in loc["candidates"]], "resource_id": loc.get("resource_id"),
                        "content_desc": loc.get("content_desc"), "text": loc.get("text")}}


def _much_smaller(element, locator: dict, screen: dict) -> bool:
    """Whether the element found is far smaller (relative to the screen) than the one recorded -
    judged from the recorded fingerprint's bounds. False when that's unknown."""
    fp = locator.get("fingerprint") or {}
    b = mc.parse_bounds(fp.get("bounds") or locator.get("bounds") or "")
    if not b:
        return False
    rec_w, rec_h = fp.get("screen") or (screen["width"], screen["height"])
    recorded = (b[2] - b[0]) * (b[3] - b[1]) / max(1, rec_w * rec_h)
    try:
        rect = element.rect
    except Exception:
        return False
    found = rect["width"] * rect["height"] / max(1, screen["width"] * screen["height"])
    return recorded > 0 and found < 0.25 * recorded


def _page_sized(element, screen: dict) -> bool:
    """A screen-sized container (a page body): tapping its middle almost never hits what was tapped."""
    try:
        rect = element.rect
    except Exception:
        return False
    return rect["width"] * rect["height"] > 0.5 * screen["width"] * screen["height"]


KEY_WAIT_S = 5.0


def _press_key(driver, scope: str, key_class: Optional[str], ch: str, n: int, total: int):
    """Tap the key showing `ch` on an app's own keypad - by its character, as keypads may be shuffled."""
    literal = mc._xpath_literal(ch)
    xpath = f"{scope}//*[@text={literal} or @content-desc={literal}]"
    deadline = time.time() + KEY_WAIT_S
    while True:
        keys = []
        for el in mc._find_by(driver, "xpath", xpath):
            try:
                if el.is_displayed():
                    keys.append(el)
            except Exception:
                pass
        if key_class and len(keys) > 1:
            keys = [el for el in keys if el.get_attribute("class") == key_class] or keys
        if keys:
            keys[0].click()
            return
        if time.time() >= deadline:
            message = f"Key {n} of {total} wasn't found on the keypad within {KEY_WAIT_S:g}s"
            # Nothing pressed yet: safe to retry. Half-way through a PIN: never repeat it.
            raise (LookupError if n == 1 else RuntimeError)(message)
        time.sleep(0.25)


def _replay_keypad(driver, step: dict, check, should_stop) -> str:
    """Keys of an app's own on-screen keypad (a PIN pad, a calculator), entered one by one by
    the character each key shows - see app/arp/helper_recorder.merge_keypad."""
    locator = step.get("locator") or {}
    keys = step.get("text") or ""
    if not keys:
        raise ValueError("This keypad step has no keys to enter")
    scope = f"//*[@resource-id={mc._xpath_literal(locator['resource_id'])}]" if locator.get("resource_id") else ""
    if any(locator.get(k) for k in _IDENTITY_KEYS):
        pad = mc.resolve_with_scroll_search(driver, locator, should_stop=should_stop, wait_s=_wait_for(step),
                                            while_waiting=_clearer())
        _require_target(dict(step, description=step.get("description") or "the keypad"), pad)
    for n, ch in enumerate(keys, 1):
        check()
        _press_key(driver, scope, locator.get("key_class"), ch, n, len(keys))
    return f"Entered {len(keys)} key{'s' if len(keys) != 1 else ''} on the keypad"


def _replay_swipe(driver, screen: dict, step: dict) -> Optional[str]:
    direction = step.get("text") or "up"
    x1, y1, x2, y2 = (step.get(k) for k in ("x_pct", "y_pct", "x2_pct", "y2_pct"))
    if direction in ("left", "right") and x1 is not None and (x1 <= 0.1 or x1 >= 0.9):
        mc.press_key(driver, "back")   # an edge swipe IS the Back gesture; injected mid-screen it does nothing
        return "Edge swipe replayed as Back"
    if None not in (x1, y1, x2, y2):   # replay the gesture as recorded, not a generic one in the middle of the screen
        w, h = screen["width"], screen["height"]
        mc.swipe_coords(driver, int(x1 * w), int(y1 * h), int(x2 * w), int(y2 * h))
        return None
    mc.swipe_direction(driver, screen, direction)
    return None


CHECK_POLL_S = 0.5
CHECK_MIN_S = 3.0   # once its element is there, a check still gets this long to come true


class CheckFailed(AssertionError):
    pass


def _normalize(text, mode: Optional[str]) -> str:
    """A value as it's kept (a captured value) or compared (a text check): raw as-is; `trim`
    with runs of whitespace collapsed; `digits` with everything but digits dropped (account
    numbers shown with spaces/spelled out); `number` the first number with its grouping commas
    and currency removed ("₹ 1,94,86,145.35" -> "19486145.35"), so the same amount matches
    however it's formatted on another screen."""
    text = text or ""
    if mode == "trim":
        return " ".join(text.split())
    if mode == "digits":
        return re.sub(r"\D", "", text)
    if mode == "number":
        m = re.search(r"-?\d[\d,]*(?:\.\d+)?", text)
        return m.group(0).replace(",", "") if m else ""
    return text


def _evaluate(kind: str, element, expected: str, normalize: Optional[str] = None):
    """(passed, what was actually seen)."""
    state = mc.element_state(element)
    text = state["text"]
    if kind == "visible":
        return True, "it is on screen"
    # When a normalization is set (comparing a formatted value, or one remembered earlier),
    # both sides are reduced the same way first - "₹ 1,94,86,145.35" vs "19486145.35".
    if kind in ("text_equals", "text_contains", "text_matches") and normalize:
        shown, text, expected = text, _normalize(text, normalize), _normalize(expected, normalize)
        seen = f'its value is "{text}" (from "{shown}")'
    else:
        seen = f'its text is "{text}"'
    # Line breaks and spacing aren't part of what a text says (a message starting with a line
    # break, a label ending in a space).
    if kind == "text_equals":
        return step_types.same_text(text, expected), seen
    if kind == "text_contains":
        return step_types.plain_spaces(expected).lower() in step_types.plain_spaces(text).lower(), seen
    if kind == "text_matches":
        return _regex_search(expected, text), seen
    if kind in ("enabled", "disabled"):
        return state["enabled"] == (kind == "enabled"), "it is enabled" if state["enabled"] else "it is disabled"
    if kind in ("checked", "unchecked"):
        return state["checked"] == (kind == "checked"), "it is checked" if state["checked"] else "it is not checked"
    if kind == "selected":
        return bool(state["selected"]), "it is selected" if state["selected"] else "it is not selected"
    raise CheckFailed(f"Unknown check '{kind}'")


def _regex_search(pattern: str, text: str) -> bool:
    try:
        return re.search(pattern, text or "") is not None
    except re.error as e:
        raise CheckFailed(f"'{pattern}' isn't a valid regular expression ({e})")


def _evaluate_screen(driver, kind: str, expected: str, locator: dict):
    """(passed, what was actually seen) for a screen-level check."""
    want = expected.strip().lower()
    if kind in ("screen_has_text", "screen_lacks_text"):
        want = " ".join(want.split())
        found = next((t for t in mc.screen_texts(driver) if want in " ".join(t.lower().split())), None)
        if found is None:
            # A web popup can be missing from Android's view of the screen - ask the page too.
            page = " ".join(_web_page_text(driver).split())
            if want and want in page.lower():
                found = "the app's web page"
        if kind == "screen_has_text":
            return found is not None, (f'found in "{found}"' if found else "it isn't on screen")
        return found is None, ("it isn't on screen" if found is None else f'it is on screen: "{found}"')
    if kind == "toast":
        toasts = mc.toast_texts(driver)
        hit = next((t for t in toasts if want in t.lower()), None) if toasts else None
        if hit is not None:
            return True, f'toast "{hit}"'
        return False, (f'the toast said "{toasts[0]}"' if toasts else "no toast appeared")
    if kind == "on_screen":
        package = mc.current_package(driver)
        activity = mc.current_activity(driver)
        want_package = locator.get("package") or package
        # Activities are reported with or without the package ("com.x.Main" / ".Main").
        same_activity = not want or activity.lower().endswith(want.split("/")[-1].lstrip(".").lower())
        return (package == want_package and same_activity), f"the app in front is {package} {activity}"
    if kind in ("dialog_shown", "no_dialog"):
        windows = mc.app_window_count(driver, mc.current_package(driver))
        open_ = windows > 1
        return open_ == (kind == "dialog_shown"), ("a popup is open" if open_ else "no popup is open")
    if kind in ("keyboard_shown", "keyboard_hidden"):
        shown = mc.keyboard_shown(driver)
        if shown is None:
            return False, "the keyboard's state couldn't be read"
        return shown == (kind == "keyboard_shown"), ("the keyboard is shown" if shown else "the keyboard is hidden")
    raise CheckFailed(f"Unknown check '{kind}'")


def _run_check(driver, step: dict, screen: dict, check, should_stop=None) -> str:
    """Verify an assert step, re-reading until it passes or STEP_WAIT_SECONDS runs out -
    a value that loads a moment late passes, a wrong one fails with what was there."""
    locator = step.get("locator") or {}
    kind = step.get("check") or "visible"
    expected = step.get("text") or ""
    normalize = step.get("normalize")
    wanted = mc.CHECKS.get(kind, kind) + (f' "{expected}"' if kind in mc.TEXT_CHECKS and expected else "")
    deadline = time.time() + settings.step_wait_seconds

    if kind in mc.SCREEN_CHECKS:
        # Nothing to find first - look at the whole screen until it's true or time runs out.
        # A toast only shows for 2-3 s, so it's looked for more often.
        poll = 0.2 if kind == "toast" else CHECK_POLL_S
        while True:
            check()
            passed, actual = _evaluate_screen(driver, kind, expected, locator)
            if passed:
                return f"Passed: {actual}"
            if time.time() >= deadline:
                raise CheckFailed(f"Check failed ({wanted}): {actual} (waited {settings.step_wait_seconds:g}s)")
            time.sleep(poll)

    # Recorded on the app's web page: ask the page itself (its own locator, the whole text).
    if locator.get("web") and kind in WEB_CHECKS:
        result = _run_web_check(step, screen, check, kind, expected, wanted)
        if result is not None:
            return result

    # The text the element is found by - also looked for in the app's web page, since a web
    # popup (a Bootstrap modal) can be missing from Android's view of the screen entirely.
    _, _, by_text = mc._semantic_target(locator)

    def find():
        element = mc.find_for_check(driver, locator, screen)
        if element is None and by_text and not locator.get("anchor"):
            element = _web_text_element(driver, by_text)
        return element

    if kind == "not_visible":
        while True:
            check()
            if find() is None:
                return "Passed: not on screen"
            if time.time() >= deadline:
                raise CheckFailed(f"Check failed ({wanted}): still on screen after {settings.step_wait_seconds:g}s")
            time.sleep(CHECK_POLL_S)

    # Look (without scrolling) until it appears and the check holds, or time runs out.
    actual = "it was not found on screen"
    element, scrolled = find(), False
    started, clearer = time.time(), _clearer()
    while True:
        check()
        if element is not None:
            passed, actual = _evaluate(kind, element, expected, normalize)
            if passed:
                return f"Passed: {actual}" + (" (found in the app's web page)" if isinstance(element, WebText) else "")
        if clearer is not None and clearer(time.time() - started):
            element = find()   # a popup (or the keyboard) was in the way: look again at once
            continue
        if time.time() >= deadline:
            if element is None and not scrolled:
                # Never on screen: it may be further down a list - scroll for it once.
                scrolled = True
                found = mc.resolve_with_scroll_search(driver, locator, should_stop=should_stop, wait_s=0,
                                                      also_look=_web_fallback(driver, locator))
                element = found if isinstance(found, WebText) else mc.check_target(driver, found, locator, screen)
                deadline = time.time() + CHECK_MIN_S
                continue
            raise CheckFailed(f"Check failed ({wanted}): {actual}")
        time.sleep(CHECK_POLL_S)
        element = find()


def _run_capture(driver, step: dict, screen: dict, check, should_stop=None):
    """A "capture" step: read the value an element shows now and remember it under step["var"]
    for the rest of this run (used later as ${var} in a check's expected value, a typed field,
    or anything that takes test data). Normalized by step["normalize"] (see _normalize), so a
    value is kept in a steady form. Returns (name, value, note); raises LookupError (retryable,
    so a value that loads a moment late still works) when the element isn't found.

    The read reuses a check's one-look-then-scroll finding - the same way an assert locates its
    element - so capturing works wherever a check does (including a label-anchored row or a web
    popup not in Android's view)."""
    name = (step.get("var") or "").strip()
    if not name:
        raise CheckFailed("This Remember step has no name to store the value under - set one.")
    locator = step.get("locator") or {}
    _, _, by_text = mc._semantic_target(locator)

    def find():
        element = mc.find_for_check(driver, locator, screen)
        if element is None and by_text and not locator.get("anchor"):
            element = _web_text_element(driver, by_text)
        return element

    deadline = time.time() + settings.step_wait_seconds
    element = find()
    while element is None and time.time() < deadline:
        check()
        time.sleep(CHECK_POLL_S)
        element = find()
    if element is None:
        # Not on screen without scrolling: it may be further down a list - look once, scrolling.
        found = mc.resolve_with_scroll_search(driver, locator, should_stop=should_stop, wait_s=0,
                                              also_look=_web_fallback(driver, locator))
        element = found if isinstance(found, WebText) else mc.check_target(driver, found, locator, screen)
    if element is None:
        raise LookupError(f"Couldn't find the value to remember as '{name}' on screen.")
    raw = mc.element_state(element)["text"] or ""
    value = _normalize(raw, step.get("normalize"))
    shown = value if len(value) <= 60 else value[:57] + "…"
    return name, value, f'Remembered "{shown}" as {name}'


_web_clients: dict = {}   # app package -> WebViewClient, for the current run


def _web_client_for(package: str):
    client = _web_clients.get(package)
    if client is None:
        client = _web_clients[package] = web_cdp.WebViewClient(package, device_serial(), resolve_adb())
    return client


def _near(step: dict, screen: dict) -> tuple:
    return int((step.get("x_pct") or 0) * screen["width"]), int((step.get("y_pct") or 0) * screen["height"])


def _settled(client, web: dict, near: tuple, center: tuple, pause: float = 0.15, tolerance: int = 4):
    """The element's position once it has stopped moving, or None if it's still moving: a page
    mid smooth-scroll, or content still sliding in, would be tapped where it was a moment ago."""
    time.sleep(pause)
    again = client.find(web, near=near).get("center")
    if again and abs(again[0] - center[0]) <= tolerance and abs(again[1] - center[1]) <= tolerance:
        return again
    return None


def _web_point(step: dict, screen: dict, check) -> tuple:
    """(screen point, healed) of a step recorded on an app's web page (see app/arp/web_cdp.py),
    found by asking the page itself - waiting for it like any other target, and tapped only
    once it has stopped moving. When its locator finds nothing for a few seconds, the page is
    also searched by the element's fingerprint (self-healing; `healed` then says what was
    found). (None, None) when the step has no web locator or the page can't be inspected
    now, so the native locator is used instead."""
    web = (step.get("locator") or {}).get("web")
    if not web or not web.get("package"):
        return None, None
    client = _web_client_for(web["package"])
    near = _near(step, screen)
    wait = _wait_for(step) or settings.step_wait_seconds
    started = time.time()
    deadline, heal_at = started + wait, started + min(healing.HEAL_AFTER, wait / 2)
    near_misses = None
    try:
        while True:
            check()
            found = client.find(web, near=near)
            if found.get("center"):
                center = _settled(client, web, near, found["center"])
                if center:
                    return center, None
            elif not found.get("count") and not step.get("optional") and _options["heal"] and time.time() >= heal_at:
                scored = [(c["score"], c["sims"], c) for c in client.heal(web, near=near)]
                best = healing.pick(scored)
                near_misses = [{"score": round(sc, 2), "element": web_cdp.describe(c["loc"]),
                                "matched": healing.matched_features(sims)} for sc, sims, c in scored[:3]]
                if best is not None and best[2]["on_top"]:   # (covered by something else: keep waiting)
                    score, sims, cand = best
                    return cand["center"], {
                        "strategy": "web", "value": web_cdp.describe(cand["loc"]), "index": 0, "web": cand["loc"],
                        "score": round(score, 2), "matched": healing.matched_features(sims)}
                heal_at = time.time() + healing.HEAL_EVERY
            if time.time() >= deadline:
                if any((step.get("locator") or {}).get(k) for k in _IDENTITY_KEYS):
                    return None, None   # try the native locator
                state = "is covered or hidden" if found.get("count") else "is not on the page"
                raise LookupError(f"'{web_cdp.describe(web)}' {state} (waited {wait:g}s)"
                                  + healing.near_miss_text(near_misses))
            time.sleep(0.25)
    except web_cdp.WebViewUnavailable:
        return None, None


WEB_CHECKS = ("visible", "not_visible", "text_equals", "text_contains", "text_matches")


def _run_web_check(step: dict, screen: dict, check, kind: str, expected: str, wanted: str) -> Optional[str]:
    """A check on web content, evaluated in the page itself against the element's whole text;
    re-checked until it passes or time runs out. None if the page can't be inspected now."""
    web = step["locator"]["web"]
    if not web.get("package"):
        return None
    near = _near(step, screen)
    deadline = time.time() + settings.step_wait_seconds
    try:
        client = _web_client_for(web["package"])
        while True:
            check()
            found = client.find(web, near=near)
            shown = found.get("center") is not None
            text = " ".join((found.get("full_text") or found.get("text") or "").split()) if shown else ""
            if kind == "visible":
                passed, actual = shown, ("it is on the page but covered or hidden" if found.get("count")
                                         else "it is not on the page")
            elif kind == "not_visible":
                passed, actual = not shown, "it is visible"
            elif not shown:
                passed, actual = False, "it is not visible"
            elif kind == "text_equals":
                passed, actual = text == " ".join(expected.split()), f'its text is "{text}"'
            elif kind == "text_contains":
                passed, actual = " ".join(expected.split()).lower() in text.lower(), f'its text is "{text}"'
            else:
                passed, actual = _regex_search(expected, text), f'its text is "{text}"'
            if passed:
                shown_as = {"visible": "it is on screen", "not_visible": "not on screen"}.get(kind, actual)
                return f"Passed: {shown_as} (in the app's web page)"
            if time.time() >= deadline:
                raise CheckFailed(f"Check failed ({wanted}): {actual} (waited {settings.step_wait_seconds:g}s)")
            time.sleep(CHECK_POLL_S)
    except web_cdp.WebViewUnavailable:
        return None


def _close_web_clients():
    for client in _web_clients.values():
        try:
            if client is not None:
                client.close()
        except Exception:
            pass
    _web_clients.clear()


# ---------------------------------------------------------------------
# The app's web page as a fallback (see app/arp/web_cdp.py)
# ---------------------------------------------------------------------

# The smallest visible element whose text is (or, EXACT false, contains) TEXT - spacing and
# case ignored. Read-only.
_FIND_TEXT_JS = r"""(() => {
  const norm = s => (s || '').replace(/\s+/g, ' ').trim().toLowerCase();
  const want = norm(TEXT);
  let best = null;
  for (const e of document.querySelectorAll('body *')) {
    const t = norm(e.innerText);
    if (!t || !(EXACT ? t === want : t.includes(want))) continue;
    const r = e.getBoundingClientRect();
    if (!r.width || !r.height) continue;
    const cs = getComputedStyle(e);
    if (cs.visibility === 'hidden' || cs.display === 'none' || cs.opacity === '0') continue;
    if (!best || r.width * r.height < best.area)
      best = {area: r.width * r.height, text: (e.innerText || '').replace(/\s+/g, ' ').trim(), rect: [r.left, r.top, r.width, r.height]};
  }
  return best && {text: best.text, rect: best.rect};
})()"""


class WebText:
    """An element found in the app's web page by its text - answers what a check reads."""

    def __init__(self, text: str, center: tuple):
        self.text, self.center = text, center
        self.rect = {"x": center[0], "y": center[1], "width": 0, "height": 0}

    def get_attribute(self, name: str):
        return self.text if name == "text" else None


def _web_client(driver):
    """A connection to the foreground app's web page, or None if it has none it can reach
    (a native app, or WebView debugging off) - remembered for the rest of the run."""
    package = session.package or mc.current_package(driver)
    if not package:
        return None
    if package not in _web_clients:
        client = web_cdp.WebViewClient(package, device_serial(), resolve_adb())
        try:
            client.call("true")
        except Exception:
            try:
                client.close()
            except Exception:
                pass
            client = None
        _web_clients[package] = client
    return _web_clients[package]


def _web_text_element(driver, text: str, exact: bool = True) -> Optional[WebText]:
    client = _web_client(driver)
    if client is None:
        return None
    try:
        # EXACT first: the text itself could contain the word "EXACT".
        found = client.call(_FIND_TEXT_JS.replace("EXACT", "true" if exact else "false").replace("TEXT", json.dumps(text)))
    except Exception:
        return None
    return WebText(found["text"], client.to_screen(found["rect"])) if found else None


def _web_fallback(driver, locator: dict):
    """For resolve_with_scroll_search(also_look=...): look for the step's text in the app's
    web page too. None when there's no text to look for (or it's a label anchor)."""
    text = locator.get("text")
    if not text or locator.get("anchor") or locator.get("prefer"):
        return None
    return lambda: _web_text_element(driver, text)


def _point_bounds(center: tuple) -> str:
    x, y = center
    return f"[{x - 1},{y - 1}][{x + 1},{y + 1}]"


def _web_page_text(driver) -> str:
    client = _web_client(driver)
    if client is None:
        return ""
    try:
        return client.call("document.body ? document.body.innerText : ''") or ""
    except Exception:
        return ""


def _replay_select(driver, step: dict, screen: dict, check, should_stop) -> str:
    """A dropdown choice (recorded as one step - see app/arp/helper_recorder.merge_selections):
    open the dropdown, then pick the option by its text, scrolling the list if needed -
    not by where it was, since a list opens on its current choice."""
    locator = step.get("locator") or {}
    option = step.get("text") or ""
    before = mc.screen_signature(driver)
    healer = None
    web_point, _ = _web_point(step, screen, check)
    if web_point is not None:
        check()
        mc.tap_coords(driver, *web_point)
    else:
        dropdown = None
        has_coords = step.get("x_pct") is not None
        # A dropdown is found by its id / structure, never by the value it currently shows: its
        # text (e.g. "Select") is just the placeholder and also matches other empty dropdowns.
        open_locator = locator
        if any(locator.get(k) for k in ("resource_id", "candidates", "xpath", "label_xpath", "content_desc")):
            open_locator = {k: v for k, v in locator.items() if k not in ("text", "text_index")}
        # An opener captured as a row inside the list it opens (a native Spinner's dialog) can't
        # be found before the list is open: skip looking for it and open the dropdown by its
        # recorded screen position. The option is still picked by its text below.
        if not mc.opener_in_open_list(open_locator) and any(open_locator.get(k) for k in _IDENTITY_KEYS):
            dropdown = mc.resolve_with_scroll_search(driver, open_locator, should_stop=should_stop,
                                                     wait_s=_wait_for(step), while_waiting=_clearer())
            if dropdown is None:
                # A dropdown's text is its current choice, never a name: healed without it.
                dropdown, healer = _heal_native(driver, step, use_text=False)
        if dropdown is None and not has_coords:
            _require_target(step, dropdown, healer)   # nothing to open it with
        check()
        if dropdown is not None:
            mc.tap_element(driver, dropdown, locator.get("tap_offset"), screen, locator)
        else:
            # Open the dropdown where it was tapped; if that opens nothing, the option search fails clearly.
            mc.tap_coords(driver, int((step.get("x_pct") or 0) * screen["width"]),
                          int((step.get("y_pct") or 0) * screen["height"]))
    mc.wait_for_change(driver, before)   # the list opening
    # The list may open in a popup window of its own, which the page source only includes
    # with multi-window on.
    try:
        driver.update_settings({"enableMultiWindows": True})
        multi = True
    except Exception:
        multi = False
    try:
        # The list may still be loading (picking the To date reloads the form): wait for it to
        # show options before searching.
        opened = _wait_for_list(driver, should_stop)
        choice = mc.resolve_with_scroll_search(
            driver, {"text": option, "text_index": 0, "in_list": True, "list_index": 0}, should_stop=should_stop) \
            if opened else None
        shown_options = _open_list_options(driver) if choice is None else []
    finally:
        if multi:
            try:
                driver.update_settings({"enableMultiWindows": False})
            except Exception:
                pass
    if choice is None:
        if shown_options:
            # The list opened but doesn't have this option: genuinely absent (e.g. it depends on
            # the leave type). Not retryable - re-tapping would just toggle the open list.
            shown = ", ".join(f'"{o}"' for o in shown_options[:12]) + (" ..." if len(shown_options) > 12 else "")
            raise RuntimeError(f"Option '{option}' wasn't in the list that opened - the list has: {shown}. "
                               "This list may depend on an earlier step's choice (e.g. the leave type).")
        # No list opened at all - the dropdown didn't open, usually because the app is still
        # loading (a date pick reloads the form). Retryable: it's tried again, and a Wait step
        # before it (or a higher 'Wait up to') helps if the load is slow.
        raise LookupError(f"The '{option}' dropdown didn't open - the app may still be loading after an "
                          "earlier step. It's retried; add a Wait step before it if the app needs longer.")
    check()
    mc.tap_element(driver, choice)
    if healer is not None and healer.result:
        return (f"Picked '{option}'; self-healed: the dropdown's locators matched nothing, so it was found "
                f"as {healer.result['element']} by its recorded fingerprint (score {healer.result['score']:.2f})")
    return f"Picked '{option}'"


# The rows of an opened dropdown list: a native picker's CheckedTextViews (android:id/text1),
# a dialog list. The whole page (a WebView) is NOT one of these - so an empty result means the
# dropdown genuinely didn't open (the app is still loading / the tap missed), not "no options".
_LIST_ROW = ("android:id/text1", "android:id/text2")


def _open_list_options(driver, limit: int = 25) -> list:
    """Option texts of an open dropdown list now - a native picker's / dialog's rows. [] when no
    such list is open (the page itself is never mistaken for a list). A web <select> that an app
    renders inside a WebView opens as exactly such a native list when tapped."""
    try:
        nodes = mc.parse_page_source(mc.get_page_source(driver))
    except Exception:
        return []
    rows = [mc._sanitize(n.get("text")) for n in nodes
            if n.get("displayed") != "false" and (n.get("resource-id") or "") in _LIST_ROW]
    if not rows:
        # A list inside a popup window of its own (a dropdown's own window), if one is open.
        inside = [n for n in nodes if "select_dialog_listview" in (n.get("resource-id") or "")]
        if inside:
            rows = [mc._own_label(n) for n in nodes if n.get("displayed") != "false" and mc._own_label(n)]
    return [l for l in dict.fromkeys(rows) if l and not mc.looks_dynamic(l)][:limit]


def _wait_for_list(driver, should_stop=None, timeout: Optional[float] = None) -> bool:
    """Wait for the dropdown's option list to actually appear - the app may still be loading after
    an earlier step (e.g. picking the To date reloads the form), so the tap opens nothing for a
    while. True once options show. Waits up to the step's wait (STEP_WAIT_SECONDS)."""
    deadline = time.time() + (settings.step_wait_seconds if timeout is None else timeout)
    while True:
        if should_stop is not None and should_stop():
            return False
        if _open_list_options(driver):
            return True
        if time.time() >= deadline:
            return False
        time.sleep(0.25)


KEYBOARD_AFTER_S = 0.8   # a step that hasn't found its element for this long closes an open keyboard
POPUP_AFTER_S = 1.5      # ...and after this long answers popups (popup_handlers)
POPUP_EVERY_S = 2.0

_step_ctx = threading.local()   # the step being replayed: its _Clearer
_options = {"heal": True}       # per run (see _execute_run): self-healing on or off


class _Clearer:
    """While a step waits for its element (mobile_control.resolve_with_scroll_search's
    while_waiting): after KEYBOARD_AFTER_S an open keyboard is closed (it can cover or shift
    the element), after POPUP_AFTER_S known popups are answered. Only while something is
    missing - never before every step, so it costs nothing when nothing's in the way."""

    def __init__(self, driver):
        self.driver, self.keyboard_checked, self.next_popup, self.notes = driver, False, 0.0, []

    def __call__(self, waited: float) -> bool:
        if not self.keyboard_checked and waited >= KEYBOARD_AFTER_S:
            self.keyboard_checked = True
            if mc.hide_keyboard(self.driver):
                self.notes.append("closed the keyboard, which was in the way")
                return True
        if waited >= POPUP_AFTER_S and time.time() >= self.next_popup:
            self.next_popup = time.time() + POPUP_EVERY_S
            try:
                done = popup_handlers.dismiss(self.driver)
            except Exception:
                done = []
            if done:
                self.notes.extend(done)
                time.sleep(0.5)
                return True
        return False


def _clearer():
    return getattr(_step_ctx, "clearer", None)


_PICKER = "//*[@resource-id='android:id/datePicker']"
_PICKER_DAYS = "//*[@resource-id='android:id/month_view']/*"
_YEAR_HEADER = "android:id/date_picker_header_year"
_YEAR_LIST = "android:id/date_picker_year_picker"
MAX_MONTH_TAPS = 24   # only the months within a year - the year is jumped to via the year list


def _shown_month(driver):
    """(year, month) the calendar shows and how its days are labelled, from a day's label."""
    for el in mc._find_by(driver, "xpath", _PICKER_DAYS)[:3]:
        label = el.get_attribute("content-desc") or ""
        day = step_types.parse_date(label)
        if day:
            return (day.year, day.month), label
    return None, None


def _year_list_open(driver) -> bool:
    """Whether the picker is currently showing its scrollable year list (not the day grid)."""
    return bool(mc._find_by(driver, "xpath", f"//*[@resource-id='{_YEAR_LIST}']//*[@resource-id='android:id/text1']"))


def _pick_year(driver, year: int, check) -> bool:
    """Jump straight to a year using the picker's year list, so a far date doesn't need hundreds
    of month-arrow taps. Opens the year list via the year header if it isn't already open (a
    previous step may have left it open). False when there's no year header to use (then the
    caller falls back to the month arrows)."""
    if not _year_list_open(driver):
        header = mc._find_by(driver, "id", _YEAR_HEADER)
        if not header:
            return False
        check()
        header[0].click()
        deadline = time.time() + 5.0
        while not _year_list_open(driver) and time.time() < deadline:
            time.sleep(0.15)
    found = _scroll_year_list(driver, year, check)
    if not found:
        raise RuntimeError(f"Couldn't find the year {year} in the calendar's year list "
                           "(it may be outside the dates the picker allows)")
    check()
    found[0].click()
    time.sleep(0.3)
    return True


def _year_texts(driver) -> list:
    out = []
    for el in mc._find_by(driver, "xpath", f"//*[@resource-id='{_YEAR_LIST}']//*[@resource-id='android:id/text1']"):
        try:
            t = (el.get_attribute("text") or "").strip()
        except Exception:
            continue
        if t.isdigit():
            out.append(int(t))
    return out


def _scroll_year(driver, bounds: tuple, up: bool, percent: float = 0.8):
    """Scroll the year list one controlled step (no fling momentum, so it never overshoots far
    past the target). `up` reveals one direction; the caller learns which from what appears."""
    x1, y1, x2, y2 = bounds
    size = {"left": x1, "top": y1, "width": max(1, x2 - x1), "height": max(1, y2 - y1)}
    try:
        driver.execute_script("mobile: scrollGesture", dict(size, direction="up" if up else "down", percent=percent))
    except Exception:
        cx, hy, ly = (x1 + x2) // 2, int(y1 + (y2 - y1) * 0.3), int(y1 + (y2 - y1) * 0.7)
        mc.swipe_coords(driver, cx, (hy if up else ly), cx, (ly if up else hy), duration_ms=300)


def _scroll_year_list(driver, year: int, check, max_steps: int = 60) -> list:
    """Scroll the year list to `year` and return it. Scrolls a controlled step at a time toward
    the year, learning which scroll direction reveals earlier years from how the visible years
    actually move - so it always heads toward the target (never the wrong way, as the old
    fling-to-search did) and can't overshoot into oscillation. [] if the year is outside the
    picker's range."""
    nodes = mc.parse_page_source(mc.get_page_source(driver))
    picker = next((n for n in nodes if (n.get("resource-id") or "") == _YEAR_LIST), None)
    screen = mc.get_window_size(driver)
    bounds = mc.parse_bounds((picker or {}).get("bounds") or "") or (0, 0, screen["width"], screen["height"])
    up_means_earlier = True   # assumption; corrected the first time we see which way the years move
    prev_mid = last_intended_earlier = None
    stuck = 0
    for _ in range(max_steps):
        check()
        hit = [el for el in mc._find_by(driver, "xpath",
               f"//*[@resource-id='{_YEAR_LIST}']//android.widget.TextView[@text='{year}']")
               if _displayed_safe(el)]
        if hit:
            return hit
        years = _year_texts(driver)
        if not years:
            return []
        mid = (min(years) + max(years)) // 2
        if prev_mid is not None and last_intended_earlier is not None:
            if mid == prev_mid:
                stuck += 1
                if stuck >= 3:
                    return []   # not moving: the picker's range doesn't reach this year
            else:
                stuck = 0
                if (mid < prev_mid) != last_intended_earlier:   # moved the wrong way - flip the mapping
                    up_means_earlier = not up_means_earlier
        want_earlier = year < mid
        scroll_up = up_means_earlier if want_earlier else (not up_means_earlier)
        prev_mid, last_intended_earlier = mid, want_earlier
        # A small step when close to avoid stepping over the target, a big one when far.
        percent = 0.4 if abs(year - mid) <= 6 else 0.85
        _scroll_year(driver, bounds, scroll_up, percent)
        time.sleep(0.3)
    return []


def _displayed_safe(el) -> bool:
    try:
        return el.is_displayed()
    except Exception:
        return False


def _day_label(target, sample: str) -> str:
    """`target` written the way the calendar labels its days (learnt from one label, e.g.
    "01 October 2026" -> "%d %B %Y"), so it works in any phone language that parses."""
    import datetime
    for fmt in step_types._DATE_FORMATS:
        try:
            datetime.datetime.strptime(step_types.plain_spaces(sample), fmt)
        except ValueError:
            continue
        return target.strftime(fmt)
    return target.strftime("%d %B %Y")


def _pick_in_calendar(driver, target, check) -> str:
    """Pick `target` in Android's standard date picker: move to its month, tap the day, OK.
    Adapted from android-record-playback's appium_playback._pick_in_calendar."""
    deadline = time.time() + settings.step_wait_seconds
    while not mc._find_by(driver, "xpath", _PICKER):
        if time.time() > deadline:
            raise LookupError("No calendar opened (this works with Android's standard date picker; an app's own "
                              "calendar needs the day tapped as separate steps)")
        time.sleep(0.25)
    # Jump to the target year via the year list first - so a far date (or a different year) takes
    # a few taps, not hundreds of month arrows. Also handles the year list being left open by a
    # previous step (then there's no day grid to read yet). Then the month arrows move within the year.
    jumped = False
    if _year_list_open(driver):
        jumped = _pick_year(driver, target.year, check)
    else:
        shown, _ = _shown_month(driver)
        if shown and shown[0] != target.year:
            jumped = _pick_year(driver, target.year, check)
    taps = 0
    while True:
        check()
        shown, sample = _shown_month(driver)
        if shown is None:
            if _year_list_open(driver):   # still on the year list - pick the year and look again
                jumped = _pick_year(driver, target.year, check)
                continue
            raise RuntimeError("The calendar's days have no readable dates")
        diff = (target.year * 12 + target.month) - (shown[0] * 12 + shown[1])
        if diff == 0:
            break
        if taps >= MAX_MONTH_TAPS:
            where = "its year list doesn't go that far" if jumped else f"{abs(diff)} months of arrows is too many"
            raise RuntimeError(f"Couldn't reach {target:%d/%m/%Y} in the calendar ({where})")
        found = mc._find_by(driver, "id", "android:id/next" if diff > 0 else "android:id/prev")
        if not found:
            raise RuntimeError(f"Can't move the calendar {'forward' if diff > 0 else 'back'} - "
                               f"{target:%d/%m/%Y} is outside the dates it allows")
        for _ in range(min(abs(diff), 6)):   # a few at a time, then check where it landed
            found[0].click()
            taps += 1
        time.sleep(0.3)
    label = _day_label(target, sample)
    days = [el for el in mc._find_by(driver, "xpath", f"//*[@content-desc={mc._xpath_literal(label)}]")
            if el.is_enabled()]
    if not days:
        raise RuntimeError(f"{label} can't be picked in the calendar (outside the dates it allows)")
    check()
    days[0].click()
    ok = mc._find_by(driver, "id", "android:id/button1")
    if ok:
        ok[0].click()
    how = ("jumped to the year" if jumped else "") + (f"{' then ' if jumped else ''}{taps} month tap"
                                                      f"{'s' if taps != 1 else ''}" if taps or not jumped else "")
    return f"Picked {label} in the calendar ({how})"


def _replay_pick_date(driver, step: dict, screen: dict, check, should_stop) -> str:
    """Pick date: tap the date field (if one was recorded - else the calendar is already open),
    then move the calendar to the date's month and tap the day. The date may be test data
    (${today+7d}, ${start_date}) - filled in before the step runs."""
    wanted = step.get("text") or ""
    target = step_types.parse_date(wanted)
    if target is None:
        raise ValueError(f"'{wanted}' isn't a date - write it like 25/10/2026, or use ${{today+7d}}")
    locator = step.get("locator") or {}
    note = "calendar already open"
    if any(locator.get(k) for k in _IDENTITY_KEYS):
        field = mc.resolve_with_scroll_search(driver, locator, should_stop=should_stop, wait_s=_wait_for(step),
                                              while_waiting=_clearer())
        healer = None
        if field is None:
            field, healer = _heal_native(driver, step)
        _require_target(step, field, healer)
        check()
        mc.tap_element(driver, field, locator.get("tap_offset"), screen, locator)
        note = "opened the calendar"
    return f"{note}; {_pick_in_calendar(driver, target, check)}"


def _replay_one(driver, step: dict, should_stop=None, overrides: Optional[dict] = None) -> dict:
    action = step["action"]

    def check():
        # Called right before anything is done to the phone, so a Stop pressed while
        # this step was waiting on the device (or resolving its target) never taps.
        if should_stop is not None and should_stop():
            raise mc.RunStopped()

    clearer = _step_ctx.clearer = _Clearer(driver)
    with session.command_lock:
        try:
            mc.last_match = None
            screen = mc.get_window_size(driver)
            check()
            skipped = False
            note = None
            captured = None   # a "capture" step's (name, value) - stored into the run's variables
            healed = None   # what self-healing found, when the step's locators found nothing
            if action in ("tap", "long_press"):
                locator = step.get("locator") or {}
                offset = locator.get("tap_offset")
                press = mc.tap_coords if action == "tap" else mc.long_press_coords
                web_point, healed = _web_point(step, screen, check)
                if web_point is not None:
                    check()
                    press(driver, *web_point)
                    note = "Found in the app's web page"
                    if healed:
                        note = (f"Self-healed: its web locator matched nothing, so it was found as "
                                f"{healed['value']} by its recorded fingerprint (score {healed['score']:.2f})")
                else:
                    element = mc.resolve_with_scroll_search(driver, locator, should_stop=should_stop,
                                                            wait_s=_wait_for(step), also_look=_web_fallback(driver, locator),
                                                            while_waiting=clearer)
                    if isinstance(element, WebText):
                        element, note = mc.PointTarget(driver, {"bounds": _point_bounds(element.center)}), \
                            "Found in the app's web page"
                    if element is not None and locator.get("web") and _page_sized(element, screen):
                        # Recorded on the web page, whose lookup failed: Android's stand-in is the
                        # whole page body, and its middle is almost never what was tapped.
                        raise LookupError(f"'{web_cdp.describe(locator['web'])}' wasn't found on the app's web "
                                          "page (Android only sees the page around it)")
                    healer = None
                    if element is None:
                        element, healer = _heal_native(driver, step)
                        if element is not None:
                            healed = _healed_result(healer)
                            note = (f"Self-healed: its locators matched nothing, so it was found as "
                                    f"{healed['element']} by its recorded fingerprint (score {healed['score']:.2f}, "
                                    f"same {'/'.join(healed['matched'])})")
                    _require_target(step, element, healer)
                    if element is not None and mc.last_search_pages:
                        note = f"Scrolled {mc.last_search_pages} page{'s' if mc.last_search_pages != 1 else ''} to find it"
                    checked_target = step.get("checked_target")
                    # An offset tap is found by its caption, which has no checked state of its own to read.
                    if element is not None and checked_target is not None and not offset:
                        current = mc.read_checked_state(driver, element, locator)
                        if current == checked_target:
                            skipped, note = True, "Already in the desired state"
                    if element is not None and locator.get("tap_at") and _much_smaller(element, locator, screen):
                        # "The same spot within it" only makes sense in the same element: a much
                        # smaller one found by the same layout position is something else (a small
                        # icon where a big background was), and tapping it does something else.
                        raise LookupError(f"'{step.get('description') or 'the target'}' wasn't found: what's at its "
                                          "place in the layout now is a different, much smaller element")
                    check()
                    if not skipped:
                        if element is not None and action == "tap":
                            mc.tap_element(driver, element, offset, screen, locator)
                        elif element is not None:
                            rect = element.rect
                            press(driver, int(rect["x"] + rect["width"] / 2), int(rect["y"] + rect["height"] / 2))
                        else:
                            press(driver, int((step.get("x_pct") or 0) * screen["width"]),
                                  int((step.get("y_pct") or 0) * screen["height"]))
            elif action == "select":
                note = _replay_select(driver, step, screen, check, should_stop)
            elif action == "keypad":
                note = _replay_keypad(driver, step, check, should_stop)
            elif action == "pick_date":
                note = _replay_pick_date(driver, step, screen, check, should_stop)
            elif action == "type":
                element = mc.resolve_with_scroll_search(driver, step.get("locator") or {}, should_stop=should_stop,
                                                        need_element=True, wait_s=_wait_for(step),
                                                        while_waiting=clearer)
                healer = None
                if element is None:
                    # A field's text is what was typed into it, never its name: healed without it.
                    element, healer = _heal_native(driver, step, use_text=False)
                    if element is not None:
                        healed = _healed_result(healer)
                        note = (f"Self-healed: its locators matched nothing, so it was found as "
                                f"{healed['element']} by its recorded fingerprint (score {healed['score']:.2f})")
                _require_target(step, element, healer)
                if element is not None and mc.last_search_pages:
                    note = f"Scrolled {mc.last_search_pages} page{'s' if mc.last_search_pages != 1 else ''} to find it"
                text = step.get("text") or ""
                if step.get("redacted"):
                    override = (overrides or {}).get(step["order_index"])
                    if not override:
                        raise LookupError(
                            f"{step.get('description') or 'This step'} needs a value - its value "
                            "was never saved (for security). Provide one when starting this run."
                        )
                    text = override
                check()
                if element is not None:
                    mc.type_into_element(driver, element, text)
                else:
                    mc.type_at_coords(driver, int((step.get("x_pct") or 0) * screen["width"]),
                                       int((step.get("y_pct") or 0) * screen["height"]), text)
            elif action == "swipe":
                check()
                note = _replay_swipe(driver, screen, step) or note
            elif action == "key":
                check()
                mc.press_key(driver, step.get("text") or "back")
            elif action == "assert":
                note = _run_check(driver, step, screen, check, should_stop)
            elif action == "capture":
                name, value, note = _run_capture(driver, step, screen, check, should_stop)
                captured = {"name": name, "value": value}
            else:
                raise ValueError(f"Unknown action '{action}'")
            result = {"order_index": step["order_index"], "action": action,
                      "description": step.get("description"), "status": "ok"}
            if captured:
                result["captured"] = captured
            match = mc.last_match
            if healed:
                # Found by its fingerprint (or the page's own healing): the UI offers to save the
                # new locator into the step.
                result["healed"] = healed
                result["found_by"] = f"self-healing: {healed['strategy']} = {healed['value']}"
            elif match:
                result["found_by"] = f"{match['strategy']} = {match['value']}"
                if not match["primary"]:
                    # The main locator no longer finds it, a backup did: the step ran, and the
                    # UI offers to make the backup the main one (self-healing).
                    index = next((s["index"] for s in mc.locator_strategies(step.get("locator") or {})
                                  if s["strategy"] == match["strategy"] and s["value"] == match["value"]), 0)
                    result["healed"] = {"strategy": match["strategy"], "value": match["value"], "index": index}
                    note = (f"{note}; " if note else "") + "found by a backup locator - its main one didn't match"
            if skipped:
                result["skipped"] = True
            if clearer.notes:   # what was cleared out of the way while it waited (a keyboard, a popup)
                note = "; ".join(list(dict.fromkeys(clearer.notes)) + ([note] if note else []))
            if note:
                result["note"] = note
            return result
        except mc.RunStopped:
            return {"order_index": step["order_index"], "action": action,
                    "description": step.get("description"), "status": "stopped"}
        except Exception as e:
            error = str(e) + (f" [{'; '.join(dict.fromkeys(clearer.notes))}]" if clearer.notes else "")
            result = {"order_index": step["order_index"], "action": action,
                      "description": step.get("description"), "status": "error", "error": error}
            if isinstance(e, LookupError):
                result["not_found"] = True   # an optional step is skipped for this, not failed
            # Safe to try again: nothing was done to the phone (its element wasn't found, or a
            # check wasn't true yet). Any other failure may have happened half-way - never repeat it.
            result["retryable"] = isinstance(e, (LookupError, CheckFailed))
            return result


OPTIONAL_WAIT_S = 3.0   # an optional step (a popup that only sometimes shows) waits this long, then is skipped


def _wait_for(step: dict) -> Optional[float]:
    return OPTIONAL_WAIT_S if step.get("optional") else None


# Pause after each step, per playback speed - so a person can follow what's happening.
SPEED_PAUSE_S = {"fast": 0.0, "medium": 1.0, "slow": 2.5}


def _seconds(text) -> float:
    try:
        return max(0.0, min(float(text), 600.0))
    except (TypeError, ValueError):
        return 1.0


def _pause(run: runs_registry.Run, seconds: float):
    """Wait, but give up the moment Stop is pressed."""
    deadline = time.time() + seconds
    while time.time() < deadline and not run.stop_requested:
        time.sleep(0.1)


RETRY_DELAY_S = 1.5   # before retrying a step that failed (a screen still loading)


def _dismiss_popups() -> list:
    try:
        with session.command_lock:
            return popup_handlers.dismiss(session.require_driver())
    except Exception:
        return []


def _fill(value, variables: dict):
    """${...} filled in throughout a value (strings, lists, dicts)."""
    if isinstance(value, str):
        return step_types.substitute(value, variables)
    if isinstance(value, list):
        return [_fill(v, variables) for v in value]
    if isinstance(value, dict):
        return {k: _fill(v, variables) for k, v in value.items()}
    return value


def _with_variables(step: dict, variables: dict) -> dict:
    """The step with ${name}, ${env:NAME} and dates (${today+7d}) filled in: in its typed
    text, option, expected value or date, and in what finds its element (an account picked
    from a list as ${account} - see app/arp/step_types). Raises step_types.MissingVariable."""
    out = step
    if step["action"] in ("type", "select", "keypad", "assert", "pick_date") and "${" in (step.get("text") or ""):
        out = dict(out, text=step_types.substitute(step["text"], variables))
    locator = step.get("locator") or {}
    if "${" in json.dumps(locator, ensure_ascii=False):
        out = dict(out, locator=_fill(locator, variables))
    return out


def expand_steps(steps: list, seen: tuple = ()) -> tuple:
    """(steps, test data): each "run_case" step (its text: the id of the scenario to run - a
    reusable flow such as Login) replaced by that scenario's steps, recursively. They run
    under the calling step's place in the list, named "[Login 2/5] ...". The data: the called
    scenarios' own test data, for the caller's to override."""
    out, data = [], {}
    for step in steps:
        if step["action"] != "run_case" or step.get("disabled"):
            out.append(step)
            continue
        try:
            called_id = int(str(step.get("text") or "").strip())
        except ValueError:
            raise ValueError(f"Step {step['order_index'] + 1} doesn't say which scenario to run") from None
        if called_id in seen:
            raise ValueError(f"Step {step['order_index'] + 1} runs a scenario that runs itself (scenario {called_id})")
        try:
            called = get_scenario(called_id)
        except ValueError:
            raise ValueError(f"Step {step['order_index'] + 1} runs scenario {called_id}, which no longer exists") from None
        inner, inner_data = expand_steps(called["steps"], seen + (called_id,))
        data.update({**inner_data, **(called.get("variables") or {})})
        for n, sub in enumerate(inner, 1):
            out.append(dict(sub, order_index=step["order_index"], called=called["name"],
                            continue_on_failure=sub.get("continue_on_failure") or step.get("continue_on_failure"),
                            description=f"[{called['name']} {n}/{len(inner)}] {sub.get('description') or sub['action']}"))
    return out, data


def _screenshot(driver) -> str:
    """A screenshot for the run's results - with account numbers, amounts and dates blacked out
    unless MASK_SCREENSHOTS is off."""
    shot = mc.get_screenshot_b64(driver)
    if settings.mask_screenshots:
        try:
            nodes = mc.parse_page_source(mc.get_page_source(driver))
            shot = mc.mask_screenshot_b64(shot, nodes, mc.get_window_size(driver)["width"])
        except Exception:
            pass
    return shot


def run_scenario(scenario_id: int, overrides: Optional[dict] = None, speed: str = "fast",
                 start_index: int = 0, retries: int = 0, variables: Optional[dict] = None, heal: bool = True) -> str:
    """Kicks off replay in a background thread and returns a run_id right
    away - the frontend polls runs_registry.get_run(run_id) for live
    per-step progress and can call runs_registry.request_stop(run_id) to
    cancel between steps. Raises ValueError immediately (before spawning
    anything) if the scenario doesn't exist, same as before. `overrides`
    supplies values for this run only (order_index -> text) for any
    redacted (password/PIN/OTP) steps - never persisted anywhere."""
    scenario = get_scenario(scenario_id)
    start_index = max(0, min(start_index, len(scenario["steps"]) - 1)) if scenario["steps"] else 0
    run = runs_registry.create_run("scenario", total_steps=len(scenario["steps"]) - start_index,
                                   scenario_id=scenario_id, start_index=start_index)
    pause = SPEED_PAUSE_S.get(speed, 0.0)
    thread = threading.Thread(target=_execute_run,
                              args=(run, scenario_id, overrides or {}, pause, start_index, max(0, min(retries, 3)),
                                    variables or {}, heal),
                              daemon=True)
    thread.start()
    return run.id


def _execute_run(run: runs_registry.Run, scenario_id: int, overrides: Optional[dict] = None, pause: float = 0.0,
                 start_index: int = 0, retries: int = 0, run_variables: Optional[dict] = None, heal: bool = True):
    settle = None
    scenario = None
    _options["heal"] = heal
    try:
        scenario = get_scenario(scenario_id)
        package = scenario["android_app_package"]
        activity = scenario["android_app_activity"]
        # Reusable flows ("run another scenario") replaced by their steps; then "run from this
        # step" by the steps' place in this scenario.
        steps, called_data = expand_steps(scenario["steps"], (scenario_id,))
        steps = [s for s in steps if s["order_index"] >= start_index]
        # Test data: the called flows' own as defaults, this scenario's over them, the run's over all.
        variables = {**called_data, **(scenario.get("variables") or {}), **(run_variables or {})}

        if not session.is_connected:
            session.connect(package, activity)
        session.ensure_healthy()
        driver = session.require_driver()

        # Always ensure the target app is actually the foreground app
        # before replaying, regardless of whether the session was already
        # connected - this is what makes Run "open the app if it isn't,
        # or just proceed if it already is" rather than blindly tapping
        # whatever happens to be on screen (and it wakes/unlocks the
        # device first, so a screen that timed out and locked itself
        # since the last interaction doesn't derail the run).
        serial = device_serial()
        since = run_diagnosis.device_time(serial)   # Android's log is read from here if a step fails
        with session.command_lock:
            mc.ensure_foreground(driver, package)
        if start_index == 0:
            # A known start (not when running from a step: that continues from where the app is).
            start = {**START_DEFAULTS, **(scenario.get("start") or {})}
            _start_app(run, driver, package, start["app"], serial)
            if start["setup_scenario_id"]:
                try:
                    setup, setup_data = expand_steps([{"order_index": -1, "action": "run_case",
                                                       "text": str(start["setup_scenario_id"])}], (scenario_id,))
                except ValueError:
                    raise ValueError("The scenario set to run first (under \"Before it runs\") no longer exists "
                                     "or runs this one - change it in the scenario's settings") from None
                steps = [dict(s, setup=True) for s in setup] + steps
                variables = {**setup_data, **variables}
        if settings.settle_before_steps:
            settle = ScreenSettle(serial, session.command_lock)

        failed_on = False   # a continue-on-failure step failed: run on, but the run fails
        for i in range(len(steps)):
            step = steps[i]
            if run.stop_requested:
                run.finish("stopped")
                return

            if step.get("disabled"):
                run.append({"order_index": step["order_index"], "action": step["action"], "status": "ok",
                            "description": step.get("description"), "skipped": True, "note": "Disabled - skipped"})
                continue

            try:
                step = _with_variables(step, variables)
            except step_types.MissingVariable as e:
                failed = {"order_index": step["order_index"], "action": step["action"], "status": "error",
                          "description": step.get("description"),
                          "error": f"{e.args[0]} - add it under the scenario's test data, or set it before running"}
                run.append(failed)
                run.failure = run.failure or run_diagnosis.diagnose(None, serial, "", None, failed)
                if not step.get("continue_on_failure"):
                    run.finish("failed")
                    return
                failed_on = True
                continue

            if step["action"] == "wait":
                seconds = _seconds(step.get("text"))
                _pause(run, seconds)   # never under the device lock - the mirror keeps updating
                run.append({"order_index": step["order_index"], "action": "wait", "status": "ok",
                            "description": step.get("description"), "duration": seconds})
                continue

            if step["action"] == "swipe" and _leads_to_locatable_target(steps, i):
                run.append({
                    "order_index": step["order_index"], "action": "swipe",
                    "description": step.get("description"), "status": "ok",
                    "skipped": True, "note": "Scrolling handled automatically by the next step",
                })
                continue

            # Before acting, the screen must have settled (not still opening or loading): a tap
            # while it's still changing is ignored by the app.
            settled = 0.0
            if settle is not None and needs_settle(steps, i):
                settled = settle.wait(session.require_driver(), lambda: run.stop_requested)

            stale = session.driver
            started = time.time()
            result = _replay_one(session.require_driver(), step, lambda: run.stop_requested, overrides)
            if settled >= 0.5 and result["status"] == "ok":
                result["note"] = "; ".join([f"first waited {settled:.1f}s for the screen to finish loading"]
                                           + ([result["note"]] if result.get("note") else []))
            if result["status"] == "stopped":
                run.finish("stopped")
                return
            if result["status"] == "error" and is_dead_session_error(Exception(result.get("error", ""))):
                # The phone's UiAutomator2 server died mid-run. It failed on its first
                # device call, so nothing was executed yet and retrying the step is safe.
                with session.command_lock:
                    if session.driver is stale:  # the mirror may have recovered it already
                        session.recover()
                result = _replay_one(session.require_driver(), step, lambda: run.stop_requested, overrides)
                if result["status"] == "stopped":
                    run.finish("stopped")
                    return
                if not result.get("note"):
                    result["note"] = "Device session was lost and re-established before this step"

            # Its element wasn't found / a check wasn't true: a popup may be covering the screen
            # (dismiss it and try again), or the screen is just slow (retry, if retries are on).
            # Only failures where nothing was done to the phone get here (see "retryable").
            tries, popups = 0, []
            step_retries = 0 if step.get("optional") else retries
            while (result["status"] == "error" and result.get("retryable") and not run.stop_requested
                   and tries < step_retries + 3):
                dismissed = _dismiss_popups()
                popups += dismissed
                if not dismissed:
                    if tries >= step_retries:
                        break
                    _pause(run, RETRY_DELAY_S)
                tries += 1
                result = _replay_one(session.require_driver(), step, lambda: run.stop_requested, overrides)
                if result["status"] == "stopped":
                    run.finish("stopped")
                    return
            extra = popups + ([f"passed on attempt {tries + 1}"] if tries and result["status"] == "ok" else [])
            if extra:
                result["note"] = "; ".join(extra + ([result["note"]] if result.get("note") else []))
            result["duration"] = round(time.time() - started, 2)
            if result["status"] == "error" and step.get("optional") and result.get("not_found"):
                result.update(status="ok", skipped=True, note="Optional - it didn't appear, so it was skipped")
                result.pop("error", None)
            # With the live stream the browser already sees each step land; a failure always
            # gets a screenshot, for the Run view to show what was on screen.
            if result["status"] == "error" or not session.mjpeg_active:
                try:
                    with session.command_lock:
                        result["screenshot"] = _screenshot(session.require_driver())
                except Exception:
                    pass
            if step.get("called"):
                result["called"] = step["called"]   # one of the steps of a scenario this one runs
            if result["status"] == "error" and run.failure is None:
                # Why: the app (crashed, froze, closed), the test, or the phone / session.
                try:
                    with session.command_lock:
                        run.failure = run_diagnosis.diagnose(session.driver, serial, package, since, result)
                except Exception:
                    run.failure = run_diagnosis.diagnose(None, serial, package, since, result)
                result["failure_kind"] = run.failure["kind"]
            if result.get("captured") and result["status"] == "ok":
                # Remembered for the rest of this run: later steps use it as ${name} in a check's
                # expected value, a typed field, or anywhere else test data is read.
                variables[result["captured"]["name"]] = result["captured"]["value"]
            run.append(result)
            if result["status"] == "error":
                if not step.get("continue_on_failure"):
                    run.finish("failed")
                    return
                failed_on = True
            # No pause before a toast check: the toast (shown for 2-3 s) would be gone by then.
            next_is_toast = i + 1 < len(steps) and steps[i + 1].get("check") == "toast"
            if pause and i < len(steps) - 1 and not next_is_toast:
                _pause(run, pause)
        run.finish("failed" if failed_on else "passed")
    except Exception as e:
        run.append({"action": "run", "status": "error", "error": str(e)})
        run.failure = run.failure or run_diagnosis.run_error(str(e))
        run.finish("failed")
    finally:
        _close_web_clients()
        if settle is not None:
            settle.close()
        _options["heal"] = True
        run_history.save(run, (scenario or {}).get("name", ""))


def _start_app(run: runs_registry.Run, driver, package: str, mode: str, serial: Optional[str]):
    """Put the app in the scenario's known start state: "restart" closes and opens it again,
    "clear" also clears its data first (logged out, as freshly installed)."""
    if mode not in ("restart", "clear") or not package:
        return
    started = time.time()
    with session.command_lock:
        try:
            driver.terminate_app(package)
        except Exception:
            pass
        if mode == "clear":
            try:
                driver.execute_script("mobile: clearApp", {"appId": package})
            except Exception:
                run_diagnosis._adb(["shell", "pm", "clear", package], serial)
        driver.activate_app(package)
        mc.ensure_foreground(driver, package)
    run.append({"order_index": -1, "action": "start", "status": "ok", "setup": True,
                "description": "Cleared the app's data and opened it" if mode == "clear" else "Restarted the app",
                "duration": round(time.time() - started, 2)})
