"""
Background job tracking for scenario replay and AI-assisted execution.

The server is the single source of truth for a run's state: the UI never
tracks a run itself, it just asks "what is the active run right now?" and
renders the answer. That is what makes Stop reliable - stopping a run
finalizes it here immediately, without waiting for the worker thread (which
may be blocked inside a slow device call) to notice.

Plain in-memory, single process: one tester driving one device.
"""

import threading
import time
import uuid
from typing import Optional

_MAX_RUNS = 100


class Run:
    def __init__(self, kind: str, total_steps: Optional[int] = None, scenario_id: Optional[int] = None,
                 start_index: int = 0):
        self.id = str(uuid.uuid4())
        self.kind = kind  # "scenario" | "assist"
        self.scenario_id = scenario_id
        self.start_index = start_index   # "run from this step": steps before it weren't run
        self.status = "running"  # running | passed | failed | stopped
        self.log: list = []
        self.total_steps = total_steps
        self.stop_requested = False
        self.created_at = time.time()
        self.finished_at: Optional[float] = None
        # Why it failed (app/services/run_diagnosis.py): {kind, group, summary, detail, step}.
        self.failure: Optional[dict] = None
        self._lock = threading.Lock()

    def append(self, entry: dict):
        with self._lock:
            if self.status != "running":
                return  # a stopped run stays exactly as it was when Stop was pressed
            self.log.append(entry)

    def finish(self, status: str):
        with self._lock:
            if self.status == "running":  # first finish wins
                self.status = status
                self.finished_at = time.time()

    def to_dict(self) -> dict:
        with self._lock:
            return {
                "run_id": self.id, "kind": self.kind, "scenario_id": self.scenario_id,
                "start_index": self.start_index, "status": self.status, "total_steps": self.total_steps,
                "created_at": self.created_at, "finished_at": self.finished_at, "log": list(self.log),
                "failure": self.failure,
            }


_runs: dict = {}
_runs_lock = threading.Lock()


def create_run(kind: str, total_steps: Optional[int] = None, scenario_id: Optional[int] = None,
               start_index: int = 0) -> Run:
    run = Run(kind, total_steps, scenario_id, start_index)
    with _runs_lock:
        _runs[run.id] = run
        if len(_runs) > _MAX_RUNS:
            finished = sorted((r for r in _runs.values() if r.status != "running"), key=lambda r: r.created_at)
            for old in finished[: len(_runs) - _MAX_RUNS]:
                _runs.pop(old.id, None)
    return run


def get_run(run_id: str) -> Optional[Run]:
    with _runs_lock:
        return _runs.get(run_id)


def latest_run(kind: Optional[str] = None) -> Optional[Run]:
    with _runs_lock:
        candidates = [r for r in _runs.values() if kind is None or r.kind == kind]
    return max(candidates, key=lambda r: r.created_at) if candidates else None


def recent_runs(kind: Optional[str] = None, limit: int = 10) -> list:
    """The latest runs, newest first (kept in memory until the backend restarts)."""
    with _runs_lock:
        candidates = [r for r in _runs.values() if kind is None or r.kind == kind]
    return sorted(candidates, key=lambda r: r.created_at, reverse=True)[:limit]


def request_stop(run_id: str) -> Optional[Run]:
    """Flags the worker to stop AND finalizes the run right now, so every
    status read from this moment on says "stopped" - the worker exits at its
    next check, and anything it produces afterwards is discarded."""
    run = get_run(run_id)
    if run is None:
        return None
    run.stop_requested = True
    run.finish("stopped")
    return run
