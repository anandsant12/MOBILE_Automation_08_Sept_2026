"""
Turns real touches on the phone (app/automation/physical_touch.py) into
recorded steps, using the same element-lookup and description logic as a
mirror click - except the action already happened, so it is never repeated.

The hard part is WHICH screen a touch landed on. Appium's page-source dump
takes hundreds of milliseconds to over a second, so dumping it in response to
a finished gesture captures the screen AFTER the tap's effect (the next screen)
and identifies the wrong element. So a sampler thread keeps recent hierarchy
snapshots, and:
  - every finger-DOWN triggers a dump straight away - an app reacts to a tap
    when the finger lifts, so a dump started while the finger is down reads the
    screen the user was actually touching;
  - a screen change triggers a dump once it settles, plus follow-ups while the
    screen finishes loading, and there's a refresh every few seconds when idle.
Each touch is matched to the newest snapshot taken before the finger went down
if nothing has changed the screen since; otherwise to the one its own
touch-down triggered. A touch matched against a snapshot that may not show the
screen as it was is flagged "approximate" rather than presented as certain.

Also handled here:
  - the navigation bar's Back/Home (and "hide keyboard", which is Back while a
    keyboard is up) become key steps - System UI isn't in the app's page source;
  - a touch on a password field's show/hide icon becomes a tap on that icon;
  - a touch on something with no identity of its own (an unlabelled card or
    tab icon) is anchored to the caption nearest it; taps on the keyboard or
    plain empty background are skipped;
  - text typed on the phone is detected by diffing EditText contents between
    snapshots and recorded as one "type" step per field (unless the mirror
    typed it - no duplicates); password fields become value-less placeholders;
  - every decision is counted and logged (status() for the UI, and a JSON file
    in recording_debug/ when recording stops, to trace a wrongly recorded step).

With the recorder helper app (app/automation/helper_client.py, on by default)
the guesswork above mostly goes away:
  - at each finger-down the helper names the element under the finger, read
    on the phone within ~20ms - before the app reacts - and says whether the
    touch is on the keyboard or the navigation bar. That element is then found
    in a snapshot by its exact bounds, for the context locators need (labels,
    lists); if no snapshot has it, it's used on its own;
  - typing comes from the field itself (the helper reports each field's value
    as it changes and once more when focus leaves it) instead of snapshot diffs.
Without the helper (USE_RECORDER_HELPER=false, or it failed to start - the
reason is in status()), everything falls back to snapshots alone.

Best-effort throughout: a failure to start is reported via status(), never
raised - mirror recording must keep working regardless.
"""

import asyncio
import json
import queue
import threading
import time
from collections import deque
from pathlib import Path
from typing import Optional

from config import settings
from app.automation import helper_client as hc
from app.automation import mobile_control as mc
from app.automation import physical_touch as pt
from app.automation.session_manager import session, device_serial
from app.services import recording_service, screen_events

SETTLE_S = 0.3              # let the screen finish reacting before re-sampling after a change
FOLLOWUPS_S = (0.8, 1.8)    # re-read again this long after a change: screens often load in stages
IDLE_REFRESH_S = 2.0        # re-sample this often even if nothing we know of changed
SNAPSHOT_WAIT_S = 2.0       # how long a touch waits for the snapshot its own finger-down triggered
POLL_S = 0.05
MASK_CHARS = set("•*●∙·")
DEBUG_DIR = Path(settings.base_dir) / "recording_debug"

_listener: Optional["pt.PhysicalTouchListener"] = None
_generation = 0         # bumping this retires the worker threads of a previous session
_mode = "basic"
_snapshots: deque = deque(maxlen=10)  # (wall time the dump started, nodes), oldest first
_snap_lock = threading.Lock()
_touch_wake = threading.Event()       # a finger just went down - dump now
_pending_steps: "queue.Queue[dict]" = queue.Queue()
_prev_nodes: Optional[list] = None    # snapshot used for the previous gesture, for typing diffs
_prev_snap_t = 0.0                    # ...and when it was taken (diffs only ever move forward in time)
_nav_buttons: list = []
_sensitive_keys: set = set()          # fields seen as sensitive once stay so (a revealed password shows plain text)
# A field being typed into isn't recorded keystroke-by-keystroke (Android delivers typing as one
# touch per KEY, each landing on the on-screen keyboard - not part of the app's own hierarchy at
# all - so every one of those touches shows up here purely as a text-diff, never as its own tap).
# Buffered here and flushed as ONE step once the user demonstrably moves on: a real tap lands on a
# DIFFERENT element, a swipe happens, or recording stops. Never on a skipped touch (a keyboard key,
# or empty space) - those are indistinguishable from "still typing into the same field".
_pending_edit: Optional[dict] = None
# Same idea as _pending_edit, for a SENSITIVE field - flushed as a step with NO captured
# value (see _flush_pending_redacted), so the scenario still records that something goes
# here and in what order, without ever writing the value itself to disk.
_pending_redacted: Optional[dict] = None
_last_error: Optional[str] = None
_adb_path: Optional[str] = None
_stats = {"seen": 0, "recorded": 0, "skipped": 0}
_events: deque = deque(maxlen=12)
_debug: deque = deque(maxlen=500)

HIT_WAIT_S = 1.0            # how long a gesture waits for its touch-down helper lookup
_helper: Optional["hc.HelperClient"] = None
_helper_error: Optional[str] = None
_hits: dict = {}                                  # round(t_down, 3) -> helper "hit" result
_helper_events: "queue.Queue[dict]" = queue.Queue()
# The text field that has focus, per the helper: {"key", "attrs", "original", "value", "ts"}.
_field: Optional[dict] = None
_proc_lock = threading.RLock()   # gesture processing vs. stop()'s final flush
_REDACTED = object()
_last_typed: dict = {}           # field key -> the value (or _REDACTED) last recorded for it
_speak_password_before: Optional[str] = None   # the phone's setting, restored when recording stops


def _log(message: str):
    _events.appendleft(f"{time.strftime('%H:%M:%S')}  {message}")


def status() -> dict:
    listener = _listener
    alive = listener is not None and listener.is_alive()
    error = _last_error
    if listener is not None and not alive and not error:
        error = "The touch event stream ended (phone unplugged, or adb restarted?). Stop and start recording again."
    helper = _helper
    helper_on = helper is not None and not helper.closed.is_set()
    return {
        "available": alive,
        "error": error,
        "adb": _adb_path,
        "touch_device": listener.node if listener is not None else None,
        "stats": dict(_stats),
        "recent": list(_events),
        "helper": helper_on,
        "helper_error": None if helper_on else (_helper_error or (
            "the connection to the recorder helper was lost" if helper is not None else None)),
    }


def _helper_on() -> bool:
    return _helper is not None and not _helper.closed.is_set()


def _start_helper(use_helper: bool = True):
    global _helper, _helper_error
    _helper, _helper_error = None, None
    if not (settings.use_recorder_helper and use_helper):
        _helper_error = "turned off (USE_RECORDER_HELPER=false)" if not settings.use_recorder_helper else "not used"
        return
    try:
        _helper = hc.HelperClient(device_serial(), on_event=_helper_events.put).connect()
        _log("recorder helper connected - touches are identified on the phone as they land")
    except Exception as e:
        _helper, _helper_error = None, str(e)
        _log(f"recorder helper unavailable ({e}) - using screen snapshots only")


def start(mode: str, use_helper: bool = True):
    global _listener, _mode, _last_error, _adb_path, _prev_nodes, _prev_snap_t, _generation, _nav_buttons, _field
    stop()
    _mode, _last_error, _prev_nodes, _prev_snap_t, _field = mode, None, None, 0.0, None
    _stats.update(seen=0, recorded=0, skipped=0)
    _events.clear()
    _debug.clear()
    _sensitive_keys.clear()
    _last_typed.clear()
    _hits.clear()
    _touch_wake.clear()
    _drain_queue(_helper_events)
    with _snap_lock:
        _snapshots.clear()
    try:
        session.ensure_healthy()
        driver = session.require_driver()
        with session.command_lock:
            screen = mc.get_window_size(driver)
            _nav_buttons = mc.nav_buttons(driver)
        _adb_path = pt.resolve_adb()
        _listener = pt.PhysicalTouchListener(device_serial(), screen["width"], screen["height"])
        _listener.start()
    except Exception as e:
        _listener, _last_error = None, str(e)
        _log(f"could not start: {e}")
        return

    _start_helper(use_helper)
    _reveal_passwords(True)
    _log(f"listening for touches on {_listener.node}"
         + (f"; nav bar: {', '.join(b['key'] for b in _nav_buttons)}" if _nav_buttons else ""))
    _generation += 1
    gen = _generation
    screen_events.notify_screen_changed()
    for target in (_sampler_loop, _gesture_loop, _touch_loop):
        threading.Thread(target=target, args=(gen,), daemon=True).start()


def stop(flush: bool = False):
    global _listener, _generation, _helper
    listener = _listener
    if flush and listener is not None:
        with _proc_lock:
            try:
                _take_snapshot()
                if _helper_on():
                    _drain_helper_events()
                    node = _helper.request("focused").get("node")
                    if node:   # the field still focused when recording stops: its final value
                        _on_field_event({"event": "field_text", "node": node, "mono": time.monotonic()})
                    _commit_field(close=True)
                else:
                    with _snap_lock:
                        last = _snapshots[-1] if _snapshots else None
                    if last is not None and _prev_nodes is not None:
                        _note_changes(_prev_nodes, last[1], listener.screen_size, time.time())
                _flush_all()
            except Exception:
                pass
    _generation += 1
    if listener is not None:
        listener.stop()
        _write_debug()
    _listener = None
    _reveal_passwords(False)
    if _helper is not None:
        _helper.close()
        _helper = None


def _reveal_passwords(on: bool):
    """Android shows a password field's text to accessibility (the helper, and Appium's page
    source) as dots, unless its "speak passwords" accessibility setting is on. While
    recording with REDACT_SENSITIVE_VALUES off, turn it on so the real value can be
    recorded; put the phone's own setting back afterwards."""
    global _speak_password_before
    if settings.redact_sensitive_values:
        return
    serial = device_serial()
    try:
        if on:
            if _speak_password_before is None:
                _speak_password_before = hc._adb(["shell", "settings", "get", "secure", "speak_password"], serial)
            hc._adb(["shell", "settings", "put", "secure", "speak_password", "1"], serial)
        elif _speak_password_before is not None:
            if _speak_password_before in ("", "null"):
                hc._adb(["shell", "settings", "delete", "secure", "speak_password"], serial)
            else:
                hc._adb(["shell", "settings", "put", "secure", "speak_password", _speak_password_before], serial)
            _speak_password_before = None
    except Exception as e:
        _log(f"couldn't change the phone's speak-passwords setting ({e}) - password values may show as dots")


def _drain_queue(q: "queue.Queue") -> list:
    items = []
    while True:
        try:
            items.append(q.get_nowait())
        except queue.Empty:
            return items


def drain_pending_steps() -> list:
    steps = []
    while True:
        try:
            steps.append(_pending_steps.get_nowait())
        except queue.Empty:
            return steps


def _write_debug():
    """Every touch, the snapshot it was matched against and what was decided - so a
    missing or wrong step can be traced afterwards (like android-record-playback's
    *_debug.json). Typed values are never written here."""
    if not _debug:
        return
    try:
        DEBUG_DIR.mkdir(parents=True, exist_ok=True)
        path = DEBUG_DIR / f"physical_{time.strftime('%Y%m%d_%H%M%S')}.json"
        path.write_text(json.dumps({"nav_buttons": _nav_buttons, "gestures": list(_debug)}, indent=1, default=str),
                        encoding="utf-8")
        _log(f"debug log: recording_debug/{path.name}")
    except OSError:
        pass


def _brief(attrs: Optional[dict]) -> Optional[dict]:
    if attrs is None:
        return None
    keys = ("class", "resource-id", "content-desc", "bounds", "clickable")
    out = {k: attrs.get(k) for k in keys}
    if not mc.is_editable(attrs):
        out["text"] = attrs.get("text")   # never a field's typed value
    return out


# ---------------------------------------------------------------------
# Snapshots
# ---------------------------------------------------------------------

def _take_snapshot():
    t0 = time.time()
    with session.command_lock:
        driver = session.require_driver()
        nodes = mc.parse_page_source(mc.get_page_source(driver))
    with _snap_lock:
        _snapshots.append((t0, nodes))


def _touch_loop(gen: int):
    """At each finger-down: ask the helper what's under the finger right now (before the
    app reacts), and wake the sampler for a snapshot - except for a key on the on-screen
    keyboard, which needs neither (a dump per keystroke would only slow everything)."""
    global _helper_error
    while gen == _generation:
        listener = _listener
        if listener is None:
            time.sleep(0.2)
            continue
        try:
            x, y, t_down = listener.touch_starts.get(timeout=0.3)
        except queue.Empty:
            continue
        hit = None
        if _helper_on():
            try:
                hit = _helper.request("hit", x=x, y=y, timeout=2.0)
            except Exception as e:
                hit = {"error": str(e)}
                if not _helper_on():
                    _helper_error = f"lost the recorder helper ({e}) - using screen snapshots only"
                    _log(_helper_error)
            _hits[round(t_down, 3)] = hit
            if len(_hits) > 300:
                for k in sorted(_hits)[:100]:
                    _hits.pop(k, None)
        if not (hit and hit.get("keyboard")):
            _touch_wake.set()


def _await_hit(t_down: float) -> Optional[dict]:
    key = round(t_down, 3)
    deadline = time.time() + HIT_WAIT_S
    while key not in _hits and time.time() < deadline and _helper_on():
        time.sleep(0.02)
    hit = _hits.pop(key, None)
    return None if hit is None or hit.get("error") else hit


def _sampler_loop(gen: int):
    last = 0.0
    followups: list = []
    while gen == _generation:
        now = time.time()
        if _touch_wake.is_set():
            _touch_wake.clear()
        elif screen_events.resample.is_set() and now - screen_events.last_change() >= SETTLE_S:
            screen_events.resample.clear()
            followups = [now + d for d in FOLLOWUPS_S]
        elif followups and now >= followups[0]:
            followups.pop(0)
        elif now - last < IDLE_REFRESH_S:
            time.sleep(POLL_S)
            continue
        try:
            _take_snapshot()
        except Exception:
            pass
        last = time.time()


def _pick_snapshot(t_down: float, t_up: float):
    """(snapshot or None, approximate). The newest snapshot from before the finger went
    down, if nothing changed the screen since; else the one the touch-down triggered -
    approximate only if even that started after the finger lifted (the app may have
    reacted already)."""
    with _snap_lock:
        snaps = list(_snapshots)
    before = [s for s in snaps if s[0] < t_down]
    if before and not screen_events.changed_between(before[-1][0], t_down):
        return before[-1], False
    after = [s for s in snaps if t_down <= s[0] <= t_down + SNAPSHOT_WAIT_S]
    if after:
        return after[0], after[0][0] > t_up + 0.15
    if before:
        return before[-1], True
    return (snaps[0], True) if snaps else (None, True)


def _await_snapshot_after(t_down: float):
    deadline = time.time() + SNAPSHOT_WAIT_S
    while time.time() < deadline:
        with _snap_lock:
            if any(s[0] >= t_down for s in _snapshots):
                return
        time.sleep(POLL_S)


# ---------------------------------------------------------------------
# Typing (EditText diffs between snapshots)
# ---------------------------------------------------------------------

def _is_junk_target(attrs: dict, screen: dict) -> bool:
    """A tap that resolved to a big non-interactive container: the on-screen
    keyboard (not part of the app's hierarchy, so the app's background is what
    lies under it) or plain empty space - not something to record."""
    if mc._is_actionable(attrs) or mc.is_editable(attrs):
        return False
    b = mc.parse_bounds(attrs.get("bounds", ""))
    if not b:
        return True
    total = (screen.get("width") or 0) * (screen.get("height") or 0)
    return total > 0 and ((b[2] - b[0]) * (b[3] - b[1])) / total > 0.3


def _editable_map(nodes: list) -> dict:
    return {screen_events.field_key(n): n for n in nodes if "EditText" in (n.get("class") or "")}


def _is_reveal(old: str, new: str) -> bool:
    """Show/hide password swaps dots for the real characters (or back): same length,
    nothing typed."""
    return len(old) == len(new) and (set(old) <= MASK_CHARS or set(new) <= MASK_CHARS)


def _masked(value: str) -> bool:
    return bool(value) and set(value) <= MASK_CHARS


def _redacts(key: str, value: str) -> bool:
    """Whether this field's value is recorded as a placeholder instead of the value: when
    the phone only shows dots (there's no value to record), or when REDACT_SENSITIVE_VALUES
    is on and it's a password/PIN/OTP field (a field once seen as sensitive stays so, since
    revealing a password makes it look ordinary)."""
    return _masked(value) or (settings.redact_sensitive_values and key in _sensitive_keys)


def _changed(prev_nodes: list, nodes: list, redacted: bool):
    """(key, node, text) for each EditText whose visible text changed, split by
    whether it's recorded as a placeholder (see _redacts)."""
    prev = _editable_map(prev_nodes)
    for key, n in _editable_map(nodes).items():
        if key in _sensitive_keys or mc.is_sensitive_field(n, nodes):
            _sensitive_keys.add(key)
        old = prev.get(key)
        text = n.get("text") or ""
        if _redacts(key, text) != redacted:
            continue
        old_text = (old.get("text") or "") if old is not None else ""
        if old is None or not text or text == (n.get("hint") or "") or text == old_text or _is_reveal(old_text, text):
            continue
        yield key, n, text


def _note_changes(prev_nodes: list, nodes: list, screen: dict, ts: float):
    """Updates the one pending edit in place while the SAME field keeps changing (so
    five keystrokes become one step, not five) - flushing it first if a DIFFERENT
    field changed instead (moving straight from one field to another with no tap
    landing cleanly in between, which does happen on a fast form). A sensitive field
    goes through the SAME buffering but is flushed as a placeholder with no value at
    all - see _flush_pending_redacted."""
    global _pending_edit, _pending_redacted
    for key, field, text in _changed(prev_nodes, nodes, redacted=False):
        if screen_events.was_typed_by_mirror(key, text):
            continue
        if _pending_redacted is not None and screen_events.field_key(_pending_redacted["field"]) == key:
            _pending_redacted = None   # its real value is readable now (revealed) - record that instead
        if _pending_edit is not None and screen_events.field_key(_pending_edit["field"]) == key:
            _pending_edit.update(field=field, text=text, nodes=nodes, ts=ts, screen=screen)
        else:
            _flush_pending_edit()
            _pending_edit = {"field": field, "text": text, "nodes": nodes, "ts": ts, "screen": screen}
    for key, field, _text in _changed(prev_nodes, nodes, redacted=True):
        if _pending_redacted is not None and screen_events.field_key(_pending_redacted["field"]) == key:
            _pending_redacted.update(field=field, nodes=nodes, ts=ts)
        else:
            _flush_pending_redacted()
            _pending_redacted = {"field": field, "nodes": nodes, "ts": ts}
            _log(f"typing into {mc.field_name(nodes, field, 'a sensitive field')} - its value isn't readable "
                 "(the phone shows dots), so a placeholder step is added; tap its eye icon to record the value.")


def _flush_pending_edit():
    global _pending_edit
    if _pending_edit is None:
        return
    pe, _pending_edit = _pending_edit, None
    _put_typed(pe["field"], pe["text"], pe["nodes"], pe["screen"], pe["ts"])


def _put_typed(field: dict, text: str, nodes: list, screen: dict, ts: float):
    key = screen_events.field_key(field)
    if _last_typed.get(key) == text:
        return   # e.g. the eye icon toggled it back and forth: nothing new was typed
    _last_typed[key] = text
    step = dict(_typed_step(field, text, nodes, screen, ts), field_key=key)   # lets the UI drop this field's placeholder
    _pending_steps.put(step)
    _stats["recorded"] += 1
    _log(f"recorded type: {step['description']}")


def _flush_pending_redacted():
    global _pending_redacted
    if _pending_redacted is None:
        return
    pr, _pending_redacted = _pending_redacted, None
    _put_redacted(pr["field"], pr["nodes"], pr["ts"])


def _put_redacted(field: dict, nodes: list, ts: float):
    key = screen_events.field_key(field)
    if _last_typed.get(key) == _REDACTED:
        return
    _last_typed[key] = _REDACTED
    screen = _listener.screen_size if _listener is not None else {"width": 1080, "height": 2400}
    label = mc.field_name(nodes, field, "a sensitive field")
    locator = mc.extract_locator(field, nodes)
    recording_service._embed_if_ai(_mode, label, "type", locator)
    x_pct, y_pct = _pct(field.get("bounds"), screen)
    step = {
        "action": "type", "description": f"{label} (value not saved - provide it before running)",
        "locator": locator, "x_pct": x_pct, "y_pct": y_pct, "text": "", "redacted": True,
        "field_key": key, "ts": ts, "source": "physical", "approximate": False, "screenshot": None,
    }
    _pending_steps.put(step)
    _stats["recorded"] += 1
    _log(f"recorded a placeholder for a sensitive field ({label}) - no value saved")


def _flush_all():
    """The user moved on from any typing in progress: record it now."""
    _flush_pending_edit()
    _flush_pending_redacted()
    _commit_field(close=False)


# ---------------------------------------------------------------------
# Typing, per the helper (the field's own value, as reported by the phone)
# ---------------------------------------------------------------------

def _wall(mono: float) -> float:
    return time.time() - (time.monotonic() - mono)


def _in_snapshot(attrs: dict, around: Optional[float] = None):
    """(snapshot node, its nodes) for the element the helper reported - the same bounds,
    class, id and description - searching snapshots nearest `around` first. Gives the
    locator/description code the whole screen for context. (None, None) if none has it."""
    with _snap_lock:
        snaps = list(_snapshots)
    if around is not None:
        snaps.sort(key=lambda s: abs(s[0] - around))
    else:
        snaps.reverse()
    editable = mc.is_editable(attrs)
    for _t, nodes in snaps:
        for n in nodes:
            if (n.get("bounds") == attrs.get("bounds") and n.get("class") == attrs.get("class")
                    and (n.get("resource-id") or "") == attrs.get("resource-id")
                    and (n.get("content-desc") or "") == attrs.get("content-desc")
                    and (editable or (n.get("text") or "") == attrs.get("text"))):
                return n, nodes
    return None, None


def _standalone(*attrs_list) -> list:
    """Node list built from helper-reported elements alone (no snapshot had them),
    outermost first, so one inside another counts as its descendant (a card's caption
    inside the card)."""
    nodes = [dict(a) for a in attrs_list if a]
    for i, n in enumerate(nodes):
        n["_i"], n["_end"] = i, len(nodes) - 1
    return nodes


def _drain_helper_events():
    for event in _drain_queue(_helper_events):
        if event.get("event") in ("field_focus", "field_text", "field_blur"):
            _on_field_event(event)


def _on_field_event(event: dict):
    global _field
    node = event.get("node") or {}
    attrs = hc.as_attrs(node)
    key = screen_events.field_key(attrs)
    value = node.get("value") or ""
    if node.get("password"):
        _sensitive_keys.add(key)
    kind = event["event"]
    if kind == "field_focus":
        _commit_field(close=True)
        _field = {"key": key, "attrs": attrs, "original": value, "value": value, "ts": _wall(event["mono"])}
    elif kind == "field_text":
        if _field is not None and _field["key"] == key:
            _field.update(attrs=attrs, value=value)
    elif kind == "field_blur":
        if _field is None or _field["key"] != key:
            _commit_field(close=True)
            _field = {"key": key, "attrs": attrs, "original": event.get("original") or "", "ts": _wall(event["mono"])}
        _field.update(attrs=attrs, value=value)
        _commit_field(close=True)


def _commit_field(close: bool):
    """Record the focused field's typing, if its value changed. close=False keeps
    tracking it (the user tapped elsewhere but focus stayed): later typing in the same
    field becomes another step."""
    global _field
    f = _field
    if f is None:
        return
    if close:
        _field = None
    value, original = f["value"], f["original"]
    if value == original:
        return
    f["original"] = value
    key, attrs = f["key"], f["attrs"]
    node, nodes = _in_snapshot(attrs, f["ts"])
    if node is None:
        nodes = _standalone(attrs)
        node = nodes[0]
    if key in _sensitive_keys or mc.is_sensitive_field(node, nodes):
        _sensitive_keys.add(key)
    if _redacts(key, value):
        _put_redacted(node, nodes, f["ts"])
        return
    if screen_events.was_typed_by_mirror(key, value):
        return
    screen = _listener.screen_size if _listener is not None else {"width": 1080, "height": 2400}
    _put_typed(node, value, nodes, screen, f["ts"])


# ---------------------------------------------------------------------
# Steps
# ---------------------------------------------------------------------

def _pct(bounds_str: str, screen: dict):
    b = mc.parse_bounds(bounds_str or "") or (0, 0, 0, 0)
    w, h = screen.get("width") or 1, screen.get("height") or 1
    return round(((b[0] + b[2]) / 2) / w, 4), round(((b[1] + b[3]) / 2) / h, 4)


def _at(g, screen: dict) -> dict:
    return {"x_pct": round(g.x1 / (screen["width"] or 1), 4), "y_pct": round(g.y1 / (screen["height"] or 1), 4)}


def _typed_step(field: dict, text: str, nodes: list, screen: dict, ts: float) -> dict:
    locator = mc.extract_locator(field, nodes)
    # Named after the field, not what it holds (the value is the step's text; a snapshot's
    # copy of it may be out of date anyway).
    description = asyncio.run(recording_service._describe(dict(field, text=""), nodes, _mode))
    recording_service._embed_if_ai(_mode, description, "type", locator)
    x_pct, y_pct = _pct(field.get("bounds"), screen)
    return {"action": "type", "description": description, "locator": locator, "x_pct": x_pct, "y_pct": y_pct,
            "text": text, "ts": ts, "source": "physical", "approximate": False, "screenshot": None}


async def _tap_step(g, attrs: dict, nodes: list, screen: dict, approximate: bool) -> dict:
    locator = mc.extract_locator(attrs, nodes, point=(g.x1, g.y1), screen=screen)
    description = await recording_service._describe(attrs, nodes, _mode)
    recording_service._embed_if_ai(_mode, description, "tap", locator)
    return {
        "action": "tap", "description": description, "locator": locator, **_at(g, screen),
        "is_editable": mc.is_editable(attrs), "checked_target": mc.desired_checked_state(attrs, nodes),
        "ts": g.t_down, "source": "physical", "approximate": approximate, "screenshot": None,
    }


def _icon_step(g, attrs: dict, nodes: list, screen: dict, approximate: bool) -> dict:
    locator = dict(mc.extract_locator(attrs, nodes), tap_offset=mc.offset_from_center(attrs, (g.x1, g.y1), screen))
    description = mc.field_icon_description(nodes, attrs)
    recording_service._embed_if_ai(_mode, description, "tap", locator)
    return {"action": "tap", "description": description, "locator": locator, **_at(g, screen),
            "ts": g.t_down, "source": "physical", "approximate": approximate, "screenshot": None}


def _anchored_step(g, locator: dict, screen: dict, approximate: bool) -> dict:
    description = locator.get("text") or locator.get("content_desc") or "tapped element"
    recording_service._embed_if_ai(_mode, description, "tap", locator)
    return {"action": "tap", "description": description, "locator": locator, **_at(g, screen),
            "ts": g.t_down, "source": "physical", "approximate": approximate, "screenshot": None}


def _key_step(g, key: str) -> dict:
    description = f"Press {key}"
    recording_service._embed_if_ai(_mode, description, "key", {})
    return {"action": "key", "description": description, "locator": {}, "text": key,
            "ts": g.t_down, "source": "physical", "approximate": False, "screenshot": None}


def _swipe_step(g, screen: dict) -> dict:
    direction = recording_service._infer_direction(g.x2 - g.x1, g.y2 - g.y1)
    description = f"Swipe {direction}"
    recording_service._embed_if_ai(_mode, description, "swipe", {})
    return {
        "action": "swipe", "description": description, "locator": {}, **_at(g, screen),
        "x2_pct": round(g.x2 / (screen["width"] or 1), 4), "y2_pct": round(g.y2 / (screen["height"] or 1), 4),
        "text": direction, "ts": g.t_down, "source": "physical", "approximate": False, "screenshot": None,
    }


def _gesture_loop(gen: int):
    while gen == _generation:
        listener = _listener
        if listener is None:
            time.sleep(0.2)
            continue
        try:
            gesture = listener.gestures.get(timeout=0.3)
        except queue.Empty:
            try:
                with _proc_lock:
                    _drain_helper_events()   # typing is recorded between touches too
            except Exception as e:
                _log(f"error handling a field event: {e}")
            continue
        try:
            with _proc_lock:
                _drain_helper_events()
                _process_gesture(gesture)
        except Exception as e:  # one bad gesture must never kill the loop
            _stats["skipped"] += 1
            _log(f"error handling a touch: {e}")


def _element_from_hit(hit: dict, screen: dict) -> Optional[dict]:
    """What the touch operated, from the helper's answer - the same rules as for a
    snapshot (mc.choose_target): the smallest element under the finger, or the clickable
    one around it."""
    node, target = hc.as_attrs(hit.get("node")), hc.as_attrs(hit.get("target"))
    if node is not None and target is not None and node["bounds"] == target["bounds"]:
        target = node
    return mc.choose_target(node, target, (screen.get("width") or 0) * (screen.get("height") or 0))


def _nav_from_hit(hit: dict) -> Optional[str]:
    if ((hit.get("window") or {}).get("type")) != "system":
        return None
    for n in (hit.get("target"), hit.get("node")):
        if n:
            key = mc.nav_key_for(n.get("resource_id"), n.get("content_desc"))
            if key:
                return key
    return None


def _brief_hit(hit: Optional[dict]) -> Optional[dict]:
    if hit is None:
        return None
    window = hit.get("window") or {}
    return {"window": window.get("type"), "keyboard": bool(hit.get("keyboard")),
            "node": _brief(hc.as_attrs(hit.get("node"))), "target": _brief(hc.as_attrs(hit.get("target")))}


def _process_gesture(g: "pt.PhysicalGesture"):
    global _prev_nodes, _prev_snap_t
    _stats["seen"] += 1
    listener = _listener
    screen = listener.screen_size if listener is not None else {"width": 1080, "height": 2400}
    t_up = g.t_down + g.duration_s
    hit = _await_hit(g.t_down) if _helper_on() else None
    rec = {"t_down": round(g.t_down, 3), "kind": g.kind, "at": [g.x1, g.y1], "to": [g.x2, g.y2],
           "helper": _brief_hit(hit)}
    out = []

    nav_key = None
    if g.kind != "swipe":
        nav_key = (_nav_from_hit(hit) if hit else None) or mc.nav_button_at(_nav_buttons, g.x1, g.y1)
    if hit and hit.get("keyboard") and not nav_key:
        # A key on the on-screen keyboard (or a swipe-typed word): the typing itself comes
        # from the field (see _on_field_event), never from the keys.
        _stats["skipped"] += 1
        rec["decision"] = "on-screen keyboard"
        _debug.append(rec)
        return

    snap, approximate = _pick_snapshot(g.t_down, t_up)
    element = _element_from_hit(hit, screen) if hit and not nav_key else None
    if element is not None:
        # The helper named the element exactly; a snapshot only adds context around it.
        attrs, nodes = _in_snapshot(element, g.t_down)
        if attrs is None:
            _await_snapshot_after(g.t_down)
            attrs, nodes = _in_snapshot(element, g.t_down)
        rec["in_snapshot"] = attrs is not None
        if attrs is None:
            # No snapshot shows it (the screen moved on too fast): the helper's own answer
            # is still exact - use it alone, with the text under the finger as its label.
            outer, inner = hc.as_attrs(hit.get("target")), hc.as_attrs(hit.get("node"))
            if outer and inner and element["bounds"] == outer["bounds"] and inner["bounds"] != outer["bounds"]:
                nodes = _standalone(element, inner)
            else:
                nodes = _standalone(element)
            attrs = nodes[0]
        approximate = False
    else:
        if approximate:
            _await_snapshot_after(g.t_down)   # its own touch-down read may still be in flight
            snap, approximate = _pick_snapshot(g.t_down, t_up)
        nodes = snap[1] if snap else None
        attrs = mc.pick_attrs_at_point(nodes, g.x1, g.y1) if nodes is not None else None
        rec["snapshot_age_s"] = round(g.t_down - snap[0], 3) if snap else None
        if not _helper_on() and nodes is not None and snap[0] > _prev_snap_t:
            if _prev_nodes is not None:
                _note_changes(_prev_nodes, nodes, screen, g.t_down - 0.001)
            _prev_nodes, _prev_snap_t = nodes, snap[0]
    rec["approximate"] = approximate

    if nav_key:
        _flush_all()
        if nav_key in ("back", "home"):
            out.append(_key_step(g, nav_key))
            decision = f"navigation bar: {nav_key}"
        else:
            _stats["skipped"] += 1
            decision = f"navigation bar: {nav_key} - not recorded"
            _log(f"tap on the nav bar's {nav_key} button - not recorded")
    elif g.kind == "swipe":
        _flush_all()
        out.append(_swipe_step(g, screen))  # a swipe needs no element - it's never skipped
        decision = "swipe"
    elif nodes is None:
        _stats["skipped"] += 1
        decision = "skipped: no snapshot yet"
        _log(f"tap at ({g.x1},{g.y1}) skipped: no screen snapshot available yet")
    else:
        rec["picked"] = _brief(attrs)
        field = mc.field_icon_at(nodes, attrs, g.x1, g.y1)
        if field is not None:
            _flush_all()
            out.append(_icon_step(g, field, nodes, screen, approximate))
            decision = "text field icon"
        elif attrs is None or _is_junk_target(attrs, screen):
            # Without the helper a keyboard key looks exactly like a touch on the app content
            # beneath it - so no anchoring while typing. The helper tells keys apart for sure.
            typing = _pending_edit is not None or _pending_redacted is not None
            maybe_keyboard = hit is None and (typing or mc.keyboard_likely(nodes, screen, g.y1))
            locator = None if maybe_keyboard else mc.anchored_tap_locator(nodes, (g.x1, g.y1), screen)
            if locator:
                _flush_all()
                out.append(_anchored_step(g, locator, screen, approximate))
                decision = "no element of its own - anchored to a nearby label"
            else:
                _stats["skipped"] += 1
                decision = "skipped: keyboard or empty area"
                _log(f"tap at ({g.x1},{g.y1}) skipped: nothing tappable there (on-screen keyboard or empty area)")
                # No flush here: a skipped touch (almost always a keyboard key) can't be told apart
                # from "still typing into the pending field" - only a REAL tap elsewhere proves that.
        else:
            key = screen_events.field_key(attrs)
            same_field = (
                (_pending_edit is not None and screen_events.field_key(_pending_edit["field"]) == key)
                or (_pending_redacted is not None and screen_events.field_key(_pending_redacted["field"]) == key)
                or (_field is not None and _field["key"] == key)
            )
            if not same_field:
                _flush_all()
                out.append(asyncio.run(_tap_step(g, attrs, nodes, screen, approximate)))
                decision = "tap"
            else:
                # tapping back into the field already being edited (e.g. to move the
                # cursor) - not a new step; the pending edit already covers it.
                decision = "same field as the typing in progress - not a new step"

    if out and not session.mjpeg_active:
        try:
            with session.command_lock:
                out[-1]["screenshot"] = mc.get_screenshot_b64(session.require_driver())
        except Exception:
            pass
    for step in out:
        _pending_steps.put(step)
        _log(f"recorded {step['action']}: {step['description']}" + (" (approximate)" if step.get("approximate") else ""))
    _stats["recorded"] += len(out)
    if out:
        screen_events.notify_screen_changed(at=g.t_down)
    rec["decision"] = decision
    rec["steps"] = [s["description"] for s in out]
    _debug.append(rec)
