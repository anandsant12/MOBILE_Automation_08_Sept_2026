"""
Waiting for the app's screen to be ready before a step acts on it.

Consecutive screens often share elements (a header's Back and Home), so "the element is
there" doesn't mean the new screen is ready - a tap while it's still opening or loading is
ignored by the app (it's how Home got tapped mid-transition and missed). So before each
action step replay waits until:

  - the recorder helper on the phone reports no change on screen for SETTLE_QUIET_MS
    (its "quiet" command; a ticking clock doesn't count), at most SETTLE_MAX seconds, and
  - no loading indicator is showing, at most LOADING_MAX seconds.

Without the helper (not installed, too old, not running) only loading indicators are looked
for, through Appium. A run never installs or starts the helper. Best effort: nothing here
ever fails a step. Adapted from android-record-playback's appium_playback._ScreenSettle.
"""

import time
from typing import Optional

from selenium.webdriver.common.by import By

from app.arp import helper_client as arp_helper
from app.automation.helper_client import HelperClient
from app.automation.physical_touch import resolve_adb

from config import settings as _settings

SETTLE_QUIET_MS = 250      # no change on screen for this long
SETTLE_MAX = 6.0           # ...waited for at most this long
# A loading indicator is waited out for at most this long (LOADING_MAX_SECONDS in .env). Some
# screens reload data after a choice (e.g. picking a date reloads the leave form) and take a while.
LOADING_MAX = float(getattr(_settings, "loading_max_seconds", 30.0))
SETTLE_STEPS = ("tap", "long_press", "type", "select", "keypad", "swipe", "pick_date")
_LOADING_XPATH = (
    "//*[@class='android.widget.ProgressBar'"
    " or contains(translate(@text, 'LOADING', 'loading'), 'loading')"
    " or contains(translate(@content-desc, 'LOADING', 'loading'), 'loading')"
    " or contains(translate(@text, 'PLEASE WAIT', 'please wait'), 'please wait')"
    " or contains(translate(@content-desc, 'PLEASE WAIT', 'please wait'), 'please wait')"
    " or contains(@content-desc, 'in progress')]"
)


def needs_settle(steps: list, i: int) -> bool:
    """Whether step i acts on the screen (so waits for it) - not typing into the field the
    step before just tapped: there's nothing to wait for."""
    step = steps[i]
    if i == 0 or step["action"] not in SETTLE_STEPS:
        return False
    return not (steps[i - 1]["action"] == "tap" and step["action"] in ("type", "keypad"))


class ScreenSettle:
    def __init__(self, serial: Optional[str], lock=None):
        self.client = None
        self.lock = lock   # held only around Appium reads - the helper's answers need no driver
        self.permanent = set()   # indicators that never went away (a progress bar in the design)
        try:
            adb = resolve_adb()
            # Only a helper that's already installed, current and running.
            if (arp_helper.socket_listening(serial, adb)
                    and (arp_helper.installed_version(serial, adb) or 0) >= arp_helper.bundled_version()):
                self.client = HelperClient(serial).connect()
                self.client.request("quiet")
        except Exception:
            self.close()

    @property
    def uses_helper(self) -> bool:
        return self.client is not None

    def _loading(self, driver) -> list:
        if self.lock is not None:
            with self.lock:   # Appium takes one command at a time (see session_manager.command_lock)
                return self._read_loading(driver)
        return self._read_loading(driver)

    def _read_loading(self, driver) -> list:
        found = []
        try:
            for el in driver.find_elements(By.XPATH, _LOADING_XPATH):
                label = (el.get_attribute("content-desc") or "") + " " + (el.text or "")
                if len(label.strip()) > 40 or not el.is_displayed():
                    continue   # a sentence that mentions loading, not an indicator
                key = (el.get_attribute("className") or el.tag_name, str(el.rect), label.strip())
                if key not in self.permanent:
                    found.append(key)
        except Exception:
            return []
        return found

    def wait(self, driver, should_stop=None) -> float:
        """Seconds spent waiting for the screen to be ready."""
        started = time.monotonic()
        if self.client is not None:
            # One quick request answers both: has the screen been still, and is it loading.
            deadline, loading_deadline = started + SETTLE_MAX, started + LOADING_MAX
            try:
                while not (should_stop and should_stop()):
                    state = self.client.request("quiet")
                    quiet = state.get("quiet_ms", 10 ** 9) >= SETTLE_QUIET_MS
                    busy = bool(state.get("busy")) and time.monotonic() < loading_deadline
                    if (quiet or time.monotonic() >= deadline) and not busy:
                        break
                    time.sleep(0.05)
                return time.monotonic() - started
            except Exception:   # fall back to looking for indicators through Appium
                self.close()
        loading = self._loading(driver)
        deadline = time.monotonic() + LOADING_MAX
        while loading and time.monotonic() < deadline and not (should_stop and should_stop()):
            time.sleep(0.3)
            loading = self._loading(driver)
        self.permanent.update(loading)   # still there after the limit: part of the screen, not loading
        return time.monotonic() - started

    def close(self):
        if self.client is not None:
            try:
                self.client.close()
            except Exception:
                pass
        self.client = None
