"""
Tiny shared state between mirror-driven recording and physical-touch capture.

Both need to know "the screen just changed" (so a fresh hierarchy snapshot
gets taken once it settles) and "this text was typed by the mirror" (so the
physical side doesn't record the same typing a second time).
"""

import threading
import time
from collections import deque
from typing import Optional

resample = threading.Event()  # set => take a fresh screen snapshot soon
_last_change = 0.0
_changes: deque = deque(maxlen=64)
_mirror_typed: dict = {}


def notify_screen_changed(at: Optional[float] = None):
    global _last_change
    t = at if at is not None else time.time()
    _last_change = max(_last_change, t)
    _changes.append(t)
    resample.set()


def last_change() -> float:
    return _last_change


def changed_between(start: float, end: float) -> bool:
    """Whether anything changed the screen after `start` and before `end`."""
    return any(start < t < end for t in list(_changes))


def field_key(attrs: dict) -> str:
    return attrs.get("resource-id") or attrs.get("bounds") or ""


def note_mirror_typed(attrs: dict, text: str):
    _mirror_typed[(field_key(attrs), text)] = time.time()


def was_typed_by_mirror(key: str, text: str, within: float = 60.0) -> bool:
    stamp = _mirror_typed.get((key, text))
    return stamp is not None and time.time() - stamp < within
