"""
Scenarios and run results in formats other tools read:

  - junit_xml(): a run (or several) as JUnit XML, for CI systems (Jenkins, GitHub
    Actions, GitLab, Azure DevOps);
  - pytest_script(): a scenario as a standalone pytest + Appium-Python-Client test,
    to run or extend in any Appium setup;
  - scenario_json() / import_scenario(): a scenario as a portable JSON file, to share
    it or keep it in version control.

The XML and pytest code come from app/arp/export.py (android-record-playback);
this module turns this app's steps and runs into the shape it expects.
"""

import re
from typing import Optional

from config import settings

from app.arp import export as arp_export
from app.automation import mobile_control as mc

FORMAT = "mobile-automation-scenario"
FORMAT_VERSION = 1


# ---------------------------------------------------------------------
# JUnit XML
# ---------------------------------------------------------------------

def _run_result(name: str, run: dict) -> dict:
    """One run (runs_registry.Run.to_dict) as export.junit_xml's result shape."""
    report = []
    failure = run.get("failure") or {}
    for entry in run.get("log") or []:
        if entry.get("order_index") is None:
            continue   # a run-level error, reported below
        status = "failed" if entry.get("status") == "error" else "skipped" if entry.get("skipped") else "passed"
        error = entry.get("error")
        if error and entry.get("failure_kind") and failure:
            # Why it failed: the app (crashed, froze, closed), the test, or the phone / session.
            error = f"[{failure.get('group')} problem: {failure.get('summary')}] {error}"
        report.append({
            "index": entry["order_index"] + 1 if entry["order_index"] >= 0 else 0,
            "label": entry.get("description") or entry.get("action") or "step",
            "status": status, "error": error, "healed": bool(entry.get("healed")),
            "method": entry.get("found_by") or entry.get("note") or "",
        })
    run_error = next((e.get("error") for e in run.get("log") or [] if e.get("order_index") is None and e.get("error")),
                     None)
    status = {"passed": "passed", "failed": "failed"}.get(run.get("status"), "error")
    if status == "failed" and run_error and not any(r["status"] == "failed" for r in report):
        status = "error"   # never got to a step (no phone, no session)
    elapsed = sum(e.get("duration") or 0 for e in run.get("log") or [])
    error = run_error or ("the run was stopped" if run.get("status") == "stopped" else
                          "the run hasn't finished" if run.get("status") == "running" else None)
    return {"name": name, "status": status, "elapsed": elapsed, "report": report, "error": error}


def junit_xml(runs: list, suite_name: str = "mobile-automation") -> str:
    """`runs`: [(scenario name, run dict)]."""
    return arp_export.junit_xml([_run_result(name, run) for name, run in runs], suite_name)


# ---------------------------------------------------------------------
# pytest + Appium-Python-Client
# ---------------------------------------------------------------------

# Added to export.py's helpers: this app keeps positions as fractions of the screen.
_HELPERS = '''

def tap_frac(driver, fx, fy, ms=None):
    """Tap a spot given as fractions of the screen (a step recorded without an element)."""
    size = driver.get_window_size()
    point = [(round(fx * size["width"]), round(fy * size["height"]))]
    driver.tap(point, ms) if ms else driver.tap(point)


def swipe_frac(driver, x1, y1, x2, y2, ms=400):
    size = driver.get_window_size()
    w, h = size["width"], size["height"]
    driver.swipe(round(x1 * w), round(y1 * h), round(x2 * w), round(y2 * h), ms)


def tap_beside(driver, el, dx, dy):
    """Tap beside an element (the icon its label captions), dx/dy as fractions of the screen."""
    size = driver.get_window_size()
    r = el.rect
    driver.tap([(round(r["x"] + r["width"] / 2 + dx * size["width"]),
                 round(r["y"] + r["height"] / 2 + dy * size["height"]))])


def _norm(text, mode):
    """A captured value as it's kept: raw / trim spaces / digits only / number (no commas, no currency)."""
    import re
    text = text or ""
    if mode == "trim":
        return " ".join(text.split())
    if mode == "digits":
        return re.sub(r"\\D", "", text)
    if mode == "number":
        m = re.search(r"-?\\d[\\d,]*(?:\\.\\d+)?", text)
        return m.group(0).replace(",", "") if m else ""
    return text

'''

_KEYS = {"back": "BACK", "home": "HOME", "enter": "ENTER", "recents": "APP_SWITCH", "menu": "MENU",
         "volume_up": "VOLUME_UP", "volume_down": "VOLUME_DOWN", "power": "POWER"}
_WEB_CHECKS = ("visible", "not_visible", "text_equals", "text_contains", "text_matches")


def _lit(value: str) -> str:
    return mc._xpath_literal(value)


def candidates(locator: dict) -> list:
    """This app's ways of finding an element (mobile_control.locator_strategies) as Appium
    (strategy, value) pairs, in the order replay tries them."""
    out = []
    for s in mc.locator_strategies(locator):
        strategy, value, index = s["strategy"], s["value"], s["index"]
        if strategy in ("content-desc", "text"):
            strategy, value = "xpath", f"//*[@{strategy}={_lit(value)}]"
        elif strategy == "id" and ":id/" not in value:
            # Appium's "id" only matches package-qualified ids; a web page's bare HTML id needs xpath.
            strategy, value = "xpath", f"//*[@resource-id={_lit(value)}]"
        if index:   # the n-th of several sharing it (list rows)
            if strategy == "id":
                value = f"//*[@resource-id={_lit(value)}]"
            elif strategy == "accessibility id":
                value = f"//*[@content-desc={_lit(value)}]"
            strategy, value = "xpath", f"({value})[{index + 1}]"
        if (strategy, value) not in out:
            out.append((strategy, value))
    return out


def _timeout() -> float:
    return max(float(settings.step_wait_seconds), 5.0)


def _step_lines(step: dict, n: int) -> list:
    action, locator = step["action"], step.get("locator") or {}
    cands = candidates(locator)
    web = locator.get("web")
    text = step.get("text") or ""
    label = step.get("description") or action
    timeout = _timeout()
    theirs = {"index": n, "label": label, "timeout": timeout, "optional": step.get("optional")}

    if action in ("tap", "long_press"):
        if web and web.get("css"):
            # Recorded on the app's web page: found by the page's own locator, as replay does.
            return arp_export._step_code(dict(theirs, type=action, web=web))
        if cands and locator.get("tap_offset") and action == "tap":
            offset = locator["tap_offset"]
            return [f"tap_beside(driver, find(driver, {_cands(cands)}, {timeout:g}), "
                    f"{offset.get('dx', 0)}, {offset.get('dy', 0)})"]
        if cands:
            # (A checkbox / switch with checked_target is tapped only if it isn't already that way.)
            return arp_export._step_code(dict(theirs, type=action, locator={"candidates": cands},
                                              tap_at=locator.get("tap_at"), checked_target=step.get("checked_target")))
        ms = ", 1000" if action == "long_press" else ""
        return [f"tap_frac(driver, {step.get('x_pct') or 0}, {step.get('y_pct') or 0}{ms})  # no element was recorded"]
    if action == "type":
        if step.get("redacted"):
            # Never saved: read from an environment variable when the test runs.
            text = f"${{env:STEP_{n}_VALUE}}"
        if not cands:
            return [f"tap_frac(driver, {step.get('x_pct') or 0}, {step.get('y_pct') or 0})",
                    f"driver.execute_script('mobile: type', {{'text': {arp_export._data_expr(text)}}})"]
        return arp_export._step_code(dict(theirs, type="type", locator={"candidates": cands}, text=text))
    if action == "select":
        return arp_export._step_code(dict(theirs, type="select", locator={"candidates": cands}, option=text))
    if action == "keypad":
        loc = {"candidates": cands, "resource_id": locator.get("resource_id")} if cands else None
        return arp_export._step_code(dict(theirs, type="keypad", locator=loc, text=text))
    if action == "pick_date":
        return arp_export._step_code(dict(theirs, type="pick_date", locator={"candidates": cands} if cands else None,
                                          date=text))
    if action == "key":
        return arp_export._step_code(dict(theirs, type="key", key=_KEYS.get(text, "BACK")))
    if action == "wait":
        try:
            seconds = max(0.0, float(text))
        except ValueError:
            seconds = 1.0
        return arp_export._step_code(dict(theirs, type="wait", seconds=seconds))
    if action == "swipe":
        x1, y1, x2, y2 = (step.get(k) for k in ("x_pct", "y_pct", "x2_pct", "y2_pct"))
        if None in (x1, y1, x2, y2):
            x1, y1, x2, y2 = {"up": (0.5, 0.7, 0.5, 0.3), "down": (0.5, 0.3, 0.5, 0.7),
                              "left": (0.8, 0.5, 0.2, 0.5), "right": (0.2, 0.5, 0.8, 0.5)}.get(text, (0.5, 0.7, 0.5, 0.3))
        return [f"swipe_frac(driver, {x1}, {y1}, {x2}, {y2})"]
    if action == "assert":
        return _check_lines(step, theirs, cands, web, text)
    if action == "capture":
        var = (step.get("var") or "value").strip()
        if not cands:
            return [f"# not exported (no element recorded): {label}"]
        mode = step.get("normalize") or "raw"
        getter = f"text_of(find(driver, {_cands(cands)}, {timeout:g}))"
        return [f"DATA[{var!r}] = _norm({getter}, {mode!r})  # remembered; used as ${{{var}}} below"]
    return [f"# unsupported step: {label}"]


def _check_lines(step: dict, theirs: dict, cands: list, web: Optional[dict], expected: str) -> list:
    check = step.get("check") or "visible"
    timeout, msg = theirs["timeout"], repr(theirs["label"])
    exp = arp_export._data_expr(expected)
    if check in mc.SCREEN_CHECKS:
        condition = {
            "screen_has_text": f"{exp}.lower() in driver.page_source.lower()",
            "screen_lacks_text": f"{exp}.lower() not in driver.page_source.lower()",
            "toast": f"any({exp}.lower() in (t.text or '').lower() "
                     "for t in driver.find_elements(AppiumBy.XPATH, '//android.widget.Toast'))",
            "keyboard_shown": "driver.is_keyboard_shown()",
            "keyboard_hidden": "not driver.is_keyboard_shown()",
            "on_screen": f"driver.current_activity.lower().endswith({exp}.split('/')[-1].lstrip('.').lower())",
        }.get(check)
        if condition is None:
            return [f"# not exported (no Appium equivalent): {theirs['label']}"]
        return [f"expect(lambda: {condition}, {timeout:g}, {msg})"]
    if web and web.get("css") and check in _WEB_CHECKS:
        return arp_export._step_code(dict(theirs, type="assert", web=web, check=check, expected=expected))
    if not cands:
        return [f"# not exported (no element recorded): {theirs['label']}"]
    if check == "text_contains":   # this app compares case-insensitively
        getter = f"find(driver, {_cands(cands)}, 1)"
        return [f"expect(lambda: plain({exp}).lower() in plain(text_of({getter})).lower(), {timeout:g}, {msg})"]
    return arp_export._step_code(dict(theirs, type="assert", locator={"candidates": cands}, check=check,
                                      expected=expected))


def _cands(cands: list) -> str:
    """Python for a candidates list - with test data in a locator (an account picked as
    ${account}) filled in from DATA / the environment when the test runs."""
    return arp_export._cands({"candidates": cands})


def pytest_script(scenario: dict, serial: Optional[str] = None) -> tuple:
    """(file name, code) of a pytest test doing what the scenario does. Steps that run another
    scenario (a reusable flow) are written out in place, with its test data."""
    from app.services.scenario_service import expand_steps   # avoid an import cycle
    func = re.sub(r"\W+", "_", scenario["name"]).strip("_").lower() or "recorded"
    filename = f"test_{func}.py"
    steps, called_data = expand_steps(scenario.get("steps") or [], (scenario.get("id"),))
    scenario = dict(scenario, steps=steps, variables={**called_data, **(scenario.get("variables") or {})})
    preamble = arp_export._PREAMBLE.format(
        title=scenario["name"], filename=filename, serial=serial, variables=scenario.get("variables") or {},
        func=func)
    preamble = preamble.replace("\n\ndef test_", _HELPERS + "\ndef test_", 1)
    preamble = preamble.replace("Exported from android-record-playback.", "Exported from the mobile automation tool.")
    out = [preamble]
    package = scenario.get("android_app_package")
    if package:
        out.append(f"    driver.activate_app({package!r})")
    body_lines = 0
    for i, step in enumerate(scenario.get("steps") or []):
        n = i + 1
        if step.get("disabled"):
            out.append(f"    # {n}. (disabled) {step.get('description') or step['action']}")
            continue
        out.append(f"    # {n}. {step.get('description') or step['action']}")
        body = _step_lines(step, n)
        cands = candidates(step.get("locator") or {})
        if step.get("optional") and cands and step["action"] != "assert":
            out.append(f"    if _present(driver, {_cands(cands)}, 5):  # optional step")
            out += [f"        {line}" for line in body]
        elif step.get("continue_on_failure"):
            out.append("    try:")
            out += [f"        {line}" for line in body]
            out.append("    except AssertionError as exc:")
            out.append("        print(f'continuing after failure: {exc}')")
        else:
            out += [f"    {line}" for line in body]
        body_lines += 1
    if not body_lines and not package:
        out.append("    pass")
    return filename, "\n".join(out) + "\n"


# ---------------------------------------------------------------------
# Portable JSON
# ---------------------------------------------------------------------

_STEP_FIELDS = ("action", "description", "locator", "x_pct", "y_pct", "x2_pct", "y2_pct", "text",
                "checked_target", "redacted", "check", "var", "normalize", "optional",
                "continue_on_failure", "disabled")


def scenario_json(scenario: dict) -> dict:
    return {
        "format": FORMAT, "version": FORMAT_VERSION,
        "name": scenario["name"], "mode": scenario.get("mode") or "basic",
        "android_app_package": scenario.get("android_app_package") or "",
        "android_app_activity": scenario.get("android_app_activity") or "",
        "variables": scenario.get("variables") or {},
        "steps": [{k: step.get(k) for k in _STEP_FIELDS if step.get(k) not in (None, {}, "")}
                  for step in scenario.get("steps") or []],
    }


def parse_scenario_json(data: dict) -> dict:
    """Checks an imported file and returns it ready for scenario_service.save_scenario."""
    if not isinstance(data, dict) or data.get("format") != FORMAT:
        raise ValueError("This isn't a scenario file exported from this tool.")
    if int(data.get("version") or 0) > FORMAT_VERSION:
        raise ValueError("This scenario file is from a newer version of the tool - update it first.")
    steps = data.get("steps")
    if not isinstance(steps, list):
        raise ValueError("The scenario file has no steps list.")
    clean = []
    for i, step in enumerate(steps):
        if not isinstance(step, dict) or not step.get("action"):
            raise ValueError(f"Step {i + 1} in the file has no action.")
        clean.append({k: step.get(k) for k in _STEP_FIELDS})
    return {"name": str(data.get("name") or "Imported scenario").strip(), "mode": data.get("mode") or "basic",
            "android_app_package": data.get("android_app_package") or "",
            "android_app_activity": data.get("android_app_activity") or "",
            "variables": data.get("variables") or {}, "steps": clean}
