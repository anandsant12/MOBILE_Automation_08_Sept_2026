"""
Why a run failed - so a tester knows at once whether to report a bug in the app, fix the test,
or look at the phone / setup:

  app          app_crashed         the app crashed (Android's crash log, or its "keeps stopping" dialog)
               app_not_responding  the app froze ("isn't responding" / an ANR in Android's log)
               app_closed          the app isn't in front any more (it closed, or another app opened)
  test         check_failed        a check didn't hold: the app showed something other than expected
               element_not_found   an element a step needs wasn't on screen (the screen changed, or the
                                   test's locator broke)
               test_data           a ${value} the step uses has no value
  environment  environment         the phone or the Appium session went away, or the app couldn't start

Android's log is read only for the time since the run started (adb logcat -T), never cleared.
"""

import re
import subprocess
import time
from typing import Optional

from app.automation import mobile_control as mc
from app.automation.physical_touch import resolve_adb
from app.automation.session_manager import is_dead_session_error

GROUPS = {
    "app_crashed": "app", "app_not_responding": "app", "app_closed": "app",
    "check_failed": "test", "element_not_found": "test", "test_data": "test",
    "environment": "environment", "error": "test",
}

_ENVIRONMENT = re.compile(
    r"device .*(not found|offline|unauthorized)|no devices|adb.*(not found|failed)|could not proxy|"
    r"connection refused|max retries exceeded|session is either terminated|instrumentation process|"
    r"cannot start the .* application|activity class .* does not exist|appium server|"
    r"isn't reachable|not installed", re.I)
# Android's own "app keeps stopping" / "app isn't responding" dialogs.
_CRASH_DIALOG = re.compile(r'resource-id="android:id/aerr_(close|restart|app_info|mute)"')
_ANR_DIALOG = re.compile(r'resource-id="android:id/aerr_wait"')
# Windows of the system that can be in front of the app without it having closed.
_SYSTEM_PACKAGES = ("com.android.permissioncontroller", "com.google.android.permissioncontroller",
                    "com.android.systemui", "com.android.packageinstaller", "android")


def _adb(args: list, serial: Optional[str], timeout: float = 8.0) -> str:
    try:
        cmd = [resolve_adb()] + (["-s", serial] if serial else []) + args
        return subprocess.run(cmd, capture_output=True, text=True, timeout=timeout,
                              encoding="utf-8", errors="replace").stdout or ""
    except Exception:
        return ""


def device_time(serial: Optional[str]) -> Optional[float]:
    """The phone's clock (epoch seconds) - where to read its log from later. None if unknown."""
    out = _adb(["shell", "date", "+%s"], serial, timeout=5).strip()
    return float(out) if out.isdigit() else None


def _log_since(serial: Optional[str], since: Optional[float]) -> str:
    if since is None:
        return ""
    return _adb(["logcat", "-d", "-b", "crash,system,main", "-v", "brief", "-T", f"{since:.3f}"], serial, timeout=10)


def _crash_in_log(log: str, package: str) -> Optional[tuple]:
    """(kind, detail) for a crash or ANR of `package` in Android's log, else None."""
    if not package:
        return None
    lines = log.splitlines()
    for i, line in enumerate(lines):
        if "FATAL EXCEPTION" in line:
            window = "\n".join(lines[i:i + 8])
            if f"Process: {package}" in window:
                cause = next((l.split(":", 1)[-1].strip() for l in lines[i + 1:i + 8]
                              if re.search(r"(Exception|Error)\b", l) and "Process:" not in l), "")
                return "app_crashed", cause
        if f"ANR in {package}" in line:
            reason = next((l.split("Reason:", 1)[-1].strip() for l in lines[i:i + 6] if "Reason:" in l), "")
            return "app_not_responding", reason
    return None


def diagnose(driver, serial: Optional[str], package: str, since: Optional[float], result: dict) -> dict:
    """{kind, group, summary, detail} for a failed step's result (scenario_service result dict)."""
    error = result.get("error") or ""

    def verdict(kind: str, summary: str, detail: str = "") -> dict:
        return {"kind": kind, "group": GROUPS[kind], "summary": summary, "detail": detail[:400],
                "step": result.get("order_index"), "description": result.get("description")}

    if is_dead_session_error(Exception(error)) or _ENVIRONMENT.search(error):
        return verdict("environment", "The phone or the Appium session went away (or the app couldn't start)",
                       error.splitlines()[0] if error else "")

    crash = _crash_in_log(_log_since(serial, since), package)
    source = ""
    if driver is not None:
        try:
            source = mc.get_page_source(driver)
        except Exception as e:
            if is_dead_session_error(e):
                return verdict("environment", "The phone or the Appium session went away", str(e).splitlines()[0])
    if crash is None and source:
        if _ANR_DIALOG.search(source):
            crash = ("app_not_responding", "Android shows its \"isn't responding\" dialog")
        elif _CRASH_DIALOG.search(source):
            crash = ("app_crashed", "Android shows its \"keeps stopping\" dialog")
    if crash is not None:
        kind, detail = crash
        return verdict(kind, "The app crashed" if kind == "app_crashed" else "The app stopped responding", detail)

    if driver is not None and package:
        try:
            current = mc.current_package(driver)
        except Exception:
            current = ""
        if current and current != package and current not in _SYSTEM_PACKAGES:
            return verdict("app_closed", "The app isn't in front any more - it closed, or another app opened",
                           f"in front now: {current}")

    if result.get("action") == "assert" or "Check failed" in error:
        return verdict("check_failed", "A check didn't hold - the app showed something other than expected",
                       error)
    if "test data" in error or "environment variable" in error:
        return verdict("test_data", "A value the step uses has no test data", error)
    if result.get("not_found") or "Could not find" in error or "wasn't found" in error:
        return verdict("element_not_found",
                       "An element the step needs wasn't on screen - the screen changed, or its locator broke",
                       error)
    return verdict("error", "The step failed", error)


def run_error(error: str) -> dict:
    """For a run that failed before any step ran (connecting, starting the app)."""
    kind = "environment" if (_ENVIRONMENT.search(error) or is_dead_session_error(Exception(error))) else "error"
    summary = ("The phone, the Appium session or starting the app failed" if kind == "environment"
               else "The run couldn't start")
    return {"kind": kind, "group": GROUPS[kind], "summary": summary, "detail": error.splitlines()[0][:400] if error else "",
            "step": None, "description": None, "at": time.time()}
