"""
Help with steps after recording, on this app's step format (adapted from
android-record-playback's step_types / helper_recorder / streamlit_app):

  - suggestions(): per step, a number that's data of the account under test (an account
    number tapped in a list - "make it test data") and dates that will be wrong tomorrow
    ("use ${today+7d}");
  - make_data() / use_date(): apply one;
  - merge_date_picks(): calendar taps recorded as separate steps -> one Pick date step;
  - screen_elements() / check_from_screen(): checks on anything that was on a step's screen,
    from the screens saved while recording (no phone needed).
"""

import copy
import re
from typing import Optional

from app.arp import healing, screens, step_types
from app.arp import locator as locator_mod
from app.arp.helper_recorder import merge_date_picks as _merge_date_picks
from app.automation import mobile_control as mc

_FIELD_BY_ACTION = {"type": "text", "keypad": "text", "select": "option", "assert": "expected", "pick_date": "date"}


def _theirs(step: dict, index: int) -> dict:
    """A step in android-record-playback's shape, for its helpers."""
    loc = copy.deepcopy(step.get("locator") or {})
    candidates = [tuple(c) for c in loc.get("candidates") or []]
    # Steps recorded through the mirror have no candidates: their id / description / text are.
    if not candidates:
        if loc.get("resource_id"):
            candidates.append(("id", loc["resource_id"]))
        if loc.get("content_desc"):
            candidates.append(("accessibility id", loc["content_desc"]))
        if loc.get("text"):
            candidates.append(("xpath", f"//*[@text={mc._xpath_literal(loc['text'])}]"))
    loc["candidates"] = candidates
    out = {"index": index, "type": step["action"], "time": float(index),
           "locator": loc if (candidates or loc.get("content_desc") or loc.get("resource_id")) else None,
           "web": loc.get("web"), "pixel_start": None,
           # Carried so merging calendar taps can recognise the date picker (by id or ancestor).
           "fingerprint": step.get("fingerprint") or loc.get("fingerprint")}
    field = _FIELD_BY_ACTION.get(step["action"])
    if field:
        out[field] = step.get("text")
    return out


def suggestions(steps: list) -> list:
    """[{index, kind: "data", value, name}] and [{index, kind: "date", field, value, token}]."""
    theirs = [_theirs(s, i) for i, s in enumerate(steps)]
    out = [{"index": i, "kind": "data", "value": value, "name": name}
           for i, value, name in step_types.data_suggestions(theirs)]
    for i, field, value, token in step_types.date_suggestions(theirs):
        out.append({"index": i, "kind": "date", "field": "locator" if field == "locator" else "text",
                    "value": value, "token": token})
    return out


def _replace(value, old: str, new: str):
    if isinstance(value, str):
        return value.replace(old, new)
    if isinstance(value, list):
        return [_replace(v, old, new) for v in value]
    if isinstance(value, dict):
        return {k: _replace(v, old, new) for k, v in value.items()}
    return value


def make_data(step: dict, value: str, name: str) -> dict:
    """The step with ${name} in place of `value` wherever it names or finds its element (and in
    its text). Only locators that use the value are kept: the rest (a row's place in a list)
    would pick whatever row is there - another account - when the test runs with other data."""
    token = "${" + name + "}"
    step = copy.deepcopy(step)
    loc = step.get("locator") or {}
    if loc:
        candidates = [[s, _replace(v, value, token)] for s, v in loc.get("candidates") or []]
        with_token = [c for c in candidates if isinstance(c[1], str) and token in c[1]]
        loc = _replace({k: v for k, v in loc.items() if k != "candidates"}, value, token)
        if candidates:
            loc["candidates"] = with_token or candidates
        if with_token and loc.get("xpath") and token not in loc["xpath"]:
            loc.pop("xpath")   # a position path: it would find another row
        step["locator"] = loc
    if isinstance(step.get("text"), str):
        step["text"] = step["text"].replace(value, token)
    if isinstance(step.get("description"), str):
        step["description"] = step["description"].replace(value, token)
    return step


def use_date(step: dict, field: str, value: str, token: str) -> dict:
    """A ${today...} date in place of a recorded one (see suggestions)."""
    if field == "locator":
        return make_data(step, value, token[2:-1])
    step = dict(step, text=token)
    if isinstance(step.get("description"), str):
        step["description"] = step["description"].replace(value, token)
    return step


def merge_date_picks(steps: list) -> Optional[list]:
    """Calendar taps (date field, month arrows, day, OK) recorded as separate steps, merged into
    one Pick date step each - None when there are none."""
    theirs = [_theirs(s, i) for i, s in enumerate(steps)]
    merged = _merge_date_picks([dict(t) for t in theirs])
    if len(merged) == len(steps):
        return None
    out = []
    for t in merged:
        if t["type"] != "pick_date":
            out.append(steps[t["index"]])
            continue
        first = steps[t["index"]]
        # The date field: the first tap of the run of calendar taps, when it wasn't the day itself.
        field_loc = first.get("locator") if t.get("locator") else {}
        # Name it by the label beside it ("From") rather than its changing value ("# Oct #").
        where = (field_loc.get("beside") or "").strip()
        if not where and "#" not in (first.get("description") or ""):
            where = (first.get("description") or "").strip()
        out.append({
            "action": "pick_date", "text": t["date"], "locator": field_loc or {},
            "x_pct": first.get("x_pct"), "y_pct": first.get("y_pct"), "ts": first.get("ts"),
            "description": f"Pick date {t['date']}" + (f" in {where}" if field_loc and where else ""),
        })
    return out


# ---------------------------------------------------------------------
# Checks from the screens saved while recording
# ---------------------------------------------------------------------

def _named(node: dict) -> bool:
    """Worth offering as a check target: shows text, has a name, or is a field / checkbox."""
    return bool((node.get("text") or "").strip() or (node.get("content_desc") or "").strip()
                or node.get("resource_id") or node.get("editable") or node.get("checkable"))


def screen_elements(screen_id: str) -> list:
    """[{index, label, check, expected}] for a saved screen's elements worth checking."""
    out = []
    for i, node in enumerate(screens.load(screen_id)):
        if not _named(node):
            continue
        check, expected = step_types.default_check_for(node)
        out.append({"index": i, "label": step_types.element_label(node), "check": check,
                    "expected": expected, "bounds": node.get("bounds")})
    return out


def check_from_screen(screen_id: str, index: int, check: Optional[str] = None,
                      expected: Optional[str] = None) -> dict:
    """A check step (this app's shape) on element `index` of a saved screen."""
    from app.services.phone_recording import to_our_locator, _name   # avoid an import cycle
    elements = screens.load(screen_id)
    if not 0 <= index < len(elements):
        raise LookupError("That element isn't on the saved screen")
    node = elements[index]
    loc = locator_mod.locator_from_node(node)
    if loc is None:
        raise ValueError("This element has nothing to find it by - pick another")
    default_check, default_expected = step_types.default_check_for(node)
    check = check or default_check
    expected = default_expected if expected is None else expected
    ours = to_our_locator(loc, {"fingerprint": healing.fingerprint(node)})
    name = _name(loc)
    what = mc.CHECKS.get(check, check)
    text = expected if check in step_types.CHECKS_WITH_EXPECTED else None
    if check == "text_matches":
        seen = " ".join(str(node.get("text") or node.get("content_desc") or "").split())
        description = f'Check text is like "{seen[:57]}" (numbers, dates and times may differ)'
    elif text:
        description = f'Check {name + " " if name and name != text else ""}{what} "{text[:60]}"'
    else:
        description = f"Check {name or 'it'} {what}"
    return {"action": "assert", "check": check, "text": text, "locator": ours, "description": description}
