"""
Scenario runs kept in the database once they finish, so results (and failure screenshots)
survive a backend restart: a scenario's history, its recent pass rate, and any old run opened
again. Live runs stay in runs_registry while they're going.

Only the latest KEEP_PER_SCENARIO runs of each scenario are kept.
"""

import json
from typing import Optional

KEEP_PER_SCENARIO = 50


def _db():
    from app.db.database import get_session   # imported late: tests stub the database out
    from app.db.models import RunRecord
    return get_session(), RunRecord


def save(run, scenario_name: str = "") -> None:
    """Store a finished scenario run (runs_registry.Run). Never raises: history is an extra."""
    if run.kind != "scenario":
        return
    try:
        d = run.to_dict()
        db, RunRecord = _db()
    except Exception:
        return
    try:
        record = db.get(RunRecord, d["run_id"]) or RunRecord(id=d["run_id"])
        record.scenario_id = d.get("scenario_id")
        record.scenario_name = scenario_name or record.scenario_name or ""
        record.status = d["status"]
        record.start_index = d.get("start_index") or 0
        record.total_steps = d.get("total_steps")
        record.created_at = d.get("created_at") or 0.0
        record.finished_at = d.get("finished_at")
        record.failure_json = json.dumps(d.get("failure")) if d.get("failure") else None
        record.log_json = json.dumps(d.get("log") or [])
        db.merge(record)
        db.commit()
        _prune(db, RunRecord, d.get("scenario_id"))
    except Exception:
        db.rollback()
    finally:
        db.close()


def _prune(db, RunRecord, scenario_id):
    if scenario_id is None:
        return
    old = (db.query(RunRecord).filter(RunRecord.scenario_id == scenario_id)
           .order_by(RunRecord.created_at.desc()).offset(KEEP_PER_SCENARIO).all())
    for record in old:
        db.delete(record)
    if old:
        db.commit()


def _as_dict(record, with_log: bool = True) -> dict:
    log = json.loads(record.log_json or "[]")
    d = {
        "run_id": record.id, "kind": "scenario", "scenario_id": record.scenario_id,
        "scenario_name": record.scenario_name, "status": record.status, "start_index": record.start_index,
        "total_steps": record.total_steps, "created_at": record.created_at, "finished_at": record.finished_at,
        "failure": json.loads(record.failure_json) if record.failure_json else None,
        "duration": round(sum(e.get("duration") or 0 for e in log), 2),
        "steps_done": len({e.get("order_index") for e in log if (e.get("order_index") or 0) >= 0
                           and e.get("order_index") is not None}),
    }
    if with_log:
        d["log"] = log
    return d


def get(run_id: str) -> Optional[dict]:
    try:
        db, RunRecord = _db()
    except Exception:
        return None
    try:
        record = db.get(RunRecord, run_id)
        return _as_dict(record) if record else None
    finally:
        db.close()


def for_scenario(scenario_id: int, limit: int = 20) -> list:
    """The scenario's latest runs, newest first, without their step results."""
    try:
        db, RunRecord = _db()
    except Exception:
        return []
    try:
        records = (db.query(RunRecord).filter(RunRecord.scenario_id == scenario_id)
                   .order_by(RunRecord.created_at.desc()).limit(limit).all())
        return [_as_dict(r, with_log=False) for r in records]
    finally:
        db.close()


def recent_statuses(limit: int = 10) -> dict:
    """{scenario_id: [status, ...]} of each scenario's latest runs, newest first."""
    try:
        db, RunRecord = _db()
    except Exception:
        return {}
    try:
        out: dict = {}
        for scenario_id, status in (db.query(RunRecord.scenario_id, RunRecord.status)
                                    .order_by(RunRecord.created_at.desc()).all()):
            if scenario_id is not None and len(out.setdefault(scenario_id, [])) < limit:
                out[scenario_id].append(status)
        return out
    finally:
        db.close()


def delete_for_scenario(scenario_id: int) -> None:
    try:
        db, RunRecord = _db()
    except Exception:
        return
    try:
        db.query(RunRecord).filter(RunRecord.scenario_id == scenario_id).delete()
        db.commit()
    finally:
        db.close()
