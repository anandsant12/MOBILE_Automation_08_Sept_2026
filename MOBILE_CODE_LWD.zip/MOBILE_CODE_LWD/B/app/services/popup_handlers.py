"""
Global popup handlers: interruptions dismissed automatically during replay, so they
needn't be recorded into every scenario - Android's own permission dialogs, and any
"when the screen shows X, tap Y" rules the user adds (a rating prompt, an update nag).

Checked when a step can't find what it's looking for (the usual sign that something
popped up over it), and before a failed step is retried - not before every step, which
would cost a screen read each time. Stored in backend/popup_handlers.json.
"""

import json
import threading
import time
from pathlib import Path

from config import settings
from app.automation import mobile_control as mc

PATH = Path(settings.base_dir) / "popup_handlers.json"
DEFAULTS = {"auto_allow_permissions": True, "rules": []}

# Android's runtime-permission dialog, and its buttons in order of preference.
PERMISSION_PACKAGES = ("com.android.permissioncontroller", "com.google.android.permissioncontroller",
                       "com.android.packageinstaller")
ALLOW_BUTTONS = ("permission_allow_foreground_only_button", "permission_allow_one_time_button",
                 "permission_allow_button")   # most limited grant first

_lock = threading.Lock()


def load() -> dict:
    with _lock:
        try:
            data = json.loads(PATH.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return json.loads(json.dumps(DEFAULTS))
    return {"auto_allow_permissions": bool(data.get("auto_allow_permissions", True)),
            "rules": [_clean(r) for r in data.get("rules") or [] if _clean(r)["when_text"]]}


def save(data: dict) -> dict:
    cleaned = {"auto_allow_permissions": bool(data.get("auto_allow_permissions", True)),
               "rules": [r for r in (_clean(r) for r in data.get("rules") or []) if r["when_text"] and r["tap_text"]]}
    with _lock:
        PATH.write_text(json.dumps(cleaned, indent=1), encoding="utf-8")
    return cleaned


def _clean(rule: dict) -> dict:
    return {"when_text": str(rule.get("when_text") or "").strip(), "tap_text": str(rule.get("tap_text") or "").strip(),
            "enabled": bool(rule.get("enabled", True))}


def dismiss(driver, rounds: int = 3) -> list:
    """Dismiss whatever known popup is showing (up to `rounds` stacked ones). Returns a note
    per popup dismissed; [] when there was none."""
    config = load()
    rules = [r for r in config["rules"] if r["enabled"]]
    if not rules and not config["auto_allow_permissions"]:
        return []
    notes = []
    for _ in range(rounds):
        nodes = [n for n in mc.parse_page_source(mc.get_page_source(driver)) if n.get("displayed") != "false"]
        note = _allow_permission(driver, nodes) if config["auto_allow_permissions"] else None
        note = note or _apply_rules(driver, nodes, rules)
        if not note:
            break
        notes.append(note)
        time.sleep(0.8)   # let it close before looking for another
    return notes


def _tap(driver, node: dict):
    mc.tap_coords(driver, *mc._center(node))


def _allow_permission(driver, nodes: list):
    if not any(n.get("package") in PERMISSION_PACKAGES for n in nodes):
        return None
    for button in ALLOW_BUTTONS:
        hit = next((n for n in nodes if (n.get("resource-id") or "").endswith("/" + button)), None)
        if hit is not None:
            _tap(driver, hit)
            return f"Allowed a permission request ({mc._own_label(hit) or 'Allow'})"
    return None


def _apply_rules(driver, nodes: list, rules: list):
    labels = [(n, mc._own_label(n)) for n in nodes if mc._own_label(n)]
    for rule in rules:
        when = rule["when_text"].lower()
        if not any(when in label.lower() for _, label in labels):
            continue
        tap = " ".join(rule["tap_text"].lower().split())
        # The button: exactly that text if there is one, else one containing it - the one drawn
        # last, which is the popup's, not a button with the same text on the page behind it.
        exact = [n for n, label in labels if " ".join(label.lower().split()) == tap]
        loose = [n for n, label in labels if tap in label.lower()]
        button = (exact or loose or [None])[-1]
        if button is not None:
            _tap(driver, button)
            return f"Dismissed a popup: \"{rule['when_text']}\" -> tapped \"{mc._own_label(button)}\""
    return None
