import time
import urllib.request
from typing import Optional
from urllib.parse import urlparse

from fastapi import APIRouter, HTTPException
from fastapi.responses import StreamingResponse
from pydantic import BaseModel

from config import settings
from app.automation import mobile_control as mc
from app.automation.session_manager import session
from app.services import devices, recording_service
from app.services import phone_recording as physical_capture_service  # android-record-playback's engine

router = APIRouter(prefix="/api/session", tags=["session"])


class ConnectRequest(BaseModel):
    android_app_package: Optional[str] = None
    android_app_activity: Optional[str] = None
    udid: Optional[str] = None               # which phone (its adb serial) - from /devices
    platform_version: Optional[str] = None   # its Android version, as read off the phone


@router.get("/devices")
def list_devices():
    """Phones plugged in over USB (adb devices), with their model and Android version."""
    return devices.list_devices()


@router.post("/connect")
def connect(body: ConnectRequest):
    try:
        session.connect(body.android_app_package or "", body.android_app_activity or "",
                        udid=body.udid, platform_version=body.platform_version)
        with session.command_lock:
            screen = mc.get_window_size(session.driver)
            screenshot = None if session.mjpeg_active else mc.get_screenshot_b64(session.driver)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))
    return {
        "connected": True, "package": session.package, "activity": session.activity,
        "screen": screen, "screenshot": screenshot, "udid": session.udid,
        "mirror": "mjpeg" if session.mjpeg_active else "poll",
    }


@router.post("/disconnect")
def disconnect():
    physical_capture_service.stop()
    session.disconnect()
    return {"connected": False}


@router.post("/reconnect")
def reconnect():
    """Manual version of the automatic recovery: drop the current driver
    and open a fresh session on the same device/app."""
    try:
        session.recover()
        with session.command_lock:
            screen = mc.get_window_size(session.driver)
            screenshot = None if session.mjpeg_active else mc.get_screenshot_b64(session.driver)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))
    return {
        "connected": True, "package": session.package, "activity": session.activity,
        "screen": screen, "screenshot": screenshot,
        "mirror": "mjpeg" if session.mjpeg_active else "poll",
    }


@router.get("/status")
def status():
    if not session.is_connected:
        return {"connected": False}
    driver = session.driver
    with session.command_lock:
        return {
            "connected": True,
            "udid": session.udid,
            "mirror": "mjpeg" if session.mjpeg_active else "poll",
            "package": mc.current_package(driver) or session.package,
            "activity": mc.current_activity(driver) or session.activity,
            "screen": mc.get_window_size(driver),
        }


@router.get("/screenshot")
def screenshot():
    try:
        session.require_driver()

        def _grab():
            with session.command_lock:
                return mc.get_screenshot_b64(session.require_driver())

        # The mirror hits this constantly, so it's also the first place a
        # dead device session shows up - recover right here.
        return {"screenshot": session.call_with_recovery(_grab)}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


class TapRequest(BaseModel):
    x_pct: float
    y_pct: float
    mode: str = "basic"


@router.post("/tap")
async def tap(body: TapRequest):
    try:
        return await recording_service.record_tap(body.x_pct, body.y_pct, body.mode)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


class InspectRequest(BaseModel):
    x_pct: float
    y_pct: float


@router.post("/inspect")
async def inspect(body: InspectRequest):
    """For adding a check: the element at that point and its current state. Nothing is tapped."""
    try:
        return await recording_service.inspect_element(body.x_pct, body.y_pct)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


class TypeRequest(BaseModel):
    x_pct: float
    y_pct: float
    text: str
    mode: str = "basic"


@router.post("/type")
async def type_text(body: TypeRequest):
    try:
        return await recording_service.record_type(body.x_pct, body.y_pct, body.text, body.mode)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


class SwipeRequest(BaseModel):
    x1_pct: float
    y1_pct: float
    x2_pct: float
    y2_pct: float
    mode: str = "basic"


@router.post("/swipe")
async def swipe(body: SwipeRequest):
    try:
        return await recording_service.record_swipe(body.x1_pct, body.y1_pct, body.x2_pct, body.y2_pct, body.mode)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


class KeyRequest(BaseModel):
    key: str  # "back" | "home"
    mode: str = "basic"


@router.post("/key")
async def key(body: KeyRequest):
    try:
        return await recording_service.record_key(body.key, body.mode)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


class PhysicalCaptureRequest(BaseModel):
    enabled: bool
    mode: str = "basic"


@router.post("/physical-capture")
def physical_capture(body: PhysicalCaptureRequest):
    """Turns real touches on the physical device into recorded steps
    too, alongside mirror-click recording - best-effort: if it can't
    start (no `adb`, no touchscreen device found), physical_status still
    reports why, but this never fails the request or blocks mirror-click
    recording, which works independently either way."""
    if body.enabled:
        physical_capture_service.start(body.mode)
    else:
        physical_capture_service.stop(flush=True)  # also picks up text typed on the phone since the last touch
    return physical_capture_service.status()


@router.get("/physical-capture/status")
def physical_capture_status():
    return physical_capture_service.status()


@router.get("/physical-steps")
def physical_steps():
    """Polled while recording - drains and returns any steps built from
    real touches on the device since the last call."""
    steps, replace = physical_capture_service.pending_steps()
    return {"steps": steps, "replace": replace, "status": physical_capture_service.status()}


@router.get("/stream")
def stream():
    """Live MJPEG mirror: the phone's own screen stream (UiAutomator2's
    mjpegServerPort), relayed to the browser. It rides a separate channel
    from Appium's command queue, so watching never slows down (or waits on)
    taps, replays or recording - which is what the screenshot-per-request
    mirror couldn't avoid."""
    if not session.is_connected:
        raise HTTPException(status_code=400, detail="No active device session - connect first.")
    if not session.mjpeg_active:
        raise HTTPException(status_code=503, detail="Live streaming isn't active for this session (MIRROR_MODE=poll, or the device refused the stream).")
    host = urlparse(settings.appium_server_url).hostname or "127.0.0.1"
    url = f"http://{host}:{settings.mjpeg_server_port}"
    try:
        upstream = urllib.request.urlopen(url, timeout=5)
    except Exception as e:
        raise HTTPException(status_code=503, detail=f"Could not open the device's MJPEG stream at {url}: {e}")
    content_type = upstream.headers.get("Content-Type") or "multipart/x-mixed-replace; boundary=BoundaryString"

    def frames():
        current = upstream
        failures = 0
        try:
            while True:
                try:
                    chunk = current.read1(16384)  # read1: hand over whatever has arrived, don't wait to fill the buffer
                    if not chunk:
                        raise EOFError("upstream closed")
                except Exception:
                    # The device side dropped (session restarted, screen off): re-attach a few times.
                    try:
                        current.close()
                    except Exception:
                        pass
                    failures += 1
                    if failures > 6 or not session.is_connected:
                        return
                    time.sleep(1.0)
                    try:
                        current = urllib.request.urlopen(url, timeout=5)
                    except Exception:
                        pass
                    continue
                failures = 0
                yield chunk
        finally:
            try:
                current.close()
            except Exception:
                pass

    return StreamingResponse(frames(), media_type=content_type, headers={"Cache-Control": "no-store"})
