from fastapi import APIRouter

from config import settings
from app.version import API_VERSION

router = APIRouter(tags=["config"])


@router.get("/api/config")
def get_config():
    """The frontend calls this once on load. ENABLE_LLM_ASSISTED here is
    what decides whether the AI-assisted tab renders at all - toggling it
    in .env and restarting the backend is enough, no frontend rebuild."""
    return {
        "llm_provider": settings.llm_provider,
        "enable_llm_assisted": settings.enable_llm_assisted,
        "android_app_package": settings.android_app_package,
        "android_app_activity": settings.android_app_activity,
        "android_device_name": settings.android_device_name,
        "appium_server_url": settings.appium_server_url,
        "api_version": API_VERSION,
    }
