import time
from typing import Optional

from fastapi import APIRouter, HTTPException, Query
from fastapi.responses import PlainTextResponse
from pydantic import BaseModel

from app.automation.session_manager import device_serial
from app.services import export_service, run_history, scenario_service, runs_registry

router = APIRouter(prefix="/api/scenarios", tags=["scenarios"])


class StepIn(BaseModel):
    action: str
    description: str = ""
    locator: dict = {}
    x_pct: Optional[float] = None
    y_pct: Optional[float] = None
    x2_pct: Optional[float] = None
    y2_pct: Optional[float] = None
    text: Optional[str] = None
    checked_target: Optional[bool] = None
    redacted: Optional[bool] = None
    check: Optional[str] = None   # "assert" steps: visible | not_visible | text_equals | ...
    var: Optional[str] = None        # "capture" steps: the name to remember the read value under
    normalize: Optional[str] = None  # "capture" / text-check steps: raw | trim | digits | number
    optional: Optional[bool] = None
    continue_on_failure: Optional[bool] = None
    disabled: Optional[bool] = None
    screen: Optional[str] = None         # the saved screen it acted on (recorded on the phone)
    screen_after: Optional[str] = None   # ...and the one it led to


class SaveScenarioRequest(BaseModel):
    name: str
    mode: str = "basic"
    android_app_package: str = ""
    android_app_activity: str = ""
    steps: list[StepIn]
    # Test data: ${name} in typed text, options and expected values. None on update = keep as is.
    variables: Optional[dict[str, str]] = None
    # How a run starts: {"app": "as_is" | "restart" | "clear", "setup_scenario_id": id or null}.
    # None on update = keep as is.
    start: Optional[dict] = None


@router.get("")
def list_scenarios():
    return scenario_service.list_scenarios()


@router.post("")
def save_scenario(body: SaveScenarioRequest):
    try:
        return scenario_service.save_scenario(
            body.name, body.mode, body.android_app_package, body.android_app_activity,
            [s.model_dump() for s in body.steps], body.variables, body.start,
        )
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.post("/import")
def import_scenario(body: dict):
    """A scenario file made by GET /{id}/export - saved as a new scenario."""
    try:
        return scenario_service.import_scenario(body)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.put("/{scenario_id}")
def update_scenario(scenario_id: int, body: SaveScenarioRequest):
    """Replace a saved scenario's name and steps (the Steps editor)."""
    try:
        return scenario_service.update_scenario(scenario_id, body.name, [s.model_dump() for s in body.steps],
                                                body.variables, body.start)
    except LookupError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


class PreferLocatorRequest(BaseModel):
    strategy: str
    value: str
    index: int = 0
    # Self-healing found the element by its fingerprint: its new locator ({candidates,
    # resource_id, content_desc, text}), or the web page's new locator for it.
    locator: Optional[dict] = None
    web: Optional[dict] = None


@router.post("/{scenario_id}/steps/{order_index}/prefer-locator")
def prefer_locator(scenario_id: int, order_index: int, body: PreferLocatorRequest):
    """A run found this step by a backup locator (or healed it): make that the main one."""
    try:
        return scenario_service.prefer_locator(scenario_id, order_index, body.strategy, body.value, body.index,
                                               body.locator, body.web)
    except LookupError as e:
        raise HTTPException(status_code=404, detail=str(e))


def _scenario_or_404(scenario_id: int) -> dict:
    try:
        return scenario_service.get_scenario(scenario_id)
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))


@router.get("/{scenario_id}")
def get_scenario(scenario_id: int):
    return _scenario_or_404(scenario_id)


@router.get("/{scenario_id}/runs")
def scenario_runs(scenario_id: int, limit: int = Query(20, ge=1, le=50)):
    """The scenario's latest finished runs, newest first (kept across restarts)."""
    _scenario_or_404(scenario_id)
    return {"runs": run_history.for_scenario(scenario_id, limit)}


@router.get("/{scenario_id}/export")
def export_scenario(scenario_id: int):
    """The scenario as a portable JSON file (POST /import reads it back)."""
    scenario = _scenario_or_404(scenario_id)
    return export_service.scenario_json(scenario)


@router.get("/{scenario_id}/pytest", response_class=PlainTextResponse)
def export_pytest(scenario_id: int):
    """The scenario as a standalone pytest + Appium-Python-Client test."""
    scenario = _scenario_or_404(scenario_id)
    filename, code = export_service.pytest_script(scenario, device_serial())
    return PlainTextResponse(code, media_type="text/x-python",
                             headers={"Content-Disposition": f'attachment; filename="{filename}"'})


@router.delete("/{scenario_id}")
def delete_scenario(scenario_id: int):
    try:
        scenario_service.delete_scenario(scenario_id)
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    return {"deleted": True}


class RunRequest(BaseModel):
    # order_index -> value, for this run only, for any redacted (password/PIN/OTP) steps.
    # Never written to the database - see Step.redacted in app/db/models.py.
    overrides: dict[int, str] = {}
    start_index: int = 0   # "run from this step" (0-based position in the scenario)
    retries: int = 0       # retry a step whose element wasn't found / check wasn't true (0-3)
    # "fast" (no pause), "medium" or "slow": how long to pause after each step, to watch it land.
    speed: str = "fast"
    # Test data for this run only, on top of the scenario's own (${name} in steps).
    variables: dict[str, str] = {}
    # Self-healing: a step whose locators match nothing is found by its recorded fingerprint.
    heal: bool = True


MAX_WAIT_S = 3600


@router.post("/{scenario_id}/run")
def run_scenario(scenario_id: int, body: RunRequest = RunRequest(),
                 wait: bool = Query(False, description="Answer only once the run has finished (for CI / the CLI)"),
                 timeout: int = Query(1800, ge=1, le=MAX_WAIT_S)):
    """Starts replay in the background and returns immediately - poll
    GET /api/runs/{run_id} for progress, or POST /api/runs/{run_id}/stop
    to cancel it partway through. With ?wait=true it answers once the run
    has finished, with the whole run (status passed / failed / stopped)."""
    try:
        run_id = scenario_service.run_scenario(scenario_id, body.overrides, body.speed, body.start_index,
                                               body.retries, body.variables, body.heal)
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))
    run = runs_registry.get_run(run_id)
    if wait and run is not None:
        deadline = time.time() + timeout
        while run.status == "running" and time.time() < deadline:
            time.sleep(0.5)
        d = run.to_dict()
        d["log"] = [{k: v for k, v in e.items() if k != "screenshot"} for e in d["log"]]
        return dict(d, run_id=run_id)
    return {"run_id": run_id, "total_steps": run.total_steps if run else None}
