from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from config import settings
from app.services import assist_service, runs_registry

router = APIRouter(prefix="/api/assist", tags=["assist"])


class ExecuteRequest(BaseModel):
    instruction: str


@router.post("/execute")
def execute(body: ExecuteRequest):
    """Starts the AI-assisted loop in the background and returns
    immediately - poll GET /api/runs/{run_id} for progress, or POST
    /api/runs/{run_id}/stop to cancel it partway through."""
    if not settings.enable_llm_assisted:
        raise HTTPException(status_code=403, detail="AI-assisted mode is disabled (ENABLE_LLM_ASSISTED=false in .env).")
    try:
        run_id = assist_service.start_assist_run(body.instruction)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))
    run = runs_registry.get_run(run_id)
    return {"run_id": run_id, "total_steps": run.total_steps if run else None}
