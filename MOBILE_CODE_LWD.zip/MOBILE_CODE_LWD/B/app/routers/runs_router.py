from typing import Optional

from fastapi import APIRouter, HTTPException, Query
from fastapi.responses import Response

from app.services import export_service, run_history, runs_registry, scenario_service

router = APIRouter(prefix="/api/runs", tags=["runs"])


# Declared before /{run_id}, which would otherwise swallow "active" as an id.
@router.get("/active")
def get_active_run(kind: Optional[str] = Query(None)):
    """The most recent run (running or finished) - the UI renders whatever
    this says instead of tracking runs itself."""
    run = runs_registry.latest_run(kind)
    return {"run": run.to_dict() if run else None}


@router.get("/recent")
def get_recent_runs(kind: Optional[str] = Query(None), limit: int = Query(10, ge=1, le=100)):
    """Recent runs, newest first - screenshots left out to keep it small."""
    out = []
    for run in runs_registry.recent_runs(kind, limit):
        d = run.to_dict()
        d["log"] = [{k: v for k, v in e.items() if k != "screenshot"} for e in d["log"]]
        out.append(d)
    return {"runs": out}


def _run_or_404(run_id: str) -> dict:
    """A run still in memory (running, or finished since the backend started), else one kept in
    the database (app/services/run_history.py)."""
    run = runs_registry.get_run(run_id)
    if run is not None:
        return run.to_dict()
    kept = run_history.get(run_id)
    if kept is None:
        raise HTTPException(status_code=404, detail=f"Run {run_id} not found (it may have expired).")
    return kept


@router.get("/{run_id}/junit")
def get_run_junit(run_id: str):
    """The run as JUnit XML, for CI systems."""
    d = _run_or_404(run_id)
    name = d.get("scenario_name") or f"run {run_id[:8]}"
    if d.get("scenario_id") is not None and not d.get("scenario_name"):
        try:
            name = scenario_service.get_scenario(d["scenario_id"])["name"]
        except ValueError:
            pass
    return Response(export_service.junit_xml([(name, d)]), media_type="application/xml",
                    headers={"Content-Disposition": f'attachment; filename="run-{run_id[:8]}.xml"'})


@router.get("/{run_id}")
def get_run_status(run_id: str):
    return _run_or_404(run_id)


@router.post("/{run_id}/stop")
def stop_run(run_id: str):
    run = runs_registry.request_stop(run_id)
    if run is None:
        raise HTTPException(status_code=404, detail=f"Run {run_id} not found (it may have expired).")
    return run.to_dict()
