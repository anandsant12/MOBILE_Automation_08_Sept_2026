from fastapi import APIRouter
from pydantic import BaseModel

from app.services import popup_handlers

router = APIRouter(prefix="/api/settings", tags=["settings"])


class PopupRule(BaseModel):
    when_text: str
    tap_text: str
    enabled: bool = True


class PopupHandlers(BaseModel):
    auto_allow_permissions: bool = True
    rules: list[PopupRule] = []


@router.get("/popup-handlers")
def get_popup_handlers():
    """Interruptions replay dismisses on its own (see app/services/popup_handlers.py)."""
    return popup_handlers.load()


@router.put("/popup-handlers")
def put_popup_handlers(body: PopupHandlers):
    return popup_handlers.save(body.model_dump())
