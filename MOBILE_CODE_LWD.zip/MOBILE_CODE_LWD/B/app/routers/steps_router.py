"""Help with steps in the editor: suggestions (test data, dates), merging calendar taps, and
checks picked from the screens saved while recording - see app/services/step_tools.py."""

from typing import Optional

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from app.services import step_tools

router = APIRouter(prefix="/api", tags=["steps"])


class StepsBody(BaseModel):
    steps: list[dict]


@router.post("/steps/suggestions")
def suggestions(body: StepsBody):
    """Per step: data of the account under test to make test data, dates to make relative to
    the run's date; and whether calendar taps could be merged into Pick date steps."""
    try:
        return {"suggestions": step_tools.suggestions(body.steps),
                "merge_dates": step_tools.merge_date_picks(body.steps) is not None}
    except Exception as e:   # suggestions are an extra: never break the editor
        return {"suggestions": [], "merge_dates": False, "error": str(e)}


class MakeDataBody(BaseModel):
    step: dict
    value: str
    name: str


@router.post("/steps/make-data")
def make_data(body: MakeDataBody):
    name = "".join(c if c.isalnum() else "_" for c in body.name.strip()).strip("_")
    if not name:
        raise HTTPException(status_code=400, detail="Give the test data a name.")
    return {"step": step_tools.make_data(body.step, body.value, name), "name": name}


class UseDateBody(BaseModel):
    step: dict
    field: str
    value: str
    token: str


@router.post("/steps/use-date")
def use_date(body: UseDateBody):
    return {"step": step_tools.use_date(body.step, body.field, body.value, body.token)}


@router.post("/steps/merge-dates")
def merge_dates(body: StepsBody):
    merged = step_tools.merge_date_picks(body.steps)
    return {"steps": merged if merged is not None else body.steps, "merged": merged is not None}


@router.get("/screens/{screen_id}")
def screen(screen_id: str):
    """A saved screen's elements worth checking."""
    if not screen_id.isalnum():
        raise HTTPException(status_code=400, detail="Not a screen id")
    return {"elements": step_tools.screen_elements(screen_id)}


class CheckBody(BaseModel):
    index: int
    check: Optional[str] = None
    expected: Optional[str] = None


@router.post("/screens/{screen_id}/check")
def check_from_screen(screen_id: str, body: CheckBody):
    """A check step on one element of a saved screen."""
    if not screen_id.isalnum():
        raise HTTPException(status_code=400, detail="Not a screen id")
    try:
        return step_tools.check_from_screen(screen_id, body.index, body.check, body.expected)
    except LookupError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
