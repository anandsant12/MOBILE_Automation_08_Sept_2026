"""Defensive JSON parsing shared by both providers - models occasionally
wrap their JSON in code fences, add a stray sentence, or (reasoning
models) leave a <think> block in front of it."""

import json
import re


def extract_json(raw: str) -> dict:
    if not raw or not raw.strip():
        raise ValueError("Empty response from model")

    cleaned = re.sub(r"<think>.*?</think>", "", raw, flags=re.DOTALL).strip()
    if "<think>" in cleaned:
        cleaned = cleaned.split("<think>")[0].strip()

    if cleaned.startswith("```"):
        cleaned = cleaned.strip("`")
        if cleaned.lower().startswith("json"):
            cleaned = cleaned[4:]
        cleaned = cleaned.strip()

    if not cleaned:
        raise ValueError("Empty response after stripping reasoning/fences")

    try:
        return json.loads(cleaned)
    except json.JSONDecodeError:
        pass

    match = re.search(r"\{.*\}", cleaned, re.DOTALL)
    if match:
        return json.loads(match.group(0))

    raise ValueError(f"Could not parse JSON from model output: {raw!r}")
