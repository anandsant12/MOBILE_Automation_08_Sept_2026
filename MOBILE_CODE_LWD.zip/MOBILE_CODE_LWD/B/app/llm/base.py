"""
Shared interface both providers implement, so every other module in the
project (recording classification, AI-assisted planning, vision fallback)
calls `get_provider()` once and never cares which one it got back.
"""

from abc import ABC, abstractmethod
from typing import Optional


def image_data_url(image_b64: str) -> str:
    """mobile_control.get_screenshot_b64 returns a JPEG (a PNG only if re-encoding
    failed) - label it as what it is; some endpoints reject a mismatched type."""
    mime = "image/png" if image_b64.startswith("iVBOR") else "image/jpeg"
    return f"data:{mime};base64,{image_b64}"


class LLMProvider(ABC):
    name: str = "base"

    @abstractmethod
    async def chat_json(self, system_prompt: str, user_prompt: str, timeout: float = 30.0) -> dict:
        """Text-only call. The provider is instructed (via the system
        prompt) to reply with ONLY a JSON object; implementations parse
        it defensively (strip code fences, regex-extract the {...} block)
        since not every model/provider honours strict JSON mode."""
        raise NotImplementedError

    @abstractmethod
    async def vision_json(self, system_prompt: str, user_prompt: str, image_b64: str,
                           timeout: float = 35.0) -> dict:
        """Screenshot + text -> JSON. image_b64 is raw base64 JPEG or PNG (no
        data-url prefix - see image_data_url)."""
        raise NotImplementedError

    async def embed(self, texts: list[str]) -> Optional[list[list[float]]]:
        """Batched embedding call. Returns None when the provider has no
        embeddings endpoint (Groq) - callers fall back to ChromaDB's own
        local embedding function in that case, they never treat None as
        an error."""
        return None
