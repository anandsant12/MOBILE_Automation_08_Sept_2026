import asyncio

from openai import AsyncOpenAI, BadRequestError

from config import settings
from app.llm.base import LLMProvider, image_data_url
from app.llm.json_utils import extract_json

MAX_TOKENS = 2048
VISION_MAX_TOKENS = 900


class GroqProvider(LLMProvider):
    """Groq exposes an OpenAI-compatible /openai/v1 endpoint, so the same
    `openai` SDK works here too - just pointed at Groq's base_url with a
    Groq API key. Groq has no embeddings endpoint, so embed() returns
    None and callers fall back to ChromaDB's bundled local embedder."""

    name = "groq"

    def __init__(self):
        if not settings.groq_api_key:
            raise RuntimeError("Missing GROQ_API_KEY. Check your .env.")
        self._client = AsyncOpenAI(
            api_key=settings.groq_api_key, base_url=settings.groq_base_url,
            timeout=40.0, max_retries=1,
        )

    async def _complete(self, model: str, messages: list, max_tokens: int) -> str:
        try:
            resp = await self._client.chat.completions.create(
                model=model, messages=messages, temperature=0.2,
                max_tokens=max_tokens, response_format={"type": "json_object"},
            )
        except BadRequestError:
            # Not every Groq-hosted model accepts json_object mode - fall
            # back to a plain call; extract_json still finds the {...}.
            resp = await self._client.chat.completions.create(
                model=model, messages=messages, temperature=0.2, max_tokens=max_tokens,
            )
        return resp.choices[0].message.content

    async def chat_json(self, system_prompt: str, user_prompt: str, timeout: float = 30.0) -> dict:
        messages = [{"role": "system", "content": system_prompt}, {"role": "user", "content": user_prompt}]
        raw = await asyncio.wait_for(self._complete(settings.groq_model, messages, MAX_TOKENS), timeout=timeout)
        return extract_json(raw)

    async def vision_json(self, system_prompt: str, user_prompt: str, image_b64: str,
                           timeout: float = 35.0) -> dict:
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": [
                {"type": "text", "text": user_prompt},
                {"type": "image_url", "image_url": {"url": image_data_url(image_b64)}},
            ]},
        ]
        raw = await asyncio.wait_for(
            self._complete(settings.groq_vision_model, messages, VISION_MAX_TOKENS), timeout=timeout,
        )
        return extract_json(raw)

    async def embed(self, texts: list[str]):
        return None
