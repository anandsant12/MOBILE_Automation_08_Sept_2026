from config import settings
from app.llm.base import LLMProvider

_provider: LLMProvider | None = None


def get_provider() -> LLMProvider:
    """LLM_PROVIDER=azure|groq picks which one gets constructed. Lazy +
    cached so an invalid/missing key only raises when an LLM call is
    actually attempted, not at import time (Aim 1 never touches this)."""
    global _provider
    if _provider is None:
        if settings.llm_provider == "groq":
            from app.llm.groq_provider import GroqProvider
            _provider = GroqProvider()
        else:
            from app.llm.azure_provider import AzureProvider
            _provider = AzureProvider()
    return _provider


def reset_provider():
    """Used only if the provider config changes at runtime (not needed
    for normal operation - .env is read once at process start)."""
    global _provider
    _provider = None
