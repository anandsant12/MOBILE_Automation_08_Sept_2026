import asyncio

from openai import AsyncAzureOpenAI, BadRequestError

from config import settings
from app.llm.base import LLMProvider, image_data_url
from app.llm.json_utils import extract_json

MAX_TOKENS = 2048
VISION_MAX_TOKENS = 900


class AzureProvider(LLMProvider):
    name = "azure"

    def __init__(self):
        missing = [
            n for n, v in [
                ("AZURE_OPENAI_API_KEY", settings.azure_openai_api_key),
                ("AZURE_OPENAI_ENDPOINT", settings.azure_openai_endpoint),
                ("AZURE_OPENAI_DEPLOYMENT", settings.azure_openai_deployment),
            ] if not v
        ]
        if missing:
            raise RuntimeError(f"Missing Azure OpenAI config: {', '.join(missing)}. Check your .env.")
        self._client = AsyncAzureOpenAI(
            api_key=settings.azure_openai_api_key,
            azure_endpoint=settings.azure_openai_endpoint,
            api_version=settings.azure_openai_api_version,
            timeout=40.0,
            max_retries=1,
        )

    def _text_deployment(self) -> str:
        return settings.azure_openai_deployment

    def _vision_deployment(self) -> str:
        return settings.azure_openai_vision_deployment or settings.azure_openai_deployment

    async def _complete(self, model: str, messages: list, max_tokens: int) -> str:
        try:
            resp = await self._client.chat.completions.create(
                model=model, messages=messages, temperature=0.2,
                max_tokens=max_tokens, response_format={"type": "json_object"},
            )
        except BadRequestError:
            # This deployment/api-version rejected json_object mode - retry
            # once with no response_format rather than hard-failing.
            resp = await self._client.chat.completions.create(
                model=model, messages=messages, temperature=0.2, max_tokens=max_tokens,
            )
        return resp.choices[0].message.content

    async def chat_json(self, system_prompt: str, user_prompt: str, timeout: float = 30.0) -> dict:
        messages = [{"role": "system", "content": system_prompt}, {"role": "user", "content": user_prompt}]
        raw = await asyncio.wait_for(self._complete(self._text_deployment(), messages, MAX_TOKENS), timeout=timeout)
        return extract_json(raw)

    async def vision_json(self, system_prompt: str, user_prompt: str, image_b64: str,
                           timeout: float = 35.0) -> dict:
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": [
                {"type": "text", "text": user_prompt},
                {"type": "image_url", "image_url": {"url": image_data_url(image_b64)}},
            ]},
        ]
        raw = await asyncio.wait_for(
            self._complete(self._vision_deployment(), messages, VISION_MAX_TOKENS), timeout=timeout,
        )
        return extract_json(raw)

    async def embed(self, texts: list[str]):
        if not settings.azure_openai_embedding_deployment:
            return None  # accuracy upgrade, not a hard requirement - callers fall back to Chroma's local embedder
        resp = await self._client.embeddings.create(
            model=settings.azure_openai_embedding_deployment, input=texts,
        )
        return [item.embedding for item in resp.data]
