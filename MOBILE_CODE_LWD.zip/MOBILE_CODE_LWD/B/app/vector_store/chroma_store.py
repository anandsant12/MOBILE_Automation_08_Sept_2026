"""
Persists one document per recorded step (its plain-English description)
so a later freeform instruction ("add a new contact") can retrieve
similar, previously-seen elements for the SAME app package as grounding
context for the LLM planner (see app/services/assist_service.py).

Embedding model used depends on LLM_PROVIDER:
  - azure (+ AZURE_OPENAI_EMBEDDING_DEPLOYMENT set): calls that deployment.
  - groq, or azure with no embedding deployment configured: falls back to
    ChromaDB's own bundled local embedding model (downloaded once, on
    first use, then cached) - Groq has no embeddings endpoint at all.
"""

import json
from pathlib import Path
from typing import Optional

import chromadb
from chromadb.api.types import EmbeddingFunction, Documents, Embeddings

from config import settings

_client = None
_collection = None


class AzureEmbeddingFunction(EmbeddingFunction):
    """Wraps an Azure OpenAI embedding deployment as a ChromaDB
    EmbeddingFunction. Newer chromadb versions persist a collection's
    embedding-function *config* alongside the data and re-validate it on
    every get_or_create_collection() call, so a real subclass (with
    name/get_config/build_from_config) is required - a bare object with
    just __call__ is rejected."""

    def __init__(self, deployment: Optional[str] = None):
        self._deployment = deployment or settings.azure_openai_embedding_deployment
        from openai import AzureOpenAI
        self._client = AzureOpenAI(
            api_key=settings.azure_openai_api_key,
            azure_endpoint=settings.azure_openai_endpoint,
            api_version=settings.azure_openai_api_version,
        )

    def __call__(self, input: Documents) -> Embeddings:
        resp = self._client.embeddings.create(model=self._deployment, input=list(input))
        return [d.embedding for d in resp.data]

    @staticmethod
    def name() -> str:
        return "azure_openai"

    def get_config(self) -> dict:
        return {"deployment": self._deployment}

    @staticmethod
    def build_from_config(config: dict) -> "AzureEmbeddingFunction":
        # Credentials are never part of the persisted config (only the
        # deployment name is) - rebuilt from current settings each time.
        return AzureEmbeddingFunction(deployment=config.get("deployment"))


def _get_collection():
    global _client, _collection
    if _collection is not None:
        return _collection
    persist_path = Path(settings.base_dir) / settings.chroma_persist_dir
    persist_path.mkdir(parents=True, exist_ok=True)
    _client = chromadb.PersistentClient(path=str(persist_path))

    kwargs = {"name": "ui_elements"}
    if settings.llm_provider == "azure" and settings.azure_openai_embedding_deployment:
        kwargs["embedding_function"] = AzureEmbeddingFunction()
    # else: omit embedding_function entirely - Chroma uses its bundled
    # local MiniLM ONNX model automatically (downloaded once, needs
    # internet on first use only).
    _collection = _client.get_or_create_collection(**kwargs)
    return _collection


def add_step(step_id: str, description: str, package: str, activity: str, action: str, locator: dict):
    if not description:
        return
    collection = _get_collection()
    collection.upsert(
        documents=[description],
        metadatas=[{
            "package": package or "", "activity": activity or "",
            "action": action, "locator": json.dumps(locator or {}),
        }],
        ids=[step_id],
    )


def query_similar(instruction: str, package: str, k: int = 5) -> list[dict]:
    """Best-effort retrieval - returns [] rather than raising, so a fresh
    install with an empty/uninitialized collection never blocks an
    AI-assisted run; it just proceeds with no retrieved context."""
    try:
        collection = _get_collection()
        where = {"package": package} if package else None
        results = collection.query(query_texts=[instruction], n_results=k, where=where)
    except Exception:
        return []
    docs = (results.get("documents") or [[]])[0]
    metas = (results.get("metadatas") or [[]])[0]
    out = []
    for doc, meta in zip(docs, metas):
        out.append({
            "description": doc,
            "action": meta.get("action"),
            "locator": json.loads(meta.get("locator") or "{}"),
        })
    return out
