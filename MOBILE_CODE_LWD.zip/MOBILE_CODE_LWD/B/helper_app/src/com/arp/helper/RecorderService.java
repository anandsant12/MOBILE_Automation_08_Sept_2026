package com.arp.helper;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.content.Intent;
import android.graphics.Rect;
import android.net.LocalServerSocket;
import android.net.LocalSocket;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.util.Log;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityWindowInfo;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.LinkedBlockingQueue;

/**
 * Tells the android-record-playback recorder on the computer what the user
 * interacts with, as it happens.
 *
 * The computer connects over `adb forward tcp:N localabstract:arp_helper`.
 * The protocol is newline-delimited JSON in both directions:
 *
 *  - pushed events: {"event": "click" | "long_click" | "selected" |
 *    "field_focus" | "field_text" | "field_blur" | "windows", "t": uptime ms, ...}
 *    each carrying the element involved ("node") -- read at the moment the
 *    event happens, not from a snapshot.
 *  - requests: {"id": n, "cmd": "hit" | "elements" | "windows" | "focused" | "info", ...}
 *    answered with {"id": n, "ok": true, "result": ...}.
 *
 * Only the shell user (adb) and root may connect: the stream describes
 * everything on screen, so no other app on the phone may read it.
 */
public class RecorderService extends AccessibilityService {
    static final String TAG = "ArpHelper";
    static final String SOCKET_NAME = "arp_helper";
    static final int PROTOCOL = 1;
    static final int SHELL_UID = 2000;
    static final int MAX_ELEMENTS = 600;

    private final List<Client> clients = new CopyOnWriteArrayList<>();
    private final Handler main = new Handler(Looper.getMainLooper());
    private volatile boolean running;
    private LocalServerSocket server;

    // Input-focus tracking, touched only on the main thread.
    private AccessibilityNodeInfo focusNode;
    private JSONObject focusInfo;
    private String focusOriginal;
    private String lastWindows;

    @Override
    protected void onServiceConnected() {
        AccessibilityServiceInfo info = getServiceInfo();
        info.flags |= AccessibilityServiceInfo.FLAG_INCLUDE_NOT_IMPORTANT_VIEWS
                | AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS
                | AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS;
        setServiceInfo(info);
        running = true;
        new Thread(this::serve, "arp-server").start();
        Log.i(TAG, "service connected");
    }

    @Override
    public boolean onUnbind(Intent intent) {
        running = false;
        try {
            if (server != null) server.close();
        } catch (IOException ignored) {
        }
        for (Client c : clients) c.close();
        return super.onUnbind(intent);
    }

    @Override
    public void onInterrupt() {
    }

    // ------------------------------------------------------------ events ---

    // When the app on screen last changed (content, a window, a scroll), for "quiet": playback
    // waits for the screen to settle before acting. The status bar (a clock tick) doesn't count.
    private static volatile long lastChange = 0;
    private static volatile String lastChangePackage = null;

    @Override
    public void onAccessibilityEvent(AccessibilityEvent e) {
        int type = e.getEventType();
        // A text that changes by itself (a clock ticking every second) isn't the screen moving on.
        boolean textOnly = type == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED
                && e.getContentChangeTypes() == AccessibilityEvent.CONTENT_CHANGE_TYPE_TEXT;
        if (!textOnly && (type == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED || type == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
                || type == AccessibilityEvent.TYPE_WINDOWS_CHANGED || type == AccessibilityEvent.TYPE_VIEW_SCROLLED)) {
            CharSequence pkg = e.getPackageName();
            String name = pkg == null ? "" : pkg.toString();
            if (!name.equals("com.android.systemui") && !name.equals(getPackageName())) {
                lastChange = SystemClock.uptimeMillis();
                lastChangePackage = name;
            }
        }
        if (clients.isEmpty()) return;
        try {
            switch (e.getEventType()) {
                case AccessibilityEvent.TYPE_VIEW_CLICKED:
                    emitNodeEvent("click", e);
                    checkFocus(false);
                    break;
                case AccessibilityEvent.TYPE_VIEW_LONG_CLICKED:
                    emitNodeEvent("long_click", e);
                    break;
                case AccessibilityEvent.TYPE_VIEW_SELECTED:
                    emitNodeEvent("selected", e);
                    break;
                case AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED:
                    checkFocus(true);
                    break;
                case AccessibilityEvent.TYPE_VIEW_FOCUSED:
                case AccessibilityEvent.TYPE_VIEW_TEXT_SELECTION_CHANGED:
                case AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED:
                    checkFocus(false);
                    break;
                case AccessibilityEvent.TYPE_WINDOWS_CHANGED:
                    // Android sends several of these per change; report each
                    // distinct set of windows once.
                    JSONArray list = windowsJson(sortedWindows());
                    String signature = windowsSignature(list);
                    if (!signature.equals(lastWindows)) {
                        lastWindows = signature;
                        JSONObject w = new JSONObject();
                        w.put("event", "windows");
                        w.put("t", SystemClock.uptimeMillis());
                        w.put("windows", list);
                        broadcast(w);
                    }
                    checkFocus(false);
                    break;
                default:
                    break;
            }
        } catch (Exception ex) {
            Log.w(TAG, "event handling failed", ex);
        }
    }

    private void emitNodeEvent(String name, AccessibilityEvent e) throws JSONException {
        JSONObject o = new JSONObject();
        o.put("event", name);
        o.put("t", e.getEventTime());
        o.put("package", str(e.getPackageName()));
        o.put("class", str(e.getClassName()));
        o.put("event_text", joined(e.getText()));
        AccessibilityNodeInfo src = e.getSource();
        if (src != null) o.put("node", nodeJson(src, true));
        broadcast(o);
    }

    /**
     * Report changes of the input-focused text field. A field's value is read
     * from the field itself on every text change, and once more when focus
     * leaves it -- so the value reported on blur is exactly what the field
     * holds, however fast the user typed.
     */
    private void checkFocus(boolean textChanged) throws JSONException {
        AccessibilityNodeInfo f = findFocus(AccessibilityNodeInfo.FOCUS_INPUT);
        if (f != null && !f.isEditable()) f = null;
        if (f == null ? focusNode == null : f.equals(focusNode)) {
            if (f != null) {
                focusInfo = nodeJson(f, false);
                if (textChanged) {
                    JSONObject o = new JSONObject();
                    o.put("event", "field_text");
                    o.put("t", SystemClock.uptimeMillis());
                    o.put("node", focusInfo);
                    broadcast(o);
                }
            }
            return;
        }
        if (focusNode != null) {
            // Re-read the field we're leaving: if it's still on screen this is
            // its final value; if it's gone, the last read stands.
            JSONObject last = focusNode.refresh() ? nodeJson(focusNode, true) : focusInfo;
            JSONObject o = new JSONObject();
            o.put("event", "field_blur");
            o.put("t", SystemClock.uptimeMillis());
            o.put("node", last);
            o.put("original", focusOriginal);
            broadcast(o);
        }
        focusNode = f;
        focusInfo = null;
        focusOriginal = null;
        if (f != null) {
            focusInfo = nodeJson(f, true);
            focusOriginal = focusInfo.optString("value", "");
            JSONObject o = new JSONObject();
            o.put("event", "field_focus");
            o.put("t", SystemClock.uptimeMillis());
            o.put("node", focusInfo);
            broadcast(o);
        }
    }

    private static String windowsSignature(JSONArray windows) throws JSONException {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < windows.length(); i++) {
            JSONObject w = windows.getJSONObject(i);
            sb.append(w.optInt("id")).append(w.optString("type")).append(w.optString("bounds")).append(';');
        }
        return sb.toString();
    }

    private void resetFocusTracking() {
        main.post(() -> {
            lastWindows = null;
            focusNode = null;
            focusInfo = null;
            focusOriginal = null;
            try {
                checkFocus(false);
            } catch (JSONException ignored) {
            }
        });
    }

    private void broadcast(JSONObject o) {
        String line = o.toString();
        for (Client c : clients) c.send(line);
    }

    // ---------------------------------------------------------- requests ---

    private JSONObject handle(JSONObject req) throws Exception {
        String cmd = req.optString("cmd");
        switch (cmd) {
            case "info": {
                JSONObject o = new JSONObject();
                o.put("protocol", PROTOCOL);
                o.put("sdk", Build.VERSION.SDK_INT);
                o.put("uptime", SystemClock.uptimeMillis());
                return o;
            }
            case "hit":
                return hit(req.getInt("x"), req.getInt("y"));
            case "elements":
                return elements();
            case "windows": {
                JSONObject o = new JSONObject();
                o.put("windows", windowsJson(sortedWindows()));
                return o;
            }
            case "focused": {
                JSONObject o = new JSONObject();
                AccessibilityNodeInfo f = findFocus(AccessibilityNodeInfo.FOCUS_INPUT);
                if (f != null) o.put("node", nodeJson(f, true));
                return o;
            }
            case "reset_focus":
                resetFocusTracking();
                return new JSONObject();
            case "quiet": {
                // How long the app's screen has been still.
                JSONObject o = new JSONObject();
                long now = SystemClock.uptimeMillis();
                o.put("quiet_ms", lastChange == 0 ? now : now - lastChange);
                o.put("package", lastChangePackage == null ? JSONObject.NULL : lastChangePackage);
                // And whether the app shows a loading indicator (a spinner, "Loading...").
                o.put("busy", loadingShown());
                return o;
            }
            default:
                throw new IllegalArgumentException("unknown command: " + cmd);
        }
    }

    /** The element under (x, y) in the top-most window there, read right now. */
    private JSONObject hit(int x, int y) throws JSONException {
        synchronized (RecorderService.class) {
            descIndex = null;  // descriptions are counted afresh for each touch
        }
        List<AccessibilityWindowInfo> windows = sortedWindows();
        JSONObject result = new JSONObject();
        result.put("t", SystemClock.uptimeMillis());
        result.put("windows", windowsJson(windows));
        for (AccessibilityWindowInfo w : windows) {
            Rect wb = new Rect();
            w.getBoundsInScreen(wb);
            if (!wb.contains(x, y) || w.getType() == AccessibilityWindowInfo.TYPE_ACCESSIBILITY_OVERLAY) continue;
            result.put("window", windowJson(w));
            if (w.getType() == AccessibilityWindowInfo.TYPE_INPUT_METHOD) {
                result.put("keyboard", true);
                return result;
            }
            AccessibilityNodeInfo root = w.getRoot();
            if (root == null) continue;
            Object[] touched = touchedAt(root, x, y, false);
            if (touched == null || !(Boolean) touched[1]) {
                // Nothing that handles touches under the finger, per the cached tree. Views
                // keep it current, but Compose doesn't report layout-only changes (a panel
                // sliding in, a list settling), so its cached positions can be stale: read
                // this part of the tree again, straight from the app.
                root.refresh();
                Object[] fresh = touchedAt(root, x, y, true);
                if (fresh != null && (touched == null || (Boolean) fresh[1])) touched = fresh;
            }
            if (touched == null) continue;
            AccessibilityNodeInfo best = (AccessibilityNodeInfo) touched[0];
            result.put("handled", touched[1]);
            result.put("node", nodeJson(best, true));
            AccessibilityNodeInfo target = null, control = null;
            for (AccessibilityNodeInfo n = best; n != null; n = n.getParent()) {
                if (target == null && (n.isClickable() || n.isLongClickable() || n.isCheckable() || n.isEditable())) {
                    target = n;
                }
                if (control == null && n.getViewIdResourceName() != null) control = n;
                if (target != null && control != null) break;
            }
            if (target != null) result.put("target", nodeJson(target, true));
            if (control != null) result.put("control", nodeJson(control, true));
            return result;
        }
        return result;
    }

    /**
     * The element a touch at (x, y) goes to, found the way Android dispatches
     * touches: children drawn on top first (reverse drawing order), and a
     * subtree that doesn't handle touches lets it fall through to what's drawn
     * below. So a menu drawer or bottom sheet over a screen gets the touch, not
     * the (still "visible") screen underneath. Returns the deepest element
     * under the point in the subtree that handles it -- e.g. a row's label.
     */
    private static Object[] touchedAt(AccessibilityNodeInfo root, int x, int y, boolean fresh) {
        Object[] hit = dispatch(root, x, y, 0, fresh);
        if (hit != null) return hit;
        AccessibilityNodeInfo smallest = smallestAt(root, x, y);
        return smallest == null ? null : new Object[]{smallest, false};
    }

    private static boolean blank(AccessibilityNodeInfo n) {
        return n.getChildCount() == 0 && (n.getText() == null || n.getText().toString().trim().isEmpty())
                && (n.getContentDescription() == null || n.getContentDescription().toString().trim().isEmpty());
    }

    private static boolean handlesTouch(AccessibilityNodeInfo n) {
        return n.isClickable() || n.isLongClickable() || n.isCheckable() || n.isEditable();
    }

    /** {deepest node under the point, Boolean handled} for a node containing (x, y), or null. */
    private static Object[] dispatch(AccessibilityNodeInfo n, int x, int y, int depth, boolean fresh) {
        Rect r = new Rect();
        n.getBoundsInScreen(r);
        if (depth > 60 || !n.isVisibleToUser() || !r.contains(x, y)) return null;
        List<AccessibilityNodeInfo> children = new ArrayList<>();
        List<Integer> order = new ArrayList<>();
        for (int i = 0; i < n.getChildCount(); i++) {
            AccessibilityNodeInfo c = n.getChild(i);
            if (c == null || (fresh && !c.refresh())) continue;
            children.add(c);
            order.add(i);
        }
        // Topmost first: higher drawing order, then later child.
        Integer[] idx = new Integer[children.size()];
        for (int i = 0; i < idx.length; i++) idx[i] = i;
        java.util.Arrays.sort(idx, (a, b) -> {
            int da = children.get(a).getDrawingOrder(), db = children.get(b).getDrawingOrder();
            return da != db ? Integer.compare(db, da) : Integer.compare(order.get(b), order.get(a));
        });
        // An open drawer takes every touch on it, even on parts that aren't
        // controls; nothing behind it gets them.
        CharSequence cls = n.getClassName();
        boolean drawer = cls != null && (cls.toString().contains("DrawerLayout")
                || cls.toString().contains("SlidingPaneLayout"));
        Object[] fallback = null;
        for (Integer i : idx) {
            Object[] h = dispatch(children.get(i), x, y, depth + 1, fresh);
            if (h == null) continue;
            if ((Boolean) h[1]) return h;
            // Nothing handles the touch here: it falls through to what's drawn below.
            // An empty layer on top (a transparent overlay, a spacer: no children, no
            // text) says nothing about what was touched, so content below it wins.
            if (fallback == null || (blank((AccessibilityNodeInfo) fallback[0]) && !blank((AccessibilityNodeInfo) h[0]))) {
                fallback = h;
            }
            if (drawer) break;
        }
        if (handlesTouch(n)) return new Object[]{fallback != null ? fallback[0] : n, true};
        // An empty element inside a named one (an image's unnamed drawing): the named one.
        if (fallback != null && blank((AccessibilityNodeInfo) fallback[0]) && !blankSelf(n)) fallback = null;
        return fallback != null ? fallback : new Object[]{n, false};
    }

    private static boolean blankSelf(AccessibilityNodeInfo n) {
        return (n.getText() == null || n.getText().toString().trim().isEmpty())
                && (n.getContentDescription() == null || n.getContentDescription().toString().trim().isEmpty());
    }

    private static AccessibilityNodeInfo smallestAt(AccessibilityNodeInfo root, int x, int y) {
        AccessibilityNodeInfo best = null;
        long bestArea = Long.MAX_VALUE;
        ArrayDeque<AccessibilityNodeInfo> stack = new ArrayDeque<>();
        stack.push(root);
        Rect r = new Rect();
        while (!stack.isEmpty()) {
            AccessibilityNodeInfo n = stack.pop();
            if (!n.isVisibleToUser()) continue;
            n.getBoundsInScreen(r);
            if (!r.contains(x, y)) continue;
            long area = (long) r.width() * r.height();
            if (area <= bestArea) {
                best = n;
                bestArea = area;
            }
            for (int i = n.getChildCount() - 1; i >= 0; i--) {
                AccessibilityNodeInfo c = n.getChild(i);
                if (c != null) stack.push(c);
            }
        }
        return best;
    }

    /** Elements worth checking or acting on, in every app window on screen. */
    private JSONObject elements() throws JSONException {
        JSONArray out = new JSONArray();
        List<AccessibilityWindowInfo> windows = sortedWindows();
        for (AccessibilityWindowInfo w : windows) {
            int type = w.getType();
            if (type == AccessibilityWindowInfo.TYPE_INPUT_METHOD
                    || type == AccessibilityWindowInfo.TYPE_ACCESSIBILITY_OVERLAY
                    || type == AccessibilityWindowInfo.TYPE_SYSTEM) continue;
            AccessibilityNodeInfo root = w.getRoot();
            if (root == null) continue;
            ArrayDeque<AccessibilityNodeInfo> queue = new ArrayDeque<>();
            queue.add(root);
            while (!queue.isEmpty() && out.length() < MAX_ELEMENTS) {
                AccessibilityNodeInfo n = queue.poll();
                if (!n.isVisibleToUser()) continue;
                boolean named = n.getViewIdResourceName() != null || n.getContentDescription() != null
                        || (n.getText() != null && n.getText().length() > 0);
                boolean actionable = n.isClickable() || n.isEditable() || n.isCheckable();
                if (named || actionable) out.put(nodeJson(n, !named, false));
                for (int i = 0; i < n.getChildCount(); i++) {
                    AccessibilityNodeInfo c = n.getChild(i);
                    if (c != null) queue.add(c);
                }
            }
        }
        JSONObject o = new JSONObject();
        o.put("elements", out);
        o.put("windows", windowsJson(windows));
        return o;
    }

    private List<AccessibilityWindowInfo> sortedWindows() {
        List<AccessibilityWindowInfo> windows = new ArrayList<>(getWindows());
        Collections.sort(windows, (a, b) -> Integer.compare(b.getLayer(), a.getLayer()));
        return windows;
    }

    // ------------------------------------------------------ serialization ---

    private static String str(CharSequence s) {
        return s == null ? null : s.toString();
    }

    private static String joined(List<CharSequence> parts) {
        if (parts == null || parts.isEmpty()) return null;
        StringBuilder sb = new StringBuilder();
        for (CharSequence p : parts) {
            if (p == null) continue;
            if (sb.length() > 0) sb.append(' ');
            sb.append(p);
        }
        return sb.toString();
    }

    private static String boundsStr(Rect r) {
        return "[" + r.left + "," + r.top + "][" + r.right + "," + r.bottom + "]";
    }

    private static JSONObject windowJson(AccessibilityWindowInfo w) throws JSONException {
        JSONObject o = new JSONObject();
        Rect r = new Rect();
        w.getBoundsInScreen(r);
        o.put("id", w.getId());
        o.put("type", windowType(w.getType()));
        o.put("layer", w.getLayer());
        o.put("bounds", boundsStr(r));
        o.put("title", str(w.getTitle()));
        o.put("active", w.isActive());
        AccessibilityNodeInfo root = w.getRoot();
        if (root != null) o.put("package", str(root.getPackageName()));
        return o;
    }

    private static JSONArray windowsJson(List<AccessibilityWindowInfo> windows) throws JSONException {
        JSONArray a = new JSONArray();
        for (AccessibilityWindowInfo w : windows) a.put(windowJson(w));
        return a;
    }

    private static String windowType(int type) {
        switch (type) {
            case AccessibilityWindowInfo.TYPE_APPLICATION: return "application";
            case AccessibilityWindowInfo.TYPE_INPUT_METHOD: return "input_method";
            case AccessibilityWindowInfo.TYPE_SYSTEM: return "system";
            case AccessibilityWindowInfo.TYPE_ACCESSIBILITY_OVERLAY: return "accessibility_overlay";
            case AccessibilityWindowInfo.TYPE_SPLIT_SCREEN_DIVIDER: return "split_screen_divider";
            default: return "other";
        }
    }

    static JSONObject nodeJson(AccessibilityNodeInfo n, boolean withXpath) throws JSONException {
        return nodeJson(n, withXpath, withXpath);
    }

    /**
     * An element's attributes; with `withContext`, also what surrounds it (see
     * contextJson) -- kept so a test can still find it when its id or text
     * changes in a later build ("self-healing").
     */
    static JSONObject nodeJson(AccessibilityNodeInfo n, boolean withXpath, boolean withContext) throws JSONException {
        JSONObject o = new JSONObject();
        Rect r = new Rect();
        n.getBoundsInScreen(r);
        String text = str(n.getText());
        boolean showingHint = Build.VERSION.SDK_INT >= 26 && n.isShowingHintText();
        o.put("resource_id", n.getViewIdResourceName());
        o.put("text", text);
        o.put("value", showingHint || text == null ? "" : text);
        o.put("content_desc", str(n.getContentDescription()));
        o.put("class_name", str(n.getClassName()));
        o.put("package", str(n.getPackageName()));
        if (Build.VERSION.SDK_INT >= 26) o.put("hint", str(n.getHintText()));
        o.put("showing_hint", showingHint);
        o.put("bounds", boundsStr(r));
        o.put("window_id", n.getWindowId());
        o.put("clickable", n.isClickable());
        o.put("long_clickable", n.isLongClickable());
        o.put("checkable", n.isCheckable());
        o.put("checked", n.isChecked());
        o.put("enabled", n.isEnabled());
        o.put("focused", n.isFocused());
        o.put("selected", n.isSelected());
        o.put("editable", n.isEditable());
        o.put("password", n.isPassword());
        o.put("scrollable", n.isScrollable());
        o.put("child_count", n.getChildCount());
        if (withXpath) o.put("xpath", structuralXpath(n));
        if (withContext) {
            o.put("context", contextJson(n));
            // How many elements on screen share this id (list rows and grid tiles usually do):
            // a shared id can't find this one element on its own.
            // Likewise for its text and description (the same "Pay" in two sections).
            // Each is one lookup done inside the app, so this stays fast.
            if (n.getViewIdResourceName() != null) o.put("id_count", idCount(n, n.getViewIdResourceName()));
            // Counted per attribute, as each locator matches: an accessibility id only looks at
            // descriptions, a text locator only at texts -- a tile described "Pay" with a "Pay"
            // label inside it is one element to find, not two.
            if (text != null && !text.trim().isEmpty()) o.put("text_count", textCount(n, text, MATCH_TEXT));
            CharSequence desc = n.getContentDescription();
            if (desc != null && desc.length() > 0) o.put("desc_count", textCount(n, desc.toString(), MATCH_DESC));
            // And the two together: same id *and* same text/description.
            String name = text != null && !text.trim().isEmpty() ? text : (desc == null ? null : desc.toString());
            if (n.getViewIdResourceName() != null && name != null && !name.trim().isEmpty()) {
                AccessibilityNodeInfo root = windowRoot(n);
                if (root != null) {
                    String want = normalized(name);
                    int both = 0;
                    for (AccessibilityNodeInfo m : root.findAccessibilityNodeInfosByViewId(n.getViewIdResourceName())) {
                        if (m.isVisibleToUser() && (want.equals(normalized(m.getText()))
                                || want.equals(normalized(m.getContentDescription())))) both++;
                    }
                    if (both > 0) o.put("id_text_count", both);
                }
            }
        }
        return o;
    }

    private static AccessibilityNodeInfo windowRoot(AccessibilityNodeInfo n) {
        AccessibilityWindowInfo w = n.getWindow();
        return w == null ? null : w.getRoot();
    }

    /** Visible elements in n's window with this id; -1 if unknown. */
    private static int idCount(AccessibilityNodeInfo n, String id) {
        AccessibilityNodeInfo root = windowRoot(n);
        if (root == null) return -1;
        int count = 0;
        for (AccessibilityNodeInfo m : root.findAccessibilityNodeInfosByViewId(id)) {
            if (m.isVisibleToUser()) count++;
        }
        return count;
    }

    private static String normalized(CharSequence s) {
        return s == null ? "" : s.toString().trim().replaceAll("\\s+", " ");
    }

    private static final int MATCH_TEXT = 1, MATCH_DESC = 2, MATCH_EITHER = 3;

    /**
     * Visible elements in n's window whose text (MATCH_TEXT), description (MATCH_DESC) or
     * either (MATCH_EITHER) is `value`, compared with spacing normalized; -1 if unknown.
     * For MATCH_EITHER, elements nested in n or around it count as n itself (a row whose
     * description repeats the label inside it). The search uses the first line only: the
     * lookup is a plain "contains", and a multi-line text never contains its normalized form.
     */
    private static int textCount(AccessibilityNodeInfo n, String value, int match) {
        // A count is extra information: if reading the screen fails midway (it changed under
        // us), the count is unknown -- it must never fail the lookup it's part of.
        try {
            return countMatches(n, value, match);
        } catch (RuntimeException e) {
            return -1;
        }
    }

    private static int countMatches(AccessibilityNodeInfo n, String value, int match) {
        AccessibilityNodeInfo root = windowRoot(n);
        String want = normalized(value);
        if (root == null || want.isEmpty()) return -1;
        String probe = value.trim();
        int nl = probe.indexOf('\n');
        if (nl > 0) probe = probe.substring(0, nl).trim();
        if (probe.isEmpty()) probe = want;
        int count = 0;
        boolean self = false;
        for (AccessibilityNodeInfo m : root.findAccessibilityNodeInfosByText(probe)) {
            if (!m.isVisibleToUser()) continue;
            boolean byText = want.equals(normalized(m.getText()));
            boolean byDesc = want.equals(normalized(m.getContentDescription()));
            if (!((match & MATCH_TEXT) != 0 && byText) && !((match & MATCH_DESC) != 0 && byDesc)) continue;
            if (match == MATCH_EITHER && nested(n, m)) {
                if (!self) count++;
                self = true;
                continue;
            }
            count++;
        }
        if (count == 0 && match == MATCH_DESC) count = descCount(root, want);
        return count == 0 ? -1 : count;
    }

    /**
     * Visible elements whose description is `want`, by walking the window: the text search
     * doesn't look at descriptions in every app (React Native views aren't found by them).
     */
    private static synchronized int descCount(AccessibilityNodeInfo root, String want) {
        // One walk per touch, shared by the element, its clickable parent and its control;
        // never reused for longer than half a second (the screen moves on).
        long now = SystemClock.uptimeMillis();
        if (descIndex == null || !root.equals(descIndexRoot) || now - descIndexAt > 500) {
            descIndex = new HashMap<>();
            descIndexRoot = root;
            descIndexAt = now;
            int seen = 0;
            ArrayDeque<AccessibilityNodeInfo> queue = new ArrayDeque<>();
            queue.add(root);
            while (!queue.isEmpty() && seen++ < 3000) {
                AccessibilityNodeInfo m = queue.poll();
                if (m == null || !m.isVisibleToUser()) continue;  // nothing visible inside a hidden view
                String d = normalized(m.getContentDescription());
                if (!d.isEmpty()) descIndex.put(d, descIndex.getOrDefault(d, 0) + 1);
                for (int i = 0; i < m.getChildCount(); i++) {
                    AccessibilityNodeInfo c = m.getChild(i);
                    if (c != null) queue.add(c);  // a child can vanish mid-walk; ArrayDeque refuses null
                }
            }
        }
        Integer count = descIndex.get(want);
        return count == null ? 0 : count;
    }

    private static HashMap<String, Integer> descIndex;
    private static AccessibilityNodeInfo descIndexRoot;
    private static long descIndexAt;

    /**
     * The last short text (or description) shown before n, in reading order, skipping text
     * fields (their text is a typed value). Bounded; null if none.
     */
    private static String precedingText(AccessibilityNodeInfo n) {
        AccessibilityNodeInfo root = windowRoot(n);
        if (root == null) return null;
        try {
            String last = null;
            ArrayDeque<AccessibilityNodeInfo> stack = new ArrayDeque<>();
            stack.push(root);
            int seen = 0;
            while (!stack.isEmpty() && seen++ < 3000) {
                AccessibilityNodeInfo m = stack.pop();
                if (m.equals(n)) return last;
                if (!m.isVisibleToUser()) continue;
                if (!m.isEditable()) {
                    String t = normalized(m.getText());
                    if (t.isEmpty()) t = normalized(m.getContentDescription());
                    if (!t.isEmpty() && t.length() <= 60 && !t.endsWith("edit box")) last = t;
                }
                for (int i = m.getChildCount() - 1; i >= 0; i--) {
                    AccessibilityNodeInfo c = m.getChild(i);
                    if (c != null) stack.push(c);
                }
            }
        } catch (RuntimeException e) {
            return null;
        }
        return null;
    }

    /** A visible progress spinner, or a short "Loading" / "Please wait" / "...in progress" text, in an app window. */
    private boolean loadingShown() {
        try {
            for (AccessibilityWindowInfo w : getWindows()) {
                if (w.getType() != AccessibilityWindowInfo.TYPE_APPLICATION) continue;
                AccessibilityNodeInfo root = w.getRoot();
                if (root == null) continue;
                ArrayDeque<AccessibilityNodeInfo> queue = new ArrayDeque<>();
                queue.add(root);
                int seen = 0;
                while (!queue.isEmpty() && seen++ < 3000) {
                    AccessibilityNodeInfo m = queue.poll();
                    if (!m.isVisibleToUser()) continue;
                    CharSequence cls = m.getClassName();
                    if (cls != null && cls.toString().endsWith("ProgressBar")) return true;
                    String t = normalized(m.getText());
                    if (t.isEmpty()) t = normalized(m.getContentDescription());
                    if (!t.isEmpty() && t.length() <= 40) {
                        String l = t.toLowerCase();
                        if (l.startsWith("loading") || l.contains("please wait") || l.endsWith("in progress")) return true;
                    }
                    for (int i = 0; i < m.getChildCount(); i++) {
                        AccessibilityNodeInfo c = m.getChild(i);
                        if (c != null) queue.add(c);
                    }
                }
            }
        } catch (RuntimeException e) {
            return false;
        }
        return false;
    }

    /** Whether a and b are the same element, or one contains the other. */
    private static boolean nested(AccessibilityNodeInfo a, AccessibilityNodeInfo b) {
        if (a.equals(b)) return true;
        AccessibilityNodeInfo p = b.getParent();
        for (int i = 0; p != null && i < 12; i++, p = p.getParent()) if (p.equals(a)) return true;
        p = a.getParent();
        for (int i = 0; p != null && i < 12; i++, p = p.getParent()) if (p.equals(b)) return true;
        return false;
    }

    private static final int MAX_CONTEXT_TEXTS = 6;

    /**
     * What surrounds an element, read at the moment it's reported: the nearest
     * ancestors that have a name (the card, section or list row it's in), the
     * text inside it (a button's label), the text beside it (a field's label, an
     * icon's caption), the element that labels it, and its place among its
     * siblings. Bounded, so it costs a few milliseconds.
     */
    private static JSONObject contextJson(AccessibilityNodeInfo n) throws JSONException {
        JSONObject o = new JSONObject();
        JSONArray ancestors = new JSONArray();
        AccessibilityNodeInfo p = n.getParent();
        for (int depth = 0; p != null && depth < 8 && ancestors.length() < 3; depth++, p = p.getParent()) {
            JSONObject named = identity(p);
            if (named != null) {
                // Whether this container (a section, a card) can itself be found uniquely.
                if (p.getViewIdResourceName() != null) named.put("id_count", idCount(p, p.getViewIdResourceName()));
                ancestors.put(named);
            }
        }
        o.put("ancestors", ancestors);
        List<String> inner = new ArrayList<>();
        for (int i = 0; i < n.getChildCount(); i++) collectTexts(n.getChild(i), 3, inner);
        o.put("inner_text", new JSONArray(inner));
        // A text field's label is often not beside it but somewhere before it in the form
        // ("Payee Account Number :" above the field's own box): the last text before it.
        if (n.isEditable()) {
            String before = precedingText(n);
            if (before != null) o.put("preceding_text", before);
        }
        // How many elements on screen show the label inside it (e.g. two tiles both saying "Pay").
        if (!inner.isEmpty()) o.put("label_count", textCount(n, inner.get(0), MATCH_EITHER));
        AccessibilityNodeInfo parent = n.getParent();
        List<String> siblings = new ArrayList<>();
        if (parent != null) {
            int index = 0, count = 0;
            for (int i = 0; i < parent.getChildCount(); i++) {
                AccessibilityNodeInfo c = parent.getChild(i);
                if (c == null || !c.isVisibleToUser()) continue;
                count++;
                if (c.equals(n)) index = count;
                else collectTexts(c, 2, siblings);
            }
            o.put("index", index);
            o.put("sibling_count", count);
            o.put("parent_class", str(parent.getClassName()));
        }
        o.put("sibling_text", new JSONArray(siblings));
        AccessibilityNodeInfo label = n.getLabeledBy();
        if (label != null) o.put("labeled_by", firstText(label));
        return o;
    }

    private static JSONObject identity(AccessibilityNodeInfo n) throws JSONException {
        String id = n.getViewIdResourceName(), desc = str(n.getContentDescription()), text = str(n.getText());
        if (text != null && text.trim().length() > 60) text = null;
        if (id == null && (desc == null || desc.trim().isEmpty()) && (text == null || text.trim().isEmpty())) return null;
        JSONObject o = new JSONObject();
        o.put("class_name", str(n.getClassName()));
        o.put("resource_id", id);
        o.put("content_desc", desc);
        o.put("text", text);
        return o;
    }

    private static String firstText(AccessibilityNodeInfo n) {
        List<String> out = new ArrayList<>();
        collectTexts(n, 2, out);
        return out.isEmpty() ? null : out.get(0);
    }

    /** Visible text and descriptions in a subtree, breadth-first, up to MAX_CONTEXT_TEXTS. */
    private static void collectTexts(AccessibilityNodeInfo root, int maxDepth, List<String> out) {
        if (root == null) return;
        ArrayDeque<AccessibilityNodeInfo> queue = new ArrayDeque<>();
        ArrayDeque<Integer> depths = new ArrayDeque<>();
        queue.add(root);
        depths.add(0);
        while (!queue.isEmpty() && out.size() < MAX_CONTEXT_TEXTS) {
            AccessibilityNodeInfo c = queue.poll();
            int depth = depths.poll();
            if (!c.isVisibleToUser()) continue;
            for (CharSequence s : new CharSequence[]{c.getText(), c.getContentDescription()}) {
                if (s == null) continue;
                String t = s.toString().trim().replaceAll("\\s+", " ");
                if (!t.isEmpty() && t.length() <= 60 && !out.contains(t) && out.size() < MAX_CONTEXT_TEXTS) out.add(t);
            }
            if (depth >= maxDepth) continue;
            for (int i = 0; i < c.getChildCount(); i++) {
                AccessibilityNodeInfo child = c.getChild(i);
                if (child != null) {
                    queue.add(child);
                    depths.add(depth + 1);
                }
            }
        }
    }

    /** Tag names as Appium's UiAutomator2 page source writes them. */
    private static String tag(AccessibilityNodeInfo n) {
        CharSequence cls = n.getClassName();
        String s = cls == null ? "android.view.View" : cls.toString().replaceAll("[^A-Za-z0-9._-]", "_");
        return s.isEmpty() ? "android.view.View" : s;
    }

    /**
     * Class + same-class sibling index path from the window root, matching
     * the structure of Appium's page source (which lists visible children only).
     */
    private static String structuralXpath(AccessibilityNodeInfo node) {
        List<String> parts = new ArrayList<>();
        AccessibilityNodeInfo cur = node;
        int guard = 0;
        while (cur != null && guard++ < 200) {
            AccessibilityNodeInfo parent = cur.getParent();
            String cls = tag(cur);
            if (parent == null) {
                parts.add(cls);
                break;
            }
            int index = 0, count = 0;
            for (int i = 0; i < parent.getChildCount(); i++) {
                AccessibilityNodeInfo c = parent.getChild(i);
                if (c == null || !c.isVisibleToUser() || !tag(c).equals(cls)) continue;
                count++;
                if (c.equals(cur)) index = count;
            }
            parts.add(cls + "[" + (index == 0 ? 1 : index) + "]");
            cur = parent;
        }
        Collections.reverse(parts);
        return "//" + String.join("/", parts);
    }

    // ------------------------------------------------------------ socket ---

    private void serve() {
        try {
            server = new LocalServerSocket(SOCKET_NAME);
        } catch (IOException e) {
            Log.e(TAG, "cannot open socket " + SOCKET_NAME, e);
            return;
        }
        while (running) {
            try {
                LocalSocket s = server.accept();
                int uid = s.getPeerCredentials().getUid();
                if (uid != SHELL_UID && uid != 0) {
                    Log.w(TAG, "rejected connection from uid " + uid);
                    s.close();
                    continue;
                }
                Client c = new Client(s);
                clients.add(c);
                c.start();
                resetFocusTracking();
            } catch (IOException e) {
                if (running) Log.w(TAG, "accept failed", e);
            }
        }
    }

    private class Client {
        final LocalSocket socket;
        final LinkedBlockingQueue<String> outbox = new LinkedBlockingQueue<>();
        volatile boolean open = true;

        Client(LocalSocket socket) {
            this.socket = socket;
        }

        void start() {
            new Thread(this::readLoop, "arp-client-read").start();
            new Thread(this::writeLoop, "arp-client-write").start();
        }

        void send(String line) {
            if (open) outbox.offer(line);
        }

        void close() {
            if (!open) return;
            open = false;
            clients.remove(this);
            outbox.offer("");
            try {
                socket.close();
            } catch (IOException ignored) {
            }
        }

        void readLoop() {
            try (BufferedReader in = new BufferedReader(
                    new InputStreamReader(socket.getInputStream(), StandardCharsets.UTF_8))) {
                String line;
                while (open && (line = in.readLine()) != null) {
                    if (line.trim().isEmpty()) continue;
                    JSONObject reply = new JSONObject();
                    try {
                        JSONObject req = new JSONObject(line);
                        reply.put("id", req.opt("id"));
                        reply.put("ok", true);
                        reply.put("result", handle(req));
                    } catch (Exception e) {
                        try {
                            reply.put("ok", false);
                            reply.put("error", String.valueOf(e));
                        } catch (JSONException ignored) {
                        }
                    }
                    send(reply.toString());
                }
            } catch (IOException ignored) {
            } finally {
                close();
            }
        }

        void writeLoop() {
            try {
                OutputStream out = socket.getOutputStream();
                while (open) {
                    String line = outbox.take();
                    if (!open) break;
                    out.write((line + "\n").getBytes(StandardCharsets.UTF_8));
                    out.flush();
                }
            } catch (Exception ignored) {
            } finally {
                close();
            }
        }
    }
}
