"""Build the recorder helper APK without Gradle.

Needs a JDK (Android Studio's bundled one is found automatically) and an
Android SDK with build-tools and one platform installed. Output:
helper_app/build/arp-helper.apk

    python helper_app/build.py
"""

import os
import re
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
BUILD = HERE / "build"
APK = BUILD / "arp-helper.apk"
VERSION_FILE = BUILD / "arp-helper.version"
MIN_SDK = 26
TARGET_SDK = 35
KEY_ALIAS = "arp-helper"
KEY_PASS = "arp-helper"

JDK_CANDIDATES = [
    os.environ.get("JAVA_HOME"),
    r"C:\Program Files\Android\Android Studio\jbr",
    "/Applications/Android Studio.app/Contents/jbr/Contents/Home",
    "/opt/android-studio/jbr",
]


def _exe(name):
    return name + (".exe" if os.name == "nt" else "")


def find_jdk():
    for home in JDK_CANDIDATES:
        if home and (Path(home) / "bin" / _exe("javac")).exists():
            return Path(home)
    raise SystemExit("No JDK found: set JAVA_HOME (Android Studio's 'jbr' folder works).")


def find_sdk():
    for home in (os.environ.get("ANDROID_HOME"), os.environ.get("ANDROID_SDK_ROOT"),
                 Path.home() / "AppData/Local/Android/Sdk", Path.home() / "Library/Android/sdk",
                 Path.home() / "Android/Sdk"):
        if home and (Path(home) / "build-tools").exists():
            sdk = Path(home)
            build_tools = max((sdk / "build-tools").iterdir(), key=lambda p: [int(x) for x in p.name.split(".")
                                                                             if x.isdigit()])
            platform = max((sdk / "platforms").iterdir(), key=lambda p: p.name)
            return build_tools, platform / "android.jar"
    raise SystemExit("No Android SDK found: set ANDROID_HOME.")


def run(args, env=None):
    result = subprocess.run([str(a) for a in args], capture_output=True, text=True, env=env)
    if result.returncode != 0:
        raise SystemExit(f"{Path(str(args[0])).name} failed:\n{result.stdout}\n{result.stderr}")
    return result


def build():
    jdk = find_jdk()
    build_tools, android_jar = find_sdk()
    env = dict(os.environ, JAVA_HOME=str(jdk), PATH=str(jdk / "bin") + os.pathsep + os.environ.get("PATH", ""))

    def tool(name):
        # d8 and apksigner are Java launcher scripts; the rest are native binaries.
        if name in ("d8", "apksigner"):
            return build_tools / (name + (".bat" if os.name == "nt" else ""))
        return build_tools / _exe(name)

    if BUILD.exists():
        shutil.rmtree(BUILD)
    classes, dex = BUILD / "classes", BUILD / "dex"
    for d in (classes, dex):
        d.mkdir(parents=True)

    compiled = BUILD / "res.zip"
    run([tool("aapt2"), "compile", "--dir", HERE / "res", "-o", compiled])
    unsigned = BUILD / "unsigned.apk"
    run([tool("aapt2"), "link", "-o", unsigned, "-I", android_jar, "--manifest", HERE / "AndroidManifest.xml",
         "--min-sdk-version", MIN_SDK, "--target-sdk-version", TARGET_SDK, compiled])

    sources = sorted((HERE / "src").rglob("*.java"))
    run([jdk / "bin" / _exe("javac"), "-source", "11", "-target", "11", "-nowarn", "-Xlint:-options",
         "-classpath", android_jar, "-d", classes, *sources], env=env)
    run([tool("d8"), "--min-api", MIN_SDK, "--lib", android_jar, "--output", dex,
         *sorted(classes.rglob("*.class"))], env=env)
    with zipfile.ZipFile(unsigned, "a") as apk:
        apk.write(dex / "classes.dex", "classes.dex")

    aligned = BUILD / "aligned.apk"
    run([tool("zipalign"), "-f", "4", unsigned, aligned])

    keystore = HERE / "debug.keystore"
    if not keystore.exists():
        run([jdk / "bin" / _exe("keytool"), "-genkeypair", "-keystore", keystore, "-storepass", KEY_PASS,
             "-keypass", KEY_PASS, "-alias", KEY_ALIAS, "-keyalg", "RSA", "-keysize", "2048", "-validity", "10000",
             "-dname", "CN=android-record-playback helper"], env=env)
    run([tool("apksigner"), "sign", "--ks", keystore, "--ks-pass", f"pass:{KEY_PASS}", "--ks-key-alias", KEY_ALIAS,
         "--out", APK, aligned], env=env)
    # Lets the tool tell whether this APK is current without re-reading it.
    version = re.search(r'android:versionCode="(\d+)"', (HERE / "AndroidManifest.xml").read_text(encoding="utf-8-sig"))
    VERSION_FILE.write_text(version.group(1), encoding="utf-8")
    return APK


if __name__ == "__main__":
    print(build())
    sys.exit(0)
