"""
Mock-driver validation for the two fixes in this update - no live device
needed, same pattern this project has already used for prior sessions'
changes (see area memory notes). Not part of the shipped app; just a
one-off sanity script.

Scenario 1: a header icon (like the SBI Card screen's headphone/support
icon) with NO text/content-desc/resource-id anywhere in itself or its
children - confirms it now gets a positional label instead of vanishing
from get_state() entirely.

Scenario 2: a scrollable list of "Apply Now" cards (ELITE / PULSE / AURUM,
matching the two attached screenshots) where every button shares the exact
same text - confirms _enrich_duplicate_context correctly tags each button
with its OWN card's title, and that the resolver's ambiguity check would
now defer a same-scoring duplicate pair to the LLM tier instead of
blind-accepting the first one found.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from app.automation import page_state as ps


class MockElement:
    def __init__(self, attrs: dict, children=None):
        self._attrs = attrs
        self._children = children or []

    def get_attribute(self, name):
        return self._attrs.get(name)

    def find_elements(self, by, xpath):
        # Extremely small stand-in: just returns children flagged as
        # matching (real XPath semantics aren't needed for this check).
        return self._children


class MockDriver:
    def __init__(self, all_elements, window_size=(1080, 2280)):
        self._all_elements = all_elements
        self._window_size = window_size

    def find_elements(self, by, xpath):
        # Simulate the two xpath filters used in page_state.py.
        if xpath == ps.ANDROID_INTERACTIVE_XPATH:
            interactive_classes = ("EditText", "Button", "Spinner", "CheckBox", "RadioButton", "Switch")
            return [e for e in self._all_elements if e._attrs.get("clickable") == "true"
                    or e._attrs.get("checkable") == "true"
                    or any(c in e._attrs.get("className", "") for c in interactive_classes)]
        if xpath == ps.ANDROID_TEXT_XPATH:
            return [e for e in self._all_elements
                    if e._attrs.get("text") or e._attrs.get("content-desc")]
        return []

    def get_window_size(self):
        return {"width": self._window_size[0], "height": self._window_size[1]}


def make_el(bounds, clickable="false", text="", desc="", rid="", cls="android.view.View", children=None):
    return MockElement({
        "text": text, "content-desc": desc, "resource-id": rid, "className": cls,
        "checkable": "false", "checked": "false", "clickable": clickable,
        "enabled": "true", "bounds": bounds,
    }, children=children)


def bounds_str(x1, y1, x2, y2):
    return f"[{x1},{y1}][{x2},{y2}]"


print("=== Scenario 1: unlabeled top-right header icon ===")
# A raw ImageView headphone icon: clickable, but genuinely no text/desc/
# resource-id anywhere on it or any child - the exact shape of the bug.
headphone_icon = make_el(bounds_str(985, 40, 1050, 100), clickable="true")
back_arrow = make_el(bounds_str(20, 40, 80, 100), clickable="true", desc="Back")
driver1 = MockDriver([headphone_icon, back_arrow])

state_text, ref_map, attrs_map = ps.get_state(driver1)
print(state_text)
assert len(ref_map) == 2, f"expected both elements to survive the scan, got {len(ref_map)}"
icon_ref = [r for r, a in attrs_map.items() if a["desc"].startswith("(icon button")][0]
print(f"-> headphone icon surfaced as {icon_ref}: {attrs_map[icon_ref]['desc']!r}")
assert "top-right" in attrs_map[icon_ref]["desc"], "expected a top-right positional label"
print("PASS: unlabeled icon now surfaces with a matchable positional label\n")


print("=== Scenario 2: three 'Apply Now' cards (ELITE / PULSE / AURUM) ===")
elite_title = make_el(bounds_str(600, 660, 1000, 700), text="SBI Card ELITE")
elite_btn = make_el(bounds_str(70, 1100, 1000, 1200), clickable="true", text="Apply Now", rid="com.sbi.lotusintouch:id/btnApplyNow")

pulse_title = make_el(bounds_str(600, 1450, 1000, 1490), text="SBI Card PULSE")
pulse_btn = make_el(bounds_str(70, 1900, 1000, 2000), clickable="true", text="Apply Now", rid="com.sbi.lotusintouch:id/btnApplyNow")

aurum_title = make_el(bounds_str(600, 2200, 1000, 2240), text="SBI Card AURUM")
aurum_btn = make_el(bounds_str(70, 2650, 1000, 2750), clickable="true", text="Apply Now", rid="com.sbi.lotusintouch:id/btnApplyNow")

all_els = [elite_title, elite_btn, pulse_title, pulse_btn, aurum_title, aurum_btn]
driver2 = MockDriver(all_els)

state_text2, ref_map2, attrs_map2 = ps.get_state(driver2)
print(state_text2)

# Find the three Apply Now button refs and check each got the RIGHT card's
# own context attached (not another card's, not the generic shared text).
btn_refs = [r for r, a in attrs_map2.items() if a["text"] == "Apply Now"]
assert len(btn_refs) == 3, f"expected 3 Apply Now buttons, found {len(btn_refs)}"
by_context = {r: attrs_map2[r].get("context", "") for r in btn_refs}
print("context per button:", by_context)

aurum_ref = [r for r, ctx in by_context.items() if "AURUM" in ctx][0]
elite_ref = [r for r, ctx in by_context.items() if "ELITE" in ctx][0]
pulse_ref = [r for r, ctx in by_context.items() if "PULSE" in ctx][0]
assert "AURUM" not in by_context[elite_ref] and "PULSE" not in by_context[elite_ref]
assert "ELITE" not in by_context[aurum_ref] and "PULSE" not in by_context[aurum_ref]
print("PASS: each Apply Now button correctly tagged with its OWN card's title only\n")

# Now confirm resolver.py's fuzzy tier picks the AURUM button (not the
# first/ELITE one) for a description naming AURUM, and that a genuinely
# ambiguous case (no qualifying detail at all) gets deferred to the LLM
# tier rather than blind-accepted.
from app.automation import resolver as res

scored = res._fuzzy_scores("Apply Now button for SBI Card AURUM", attrs_map2)
top_ref, top_score = scored[0]
print(f"fuzzy top pick for 'AURUM' query: {top_ref} (score={top_score}), "
      f"expected ref={aurum_ref}")
assert top_ref == aurum_ref, "fuzzy tier should now favour the AURUM card's own button"
assert not res._is_ambiguous(scored, attrs_map2), (
    "a clearly-qualified description (names AURUM specifically) should NOT "
    "be treated as ambiguous - context gave it a decisive margin"
)
print("PASS: fuzzy tier resolves directly to the correct card's button, "
      "confidently (no unnecessary LLM call needed)\n")

# And a generic, unqualified "Apply Now" query (no card named) SHOULD be
# flagged ambiguous, since nothing distinguishes the three at that point -
# this is the safety net for cases context enrichment alone can't resolve.
scored_generic = res._fuzzy_scores("Apply Now", attrs_map2)
assert res._is_ambiguous(scored_generic, attrs_map2), (
    "an unqualified 'Apply Now' query across 3 duplicate buttons should be "
    "flagged ambiguous and deferred to the LLM tier, not blind-accepted"
)
print("PASS: unqualified duplicate-label query correctly flagged ambiguous "
      "(safety net working)\n")

print("ALL SCENARIOS PASSED")

print("=== Regression checks (earlier fixes still intact) ===")

# 1. Blank EditText still gets its placeholder label.
blank_input = make_el(bounds_str(50, 500, 1000, 600), clickable="false", cls="android.widget.EditText")
blank_input._attrs["checkable"] = "false"
driver3 = MockDriver([blank_input])
_, ref_map3, attrs_map3 = ps.get_state(driver3)
assert len(ref_map3) == 1
assert attrs_map3["E0"]["desc"] == "(empty input field)"
print("PASS: blank EditText placeholder still works")

# 2. A clickable row whose ONLY child has real TEXT (country-picker style)
# still borrows the child's text, even though the xpath now also matches
# resource-id-only nodes - text/desc must still win over a resource-id
# fallback when both are available among descendants.
country_text_child = make_el(bounds_str(150, 800, 900, 860), text="Canada")
country_row = make_el(bounds_str(50, 780, 1000, 880), clickable="true", children=[country_text_child])
driver4 = MockDriver([country_row])
_, ref_map4, attrs_map4 = ps.get_state(driver4)
assert attrs_map4["E0"]["desc"] == "Canada", attrs_map4["E0"]
print("PASS: clickable row still borrows a child's real TEXT correctly")

# 3. A clickable row whose only child has a resource-id but NO text/desc -
# new capability: falls back to that resource-id.
icon_child = make_el(bounds_str(150, 800, 220, 860), rid="com.sbi.lotusintouch:id/ivSupport")
icon_row = make_el(bounds_str(50, 780, 260, 880), clickable="true", children=[icon_child])
driver5 = MockDriver([icon_row])
_, ref_map5, attrs_map5 = ps.get_state(driver5)
assert attrs_map5["E0"]["desc"] == "ivSupport", attrs_map5["E0"]
print("PASS: clickable row with only a resource-id'd child now surfaces via that id")

# 4. A single (non-duplicate) button should NOT get a ctx= tag - enrichment
# must stay a no-op on ordinary screens.
lone_btn = make_el(bounds_str(70, 1100, 1000, 1200), clickable="true", text="Continue")
driver6 = MockDriver([lone_btn])
state6, _, attrs_map6 = ps.get_state(driver6)
assert "context" not in attrs_map6["E0"]
assert "ctx=" not in state6
print("PASS: non-duplicate elements are untouched by context enrichment")

print("\nALL REGRESSION CHECKS PASSED")

print("=== Scenario 3: click() reports success but nothing happens (headphone icon) ===")
from app.automation import action_executor as ae
from app.automation.locator_engine import ResolvedTarget


class MockClickElement:
    """Simulates a real icon-only view whose semantic .click() (the
    accessibility-style click Selenium/UiAutomator2 performs) is a no-op -
    the exact failure mode reported: Appium raises no exception, but the
    app never reacts. Only a raw coordinate gesture (mobile: clickGesture)
    actually flips the driver's on-screen state."""
    def __init__(self):
        self.click_called = False

    def click(self):
        self.click_called = True  # no exception - but driver state below is untouched


class MockClickDriver:
    def __init__(self, gesture_actually_works: bool):
        self._state = "before"
        self._gesture_actually_works = gesture_actually_works
        self.gesture_calls = 0

    @property
    def page_source(self):
        return f"<hierarchy state='{self._state}'></hierarchy>"

    def execute_script(self, name, args):
        assert name == "mobile: clickGesture"
        self.gesture_calls += 1
        if self._gesture_actually_works:
            self._state = "after"


# 3a: .click() is a dead no-op, but the coordinate-tap retry DOES work
# (the real headphone-icon scenario, once execute_click's retry logic is
# exercised) - execute_click should end up reporting a real change.
driver_a = MockClickDriver(gesture_actually_works=True)
el_a = MockClickElement()
target_a = ResolvedTarget(method="ref")
target_a.element = el_a
target_a.clickable = True
target_a.center = (1017, 70)

changed_a = ae.execute_click(driver_a, target_a, verify_effect=True)
assert el_a.click_called, "expected the primary .click() to still be attempted first"
assert driver_a.gesture_calls == 1, f"expected exactly one coordinate-tap retry, got {driver_a.gesture_calls}"
assert changed_a is True, "expected execute_click to report a real change once the retry gesture worked"
print("PASS: .click() no-op correctly recovered by the coordinate-tap retry")

# 3b: NEITHER .click() nor the coordinate retry produces any change at all
# (a genuinely broken/unreachable target) - execute_click must report this
# honestly (False), not silently claim success.
driver_b = MockClickDriver(gesture_actually_works=False)
el_b = MockClickElement()
target_b = ResolvedTarget(method="ref")
target_b.element = el_b
target_b.clickable = True
target_b.center = (1017, 70)

changed_b = ae.execute_click(driver_b, target_b, verify_effect=True)
assert changed_b is False, "expected an honest False when nothing ever visibly changed"
print("PASS: a genuinely inert tap is now honestly reported as 'no visible change', not blind success")

# 3c: verify_effect=False (default) keeps the OLD behaviour exactly -
# no page_source reads, no retry, always reports True - so every other
# existing call site (e.g. execute_select's internal clicks) is untouched.
driver_c = MockClickDriver(gesture_actually_works=False)
el_c = MockClickElement()
target_c = ResolvedTarget(method="ref")
target_c.element = el_c
target_c.clickable = True
target_c.center = (1017, 70)
result_c = ae.execute_click(driver_c, target_c)  # verify_effect defaults to False
assert result_c is True and driver_c.gesture_calls == 0
print("PASS: default (verify_effect=False) behaviour is unchanged - no extra calls, no retry")

print("\nALL CLICK-RELIABILITY CHECKS PASSED")

print("=== Scenario 4: synthetic labels are excluded from blind text matching ===")
from app.automation import resolver as res2
import asyncio as _asyncio

headphone_synth = {
    "text": "", "desc": "(icon button, top-right of screen)", "resource_id": "",
    "class": "ImageView", "checkable": False, "checked": False, "clickable": True,
    "enabled": True, "center": (1017, 70), "bounds": (985, 40, 1050, 100), "synthetic": True,
}
other_synth = {
    "text": "", "desc": "(icon button, top-right of screen)", "resource_id": "",
    "class": "ImageView", "checkable": False, "checked": False, "clickable": True,
    "enabled": True, "center": (900, 70), "bounds": (870, 40, 930, 100), "synthetic": True,
}
attrs_map_synth = {"E0": headphone_synth, "E1": other_synth}
scored_synth = res2._fuzzy_scores(
    "the headphone/support icon in the top right corner",
    {r: a for r, a in attrs_map_synth.items() if not a.get("synthetic")},
)
assert scored_synth == [], "synthetic-only screen should leave nothing eligible for blind text matching"
print("PASS: synthetic positional labels never win a blind fuzzy/text match on their own")

state_text_synth = "[E0] <ImageView>(icon button, top-right of screen)</ImageView> pos=(1017,70)\n[E1] <ImageView>(icon button, top-right of screen)</ImageView> pos=(900,70)"
filtered = res2._filter_state_text(state_text_synth, {"E0", "E1"})
assert filtered.strip() == "", f"expected all synthetic lines filtered out, got: {filtered!r}"
print("PASS: synthetic lines are correctly stripped from what the LLM tier sees\n")


print("=== Scenario 5: Set-of-Marks candidate merging + drawing ===")
from app.automation import locator_engine as le

narrow_attrs = {"E0": headphone_synth}
narrow_ref = {"E0": MockElement({})}
broad_attrs = {
    "B0": {  # same real element, re-found by the broad text scan too (no text, so actually
             # it wouldn't be in a broad scan - use a distinct element instead)
        "text": "", "desc": "Back", "resource_id": "", "class": "ImageView",
        "checkable": False, "checked": False, "clickable": True, "enabled": True,
        "center": (50, 70), "bounds": (20, 40, 80, 100), "synthetic": False,
    }
}
broad_ref = {"B0": MockElement({})}

combined_ref, combined_attrs = res2._combine_candidates(narrow_attrs, narrow_ref, broad_attrs, broad_ref)
assert len(combined_ref) == 2, f"expected 2 distinct-geometry candidates, got {len(combined_ref)}"
print("PASS: _combine_candidates merges narrow+broad scans without duplicating by geometry")

# Duplicate geometry (same bounds appearing in both scans) should collapse to ONE candidate.
combined_ref2, combined_attrs2 = res2._combine_candidates(narrow_attrs, narrow_ref, narrow_attrs, narrow_ref)
assert len(combined_ref2) == 1, f"expected geometry-based de-dup to collapse to 1, got {len(combined_ref2)}"
print("PASS: identical-geometry candidates from both scans are de-duplicated correctly")

# Draw marks on a real (tiny, synthetic) PNG and confirm a valid annotated
# image + correct mark->ref mapping comes back.
from PIL import Image
buf = __import__("io").BytesIO()
Image.new("RGB", (1080, 2280), color=(255, 255, 255)).save(buf, format="PNG")
fake_screenshot_bytes = buf.getvalue()

annotated_png, mark_to_ref = le._draw_marks(fake_screenshot_bytes, combined_attrs, (1080, 2280))
assert len(mark_to_ref) == 2, f"expected 2 marks drawn, got {len(mark_to_ref)}"
# Reading order is top-to-bottom, left-to-right: both candidates share y=40-100,
# so the leftmost (Back, x=20) should be mark 1, the rightmost (headphone, x=985) mark 2.
assert combined_attrs[mark_to_ref[1]]["desc"] == "Back"
assert combined_attrs[mark_to_ref[2]]["desc"].startswith("(icon button")
reopened = Image.open(__import__("io").BytesIO(annotated_png))
assert reopened.size == (1080, 2280)
print("PASS: _draw_marks produces a valid annotated image with correctly-ordered mark numbers\n")

print("ALL SET-OF-MARKS CHECKS PASSED")

print("=== Scenario 6: end-to-end resolve_by_vision_som (mocked vision model) ===")
import app.llm.model_client as model_client_mod
import app.utils.screenshot as screenshot_mod

_orig_achat_vision_json = model_client_mod.achat_vision_json
_orig_take_screenshot = screenshot_mod.take_screenshot

async def _fake_achat_vision_json(system_prompt, user_prompt, image_b64):
    # Simulate the model correctly picking mark 2 (the headphone icon, per
    # Scenario 5's ordering) when asked to find it.
    assert "headphone" in user_prompt.lower() or "support" in user_prompt.lower()
    return {"found": True, "mark": 2, "reasoning": "top-right icon matches"}

def _fake_take_screenshot(driver, label):
    import tempfile, os
    fd, path = tempfile.mkstemp(suffix=".png")
    os.close(fd)
    Image.new("RGB", (1080, 2280), color=(255, 255, 255)).save(path)
    return path

le.achat_vision_json = _fake_achat_vision_json
le.take_screenshot = _fake_take_screenshot

headphone_el = MockElement({"clickable": "true"})
back_el = MockElement({"clickable": "true"})

class MockSomDriver:
    def get_window_size(self):
        return {"width": 1080, "height": 2280}

driver_som = MockSomDriver()
attrs_map_som = {
    "E0": dict(headphone_synth, center=(1017, 70)),
    "E1": {
        "text": "", "desc": "Back", "resource_id": "", "class": "ImageView",
        "checkable": False, "checked": False, "clickable": True, "enabled": True,
        "center": (50, 70), "bounds": (20, 40, 80, 100), "synthetic": False,
    },
}
ref_map_som = {"E0": headphone_el, "E1": back_el}

result_target = _asyncio.run(
    le.resolve_by_vision_som(driver_som, "the headphone/support icon top right", attrs_map_som, ref_map_som)
)

le.achat_vision_json = _orig_achat_vision_json
le.take_screenshot = _orig_take_screenshot

assert result_target is not None, "expected a resolved target from the mocked SoM flow"
assert result_target.method == "ref"
assert result_target.element is headphone_el, "expected the SoM pick to map back to the REAL headphone element"
assert result_target.clickable is True
assert result_target.center == (1017, 70)
print("PASS: resolve_by_vision_som correctly maps a model's chosen mark back to the real, live element")
print("      (a real ResolvedTarget with clickable/center info - not a bare coordinate guess)")

print("\nALL END-TO-END SOM CHECKS PASSED")
