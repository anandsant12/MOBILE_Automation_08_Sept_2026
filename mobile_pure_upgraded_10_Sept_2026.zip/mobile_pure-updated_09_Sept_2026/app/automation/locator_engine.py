"""
Hybrid element resolution.

Path 1 (preferred, fast, reliable, no LLM vision call at all): a real
element from page_state.get_state()'s ref_map - a plain dict lookup, done.

Path 2 (Set-of-Marks vision grounding - see resolve_by_vision_som):
reached when text-based resolution can't confidently place a target on its
own (in particular, an icon-only control with no real accessibility label
- see page_state._positional_label's "synthetic" marking). Draws a
numbered box around every candidate element already found by the text
scanners and asks the vision model to pick a BOX NUMBER, not freehand
(x, y) coordinates. Picking an item from a small labeled list is a task
vision-language models are meaningfully more reliable and consistent at
than blind coordinate regression - especially for a small icon, where a
few pixels of error in a freehand guess can land the tap entirely outside
the real touch target. Returns a REAL ResolvedTarget tied to that actual
element (its real clickable state, its real center) - not a bare
coordinate guess - so it gets the full benefit of execute_click's
ancestor-fallback and coordinate-retry logic, and is fingerprint-cacheable
like any other "ref" resolution.

Path 3 (resolve_by_vision, below): the original raw-coordinate fallback,
used only when Set-of-Marks itself finds nothing (e.g. the true target
genuinely isn't among any of the scanned candidates at all) AND
settings.enable_vision_fallback is True.
"""

import asyncio
import base64
import io
import json
import time
from dataclasses import dataclass
from typing import Optional

from app.llm.model_client import achat_vision_json
from app.utils.screenshot import take_screenshot, screenshot_to_b64
from config import settings

VISION_SYSTEM_PROMPT = """You are looking at a screenshot of a mobile app
screen. Find the single UI element described by the user and return ONLY
JSON, no reasoning, no <think> tags, no explanation outside the JSON:
{"found": true|false, "x": 0.0-1.0, "y": 0.0-1.0, "reasoning": "short reason"}
x and y are the NORMALIZED center coordinates of the element (0,0 = top-left,
1,1 = bottom-right). If you cannot find it, set found=false and x/y to 0.
"""

SOM_SYSTEM_PROMPT = """You are looking at a screenshot of a mobile app
screen with numbered red boxes drawn around candidate UI elements. Find
the box whose element matches the user's description and return ONLY
JSON, no reasoning, no <think> tags, no explanation outside the JSON:
{"found": true|false, "mark": <the number written on that box, or null>, "reasoning": "short reason"}
Only pick a number if you are genuinely confident that box IS the
described element. If none of the numbered boxes match - the real element
isn't marked at all, or you can't tell - set found=false and mark=null.
Do NOT guess a nearby-but-wrong box just because it's close.
"""

MAX_SOM_CANDIDATES = 36
# Skip a candidate box larger than this fraction of the screen's own area -
# a near-fullscreen container (a whole list, a whole toolbar) adds visual
# clutter and no real disambiguating value as a Set-of-Marks box.
SOM_MAX_BOX_AREA_FRACTION = 0.55


@dataclass
class ResolvedTarget:
    method: str  # "ref" or "vision"
    element = None
    x_px: Optional[int] = None
    y_px: Optional[int] = None
    # Only populated for method=="ref" when the caller had this element's
    # scanned attrs on hand (see resolve_by_ref's `attrs` param). Lets
    # action_executor.execute_click detect a resolved element that ISN'T
    # itself clickable (e.g. a list row's label, found via
    # page_state.get_broad_state's fallback scan) and fall back to
    # clicking a clickable ancestor or tapping `center` directly, instead
    # of calling .click() on a node Android never marked interactive.
    clickable: Optional[bool] = None
    center: Optional[tuple] = None


def resolve_by_ref(ref: str, ref_map: dict, attrs: Optional[dict] = None) -> Optional[ResolvedTarget]:
    el = ref_map.get(ref)
    if el is None:
        return None
    target = ResolvedTarget(method="ref")
    target.element = el
    if attrs:
        target.clickable = attrs.get("clickable")
        target.center = attrs.get("center")
    return target


def _save_vision_debug(driver, tag: str, description: str, result: dict,
                        annotated_png: Optional[bytes] = None,
                        candidate_count: Optional[int] = None) -> None:
    """Saves what a vision call actually saw and said, next to the regular
    step screenshots - WITHOUT this, "the model said not found" is
    completely opaque from the outside: there's no way to tell whether the
    marked-up image had a box anywhere near the real target, whether the
    model even looked in the right place, or why. Every vision attempt
    (Set-of-Marks or raw-coordinate) now writes:
      - <ts>_<tag>_marked.png - the ACTUAL annotated image sent to the
        model (only for Set-of-Marks calls; the raw-coordinate path has no
        annotation to save, since it never draws boxes)
      - <ts>_<tag>_result.json - the description asked for, the model's
        raw JSON response (including its "reasoning"), how many
        candidates were offered (Set-of-Marks only), and the live Appium
        contexts at that moment (the same cheap WebView/hybrid-screen
        signal page_state.dump_failed_screen already checks on a
        resolution failure - if this ever shows a WEBVIEW_* context, no
        native scan could ever have found the target at all, regardless
        of how good the vision model is).
    Never raises - this is diagnostics, not something that should break a
    real resolution attempt."""
    try:
        ts = int(time.time() * 1000)
        if annotated_png is not None:
            img_path = settings.screenshot_dir / f"{ts}_{tag}_marked.png"
            img_path.write_bytes(annotated_png)

        contexts = None
        try:
            contexts = driver.contexts
        except Exception:
            pass

        payload = {
            "description": description,
            "candidate_count": candidate_count,
            "model_result": result,
            "appium_contexts": contexts,
        }
        json_path = settings.screenshot_dir / f"{ts}_{tag}_result.json"
        json_path.write_text(json.dumps(payload, indent=2, default=str), encoding="utf-8")
    except Exception:
        pass


def _draw_marks(image_bytes: bytes, candidates: dict, screen_size) -> "tuple[bytes, dict]":
    """Draws a numbered red box around every candidate (a dict of
    ref -> attrs, each attrs needing a 'bounds' (x1,y1,x2,y2) rectangle in
    device-pixel/window coordinates) onto the screenshot. Boxes are
    numbered in top-to-bottom, left-to-right reading order - both a
    natural scan order for the model and a stable one run-to-run for the
    same layout. Coordinates are scaled from window size to the actual
    screenshot's pixel size in case they differ (e.g. device pixel ratio),
    the same defensive assumption resolve_by_vision below already makes
    when converting normalized coordinates back to pixels.

    Returns (annotated_png_bytes, {mark_number: ref})."""
    from PIL import Image, ImageDraw

    img = Image.open(io.BytesIO(image_bytes)).convert("RGB")
    draw = ImageDraw.Draw(img)
    img_w, img_h = img.size
    win_w, win_h = screen_size or (img_w, img_h)
    scale_x = (img_w / win_w) if win_w else 1.0
    scale_y = (img_h / win_h) if win_h else 1.0
    screen_area = (win_w * win_h) if (win_w and win_h) else None

    usable = []
    for ref, attrs in candidates.items():
        bounds = attrs.get("bounds")
        if not bounds:
            continue
        x1, y1, x2, y2 = bounds
        if screen_area:
            area = max(x2 - x1, 0) * max(y2 - y1, 0)
            if area > SOM_MAX_BOX_AREA_FRACTION * screen_area:
                continue
        usable.append((ref, (x1, y1, x2, y2)))
    usable.sort(key=lambda item: (item[1][1], item[1][0]))
    usable = usable[:MAX_SOM_CANDIDATES]

    mark_to_ref = {}
    for i, (ref, (x1, y1, x2, y2)) in enumerate(usable, 1):
        bx1, by1, bx2, by2 = x1 * scale_x, y1 * scale_y, x2 * scale_x, y2 * scale_y
        draw.rectangle([bx1, by1, bx2, by2], outline=(255, 0, 0), width=3)
        label = str(i)
        tw = 10 * len(label) + 8
        label_y0 = max(by1 - 20, 0)
        draw.rectangle([bx1, label_y0, bx1 + tw, label_y0 + 18], fill=(255, 0, 0))
        draw.text((bx1 + 4, label_y0 + 2), label, fill=(255, 255, 255))
        mark_to_ref[i] = ref

    buf = io.BytesIO()
    img.save(buf, format="PNG")
    return buf.getvalue(), mark_to_ref


async def resolve_by_vision_som(
    driver, description: str, attrs_map: dict, ref_map: dict
) -> Optional[ResolvedTarget]:
    """Set-of-Marks visual grounding - see this module's docstring. Draws a
    numbered box around every candidate in `attrs_map` (from ANY scan -
    callers typically pass a combination of page_state.get_state()'s and
    get_broad_state()'s results) that has a 'bounds' rectangle, and asks
    the vision model to pick a box number rather than freehand coordinates.

    Returns a real ResolvedTarget(method="ref", ...) tied to the actual
    picked element when the model confidently identifies one. Returns None
    if vision fallback is disabled, there are no candidates with bounds to
    mark, or the model doesn't confidently pick a box - callers should
    fall back to resolve_by_vision (raw coordinates) in that case, for a
    target that isn't among any of the scanned candidates at all."""
    if not settings.enable_vision_fallback:
        return None

    candidates = {ref: a for ref, a in attrs_map.items() if a.get("bounds")}
    if not candidates:
        return None

    await asyncio.sleep(settings.vision_settle_pause_sec)

    screenshot_path = await asyncio.to_thread(take_screenshot, driver, "locator_som")
    with open(screenshot_path, "rb") as f:
        raw_png = f.read()
    size = await asyncio.to_thread(driver.get_window_size)
    screen_size = (size["width"], size["height"])

    try:
        annotated_png, mark_to_ref = await asyncio.to_thread(
            _draw_marks, raw_png, candidates, screen_size
        )
    except Exception:
        return None
    if not mark_to_ref:
        return None

    b64 = base64.b64encode(annotated_png).decode("utf-8")
    result = await achat_vision_json(
        SOM_SYSTEM_PROMPT,
        f"Find this element: {description}",
        b64,
    )
    await asyncio.to_thread(
        _save_vision_debug, driver, "som", description, result,
        annotated_png=annotated_png, candidate_count=len(mark_to_ref),
    )

    if not result.get("found"):
        return None
    try:
        mark = int(result.get("mark"))
    except (TypeError, ValueError):
        return None
    ref = mark_to_ref.get(mark)
    if not ref:
        return None
    return resolve_by_ref(ref, ref_map, attrs_map.get(ref))


async def resolve_by_vision(driver, description: str) -> Optional[ResolvedTarget]:
    if not settings.enable_vision_fallback:
        return None

    # Vision is always the LAST resort, reached only after native resolution
    # already failed - a brief settle pause here is cheap insurance against
    # capturing a screenshot mid-animation (e.g. a list/dialog still sliding
    # or fading in), which would otherwise make the model correctly (but
    # unhelpfully) report "not found" for something that's about to render.
    await asyncio.sleep(settings.vision_settle_pause_sec)

    screenshot_path = await asyncio.to_thread(take_screenshot, driver, "locator_fallback")
    b64 = await asyncio.to_thread(screenshot_to_b64, screenshot_path)
    size = await asyncio.to_thread(driver.get_window_size)
    width, height = size["width"], size["height"]

    result = await achat_vision_json(
        VISION_SYSTEM_PROMPT,
        f"Find this element: {description}",
        b64,
    )
    await asyncio.to_thread(_save_vision_debug, driver, "raw", description, result)

    if not result.get("found"):
        return None

    x_px = int(float(result["x"]) * width)
    y_px = int(float(result["y"]) * height)
    return ResolvedTarget(method="vision", x_px=x_px, y_px=y_px)


async def aresolve_target(driver, ref: Optional[str], ref_map: dict, description: str) -> Optional[ResolvedTarget]:
    """Fast path first (no LLM call). Only calls vision if that fails AND vision fallback is enabled."""
    if ref:
        target = resolve_by_ref(ref, ref_map)
        if target:
            return target
    return await resolve_by_vision(driver, description)
