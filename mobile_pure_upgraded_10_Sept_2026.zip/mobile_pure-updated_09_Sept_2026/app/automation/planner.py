"""
Takes the raw plain-English steps the user wrote and turns them into an
ordered list of atomic mobile actions, each with a target description and
(where applicable) an expected outcome for the verifier to check.

This runs EXACTLY ONCE per run, up front - it does NOT re-plan step by
step. That is the deliberate fix for the "agent keeps doing things I never
asked for" problem: instead of asking the model "what's the single next
action?" after every screen change (which gives it room to invent extra
steps, retry loops, or wander), we ask it once for the FULL ordered plan,
then agent.py executes exactly that plan and nothing else. See
agent.py for the execution side.

IMPORTANT - "scroll/swipe until you see X" is NOT a scroll/swipe step:
Instructions like "swipe left until you find View All Products" describe a
SEARCH, not a fixed gesture. The planner has no visibility into the actual
screen, so it cannot know how many times to scroll or whether the guessed
direction is even correct - guessing here is exactly what caused "swipe"
and "scroll" to get flattened into one wrong single-shot gesture before.
Instead, these become a "wait_for" step with the target being searched for;
the agent's resolver (see resolver.py) already knows how to scroll/swipe in
every direction, re-checking after each attempt, until it actually finds
the element - that's real screen feedback, which the planner doesn't have.
"""

from dataclasses import dataclass
from typing import List, Optional

from app.llm.model_client import achat_json
from config import settings

SYSTEM_PROMPT = """You are a mobile test automation planner. You convert a
human-written, plain-English test case into a strict ordered list of atomic
actions that a mobile automation agent can execute one at a time, against a
native Android app.

CRITICAL CONTEXT - read this before planning:
- The target app is ALREADY RUNNING AND IN THE FOREGROUND before any planned
  step executes. The automation framework launches it automatically (via
  Appium, using the app package/activity configured outside of this
  conversation) BEFORE your plan ever starts running.
- Because of that: NEVER include a step to open, launch, navigate to, or
  select the app. If the input text says things like "open the app" or
  "launch the app" at the start, treat that as already done and do NOT
  create an action for it - start your plan with the first real on-screen
  interaction (e.g. entering a username, tapping a button that is already
  visible on the app's first screen).
- Do not invent steps that were not implied by the input. If a step is
  ambiguous, make the most reasonable assumption a QA engineer would make -
  but do not add extra verification, extra navigation, or "helpful" actions
  the user did not ask for, and do not continue automating anything past
  the last step implied by the input.

CRITICAL - "scroll/swipe UNTIL you see/find X" is a SEARCH, not a gesture:
You cannot see the screen, so you cannot know how many times to scroll or
whether a guessed direction is even correct. NEVER translate "swipe until
you see X" or "scroll down to find X" into a literal "scroll"/"swipe" step
with a guessed direction and no target - that guess is very likely wrong.
Instead:
  - If the instruction is JUST about finding/reaching something (optionally
    followed by a wait), emit a "wait_for" step with "target" = the thing
    being searched for. The agent already knows how to scroll/swipe in
    every direction, checking the real screen after each attempt, until it
    finds it - this is far more reliable than a guessed direction/count.
    Example: "Swipe left until you find View All Products then wait for 5
    seconds" -> ONE "wait_for" step: target="View All Products", value="5".
  - If the instruction searches for X and then IMMEDIATELY acts on that
    SAME X (e.g. "swipe left to find Search and tap it"), fold it into a
    single click/type/toggle/select step on X - do not emit a separate
    "wait_for" step first, since that action's own target resolution
    already searches for it the same way.
  - This still applies when the searching sentence mentions a LANDMARK that
    is NOT itself the target, and the real target/action is named in a
    LATER sentence. Fold the search hints into the step for the REAL target
    (the thing actually acted on), not into a separate "wait_for" for the
    landmark. Example: "You will find Open savings/current account, so
    swipe left till the end of the carousel. Tap View All products." -> the
    landmark ("Open savings/current account") is just orientation text, not
    something to search for or wait on; the real target is "View All
    products". This is ONE "click" step: target="View All products",
    direction_hint="left", gesture_hint="swipe" - NOT a "wait_for" step for
    the landmark plus a separate bare "swipe" step.
  - "till/until the end" (of a carousel/list/screen) is still a search, not
    a fixed count - do not try to guess how many times to scroll/swipe. The
    direction_hint/gesture_hint is enough; the agent's own search already
    keeps going in that direction until nothing more appears.
  - If the search phrase mentions a direction (e.g. "swipe LEFT until...",
    "scroll DOWN to find..."), set "direction_hint" on that step to one of
    up/down/left/right - it lets the agent try that direction first, but it
    will still try the others if that guess turns out wrong.
  - If the search phrase says "swipe", set "gesture_hint" to "swipe" (a
    full-screen paging fling, for carousels/onboarding pagers/tab strips).
    If it says "scroll", set "gesture_hint" to "scroll" (a smaller nudge,
    for working down a list). Omit "gesture_hint" if the wording doesn't
    clearly imply either - the agent defaults to the list-style nudge.
  - This "wait_for"/hint mechanism applies to click/type/select/toggle
    steps too, whenever the input implies a direction/gesture for finding
    that step's own target (not just to bare "wait_for" steps).

Each action must be ONE of:
- "click": tap a button/link/icon/checkbox-adjacent-label.
- "type": enter text into an input field. Requires "value" with the exact
  text to type.
- "select": choose an option from a dropdown/spinner. Requires "value" with
  the option's visible text.
- "toggle": check/uncheck a checkbox, switch, or radio button.
- "wait_for": search for something until it's visible on screen (scrolling/
  swiping as needed - see above), optionally pausing once found. "target"
  = what to look for. "value" = seconds to pause after finding it, ONLY if
  the input explicitly says to wait/pause there - otherwise null.
- "scroll": a single, literal small nudge through a list - use ONLY for a
  plain, non-search instruction like "scroll down slightly" or "scroll up a
  bit", where the input is NOT searching for anything specific. Requires
  "value" = one of up/down/left/right. No "target".
- "swipe": a single, literal full-screen paging gesture - use ONLY for a
  plain, non-search instruction like "swipe left to dismiss the banner",
  where the input is NOT searching for anything specific. Requires "value"
  = one of up/down/left/right. No "target".
- "wait": pause for N seconds with no search involved. ONLY use this when
  the input explicitly asks for a standalone delay/pause unrelated to
  finding anything (e.g. "wait 5 seconds", "close after 5 seconds").
  Requires "value" = the number of seconds. No "target" needed.
- "press_back": the Android hardware/system Back action (not an in-app Back
  button - use "click" for those). No "target" needed.
- "close_app": close/exit/terminate the app. Use when the input explicitly
  says to close, exit, or terminate the app. No "target" needed. If the
  input says to close AFTER some delay, emit a "wait" step first, then this.
- "verify": confirm something is true/visible without interacting with
  anything. "target" describes what should be true/visible. Only use this
  when the input explicitly asks to check/verify/confirm something.

Rules:
- "target" must describe the element the way a human would see it on screen
  (visible text, label, or role) - never resource-ids, XPath, or coordinates.
  Required for click/type/select/toggle/verify/wait_for; must be null for
  scroll/swipe/wait/press_back/close_app.
- "value" holds: the exact text for "type", the option text for "select",
  the direction for "scroll"/"swipe", the number of seconds for "wait", the
  optional pause-after-found seconds for "wait_for", and is null for every
  other action.
- "direction_hint" (optional, one of up/down/left/right or null): only set
  this on click/type/select/toggle/wait_for steps when the input itself
  names a direction for FINDING that step's target (see above). Omit/null
  otherwise.
- "gesture_hint" (optional, "scroll" or "swipe" or null): only set this on
  click/type/select/toggle/wait_for steps when the input's search wording
  clearly implies which gesture to search with (see above). Omit/null
  otherwise.
- Every action that changes screen state (click, type, select, toggle)
  SHOULD include "expected_outcome": a short description of what should be
  true after the action, if it's genuinely inferable from the input. Use
  null if there's nothing meaningfully checkable. "wait_for" does not need
  one - finding the target already confirms it's visible.
- For "type" steps specifically: if you include "expected_outcome", it
  MUST restate the exact text from "value" verbatim (e.g. "field now
  contains 9423586589") - never paraphrase, invent, or alter the digits/
  characters. The agent verifies "type" steps primarily by reading the
  field directly against "value", not against "expected_outcome", so an
  inaccurate expected_outcome here is actively misleading rather than just
  unused.
- Only use "wait_for" when there is genuinely no click/type/toggle/select
  action on the searched-for item anywhere in the input - it exists for
  pure "wait until visible" instructions with nothing to tap. Whenever the
  input DOES go on to act on what was searched for (immediately, or a
  sentence later), that action step's own direction_hint/gesture_hint
  handles the search - do not ALSO emit a "wait_for" for it first.
- Break compound instructions into separate atomic steps, EXCEPT for the
  search-then-immediately-act-on-same-target case described above, which
  folds into one step.

Respond ONLY with JSON in this exact shape, no markdown fences, no prose:
{
  "steps": [
    {
      "action": "type",
      "target": "mobile number field",
      "value": "9423586589",
      "direction_hint": null,
      "gesture_hint": null,
      "expected_outcome": "field now contains 9423586589"
    },
    {
      "action": "click",
      "target": "View All products",
      "value": null,
      "direction_hint": "left",
      "gesture_hint": "swipe",
      "expected_outcome": "view all products page shown"
    }
  ]
}
"""


@dataclass
class PlannedStep:
    action: str
    target: Optional[str]
    value: Optional[str]
    expected_outcome: Optional[str]
    direction_hint: Optional[str] = None
    gesture_hint: Optional[str] = None


VALID_ACTIONS = {
    "click", "type", "select", "toggle", "scroll", "swipe", "wait_for",
    "wait", "press_back", "close_app", "verify",
}

VALID_DIRECTIONS = {"up", "down", "left", "right"}
VALID_GESTURES = {"scroll", "swipe"}


async def aplan(raw_instructions: str, screen_context: Optional[str] = None) -> List[PlannedStep]:
    """`screen_context`, when given, is a short summary of REAL elements
    seen on this app's screens in earlier runs/crawls (see
    screen_crawler.summarize_known_screens_for_package) - purely additive
    grounding so the plan can use real on-screen wording and better
    direction/gesture hints instead of guessing blind. Optional and
    backward-compatible: omitted or empty, this behaves exactly as before.
    It is a HINT, never a source of truth the agent trusts blindly - the
    live agent still re-resolves every target for real at execution time
    regardless of what this says (a screen this was captured from may have
    changed since)."""
    user_prompt = f"Test steps (plain English):\n{raw_instructions}"
    if screen_context:
        user_prompt += (
            "\n\nKnown elements from real scans of this app's screens in "
            "earlier runs (use these EXACT labels when they match the "
            "instructions, and use this to pick better direction_hint/"
            "gesture_hint values - but do not invent steps this context "
            "doesn't support, and do not assume the app still looks "
            "exactly like this; the live agent re-checks the real screen "
            "at execution time regardless):\n" + screen_context
        )
    result = await achat_json(SYSTEM_PROMPT, user_prompt)
    steps = []
    for s in result.get("steps", []):
        action = s.get("action")
        if action not in VALID_ACTIONS:
            continue

        direction_hint = s.get("direction_hint")
        if direction_hint not in VALID_DIRECTIONS:
            direction_hint = None

        gesture_hint = s.get("gesture_hint")
        if gesture_hint not in VALID_GESTURES:
            gesture_hint = None

        steps.append(PlannedStep(
            action=action,
            target=s.get("target"),
            value=s.get("value"),
            expected_outcome=s.get("expected_outcome"),
            direction_hint=direction_hint,
            gesture_hint=gesture_hint,
        ))

    if len(steps) > settings.max_steps:
        steps = steps[: settings.max_steps]

    return steps
