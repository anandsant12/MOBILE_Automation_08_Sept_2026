"""
Persistent, whole-screen element map: one JSON file per (app package,
activity) recording every interactive element the agent has ever found
anywhere on that screen - not just what happened to be in the viewport at
the time - along with the scroll/swipe path needed to reach it again from
the top.

WHY THIS EXISTS: resolver.py's live auto-scroll-to-find already explores a
screen by scrolling/swiping and re-reading state whenever a target isn't
immediately visible. This module just PERSISTS what that exploration
already saw - it does NOT run its own separate crawl pass. That's the key
design choice for keeping this cheap rather than a source of overhead:
  - Nothing is scanned proactively "just in case". The map only grows as a
    side effect of searches the agent was doing anyway.
  - A later run/step that needs the SAME element can jump straight to its
    known path (a handful of gesture calls) instead of blindly scrolling
    through every direction again.
  - Fewer vision-fallback calls are needed, since a map hit resolves the
    element mechanically, with certainty, before vision would even be
    considered.
  - The map is NEVER trusted blindly: every hit is re-verified against the
    live screen by its resource-id/class fingerprint before being used. A
    changed app/screen just falls through to the normal live search (which
    then quietly re-learns the new layout), not a wrong click.

FILE LAYOUT: logs/screen_maps/<package>__<activity>.json, holding
{"package", "activity", "elements": {fingerprint_key: entry, ...}}.
Each entry: {"fingerprint", "path", "text", "desc", "resource_id", "class",
"context", "last_confirmed"}. `context` (see page_state.py's
_enrich_duplicate_context) is only ever set for an element that shared its
exact own label with another element on the same screen (e.g. one of
several identical "Apply Now" buttons in a card list) - it holds that
specific instance's surrounding on-screen text (its card's own title,
etc.), which is what keeps a recycled list-item template's identical
resource-id from collapsing every instance onto one fingerprint (see
element_fingerprint's docstring below). `path` is a list of at most one
{"gesture": "scroll"|"swipe", "direction": ..., "count": N} step, relative
to the TOP of the screen (see reset_to_top) - this project's crawler
explores vertically first, then horizontally only from the top position
(see resolver.py's docstring for why: a full 2D grid of scroll x swipe
positions is combinatorially expensive for little practical benefit on
typical app layouts, so this is a deliberate, documented simplification).
"""

import json
import time
from pathlib import Path
from typing import Optional

from thefuzz import fuzz

from config import settings

MAP_DIR = settings.screen_map_dir
MAX_ELEMENTS_PER_SCREEN = 300
MAP_FUZZY_THRESHOLD = 74  # stricter than the live fuzzy tier (70) in resolver.py -
                          # a map hit jumps straight to acting on it, sight-unseen
ORIGIN_RESET_MAX_ATTEMPTS = 8
MAX_PATH_REPLAY_STEPS = 10  # defensive cap - current crawler only ever writes 0-1 step paths

CLASS_HINT_BONUS = 8
ACTION_CLASS_HINTS = {
    "type": {"EditText"},
    "toggle": {"CheckBox", "Switch", "RadioButton"},
    "select": {"Spinner"},
}


def _safe_name(s: str) -> str:
    return "".join(c if c.isalnum() or c in "._-" else "_" for c in (s or "unknown"))


def _map_path(package: str, activity: str) -> Path:
    return MAP_DIR / f"{_safe_name(package)}__{_safe_name(activity)}.json"


def _screen_key(driver):
    try:
        pkg = driver.current_package
    except Exception:
        pkg = None
    try:
        act = driver.current_activity
    except Exception:
        act = None
    if not pkg and not act:
        return None
    return (pkg or "unknown", act or "unknown")


# ---- Element identity (fingerprint) ----
# Single source of truth for "what makes an element the same element" -
# resolver.py's in-memory per-run cache delegates to these same functions,
# so a live resolution and a map hit behave identically.

def element_fingerprint(attrs: Optional[dict]) -> Optional[dict]:
    """Prefers resource-id (stable across screen re-reads); falls back to
    class+text+desc if there's no resource-id. None if neither is usable.

    Also folds in `context` (see page_state._enrich_duplicate_context) when
    present. This matters for a recycled list-item layout (e.g. a
    scrollable list of cards that all share ONE "Apply Now" button
    template): every instance then has the SAME resource-id and class, so
    without `context` they'd all collapse onto one fingerprint - meaning
    this map could only ever remember ONE of them, and would confidently
    replay that single saved element for every future search regardless of
    which card was actually asked for. `context` (the surrounding card's
    own text) is what makes each card's button a genuinely distinct
    fingerprint instead."""
    if not attrs:
        return None
    ctx = attrs.get("context")
    if attrs.get("resource_id"):
        fp = {"resource_id": attrs["resource_id"], "class": attrs.get("class")}
        if ctx:
            fp["context"] = ctx
        return fp
    if attrs.get("text") or attrs.get("desc"):
        fp = {"class": attrs.get("class"), "text": attrs.get("text"), "desc": attrs.get("desc")}
        if ctx:
            fp["context"] = ctx
        return fp
    return None


def match_fingerprint(fp: Optional[dict], attrs_map: dict) -> Optional[str]:
    """Finds the ref in a FRESH attrs_map matching a previously-captured
    fingerprint, or None if it's not there (screen has changed - map/cache
    entry is stale, caller should fall through to live search). When the
    fingerprint carries a `context` (see element_fingerprint), a candidate
    must match it too - otherwise a recycled-template fingerprint (same
    resource-id/class shared by every card in a list) would happily match
    ANY card's button, not just the one this fingerprint was actually
    captured from."""
    if not fp:
        return None
    for ref, attrs in attrs_map.items():
        if fp.get("resource_id"):
            if attrs.get("resource_id") == fp["resource_id"] and attrs.get("class") == fp.get("class"):
                if fp.get("context") and attrs.get("context") != fp.get("context"):
                    continue
                return ref
            continue
        if attrs.get("class") == fp.get("class") and attrs.get("text") == fp.get("text") and attrs.get("desc") == fp.get("desc"):
            if fp.get("context") and attrs.get("context") != fp.get("context"):
                continue
            return ref
    return None


def fingerprint_key(fp: dict) -> str:
    ctx_part = f"::ctx={fp.get('context', '')}" if fp.get("context") else ""
    if fp.get("resource_id"):
        return f"rid::{fp['resource_id']}::{fp.get('class','')}{ctx_part}"
    return f"txt::{fp.get('class','')}::{fp.get('text','')}::{fp.get('desc','')}{ctx_part}"


# ---- Persistence ----

def load_map(driver) -> dict:
    """Returns {} if no map exists yet for this screen, or on any read
    error - a missing/corrupt map is never fatal, just means we start
    fresh (and this run may end up (re)writing a fresh one)."""
    key = _screen_key(driver)
    if not key:
        return {}
    path = _map_path(*key)
    if not path.exists():
        return {}
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data.get("elements", {}) or {}
    except Exception:
        return {}


def save_map(driver, new_elements: dict) -> None:
    """Merges `new_elements` (fp_key -> entry) into the on-disk map for
    this screen and writes it back. Never raises - a failed write just
    means the map doesn't get more useful this time, not a broken run."""
    key = _screen_key(driver)
    if not key or not new_elements:
        return
    try:
        MAP_DIR.mkdir(parents=True, exist_ok=True)
        path = _map_path(*key)
        existing = {}
        if path.exists():
            try:
                with open(path, "r", encoding="utf-8") as f:
                    existing = json.load(f).get("elements", {}) or {}
            except Exception:
                existing = {}
        existing.update(new_elements)

        if len(existing) > MAX_ELEMENTS_PER_SCREEN:
            # Drop the least-recently-confirmed entries first, so stale
            # elements from an app update naturally age out over time.
            ordered = sorted(existing.items(), key=lambda kv: kv[1].get("last_confirmed", 0))
            existing = dict(ordered[-MAX_ELEMENTS_PER_SCREEN:])

        with open(path, "w", encoding="utf-8") as f:
            json.dump({"package": key[0], "activity": key[1], "elements": existing}, f, indent=2)
    except Exception:
        pass


def record_elements(sink: dict, path: list, attrs_map: dict) -> None:
    """Called during live resolution (resolver.py) to opportunistically
    record every element visible at the CURRENT scroll/swipe position into
    `sink` (fp_key -> entry), tagged with the path taken to reach it. This
    is free - it just reuses the attrs_map that resolution already fetched
    for its own purposes, no extra Appium calls."""
    now = time.time()
    for attrs in attrs_map.values():
        fp = element_fingerprint(attrs)
        if not fp:
            continue
        key = fingerprint_key(fp)
        if key in sink:
            continue  # keep the FIRST (shortest) path an element was found via
        sink[key] = {
            "fingerprint": fp,
            "path": path,
            "text": attrs.get("text"),
            "desc": attrs.get("desc"),
            "resource_id": attrs.get("resource_id"),
            "class": attrs.get("class"),
            "context": attrs.get("context"),
            "last_confirmed": now,
        }


def find_candidate(description: str, elements: dict, action: Optional[str] = None) -> Optional[dict]:
    """Fuzzy-matches `description` against every element ever recorded for
    this screen (on- or off- the current viewport). Returns the best entry
    if it clears MAP_FUZZY_THRESHOLD, else None. Mirrors resolver.py's own
    tie-breaking (class-matches-action bonus) so map hits and live hits
    behave consistently."""
    if not elements:
        return None
    hint_classes = ACTION_CLASS_HINTS.get(action or "", set())
    best_entry, best_score = None, 0
    for entry in elements.values():
        haystack = " ".join(filter(None, [
            entry.get("text"), entry.get("desc"), entry.get("resource_id"),
            entry.get("class"), entry.get("context"),
        ]))
        score = fuzz.token_set_ratio(description.lower(), haystack.lower())
        if hint_classes and entry.get("class") in hint_classes:
            score += CLASS_HINT_BONUS
        if score > best_score:
            best_entry, best_score = entry, score
    if best_entry and best_score >= MAP_FUZZY_THRESHOLD:
        return best_entry
    return None


# ---- Navigation helpers (async - drive real gestures) ----

async def reset_to_top(driver, max_attempts: int = ORIGIN_RESET_MAX_ATTEMPTS) -> None:
    """Scrolls up repeatedly until it stops changing the screen, so both
    path-recording and path-replay have a single, consistent reference
    point ("the top") regardless of where the app happened to be scrolled
    to when this was called."""
    import asyncio
    from app.automation.action_executor import execute_scroll
    from app.automation.page_state import get_state

    prev_sig = None
    for _ in range(max_attempts):
        try:
            await asyncio.to_thread(execute_scroll, driver, "up")
        except Exception:
            break
        state_text, _, _ = await asyncio.to_thread(get_state, driver)
        sig = hash(state_text)
        if sig == prev_sig:
            break
        prev_sig = sig
        await asyncio.sleep(settings.scroll_pause_sec)


async def apply_path(driver, path: list) -> None:
    """Replays a saved path (from an element's map entry) starting from a
    freshly-reset top position. For "swipe" steps in a left/right
    direction, re-detects the current horizontal-carousel row band before
    each gesture (see page_state.detect_horizontal_row_band) so a saved
    carousel path still confines itself correctly even if the row's
    on-screen position has shifted slightly since it was recorded."""
    import asyncio
    from app.automation.action_executor import execute_scroll, execute_swipe
    from app.automation.page_state import get_state, detect_horizontal_row_band

    await reset_to_top(driver)

    for step in (path or [])[:MAX_PATH_REPLAY_STEPS]:
        gesture = step.get("gesture", "scroll")
        direction = step.get("direction")
        if not direction:
            continue
        count = min(int(step.get("count", 0) or 0), 20)

        for _ in range(count):
            anchor_y = None
            fn = execute_scroll if gesture == "scroll" else execute_swipe
            if direction in ("left", "right"):
                try:
                    _, _, attrs_map = await asyncio.to_thread(get_state, driver)
                    anchor_y = detect_horizontal_row_band(attrs_map)
                except Exception:
                    anchor_y = None
                if anchor_y is not None:
                    # Same auto-upgrade as resolver._scroll_search: a
                    # detected carousel row always gets swiped (confined to
                    # its band), regardless of what gesture the path was
                    # originally saved with.
                    fn = execute_swipe
            try:
                await asyncio.to_thread(fn, driver, direction, anchor_y)
            except Exception:
                return
            await asyncio.sleep(settings.scroll_pause_sec)
