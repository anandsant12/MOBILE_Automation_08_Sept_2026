"""
Hybrid verification.

Step 1 (cheap, deterministic, always runs, no LLM): fuzzy string match
(thefuzz) between the "expected_outcome" the planner gave us and BOTH
(a) the screen's visible text, and (b) the actual current text/values held
in EditText fields, pulled straight from the UI hierarchy.

(b) matters: a typed value never reliably appears via a generic "visible
text" read on Android, so reading EditText.text directly answers "does the
field contain X" with certainty and skips the LLM/vision call entirely.

Step 2 (only if the fuzzy score lands in a genuine grey zone, AND
settings.enable_vision_fallback is True): ask the vision model to look at
a screenshot and judge whether the expected result actually happened. If
vision fallback is disabled, a grey-zone score is treated as a fail rather
than guessed at - the UI hierarchy is the source of truth.
"""

import asyncio
from thefuzz import fuzz
from selenium.webdriver.common.by import By

from app.llm.model_client import achat_vision_json
from app.automation.page_state import clean_attr
from app.utils.screenshot import take_screenshot, screenshot_to_b64
from config import settings

VERIFY_SYSTEM_PROMPT = """You are verifying whether a mobile UI automation
step succeeded. You'll be given the expected result and a screenshot.
Respond with ONLY JSON, no reasoning, no <think> tags, no explanation
outside the JSON: {"passed": true|false, "reasoning": "short reason"}
"""

GREY_ZONE_LOW = 40

# Characters Android commonly renders a masked (password-style) field's
# value as. If a field reads as ENTIRELY these characters, its actual typed
# content can't be judged this way at all - treat it as inconclusive rather
# than scoring it (which would otherwise read as a confident, and wrong, fail).
_MASK_CHARS = set("*•●○∙·⚫")


def _visible_text(driver) -> str:
    """All on-screen text, concatenated - the Android equivalent of a web
    page's rendered body text."""
    try:
        elements = driver.find_elements(By.XPATH, "//*[@text!='']")
        return " ".join(clean_attr(el.get_attribute("text")) for el in elements)
    except Exception:
        return ""


def _field_values(driver) -> str:
    parts = []
    try:
        for el in driver.find_elements(By.XPATH, "//*[contains(@class,'EditText')]"):
            try:
                val = clean_attr(el.get_attribute("text"))
                rid = clean_attr(el.get_attribute("resource-id"))
                if val:
                    parts.append(f"{rid}={val}")
            except Exception:
                continue
    except Exception:
        pass
    return "; ".join(parts)


def _combined_state_text(driver) -> str:
    return f"{_visible_text(driver)}\nField values: {_field_values(driver)}"


async def averify_field_value(element, expected_value: str) -> "dict | None":
    """Fast, zero-LLM verification for a 'type' step, used ONLY when we still
    hold a direct element reference (target.method == "ref") from the step
    that just typed into it. Reads the field's own text attribute straight
    from the UI hierarchy instead of scanning the whole screen - cheaper
    than averify() and skips the LLM/vision call entirely whenever the
    result is unambiguous.

    Returns a result dict when the field's actual value gives a confident
    answer - including method="field_empty" when the field is genuinely
    empty, which IS treated as a confident failure (see below), not an
    inconclusive one. Returns None only when the field can't be judged at
    all this way (a masked password-style field, or the read itself
    failed) - callers should fall back to averify() in that case. Most
    callers should use averify_field_value_with_retry instead, which
    handles the empty-field/transient-timing case correctly.
    """
    if not expected_value:
        return None
    try:
        raw = await asyncio.to_thread(lambda: element.get_attribute("text"))
    except Exception:
        return None
    actual = clean_attr(raw)
    if not actual:
        # Genuinely empty - NOT the same as a masked field (which still has
        # SOME characters, just not readable ones). This is a real signal
        # that the typed text never landed (e.g. a custom numeric keypad/
        # dial-pad that didn't have focus yet, or send_keys landed on the
        # wrong element). Report it as a definite failure rather than
        # silently deferring to the general averify() - deferring here is
        # exactly what let a step get marked "passed" while the field was
        # visibly empty on screen. Retries around transient timing live in
        # agent.py's averify_field_value_with_retry, which calls this.
        return {
            "passed": False,
            "method": "field_empty",
            "score": 0,
            "reasoning": "Field is empty after typing - the text does not appear to have been entered.",
        }

    if all(ch in _MASK_CHARS for ch in actual):
        return None  # masked (e.g. password) field - the raw text can't confirm or deny anything

    score = fuzz.ratio(expected_value.lower(), actual.lower())
    if score >= 90:
        return {
            "passed": True,
            "method": "field",
            "score": score,
            "reasoning": f"Field now reads '{actual}', matching the typed text (score {score}).",
        }
    if score <= 30:
        return {
            "passed": False,
            "method": "field",
            "score": score,
            "reasoning": f"Field reads '{actual}', which does not match the typed text '{expected_value}' (score {score}).",
        }
    return None  # grey zone - e.g. masked/partial value - fall back to averify()


async def averify_field_value_with_retry(element, expected_value: str,
                                          attempts: "int | None" = None,
                                          interval: "float | None" = None) -> "dict | None":
    """Wraps averify_field_value with a short retry loop, specifically for
    the "field is genuinely empty" case (method == "field_empty") - a
    typed value can take a moment to land (custom numeric keypads/
    dial-pads in particular), so one empty read right after typing isn't
    automatically a real failure. A masked-field result (None) is NOT
    retried here - waiting longer can't reveal a password field's raw
    text, so there's nothing to gain; callers fall back to averify() for
    that case as before.

    Returns the LAST result obtained (so a genuine, persistent empty field
    is still reported, just after giving it a fair chance to catch up).
    """
    attempts = settings.type_verify_retry_attempts if attempts is None else attempts
    interval = settings.type_verify_retry_interval_sec if interval is None else interval

    result = await averify_field_value(element, expected_value)
    tries = 0
    while result is not None and result.get("method") == "field_empty" and tries < attempts:
        await asyncio.sleep(interval)
        result = await averify_field_value(element, expected_value)
        tries += 1
    return result


async def averify_with_search(driver, expected_result: str,
                                max_scroll_attempts: "int | None" = None) -> dict:
    """Same contract/return shape as averify() below, but if the expected
    text genuinely isn't on the CURRENT screen, scrolls down a bounded
    number of times - re-running the cheap fuzzy check (no LLM) after
    each - before falling back to averify()'s own grey-zone vision
    judgement on wherever this search ends up.

    WHY THIS EXISTS: plain averify() only ever looks at the screen exactly
    as it is right now. An expected_outcome that's genuinely true but
    happens to render BELOW the fold (a confirmation banner, a newly-added
    list item at the bottom of a long list, a success message the app
    scrolls to only after a short animation) would otherwise be reported
    as a false failure - not because the check was wrong, but because it
    never looked in the right place. This mirrors resolver.py's own
    auto-scroll-to-find philosophy, applied to verification instead of
    target resolution.

    Purely READ-ONLY with respect to app state - a scroll never
    submits/changes data - and stops as soon as either a pass is found or
    scrolling stops changing the screen (reached the end), same early-exit
    logic resolver.py's scroll-search already uses. The screen is simply
    left wherever this search ends up; nothing is scrolled back.
    """
    if not expected_result:
        return await averify(driver, expected_result)

    result = await averify(driver, expected_result)
    if result["passed"]:
        return result

    attempts = settings.verify_scroll_max_attempts if max_scroll_attempts is None else max_scroll_attempts
    if attempts <= 0:
        return result

    from app.automation.action_executor import execute_scroll  # local import: avoids a cycle

    prev_text = await asyncio.to_thread(_combined_state_text, driver)
    for _ in range(attempts):
        await asyncio.to_thread(execute_scroll, driver, "down")
        await asyncio.sleep(settings.scroll_pause_sec)
        cur_text = await asyncio.to_thread(_combined_state_text, driver)
        if cur_text == prev_text:
            break  # stopped changing - reached the end, no point continuing
        prev_text = cur_text
        result = await averify(driver, expected_result)
        if result["passed"]:
            return result

    return result


async def averify(driver, expected_result: str) -> dict:
    """Returns {"passed": bool, "method": "fuzzy"|"vision"|"skipped", "score": int|None, "reasoning": str}"""
    if not expected_result:
        return {"passed": True, "method": "skipped", "score": None, "reasoning": "No expectation given."}

    combined_text = await asyncio.to_thread(_combined_state_text, driver)
    score = fuzz.partial_ratio(expected_result.lower(), combined_text.lower())
    threshold = settings.fuzzy_match_threshold

    if score >= threshold:
        return {
            "passed": True,
            "method": "fuzzy",
            "score": score,
            "reasoning": f"Fuzzy match score {score} >= threshold {threshold} (screen text + field values).",
        }

    if score <= GREY_ZONE_LOW or not settings.enable_vision_fallback:
        return {
            "passed": False,
            "method": "fuzzy",
            "score": score,
            "reasoning": f"Fuzzy match score {score} below threshold {threshold} (screen text + field values).",
        }

    # Grey zone AND vision fallback enabled: ask the vision model to judge.
    screenshot_path = await asyncio.to_thread(take_screenshot, driver, "verify")
    b64 = await asyncio.to_thread(screenshot_to_b64, screenshot_path)
    result = await achat_vision_json(
        VERIFY_SYSTEM_PROMPT,
        f"Expected result: {expected_result}\nDid this happen?",
        b64,
    )
    return {
        "passed": bool(result.get("passed")),
        "method": "vision",
        "score": score,
        "reasoning": result.get("reasoning", ""),
    }
