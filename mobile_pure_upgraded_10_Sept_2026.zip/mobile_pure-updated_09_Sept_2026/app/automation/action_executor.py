
"""
Turns a resolved action into a real Appium/UiAutomator2 interaction. Covers
the full vocabulary planner.py can choose from: click, type, select
(spinner/dropdown), toggle, scroll, swipe, wait_for, press_back, close_app.

"scroll" and "swipe" are deliberately separate gestures, not aliases:
scroll is a partial-extent nudge (for working through a vertical list a bit
at a time), swipe is a full-extent fling (for paging through a horizontal
carousel/onboarding pager/tab strip). Using the list gesture on a pager - or
vice versa - is what caused "scroll" and "swipe" instructions to behave
identically before; see resolver.py's docstring for how a step's
gesture_hint picks the right one during auto-scroll-to-find search.

Coordinate-based actions (the vision fallback path, target.method=="vision")
use UiAutomator2's "mobile:" gesture commands rather than Selenium
ActionChains - ActionChains.move_by_offset is a web/desktop-mouse concept
and does not reliably drive a touch screen through Appium.

WHY execute_click CAN SELF-VERIFY AND RETRY (see `verify_effect` below):
Selenium's element.click() on UiAutomator2 performs a semantic/accessibility-
style click. That's reliable for standard native widgets with a real
OnClickListener, but MANY real apps wire an icon-only control (a header's
support/notification/menu icon in particular - often a Compose composable,
or a plain ImageView driven by a raw onTouchListener/gesture-detector
instead of a click listener) through touch handling that simply does not
respond to that semantic click at all - Appium reports success (no
exception), the element genuinely resolved correctly, and yet nothing
happens on the real device. A raw coordinate `mobile: clickGesture` (a
genuine synthetic touch down+up) exercises the exact same input path a
real finger would, and lands correctly regardless of how the view
internally wires up its own click handling - so it's a strictly more
reliable fallback, not just a different way of doing the same thing.
"""

import time

from thefuzz import fuzz
from selenium.webdriver.common.by import By

from app.automation.locator_engine import ResolvedTarget
from config import settings


def _page_signature(driver):
    """Cheap, single-round-trip 'has anything on screen changed at all'
    signal - the raw page_source XML, hashed. One HTTP call regardless of
    screen complexity (unlike page_state.get_state(), which does a round
    trip PER element) - deliberately the cheapest available signal, since
    this runs on every verified click, not just failure diagnostics."""
    try:
        return hash(driver.page_source)
    except Exception:
        return None


def _perform_ref_click(driver, target: ResolvedTarget) -> None:
    """The actual click mechanics for a method=='ref' target - unchanged
    behaviour from before, just factored out so execute_click can wrap it
    with the optional verify-and-retry pass below."""
    if target.clickable is False:
        # Resolved via page_state.get_broad_state's fallback scan (see
        # resolver.py's tier 3): this specific element is KNOWN not to
        # be clickable itself - e.g. a list row's label TextView, where
        # the tap is actually handled by a parent (a common Android
        # RecyclerView pattern: itemView.setOnClickListener on the row,
        # not on each child) or by the list's own touch handling.
        # Calling .click() straight on a node Android never marked
        # interactive is unreliable across Appium/UiAutomator2 versions.
        # Two fallbacks, in order of preference:
        #   1. Walk up to the nearest ancestor actually marked
        #      clickable/long-clickable and click THAT - the real,
        #      semantically correct click target.
        #   2. If no such ancestor exists (e.g. the tap is handled by an
        #      OnItemTouchListener on the list itself, not any single
        #      ancestor view), tap this element's own on-screen center
        #      instead. Android's touch dispatch bubbles an unconsumed
        #      touch up to whichever parent actually handles it, so
        #      tapping the label's own coordinates still lands on the
        #      right target even though the label itself never
        #      "consumes" the touch.
        try:
            ancestor = target.element.find_element(
                By.XPATH, "./ancestor::*[@clickable='true' or @long-clickable='true'][1]"
            )
            ancestor.click()
            return
        except Exception:
            pass
        if target.center:
            driver.execute_script(
                "mobile: clickGesture", {"x": target.center[0], "y": target.center[1]}
            )
            return
        # No clickable ancestor found and no bounds recorded - fall
        # through to a direct click anyway rather than silently doing
        # nothing; on some UiAutomator2 versions this still works.
    target.element.click()


def execute_click(driver, target: ResolvedTarget, verify_effect: bool = False) -> bool:
    """Performs the click. `verify_effect`, when True, adds a cheap self-
    check AFTER the primary click attempt: capture the screen's raw
    signature immediately before and after; if NOTHING changed at all and
    we have this target's on-screen coordinates, retry with a raw
    coordinate `mobile: clickGesture` tap (see this module's docstring for
    why that's a meaningfully different, more reliable mechanism than
    Selenium's own .click(), not just a repeat of the same thing).

    Returns True if the screen visibly changed as a result of either
    attempt, or if verify_effect wasn't requested at all (the caller
    doesn't care). Returns False only when verify_effect was requested AND
    neither attempt produced any visible change - a useful, honest signal
    for the caller to surface, NOT proof the click failed on its own (some
    legitimate taps - e.g. one that just starts a slow network navigation,
    or toggles something with no on-screen text of its own - genuinely
    don't change anything this check can see)."""
    pre_sig = _page_signature(driver) if verify_effect else None

    if target.method == "ref":
        _perform_ref_click(driver, target)
    else:
        driver.execute_script("mobile: clickGesture", {"x": target.x_px, "y": target.y_px})

    if not verify_effect or pre_sig is None:
        return True

    time.sleep(settings.vision_settle_pause_sec)
    post_sig = _page_signature(driver)
    if post_sig == pre_sig:
        cx, cy = (target.x_px, target.y_px) if target.method == "vision" else (
            (target.center or (None, None))
        )
        if cx is not None and cy is not None:
            driver.execute_script("mobile: clickGesture", {"x": cx, "y": cy})
            time.sleep(settings.vision_settle_pause_sec)
            post_sig = _page_signature(driver)

    return post_sig != pre_sig



def execute_type(driver, target: ResolvedTarget, text: str):
    if target.method == "ref":
        try:
            target.element.clear()
        except Exception:
            pass
        target.element.send_keys(text)
    else:
        driver.execute_script("mobile: clickGesture", {"x": target.x_px, "y": target.y_px})
        active = driver.switch_to.active_element
        try:
            active.clear()
        except Exception:
            pass
        active.send_keys(text)


def execute_toggle(driver, target: ResolvedTarget, verify_effect: bool = False) -> bool:
    """Check/uncheck a checkbox/switch, or pick a radio button. Same
    mechanics as a click - kept as a separate name purely for clearer logs."""
    return execute_click(driver, target, verify_effect=verify_effect)


def _best_matching_option(value: str, attrs_map: dict, threshold: int = 60):
    """Fuzzy-matches `value` against every element in attrs_map. Returns
    (ref, score) - ref is None if nothing clears `threshold`. Shared by
    both scan passes in execute_select below so they score options
    identically."""
    best_ref, best_score = None, 0
    for ref, attrs in attrs_map.items():
        haystack = " ".join(filter(None, [
            attrs.get("text"), attrs.get("desc"), attrs.get("resource_id"), attrs.get("context"),
        ]))
        score = fuzz.token_set_ratio(value.lower(), haystack.lower())
        if score > best_score:
            best_ref, best_score = ref, score
    if best_ref and best_score >= threshold:
        return best_ref, best_score
    return None, best_score


def execute_select(driver, target: ResolvedTarget, value: str, step_num: "int | None" = None):
    """Android has no native <select> - dropdowns/spinners open a picker
    when tapped. So: tap to open it, re-read the screen, then fuzzy-match
    the requested option's text among the newly-visible elements and tap
    that. Requires a real element (not a vision-coordinate target).

    Two passes over the opened picker, narrow first then broad:
    Pass 1 mirrors page_state.get_state()'s own interactive-only filter -
    correct and cheap for a real native Spinner/dropdown, where each option
    row IS itself clickable/checkable.
    Pass 2, ONLY if pass 1 finds nothing, re-scans with
    page_state.get_broad_state() instead. Some "dropdowns" the planner
    calls "select" on are actually a full-screen list/dialog (e.g. a
    country picker) where option rows carry NO clickable/checkable flag
    anywhere in their own hierarchy - the tap is handled by a parent or by
    the list itself (see get_broad_state's docstring / resolver.py's tier
    3). Pass 1's narrow scan can never see such a row, no matter how long
    we wait after opening the picker - this is exactly the class of bug
    that made "select Canada" keep failing even after resolver.py gained
    the same broader fallback: this function does its OWN option lookup
    and never went through resolver.py's tiers at all.
    A matched option that isn't itself clickable is still clicked
    correctly via execute_click's ancestor/coordinate-tap fallback (see
    that function) - not a bare .click() on a non-clickable node.
    """
    if target.method != "ref":
        raise RuntimeError(
            "Selecting a dropdown option needs a real element reference, "
            "not a screenshot coordinate - could not resolve the dropdown itself."
        )

    from app.automation.page_state import get_state, get_broad_state, dump_failed_screen  # local import: avoids a cycle
    from app.automation.locator_engine import resolve_by_ref  # local import: avoids a cycle

    # Open the dropdown/list via execute_click (not a bare target.element.
    # click()) so the SAME ancestor/coordinate-tap fallback applies here
    # too, in case the trigger itself is ever resolved as non-clickable
    # (e.g. via resolver.py's own broad-scan tier).
    execute_click(driver, target)
    time.sleep(0.6)

    _, ref_map, attrs_map = get_state(driver)
    best_ref, best_score = _best_matching_option(value, attrs_map)

    if not best_ref:
        # Pass 2: broader scan - see docstring above.
        _, ref_map, attrs_map = get_broad_state(driver)
        best_ref, best_score = _best_matching_option(value, attrs_map)

    if best_ref:
        option_target = resolve_by_ref(best_ref, ref_map, attrs_map.get(best_ref))
        execute_click(driver, option_target)
        return

    tag = f"step{step_num}_select_{value}" if step_num is not None else f"select_{value}"
    dump_path = dump_failed_screen(driver, tag)
    suffix = f" (UI hierarchy dumped to {dump_path} for diagnosis)" if dump_path else ""
    raise RuntimeError(f"Could not find an option matching '{value}' after opening the dropdown.{suffix}")


def execute_scroll(driver, direction: str, anchor_y: int = None):
    """A content-list nudge: a moderate, partial-extent swipe meant for
    scrolling down/up through a list a bit at a time. This is the gesture
    used by the resolver's default auto-scroll-to-find search, and by an
    explicit "scroll" step (e.g. "scroll down slightly").

    `anchor_y` is accepted (and ignored) only for call-signature parity with
    execute_swipe, so the resolver can dispatch through one gesture_fn
    variable regardless of which gesture was picked - a vertical list nudge
    doesn't need row-confinement the way a nested horizontal carousel does.
    """
    size = driver.get_window_size()
    width, height = size["width"], size["height"]
    args = {
        "left": int(width * 0.1),
        "top": int(height * 0.15),
        "width": int(width * 0.8),
        "height": int(height * 0.7),
        "direction": direction,
        "percent": 0.75,
    }
    driver.execute_script("mobile: swipeGesture", args)


def execute_swipe(driver, direction: str, anchor_y: int = None):
    """A full-extent fling: meant for paging through a horizontal carousel,
    onboarding pager, or tab strip - a bigger, faster gesture than
    execute_scroll's list nudge, and the one that actually advances a
    "swipe through the screens" pager the way a user's thumb would. Used by
    an explicit "swipe" step, and by the resolver's auto-scroll-to-find
    search when a step's gesture_hint says "swipe" (see resolver.py).

    If `anchor_y` is given (see page_state.detect_horizontal_row_band), the
    gesture is CONFINED to a narrow band around that y-coordinate instead of
    spanning the full screen height. This is what makes swiping actually
    work on a horizontal card carousel NESTED inside a vertically-scrolling
    screen (e.g. a row of quick-action cards on a home screen) - a full-
    screen swipe there can miss the carousel's own touch region, or drag a
    different part of the page instead of advancing the row.
    """
    size = driver.get_window_size()
    width, height = size["width"], size["height"]
    if anchor_y is not None and direction in ("left", "right"):
        band_half = max(int(height * 0.06), 70)
        top = max(int(anchor_y) - band_half, 0)
        band_height = min(band_half * 2, height - top)
        args = {
            "left": int(width * 0.02),
            "top": top,
            "width": int(width * 0.96),
            "height": band_height,
            "direction": direction,
            "percent": 1.0,
        }
    else:
        args = {
            "left": int(width * 0.02),
            "top": int(height * 0.02),
            "width": int(width * 0.96),
            "height": int(height * 0.96),
            "direction": direction,
            "percent": 1.0,
        }
    driver.execute_script("mobile: swipeGesture", args)


def execute_press_back(driver):
    driver.back()


def execute_close_app(driver, package: str):
    if package:
        driver.terminate_app(package)
    else:
        driver.quit()
