"""
Bounded, EXPLANATORY LLM reasoning that sits alongside the fixed plan-then-
execute pipeline (planner.py plans once, agent.py executes exactly that
plan - see both modules' docstrings for why that's a deliberate choice, not
an oversight). This module does NOT decide what the agent should do next,
and does NOT feed anything back into the running plan - it only produces
a plain-English explanation, for a HUMAN reading the run's output, of why a
step most likely failed. That distinction matters: a diagnosis is free to
be wrong sometimes without any real cost (a QA engineer just gets a less
useful note), whereas letting an LLM improvise a NEW action on the strength
of its own guess is exactly the "agent wanders off and keeps acting after
it should have stopped" failure mode agent.py's docstring explicitly
rejects. If deeper autonomy (the model deciding and taking a follow-up
action itself) is ever wanted, that's a real architecture change - see the
README's "Improvement points" section - not something to sneak in here.
"""

import asyncio
from typing import Optional

from app.llm.model_client import achat_vision_json
from app.utils.screenshot import take_screenshot, screenshot_to_b64
from config import settings

DIAGNOSE_SYSTEM_PROMPT = """You are helping a QA engineer understand why a
mobile UI automation step failed. You will be given the plain-English
target the step was looking for, the raw error message, the expected
outcome (if the step had one), and a screenshot of the app at the moment
of failure. Respond with ONLY JSON, no reasoning, no <think> tags, no
explanation outside the JSON:
{"likely_cause": "a short phrase - e.g. 'unexpected popup/dialog',
 'wrong screen than expected', 'element genuinely off-screen',
 'app still loading/network delay', 'target does not appear to exist',
 'ambiguous - multiple similar elements'",
 "explanation": "1-2 plain sentences grounded in what the screenshot
 actually shows - do not speculate about app internals you can't see",
 "suggestion": "one short, concrete sentence for the QA engineer - e.g.
 'reword the target to mention its distinguishing card/section name',
 'this screen may need a longer settle pause before this step runs',
 'check whether a permission/promo dialog is appearing intermittently'"}
You are producing a NOTE FOR A HUMAN, not a new instruction for the agent
to carry out - never suggest the agent itself retry, click something, or
take any other action.
"""


async def adiagnose_failure(driver, description: str, error_message: str,
                             expected_outcome: Optional[str] = None) -> Optional[dict]:
    """Best-effort, vision-based diagnosis of a step that just raised an
    exception (target unresolvable, action failed, etc). Returns a dict
    with likely_cause/explanation/suggestion, or None if diagnosis is
    disabled, vision fallback is disabled (same underlying vision model
    dependency as locator_engine.py/verifier.py), or anything about this
    call itself fails - a missing diagnosis should never turn one failed
    step into a broken run."""
    if not settings.brain_diagnosis_enabled or not settings.enable_vision_fallback:
        return None
    try:
        screenshot_path = await asyncio.to_thread(take_screenshot, driver, "diagnosis")
        b64 = await asyncio.to_thread(screenshot_to_b64, screenshot_path)
        user_prompt = (
            f"Target the step was looking for: {description or '(none)'}\n"
            f"Error: {error_message}\n"
            f"Expected outcome (if any was specified): {expected_outcome or '(none specified)'}"
        )
        result = await achat_vision_json(DIAGNOSE_SYSTEM_PROMPT, user_prompt, b64)
        likely_cause = result.get("likely_cause")
        if not likely_cause:
            return None
        return {
            "likely_cause": likely_cause,
            "explanation": result.get("explanation", ""),
            "suggestion": result.get("suggestion", ""),
        }
    except Exception:
        return None
