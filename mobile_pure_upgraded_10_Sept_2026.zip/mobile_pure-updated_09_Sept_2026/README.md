# AI Mobile Automation (Android)

An AI-driven UI automation agent for native Android apps, built on Appium.
You describe what you want done in plain English; the agent turns that
into an exact, ordered plan, shows it to you, then executes it — nothing
more, nothing less.

This project is **mobile-only**. All web/Selenium-target code has been
removed.

## What changed in this version

**1. Plan-then-act, not react-and-guess.**
Previously the agent asked the model "what's the single next action?"
after every screen change. That reactive loop had no fixed endpoint, so it
could keep proposing actions you never asked for. Now the agent calls the
planner **exactly once**, up front: your instructions are converted into a
strict, ordered list of atomic actions (`planner.py`). The run then
executes precisely that list, in order, and stops — see `agent.py`. If a
step fails, the run stops rather than improvising a "fix."

**2. The agent never launches the app itself.**
Appium already launches the app (via `ANDROID_APP_PACKAGE` /
`ANDROID_APP_ACTIVITY` in `.env`) before any planned step runs. The
planner's system prompt now explicitly says the app is already open and
in the foreground, and instructs it to never create an "open/launch app"
step — even if your instructions start with "open the app."

**3. One LLM provider toggle drives both text and vision.**
`LLM_PROVIDER=groq` or `LLM_PROVIDER=azure` in `.env` — no more separate
text/vision toggles. On `azure`, the same deployment (point it at your
gpt-4.1-mini deployment) is used for both text and vision calls, since
gpt-4.1-mini is multimodal.

**4. Locator/action fixes.**
- The vision-fallback click/type path previously used Selenium
  `ActionChains.move_by_offset`, which is a desktop-mouse concept and
  doesn't reliably drive a touch screen through Appium. It now uses
  UiAutomator2's `mobile: clickGesture` / `mobile: swipeGesture` commands.
- Screen-state extraction (`page_state.py`) now includes each element's
  short resource-id, checked/enabled state, and on-screen position, so the
  fuzzy/LLM resolver can tell apart elements that share similar text.
- A `verify` action and Android-native `select` (tap-to-open-dropdown +
  fuzzy-match-and-tap the option) are supported directly.

**5. Dead/broken code removed.**
`step_runner.py` (a manual step-builder path that referenced functions
that didn't exist in `action_executor.py` and was never wired into the
Streamlit UI), `action_schema.py` (its unused, web/mobile-mixed schema),
and `app/llm/groq_client.py` (an unused duplicate of `model_client.py`)
have all been deleted.

**6. Non-clickable list rows (e.g. a country picker) now resolve AND
click correctly, plus a safe scan-speed trim.**
- A previous fix taught the scanner to borrow a clickable row's child
  text as its label (so a flag-icon + country-name row isn't dropped for
  having no text of its own) - but that only helps when the row itself is
  marked `clickable`. Some rows aren't: the tap is instead handled by a
  parent view or by the list's own item-touch handling (both common
  RecyclerView patterns), so the row - and the text that actually
  identifies it - never satisfies the scanner's interactive-element
  filter at all, no matter how many times the screen is re-read.
- `page_state.get_broad_state()` is a new, much broader scan (any element
  with visible text, not just clickable/checkable/known-widget ones),
  used as a single last-chance fallback tier in `resolver.py` - tried
  once on the current screen, before the persistent map or auto-scroll
  search (which could otherwise scroll straight past an element that's
  already visible, just filtered out). Deliberately NOT the default scan
  everywhere else: on a busy screen it can return hundreds of plain
  caption/label elements, which would slow down every single screen read
  and hurt fuzzy-match precision if used unconditionally.
- Because an element found this way often isn't clickable itself,
  `action_executor.execute_click` now has a fallback for that case: click
  the nearest ancestor Android actually marked clickable, or, if none
  exists, tap the element's own on-screen coordinates directly (Android's
  touch dispatch bubbles an unconsumed tap up to whichever parent
  actually handles it, so this still lands correctly).
- Scan speed: `page_state.py` no longer reads an element's `checked`
  attribute unless it's already `checkable` - checked is only ever used
  for checkable elements, so this removes one Appium round-trip for every
  plain (non-checkable) element on screen, on every single scan.
- **Root cause of "select Canada still doesn't work" after the above**:
  `action_executor.execute_select` (used whenever the planner classifies a
  step as `select` - "choose X from a dropdown/list" - which a country
  picker instruction very naturally triggers) does its OWN option lookup
  after opening the dropdown/list, completely separate from
  `resolver.py`. It was still doing a narrow, clickable-only scan for the
  option text, so it never benefited from the broad-scan fix above at
  all. It now tries the same narrow scan first, then falls back to
  `get_broad_state()` if that finds nothing - and opens the dropdown/list
  itself via `execute_click` (ancestor/coordinate-tap aware) instead of a
  bare `.click()`, in case the trigger itself is ever non-clickable too.
  A failed option match now also dumps the UI hierarchy to
  `logs/failed_resolutions/` (via the new shared `page_state.
  dump_failed_screen`, also used by `agent.py`'s existing target-resolution
  failures), including a note of the live Appium contexts at that moment -
  a cheap early warning if a screen ever turns out to be a WebView/hybrid
  one, which no native scan (narrow or broad) can see into at all.

**7. Unlabeled icon buttons (e.g. a header's support/headphone icon) and
repeated-label buttons in a list (e.g. "Apply Now" on every card) now
resolve correctly.**
- **Root cause #1**: every scan tier in `page_state.py` required an
  element to have SOME text, content-desc, or resource-id (on itself or a
  descendant) before it was even included in the results - a pure
  icon-only control with none of those anywhere (common: many apps never
  set `contentDescription` on icon buttons) was silently dropped from
  *every* tier, narrow and broad alike. No amount of re-reading or
  scrolling could ever find it, because it simply wasn't in the result set
  to begin with. Fixed with a last-resort, purely positional label (e.g.
  `"(icon button, top-right of screen)"`, derived only from the element's
  on-screen position relative to screen size - no app-specific wording)
  so it now surfaces for fuzzy/LLM matching instead of vanishing.
  `_first_descendant_text`'s child-label-borrowing also now falls back to
  a descendant's resource-id (not just text/content-desc) as a secondary
  improvement.
- **Root cause #2**: `resolver.py`'s fuzzy tier scored each candidate
  purely on ITS OWN text/resource-id/class. For a list of cards that all
  share one "Apply Now" button template, every button scored identically
  - the resolver locked onto the first one found (well above the
  confidence threshold) and never got to the LLM tier or scrolled further
  to check for a differently-named card lower on the screen. Fixed with
  `page_state._enrich_duplicate_context`: when 2+ elements on screen share
  an exact label, each occurrence is tagged with the OTHER on-screen text
  around it (that card's own title, etc.) via a new `ctx='...'`
  annotation - purely structural (keyed only off "do labels match",
  never off any specific app's wording), so it generalizes to any
  repeated-card/list-item UI. `resolver.py`'s fuzzy scoring now reads this
  context, and an ambiguity-margin check defers a still-close call to the
  LLM tier (which also reads `ctx=`) instead of blind-accepting. This also
  fixed a related latent bug in the persistent screen map
  (`screen_map.py`): every card's identically-`resource-id`'d button would
  otherwise have collapsed onto ONE saved map entry, so a later run could
  have permanently "remembered" and always clicked the wrong card.
- **Vision-fallback ordering**: previously vision was only ever tried
  AFTER auto-scroll-search had already explored every direction - fine
  for a genuinely off-screen target, actively counterproductive for an
  on-screen-but-unlabeled icon (scrolling wastes gestures and risks the
  screen no longer matching what vision expects by the time it finally
  runs). `resolver.py` now tries vision once on the CURRENT, unscrolled
  screen right after the broad-scan tier and before any scrolling begins;
  the original post-scroll vision attempt still runs afterwards as a
  final fallback for a target that only appears after scrolling.
- Validated via `test_fixes_mock.py` (mock Appium driver/elements, no
  live device) - covers both root causes plus regression checks for the
  earlier fixes above (blank EditText placeholder, child-text borrowing,
  non-duplicate elements staying untouched).

**8. A click could report success while doing nothing at all on the real
device - now self-verifies and retries, and the UI can no longer hide it.**
- **Root cause**: `execute_click`'s "ref" path called Selenium's
  `element.click()`, which on UiAutomator2 performs a semantic/
  accessibility-style click. That's reliable for standard native widgets,
  but a bare icon control (a header's support/notification/menu icon in
  particular - often Compose-based, or wired through a raw
  `onTouchListener`/gesture-detector instead of a click listener) frequently
  does not respond to that click at all - Appium reports no exception, the
  element resolved correctly, and yet nothing happens on the device.
  Separately, a plain `click` step with no `expected_outcome` was never
  actually verified either way - `log["verification"]` simply stayed
  `None`, so the Streamlit UI showed a plain green step with no
  contradicting signal at all, which is exactly why it looked like a
  confirmed success.
- **Fix**: `execute_click(driver, target, verify_effect=True)` now
  captures the screen's raw `page_source` signature immediately before and
  after the primary click; if genuinely NOTHING changed, it retries with a
  raw coordinate `mobile: clickGesture` tap - a real synthetic touch
  down+up, which lands correctly regardless of how the view wires up its
  own click handling internally, since it exercises the same input path a
  real finger would. `agent.py`'s `click`/`toggle` steps now use this, and
  when the screen still didn't change (both attempts) AND there was no
  `expected_outcome` to independently confirm against, the step's log now
  carries an honest `method: "no_visible_change", passed: False`
  verification instead of silently defaulting to nothing-checked.
  `execute_select`'s own internal open/pick clicks are untouched
  (`verify_effect` defaults to `False`) - that flow already re-scans and
  fails clearly on its own.
- **UI**: `streamlit_app.py` no longer shows a plain green dot for a step
  that "ran" but was never confirmed - a failed verification now shows a
  distinct 🟡 icon and auto-expands the step (previously any `status=="ok"`
  step stayed collapsed by default, so a silent no-op could go unnoticed
  even when something WAS reported underneath).
- Also validated via `test_fixes_mock.py`: a mock driver/element where
  `.click()` "succeeds" but changes nothing confirms the coordinate-tap
  retry recovers it; a mock where NEITHER attempt changes anything confirms
  an honest `False` is returned rather than blind success; a
  `verify_effect=False` call confirms every other existing call site is
  completely unaffected.

**9. Icon-only elements are now resolved by Set-of-Marks vision grounding,
not blind text-matching on an invented label - the actual fix for "the
tap does nothing, even after the coordinate retry."**
- **Why fix 7/8 weren't enough on their own**: fix 7 gave a truly
  unlabeled icon a generic positional label (e.g. `"(icon button,
  top-right of screen)"`) so it would at least SURFACE in scans. But that
  label is invented by this project, not read from the app - if there's
  more than one unlabeled clickable thing in roughly the same screen
  region (an overlay, a bigger touch-target container, a decorative view),
  the SAME generic label matches all of them equally well, and the fuzzy/
  LLM text tiers would confidently accept whichever one they saw, even
  when it's the WRONG element - and once accepted with confidence, vision
  (which actually looks at the picture) never even got consulted, because
  it's the very last tier. Fix 8's coordinate-tap retry only makes the
  CLICK MECHANISM more reliable - it can't fix a click aimed at the wrong
  element to begin with.
- **Fix**: `page_state._element_info` now marks a purely positional label
  `synthetic`. `resolver._resolve_on_screen` EXCLUDES synthetic-labeled
  elements from the fuzzy tier's scoring pool and from what the LLM tier
  even sees in the screen-state text - such an element can now ONLY ever
  be picked via actual visual confirmation, never blind text similarity.
- **Set-of-Marks (SoM) vision grounding** (`locator_engine.
  resolve_by_vision_som`) replaces the old "guess normalized (x, y)
  coordinates" vision approach for BOTH vision tiers (3.5 and 6): it draws
  a numbered red box around every candidate element already found by the
  narrow + broad text scans (`resolver._combine_candidates`, deduped by
  on-screen geometry) - including a synthetic-labeled icon - onto the
  actual screenshot, and asks the vision model to return the BOX NUMBER
  that matches the description, not freehand coordinates. Picking an item
  from a small labeled list is a task vision-language models are
  meaningfully more consistent at than blind coordinate regression,
  especially for a small icon where a few pixels of error in a freehand
  guess lands the tap entirely outside the real touch target. A picked
  mark resolves to a REAL `ResolvedTarget` tied to the actual element (its
  real clickable state, its real center) - not a bare coordinate guess -
  so it gets the full benefit of `execute_click`'s ancestor-fallback and
  coordinate-retry logic (fix 8), and is fingerprint-cacheable in the
  persistent screen map like any other resolution, so a correct SoM pick
  is remembered and reused instantly on every later run without needing a
  fresh vision call each time. Falls back to the original raw-coordinate
  guess only if SoM itself finds nothing among the candidates at all.
- Validated end-to-end in `test_fixes_mock.py` with a mocked vision model:
  confirms synthetic labels never win a blind text match on their own,
  confirms `_combine_candidates` merges/de-dupes the two scans correctly,
  confirms `_draw_marks` produces a valid annotated image with correctly
  top-to-bottom/left-to-right ordered marks, and confirms a mocked "pick
  mark 2" response correctly resolves back to the real, live element (not
  a coordinate) with its actual clickable/center info intact.

**10. Every vision attempt now saves what it actually saw and said - no
more guessing at why a vision resolution failed.**
- **Root cause of "I can't tell why it isn't working"**: `resolve_by_vision_som`
  and `resolve_by_vision` both took a screenshot via the existing
  `take_screenshot` util (saved as `..._locator_som.png` /
  `..._locator_fallback.png`), but that's the RAW, pre-annotation capture -
  the actual numbered-box image sent to the model, and the model's own
  JSON response (including its `"reasoning"`), were never saved anywhere.
  A failed vision resolution was therefore a complete black box from the
  outside - impossible to tell whether the boxes were drawn in the right
  places, whether the model even considered the right area of the screen,
  or why it said "not found."
- **Fix**: `locator_engine._save_vision_debug` now writes, next to the
  existing step screenshots, for EVERY vision attempt (Set-of-Marks or
  raw-coordinate): the actual annotated image with its numbered boxes
  (`..._som_marked.png` - Set-of-Marks only, since the raw path draws
  nothing), and a `..._result.json` sidecar with the target description
  asked for, how many candidates were offered, the model's full raw JSON
  response, and the live Appium `contexts` at that moment - the same
  cheap WebView/hybrid-screen signal `page_state.dump_failed_screen`
  already checks on a resolution failure. If a `WEBVIEW_*` context shows
  up there, that's conclusive: the target is rendered outside the native
  accessibility tree entirely, and no amount of native-tree scanning
  (narrow, broad, or ancestor-climbing) could ever have found real bounds
  for it - vision (screenshot pixels, not the accessibility tree) is then
  the only viable resolution path in principle, native scanning changes
  can't help.
- Never raises - a failed diagnostic save doesn't break a real resolution
  attempt.

**11. Exhaustive, on-demand whole-screen element mapping
(`screen_crawler.py`) — every element, every property, including
carousels, not just what's currently visible.**
- **What this solves**: every scan in `page_state.py` (narrow or broad)
  only ever sees what's on screen RIGHT NOW - by design, since those scans
  run on every single resolution attempt and have to stay cheap (see that
  module's docstring). There was no way to get a complete picture of an
  entire screen - every element reachable by scrolling, every card in a
  carousel, every UiAutomator2 property of each one - as a single
  artifact you could inspect, without literally stepping through a whole
  test run.
- **How**: a new "🗺️ Map This Screen" button in the Streamlit UI launches
  the app, then exhaustively sweeps the current screen - scrolling down
  through the full vertical extent, detecting and fully swiping through
  any nested horizontal carousel row along the way (and one bounded
  root-level horizontal pass for a tab-strip/pager screen), reading the
  FULL `driver.page_source` XML at each stop (one HTTP call per stop,
  parsed locally - NOT a per-element `get_attribute()` round trip, which
  is what makes an exhaustive sweep actually fast enough to run on
  demand). Every element's full property set - text, content-desc,
  resource-id, class, package, checkable/checked/clickable/long-
  clickable/enabled/focusable/focused/scrollable/selected/password,
  exact bounds/center, index, and (for a recycled list template like
  repeated "Apply Now" buttons) its own surrounding-card context - is
  captured once, deduped by the same fingerprint identity
  `screen_map.py` already uses, tagged with the scroll/swipe path needed
  to reach it again, and exported as a downloadable JSON.
  Purely READ-ONLY (scroll/swipe + attribute reads only) - never taps or
  types anything into the app - so it's safe to run against a live app,
  including a banking app, without any risk of a real side effect.
- **This also makes the live agent smarter for free**: every crawled
  element is merged straight into the persistent screen map
  (`screen_map.py`), so the very next "Plan & Run" against that app can
  jump straight to a known element (resolver tier 4) instead of blindly
  scrolling to find it - no separate step needed.
- Validated in `test_screen_crawler_mock.py` against a simulated
  multi-screen vertical scroll with a nested 4-card carousel: confirms
  every property is parsed correctly from raw XML, confirms fingerprint
  dedup across scroll positions, and confirms every carousel card is
  captured exactly once with the correct `carousel_group` tag (this
  caught and fixed a real bug during development: the plain vertical scan
  was claiming a carousel row's first-visible cards before the carousel
  sub-crawl got to tag them, which would have silently mis-labeled them
  as ordinary elements).

**12. The planner can now be grounded in real, previously-seen screen
elements - "LLM intelligence" that's read from actual device data, not
guessed.**
- `planner.aplan()` now accepts an optional `screen_context` string. The
  Streamlit UI builds this automatically before every "Plan & Run" (see
  `screen_crawler.summarize_known_screens_for_package`) from whatever's
  already known about the configured app's screens - either from an
  earlier "Map This Screen" crawl, or from ordinary opportunistic
  discovery `screen_map.py` already does as a side effect of past runs.
  It's a pure disk read (no live device needed at planning time), so it
  costs nothing extra and silently does nothing (identical prompt, old
  behaviour) the first time you ever run against a new app.
  The planner is told explicitly to treat this as a hint, not a source of
  truth - the live agent still re-resolves everything for real at
  execution time regardless.
- **Failure diagnosis** (`app/automation/brain.py`): when a step fails
  outright, a vision-LLM call now looks at the failure screenshot and
  produces a short, plain-English likely cause and suggestion (e.g.
  "unexpected popup" vs "target genuinely off-screen" vs "app still
  loading") shown right alongside the error in the UI. This is
  deliberately EXPLANATORY only - it never feeds back into the run or
  triggers a new action; see `brain.py`'s docstring for why turning this
  into an autonomous "decide and retry" loop is a real architecture
  change this update does NOT make silently (see "Improvement points"
  below for how that could be added later, as an explicit opt-in).
- **Verification can now find a below-the-fold result**:
  `verifier.averify_with_search` scrolls a bounded amount looking for an
  `expected_outcome` that isn't on the current screen yet (e.g. a
  confirmation banner, or a newly-added item at the bottom of a list)
  before falling back to the existing grey-zone vision judgement - fixes
  a real class of false failures where the expected result was genuinely
  there, just not yet visible.

## Improvement points to consider

Roughly in order of likely impact:

1. **Multi-screen app crawl (opt-in, safety-scoped).** `screen_crawler.py`
   deliberately stops at one screen - following navigation to build a
   full app sitemap would mean tapping real buttons, which is a
   meaningfully different risk profile for a banking app under test than
   the current read-only sweep. If you want this, the safest shape is
   probably: only ever follow elements that look like pure in-app
   navigation (e.g. bottom nav tabs, list rows that open a detail
   screen), with an explicit denylist/allowlist and a hard depth limit,
   and never anything on a screen that looks like a confirm/pay/submit
   step. Worth treating as its own reviewed feature, not a quiet default.
2. **A real device/CI run.** Every fix in this project (including this
   update) has so far only ever been validated against mock drivers - see
   `test_fixes_mock.py` / `test_screen_crawler_mock.py`. That's deliberate
   given the environment these changes were written in, but it means
   there's real, not-yet-caught risk in anything that depends on actual
   UiAutomator2/Appium behaviour (timing quirks, gesture semantics,
   `page_source` formatting differences across Android/Appium versions).
   Running the full mock suite is a good smoke test before a real run,
   not a replacement for one.
3. **`screen_map.py`'s `MAP_DIR` is a module-level snapshot of
   `settings.screen_map_dir`, taken once at import time** (harmless in
   production - settings don't change after startup - but it's the one
   place in this codebase that doesn't read `settings` live on every
   call, which cost real debugging time while writing this update's own
   tests). Worth aligning with `screen_crawler.py`'s pattern (reads
   `settings.screen_graph_dir` fresh every call) for consistency, and so
   a config value can be changed at runtime (e.g. in a test harness)
   without needing to patch two different places.
4. **A page_source-based rewrite of the LIVE resolution path
   (`page_state.get_state`/`get_broad_state`).** This update's crawler
   proves the technique (one HTTP call per screen instead of one per
   element) works and is much faster - but deliberately only uses it for
   its own new, purely-read-only crawl, not for the live click/type path
   those two functions feed, since that would need on-device regression
   testing to validate click reliability isn't affected (see
   `page_state.py`'s own docstring - this exact idea was already
   considered and shelved for the same reason). If a full device test
   pass ever becomes available, this is probably the single biggest
   remaining performance win in the whole project.
5. **Bounded, scoped self-healing beyond diagnosis.** `brain.py`
   currently only explains a failure; it never acts on its own
   conclusion. A natural next step - if you want it - is letting a
   *specific, narrow* class of diagnosis trigger a *specific, narrow*
   recovery (e.g. "diagnosis says an unexpected popup" -> re-run
   `dismiss_popups` once, then retry ONLY the resolution step, not the
   whole plan) rather than a general "decide what to do" loop. Scoping it
   to a small, enumerated set of recoveries keeps the "the agent doesn't
   wander" guarantee `agent.py` is built around, while still recovering
   from the single most common real-world flake (an interstitial promo/
   permission dialog).
6. **Carousel/scroll-region crawl currently assumes one nesting level.**
   `screen_crawler.py` detects a horizontal row nested in an otherwise-
   vertical screen, and (separately) a root-level horizontal pager - it
   does not currently handle a horizontal carousel whose OWN cards each
   scroll vertically (a genuinely 2D scroll structure), which is rare but
   does exist in some apps. `screen_map.py` already made the same
   deliberate simplification for the live resolver's own scroll-search,
   for the same combinatorial-cost reason - worth revisiting together if
   it turns out to matter for a specific screen you're testing.
7. **Screen graphs are per-screen JSON files, not yet a queryable
   app-wide index.** Once you're mapping several screens regularly,
   a small index/search step (e.g. "which screen has an element matching
   X") on top of `logs/screen_graphs/` would make the exported JSON more
   useful for ad-hoc QA documentation, beyond planner grounding.

## Architecture

```
streamlit_app.py
  -> screen_crawler.summarize_known_screens_for_package   # optional plan grounding (disk read, no device)
  -> planner.aplan(instructions, screen_context)      # ONE call, produces the full plan
  -> agent.run_plan(planned_steps)    # executes that fixed plan, in order
       -> driver_manager.DriverManager   # starts Appium session (launches app)
       -> popup_handler.dismiss_popups   # clears permission/consent dialogs
       -> page_state.get_state           # fresh on-screen element list
       -> resolver.aresolve_by_description  # fuzzy -> LLM -> vision
       -> action_executor.execute_*       # the actual tap/type/scroll/etc.
       -> verifier.averify_with_search    # fuzzy text/field match (+ scroll-search) -> vision
       -> brain.adiagnose_failure         # explanatory-only, on a failed step

streamlit_app.py
  -> screen_crawler.acrawl_current_app   # standalone "Map This Screen" - its own driver session
       -> screen_crawler.acrawl_screen        # exhaustive sweep (page_source-parsed, read-only)
       -> screen_map.save_map                 # merges into the same persistent map resolver tier 4 reads
```

`app/llm/model_client.py` is the single place that talks to Groq/Azure —
every other module calls `achat_json` / `achat_vision_json` and doesn't
know or care which provider is behind it.

## Setup

1. `pip install -r requirements.txt`
2. Copy `.env.example` to `.env` and fill in your keys, deployment/model
   names, and `ANDROID_APP_PACKAGE` / `ANDROID_APP_ACTIVITY`.
3. Start Appium: `appium` (defaults to `http://127.0.0.1:4723`, matching
   `APPIUM_SERVER_URL`).
4. Connect a device or start an emulator.
5. `streamlit run streamlit_app.py`

## Using it

Type your steps in plain English, e.g.:

> Enter username 'john.doe' in the username field, enter password
> 'secret123' in the password field, tap Login, then verify the dashboard
> is shown.

Click **Plan & Run**. You'll first see the exact plan the agent extracted
(one line per atomic action) — review it before it executes. Then each
step runs, with a screenshot and pass/fail verification, and the run stops
automatically once the plan is complete.

Before your first real run against a new screen, consider opening
**🗺️ Map This Screen** and clicking **Map current screen** — it's a
one-off, read-only sweep of whatever screen the app opens on, and both
speeds up and better-grounds every "Plan & Run" against that screen from
then on (see items 11–12 above). It's optional; "Plan & Run" works fine
without ever using it, just less informed on a brand-new app.

### Supported actions (what the planner can produce)

| Action        | Needs target? | `value` holds                 |
|---------------|:--------------:|--------------------------------|
| `click`       | yes            | —                               |
| `type`        | yes            | text to type                    |
| `select`      | yes            | option text (dropdown/spinner)  |
| `toggle`      | yes            | — (checkbox/switch/radio)       |
| `scroll`      | no             | direction (up/down/left/right)  |
| `wait`        | no             | seconds                         |
| `press_back`  | no             | — (Android hardware Back)       |
| `close_app`   | no             | — (terminates the app)          |
| `verify`      | yes (as a description) | —                     |

## Config reference (`.env`)

See `.env.example` for the full list with defaults. Key ones:

- `LLM_PROVIDER` — `groq` or `azure`, drives both text and vision.
- `ANDROID_APP_PACKAGE` / `ANDROID_APP_ACTIVITY` — the app under test;
  launched automatically by Appium.
- `MAX_STEPS` — safety ceiling on how many steps a single plan may
  contain (not a retry loop — it caps plan length).
- `ENABLE_VISION_FALLBACK` — if `false`, resolution/verification never
  fall back to a screenshot-based vision call; a step that can't be
  resolved from the on-screen element list simply fails instead.
- `POPUP_DISMISS_ENABLED` — auto-dismiss common permission/consent
  dialogs before each step.
- `CRAWL_MAX_SCROLLS` / `CRAWL_MAX_CAROUSEL_SWIPES` — ceilings on how far
  "Map This Screen" sweeps vertically / swipes through a carousel before
  giving up on finding anything new.
- `GROUND_PLAN_WITH_SCREEN_MAP` — if `false`, planning never reads
  previously-crawled/discovered screen data (old behaviour).
- `BRAIN_DIAGNOSIS_ENABLED` — if `false`, a failed step's log has no
  extra diagnosis note (old behaviour); the run itself is unaffected
  either way.
- `VERIFY_SCROLL_MAX_ATTEMPTS` — set to `0` to disable verification's
  scroll-search (old averify()-only behaviour).

## Notes

- `.env` is intentionally **not** included in this delivery — keep using
  your existing one, just add the new variables shown in `.env.example`'s
  latest additions (all optional, all default to sensible values if
  omitted entirely).
- `logs/screenshots/` is created automatically at startup for step
  screenshots. `logs/screen_maps/` (persistent per-screen element map)
  and `logs/screen_graphs/` (exported "Map This Screen" JSON files) are
  created automatically too.
