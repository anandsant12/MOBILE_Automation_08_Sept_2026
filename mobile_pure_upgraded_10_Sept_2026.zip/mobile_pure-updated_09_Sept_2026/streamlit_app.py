import asyncio
import json

import streamlit as st
from config import settings
from app.automation.planner import aplan
from app.automation.agent import run_plan
from app.automation import screen_crawler

st.set_page_config(page_title="AI Mobile Automation", layout="wide")

st.title("AI-driven Mobile Automation")
st.caption(
    "Describe the steps in plain English. The agent PLANS the whole "
    "sequence first, shows you the plan, then executes exactly that plan - "
    "one time, in order - and stops. It will not invent extra steps or "
    "keep going once the plan is done."
)

with st.sidebar:
    st.header("Config (from .env)")
    st.text(f"LLM provider: {settings.llm_provider}")
    if settings.llm_provider == "groq":
        st.text(f"Text model: {settings.groq_model}")
        st.text(f"Vision model: {settings.groq_vision_model}")
    else:
        st.text(f"Azure deployment (text+vision): {settings.azure_openai_deployment}")
    st.text(f"App package: {settings.android_app_package}")
    st.text(f"App activity: {settings.android_app_activity}")
    st.text(f"Vision fallback: {'on' if settings.enable_vision_fallback else 'off (text-only locators)'}")
    st.text(f"Popup auto-dismiss: {'on' if settings.popup_dismiss_enabled else 'off'}")
    st.text(f"Max steps per plan: {settings.max_steps}")
    st.divider()
    st.caption("Screen mapping / planning intelligence")
    st.text(f"Plan grounding from known screens: {'on' if settings.ground_plan_with_screen_map else 'off'}")
    st.text(f"Failure diagnosis: {'on' if settings.brain_diagnosis_enabled else 'off'}")
    st.text(f"Verify scroll-search: up to {settings.verify_scroll_max_attempts} scroll(s)")
    st.text(f"Crawl limits: {settings.crawl_max_scrolls} scrolls / {settings.crawl_max_carousel_swipes} swipes")
    st.caption("Change any of these in your .env file, then restart the app.")

if "agent_running" not in st.session_state:
    st.session_state.agent_running = False
if "crawl_running" not in st.session_state:
    st.session_state.crawl_running = False

# Appium generally only supports one active session at a time, and "Plan &
# Run" / "Map This Screen" each start their own - so only one of the two
# may run at once. Both buttons below are disabled while EITHER is busy.
_busy = st.session_state.agent_running or st.session_state.crawl_running

# ---------------------------------------------------------------------------
# Section 1: Map This Screen - an exhaustive, READ-ONLY sweep of whatever
# screen the app is currently on (scrolls/swipes through the full screen and
# any nested carousels, capturing every element's full properties - see
# app/automation/screen_crawler.py). Produces a downloadable JSON and also
# feeds the persistent screen map that both the live resolver (faster,
# more reliable target-finding) and "Plan & Run" below (better-grounded
# planning) benefit from immediately, with no further setup.
# ---------------------------------------------------------------------------
with st.expander("🗺️ Map This Screen (exhaustive element scan)", expanded=False):
    st.caption(
        "Launches the app, then scrolls/swipes through the ENTIRE current "
        "screen - including nested carousels - recording every element's "
        "full properties (text, resource-id, class, every UiAutomator2 "
        "flag, exact bounds, and how to scroll/swipe back to it). This "
        "never types or taps anything into the app - it only reads - so "
        "it's safe to run against a live app. Results also feed the "
        "persistent screen map used by both live runs and plan grounding "
        "below."
    )
    map_clicked = st.button("Map current screen", disabled=_busy)
    map_result_container = st.container()

    if map_clicked:
        st.session_state.crawl_running = True
        with st.spinner("Launching app and mapping the current screen..."):
            try:
                graph = asyncio.run(screen_crawler.acrawl_current_app())
                with map_result_container:
                    st.success(
                        f"Mapped `{graph.get('activity') or 'unknown screen'}` - "
                        f"found {graph['total_elements']} distinct element(s) "
                        f"across {graph['vertical_scrolls_performed']} scroll(s) "
                        f"and {len(graph['carousels'])} carousel/pager region(s)."
                    )
                    st.download_button(
                        "Download screen graph JSON",
                        data=json.dumps(graph, indent=2, default=str),
                        file_name=f"{graph.get('activity') or 'screen'}_graph.json",
                        mime="application/json",
                    )
                    with st.expander("Preview elements found"):
                        st.json(graph["elements"][:200])
            except Exception as e:
                with map_result_container:
                    st.error(f"Could not map the screen: {e}")
            finally:
                st.session_state.crawl_running = False

goal = st.text_area(
    "What should the agent do?",
    placeholder="e.g. Enter username 'john.doe' in the username field, enter "
                "password 'secret123' in the password field, tap Login, then "
                "verify the dashboard is shown.",
    height=100,
)

run_clicked = st.button(
    "Plan & Run",
    type="primary",
    disabled=not goal.strip() or _busy,
)


def _render_plan(planned_steps, grounded: bool):
    title = f"📋 Plan ({len(planned_steps)} step(s)) — this is exactly what will run"
    if grounded:
        title += " · grounded with known screen map"
    with st.expander(title, expanded=True):
        for i, s in enumerate(planned_steps, 1):
            line = f"**{i}. {s.action}**"
            if s.target:
                line += f" → \"{s.target}\""
            if s.value:
                line += f" = \"{s.value}\""
            st.markdown(line)
            hints = []
            if s.direction_hint:
                hints.append(f"try {s.direction_hint} first")
            if s.gesture_hint:
                hints.append(f"{s.gesture_hint} gesture")
            if hints:
                st.caption(f"search hint: {', '.join(hints)}")
            if s.expected_outcome:
                st.caption(f"expects: {s.expected_outcome}")


def _render_step(log_container, log):
    step = log["step"]
    action = log["action"]
    status = log["status"]
    verification = log.get("verification")
    verification_failed = bool(verification) and not verification.get("passed")

    icon = {"ok": "🟢", "finished": "✅", "error": "⚠️"}.get(status, "•")
    if status == "ok" and verification_failed:
        # Execution didn't raise, but nothing actually confirmed the
        # action had an effect (e.g. a click that resolved and "succeeded"
        # per Appium, yet nothing changed on screen - see action_executor.
        # execute_click's verify_effect). A plain green dot here would be
        # misleading - this needs to look visibly different from a step
        # that both ran AND was confirmed.
        icon = "🟡"

    with log_container:
        if status == "finished":
            st.success("Plan complete. Agent has stopped - no further actions will run.")
            return

        label = action.get("action")
        if action.get("target"):
            label += f" → \"{action['target']}\""
        # Auto-expand whenever there's something worth looking at, not just
        # on a hard execution error - a step that "ran fine" but couldn't
        # be confirmed shouldn't be able to hide in a collapsed expander.
        expanded = status != "ok" or verification_failed
        with st.expander(f"{icon} Step {step}: {label}", expanded=expanded):
            st.json(action)

            if verification:
                v = verification
                vt = "✅ Passed" if v["passed"] else "❌ Failed"
                st.write(f"**Verification ({v['method']}, score={v['score']}):** {vt}")
                st.caption(v["reasoning"])

            if log.get("error"):
                st.error(log["error"])

            diagnosis = log.get("diagnosis")
            if diagnosis:
                # Explanatory only - see brain.py's docstring. Shown
                # distinctly from the raw error so it reads as "here's a
                # likely reason", not as a second, competing error message.
                st.info(
                    f"**Likely cause:** {diagnosis['likely_cause']}\n\n"
                    f"{diagnosis['explanation']}\n\n"
                    f"**Suggestion:** {diagnosis['suggestion']}"
                )

            if log.get("screenshot"):
                st.image(str(log["screenshot"]), width=400)

        if status == "error":
            st.error("Agent stopped — this step could not be completed.")
        elif verification_failed:
            st.warning(
                "This step ran without a technical error, but nothing "
                "confirmed it actually had the expected effect - see the "
                "verification note above before trusting this step."
            )


def _plan_and_run(goal: str, plan_container, log_container):
    """Plans once, shows the plan, then drives the fixed-plan execution to
    completion in one dedicated event loop. Guaranteed to run the plan
    exactly once per call - no re-planning, no repeat runs."""

    async def _drive():
        screen_context = ""
        if settings.ground_plan_with_screen_map:
            # Pure disk read of whatever's already known about this app's
            # screens (from an earlier "Map This Screen" run, or built up
            # opportunistically by past runs' own resolution - see
            # screen_map.py) - no live device needed yet at planning time.
            # "" (nothing known) leaves aplan()'s behaviour unchanged.
            screen_context = await asyncio.to_thread(
                screen_crawler.summarize_known_screens_for_package, settings.android_app_package,
            )
        planned_steps = await aplan(goal, screen_context=screen_context or None)
        if not planned_steps:
            with plan_container:
                st.warning("The planner could not turn this into any actionable steps. Try rephrasing.")
            return
        with plan_container:
            _render_plan(planned_steps, grounded=bool(screen_context))
        async for log in run_plan(planned_steps):
            _render_step(log_container, log)

    asyncio.run(_drive())


if run_clicked:
    st.session_state.agent_running = True
    plan_container = st.container()
    log_container = st.container()
    with st.spinner("Planning, then running..."):
        try:
            _plan_and_run(goal, plan_container, log_container)
        finally:
            st.session_state.agent_running = False
