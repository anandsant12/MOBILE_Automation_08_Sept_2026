"""
Mock-driver validation for this update's new capabilities - same pattern
as test_fixes_mock.py (no live device needed):

  1. screen_crawler._parse_page_source_elements: every UiAutomator2 property
     is correctly extracted from a raw page_source XML dump - against BOTH
     real Appium/UiAutomator2 output (tag name = the Android view's own
     class name, e.g. <android.widget.TextView .../>) AND the older,
     generic <node class="..."/> shape some other tools/setups use. An
     earlier version of this module only recognised the <node> shape,
     which is what `adb shell uiautomator dump` produces but is NOT what
     Appium's own page_source actually returns - so it silently found
     ZERO elements against a real device (empty elements/carousels in the
     exported JSON) even though every scenario below "passed" against
     hand-written <node>-shaped test XML. Scenario 1 now uses the REAL
     shape as its primary fixture specifically so this class of bug can't
     silently reappear and still show a green test run.
  2. screen_crawler._merge_elements: fingerprint-based dedup works (a
     re-seen element doesn't get double-counted or overwrite its first path).
  3. screen_crawler.acrawl_screen, end-to-end against a MockDriver that
     simulates a 3-"page" vertical scroll with a nested horizontal carousel
     on the middle page: confirms every element across every scroll AND
     every carousel swipe is captured exactly once, with the right
     carousel_group tagging, and that the persistent screen map + JSON
     export both come out correctly.
  4. screen_crawler.summarize_known_screens_for_package: reads that same
     freshly-written map back and produces sane grounding text.
  5. planner.aplan: screen_context, when given, actually reaches the model
     prompt (mocked achat_json) and is a no-op on the prompt when omitted.
  6. verifier.averify_with_search: finds an expected result that's only
     present after scrolling, which plain averify() alone would miss.
  7. brain.adiagnose_failure: returns a diagnosis when enabled (mocked
     vision call), and cleanly returns None when disabled - never raises.
  8. screen_crawler.acrawl_screen fails LOUDLY (raises, with a diagnostic
     XML dump) rather than silently returning an empty-looking "success"
     when the first read finds zero parseable elements.
"""

import asyncio
import json
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from config import settings
from app.automation import screen_crawler as sc
from app.automation import screen_map
from app.automation import page_state as ps
from app.automation import verifier
from app.automation import brain
from app.automation.action_executor import execute_scroll, execute_swipe
import app.llm.model_client as model_client_mod


# ---------------------------------------------------------------------------
# Scenario 1: every property is correctly parsed out of raw page_source XML,
# against the REAL Appium/UiAutomator2 tag shape.
# ---------------------------------------------------------------------------
print("=== Scenario 1: _parse_page_source_elements captures every property ===")

# This is the ACTUAL shape Appium's UiAutomator2 driver returns for
# driver.page_source: the tag name IS the Android view's class name
# (with a "class" attribute duplicating the same value), not a generic
# <node class="..."/> wrapper - see the module docstring above.
SAMPLE_XML = """<hierarchy rotation="0">
  <android.widget.FrameLayout index="0" text="" resource-id="" class="android.widget.FrameLayout" package="com.test.app" content-desc="" checkable="false" checked="false" clickable="false" enabled="true" focusable="false" focused="false" scrollable="true" long-clickable="false" password="false" selected="false" bounds="[0,0][1080,2280]">
    <android.widget.EditText index="0" text="Mobile Number" resource-id="com.test.app:id/etMobile" class="android.widget.EditText" package="com.test.app" content-desc="" checkable="false" checked="false" clickable="true" enabled="true" focusable="true" focused="true" scrollable="false" long-clickable="false" password="false" selected="false" bounds="[80,200][1000,320]"/>
    <android.widget.CheckBox index="1" text="" resource-id="com.test.app:id/cbRemember" class="android.widget.CheckBox" package="com.test.app" content-desc="Remember me" checkable="true" checked="true" clickable="true" enabled="true" focusable="true" focused="false" scrollable="false" long-clickable="false" password="false" selected="false" bounds="[80,400][400,480]"/>
  </android.widget.FrameLayout>
</hierarchy>"""

parsed = sc._parse_page_source_elements(SAMPLE_XML)
assert len(parsed) == 3, f"expected 3 nodes (1 container + 2 children), got {len(parsed)}"
mobile_field = next(e for e in parsed if e["resource_id"] == "etMobile")
remember_box = next(e for e in parsed if e["resource_id"] == "cbRemember")

assert mobile_field["text"] == "Mobile Number"
assert mobile_field["class"] == "EditText"
assert mobile_field["class_full"] == "android.widget.EditText"
assert mobile_field["package"] == "com.test.app"
assert mobile_field["clickable"] is True and mobile_field["focusable"] is True and mobile_field["focused"] is True
assert mobile_field["checkable"] is False and mobile_field["scrollable"] is False
assert mobile_field["bounds"] == (80, 200, 1000, 320)
assert mobile_field["center"] == (540, 260)
assert mobile_field["index"] == "0"

assert remember_box["desc"] == "Remember me"
assert remember_box["checkable"] is True and remember_box["checked"] is True
assert remember_box["long_clickable"] is False and remember_box["password"] is False
assert remember_box["selected"] is False
print("PASS: every UiAutomator2 property (text/desc/resource-id/class/package/"
      "checkable/checked/clickable/long-clickable/enabled/focusable/focused/"
      "scrollable/selected/password/index/bounds/center) is correctly extracted "
      "from the REAL tag-as-classname XML shape\n")

# Defense in depth: the older, generic <node class="..."/> shape (what
# `adb shell uiautomator dump` produces, as opposed to Appium's own
# page_source) must ALSO still parse correctly, in case some other
# Appium/driver setup ever emits it.
LEGACY_NODE_XML = """<hierarchy rotation="0">
  <node index="0" text="Legacy" resource-id="com.test.app:id/tvLegacy" class="android.widget.TextView" package="com.test.app" content-desc="" checkable="false" checked="false" clickable="false" enabled="true" focusable="false" focused="false" scrollable="false" long-clickable="false" password="false" selected="false" bounds="[0,0][200,60]"/>
</hierarchy>"""
legacy_parsed = sc._parse_page_source_elements(LEGACY_NODE_XML)
assert len(legacy_parsed) == 1 and legacy_parsed[0]["text"] == "Legacy"
print("PASS: the older generic <node class=\"...\"/> XML shape still parses correctly too\n")


# ---------------------------------------------------------------------------
# Scenario 2: fingerprint-based dedup in _merge_elements.
# ---------------------------------------------------------------------------
print("=== Scenario 2: _merge_elements dedups by fingerprint, keeps first path ===")
seen_fp, map_sink = {}, {}
added1 = sc._merge_elements(parsed, path=[], seen_fp=seen_fp, map_sink=map_sink)
assert added1 == 2, f"expected 2 identifiable elements (container has no rid/text), got {added1}"
added2 = sc._merge_elements(parsed, path=[{"gesture": "scroll", "direction": "down", "count": 1}],
                             seen_fp=seen_fp, map_sink=map_sink)
assert added2 == 0, "re-seeing the same elements at a later scroll position must add nothing new"
some_key = next(k for k, v in seen_fp.items() if v.get("resource_id") == "etMobile")
assert seen_fp[some_key]["path"] == [], "first-seen path must be kept, not overwritten by the later re-scan"
print("PASS: identical elements seen again at a different scroll position are not double-counted, "
      "and the FIRST (shortest) path they were found via is preserved\n")


# ---------------------------------------------------------------------------
# Scenario 3: full acrawl_screen() against a simulated 3-page vertical
# scroll with a 4-card horizontal carousel nested in the middle page.
# ---------------------------------------------------------------------------
print("=== Scenario 3: acrawl_screen end-to-end (vertical scroll + nested carousel) ===")


def _node(text="", desc="", rid="", cls="android.widget.TextView", bounds="[0,0][0,0]", clickable="false"):
    # Realistic Appium/UiAutomator2 shape - tag name IS the class name,
    # same as SAMPLE_XML in Scenario 1 above (see this file's docstring
    # for why that distinction is the whole point of this test file).
    rid_full = f"com.test.app:id/{rid}" if rid else ""
    return (f'<{cls} index="0" text="{text}" resource-id="{rid_full}" class="{cls}" '
            f'package="com.test.app" content-desc="{desc}" checkable="false" checked="false" '
            f'clickable="{clickable}" enabled="true" focusable="false" focused="false" '
            f'scrollable="false" long-clickable="false" password="false" selected="false" '
            f'bounds="{bounds}"/>')


def _hierarchy(nodes):
    return ('<hierarchy rotation="0"><android.widget.FrameLayout index="0" text="" resource-id="" '
            'class="android.widget.FrameLayout" package="com.test.app" content-desc="" '
            'checkable="false" checked="false" clickable="false" enabled="true" '
            'focusable="false" focused="false" scrollable="true" long-clickable="false" '
            'password="false" selected="false" bounds="[0,0][1080,2280]">'
            + "".join(nodes) + "</android.widget.FrameLayout></hierarchy>")


CAROUSEL_WINDOWS = {0: ("A", "B"), 1: ("B", "C"), 2: ("C", "D")}


class MockElementWrapper:
    """Just enough of a live WebElement for page_state.get_state() (used
    internally by screen_map.reset_to_top) to work against a parsed
    element dict - never touched by the crawler itself, which reads
    page_source directly (see screen_crawler.py's docstring)."""
    def __init__(self, info: dict):
        self._info = info

    def get_attribute(self, name):
        mapping = {
            "text": "text", "content-desc": "desc", "resource-id": "resource_id_full",
            "className": "class_full", "checkable": "checkable", "checked": "checked",
            "clickable": "clickable", "enabled": "enabled", "bounds": None,
        }
        if name == "bounds":
            b = self._info.get("bounds")
            return f"[{b[0]},{b[1]}][{b[2]},{b[3]}]" if b else ""
        key = mapping.get(name)
        val = self._info.get(key) if key else None
        if isinstance(val, bool):
            return "true" if val else "false"
        return val or ""

    def find_elements(self, by, xpath):
        return []


class MockCrawlDriver:
    def __init__(self):
        self.scroll_pos = 0
        self.carousel_pos = 0
        self.current_package = "com.test.app"
        self.current_activity = ".HomeActivity"
        self.swipe_log = []

    def _content_index(self):
        return min(self.scroll_pos, 2)

    @property
    def page_source(self):
        idx = self._content_index()
        if idx == 0:
            nodes = [
                _node(text="Welcome", bounds="[40,40][600,100]"),
                _node(text="Login", rid="btnLogin", cls="android.widget.Button",
                      clickable="true", bounds="[100,1200][900,1300]"),
            ]
        elif idx == 1:
            cp = min(self.carousel_pos, 2)
            left, right = CAROUSEL_WINDOWS[cp]
            nodes = [
                _node(text="Featured Cards", bounds="[40,40][600,100]"),
                _node(text=f"Card {left}", rid=f"card_{left}", clickable="true",
                      bounds="[40,1200][500,1500]"),
                _node(text=f"Card {right}", rid=f"card_{right}", clickable="true",
                      bounds="[580,1200][1040,1500]"),
            ]
        else:
            nodes = [
                _node(text="Terms and Conditions apply", bounds="[40,40][900,100]"),
                _node(text="Submit", rid="btnSubmit", cls="android.widget.Button",
                      clickable="true", bounds="[100,1200][900,1300]"),
            ]
        return _hierarchy(nodes)

    def find_elements(self, by, xpath):
        elements = sc._parse_page_source_elements(self.page_source)
        if xpath == ps.ANDROID_INTERACTIVE_XPATH:
            matches = [e for e in elements if e["clickable"]]
        elif xpath == ps.ANDROID_TEXT_XPATH:
            matches = [e for e in elements if e["text"] or e["desc"]]
        else:
            matches = []
        return [MockElementWrapper(e) for e in matches]

    def get_window_size(self):
        return {"width": 1080, "height": 2280}

    def execute_script(self, name, args=None):
        self.swipe_log.append((name, (args or {}).get("direction")))
        if name != "mobile: swipeGesture":
            return None
        direction = (args or {}).get("direction")
        if direction == "down":
            self.scroll_pos = min(self.scroll_pos + 1, 3)
        elif direction == "up":
            self.scroll_pos = max(self.scroll_pos - 1, 0)
        elif direction == "right":
            self.carousel_pos = min(self.carousel_pos + 1, 5)
        elif direction == "left":
            self.carousel_pos = max(self.carousel_pos - 1, 0)
        return None


# Redirect crawl/map output to a throwaway temp dir so this test never
# touches (or depends on) whatever real logs/ already exist. Note:
# screen_map.py reads settings.screen_map_dir into a MODULE-LEVEL constant
# (MAP_DIR) once at import time rather than per-call - correct in
# production (settings don't change after startup) but means a test must
# patch screen_map.MAP_DIR directly, not settings.screen_map_dir, to
# actually redirect it (see the README's "Improvement points" section -
# this asymmetry with screen_graph_dir, read fresh from settings on every
# call in screen_crawler.py, is a minor consistency nit worth fixing).
_tmp = Path(tempfile.mkdtemp())
_orig_map_dir_setting, _orig_map_dir_module = settings.screen_map_dir, screen_map.MAP_DIR
_orig_graph_dir = settings.screen_graph_dir
_tmp_map_dir = _tmp / "screen_maps"
settings.screen_map_dir = _tmp_map_dir       # read by screen_crawler.summarize_known_screens_for_package
screen_map.MAP_DIR = _tmp_map_dir            # read by screen_map.save_map/load_map (see note above)
settings.screen_graph_dir = _tmp / "screen_graphs"

driver = MockCrawlDriver()
graph = asyncio.run(sc.acrawl_screen(driver, max_carousel_swipes=10))

assert graph["package"] == "com.test.app" and graph["activity"] == ".HomeActivity"
# Welcome, Login, Featured Cards, Card A/B/C/D, Terms, Submit = 9 distinct elements
assert graph["total_elements"] == 9, f"expected 9 distinct elements, got {graph['total_elements']}: " \
    f"{[e.get('text') for e in graph['elements']]}"
assert graph["scrolls_vertically"] is True

labels = {e["text"] for e in graph["elements"]}
assert {"Welcome", "Login", "Featured Cards", "Card A", "Card B", "Card C", "Card D",
        "Terms and Conditions apply", "Submit"} == labels
print(f"PASS: all 9 elements across the full vertical scroll AND the nested carousel "
      f"were captured exactly once: {sorted(labels)}")

nested_carousels = [c for c in graph["carousels"] if c["id"].startswith("carousel@")]
assert len(nested_carousels) == 1, f"expected exactly 1 nested carousel region, got {nested_carousels}"
assert nested_carousels[0]["new_items_found"] == 4, "expected all 4 cards (A/B/C/D) via the carousel sweep"
card_elements = [e for e in graph["elements"] if e["text"].startswith("Card ")]
assert all(e["carousel_group"] == nested_carousels[0]["id"] for e in card_elements)
non_card_elements = [e for e in graph["elements"] if not e["text"].startswith("Card ")]
assert all(e["carousel_group"] is None for e in non_card_elements)
print("PASS: carousel cards are correctly tagged with their carousel_group; "
      "regular vertical elements are not\n")

assert Path(graph["saved_path"]).exists(), "expected the screen graph JSON to actually be written to disk"
on_disk = json.loads(Path(graph["saved_path"]).read_text())
assert on_disk["total_elements"] == 9
print(f"PASS: screen graph JSON saved to disk and round-trips correctly ({graph['saved_path']})\n")


# ---------------------------------------------------------------------------
# Scenario 4: the crawl also merges into the persistent screen map, and
# summarize_known_screens_for_package can read it back for plan grounding.
# ---------------------------------------------------------------------------
print("=== Scenario 4: crawl results feed the persistent map + planner grounding ===")
map_files = list(screen_map.MAP_DIR.glob("*.json"))
assert len(map_files) == 1, f"expected exactly one persistent map file, found {len(map_files)}"
map_data = json.loads(map_files[0].read_text())
assert map_data["package"] == "com.test.app" and len(map_data["elements"]) == 9
print("PASS: acrawl_screen merged every crawled element into the persistent screen map")

summary = sc.summarize_known_screens_for_package("com.test.app")
assert ".HomeActivity" in summary
for label in ("Login", "Submit", "Card A", "Featured Cards"):
    assert label in summary, f"expected '{label}' in grounding summary, got: {summary!r}"
print("PASS: summarize_known_screens_for_package produces a grounding summary "
      "containing the real, crawled element labels\n")

settings.screen_map_dir = _orig_map_dir_setting
screen_map.MAP_DIR = _orig_map_dir_module
settings.screen_graph_dir = _orig_graph_dir


# ---------------------------------------------------------------------------
# Scenario 5: planner.aplan actually forwards screen_context into the
# prompt when given, and is unchanged when it's omitted.
# ---------------------------------------------------------------------------
print("=== Scenario 5: planner.aplan screen_context grounding ===")
from app.automation import planner

captured_prompts = []


async def _fake_achat_json(system_prompt, user_prompt):
    captured_prompts.append(user_prompt)
    return {"steps": [{"action": "click", "target": "Login", "value": None,
                        "direction_hint": None, "gesture_hint": None,
                        "expected_outcome": None}]}


_orig_achat_json = planner.achat_json
planner.achat_json = _fake_achat_json

asyncio.run(planner.aplan("Tap the login button"))
assert "Known elements from real scans" not in captured_prompts[-1], \
    "omitting screen_context must leave the prompt exactly as before"

asyncio.run(planner.aplan("Tap the login button", screen_context="- Screen `.HomeActivity`: Login, Welcome"))
assert "Screen `.HomeActivity`: Login, Welcome" in captured_prompts[-1], \
    "screen_context, when given, must actually reach the planning prompt"
print("PASS: screen_context is correctly injected when provided, and leaves the "
      "prompt byte-for-byte unchanged (old behaviour) when omitted\n")

planner.achat_json = _orig_achat_json


# ---------------------------------------------------------------------------
# Scenario 6: verifier.averify_with_search finds an expected result that
# only appears after scrolling - plain averify() alone would report this
# as a false failure.
# ---------------------------------------------------------------------------
print("=== Scenario 6: verifier.averify_with_search scrolls to find a below-the-fold result ===")


class MockVerifyDriver:
    """A simple 3-screen vertical list: the text "Payment Successful" only
    exists on the 3rd screen (2 scrolls down from the start)."""
    def __init__(self):
        self.pos = 0

    def find_elements(self, by, xpath):
        texts = {
            0: ["Home", "Balance: 1000"],
            1: ["Recent Transactions", "No items yet"],
            2: ["Payment Successful", "Reference ABC123"],
        }.get(min(self.pos, 2), [])
        return [_TextEl(t) for t in texts]

    def get_window_size(self):
        return {"width": 1080, "height": 2280}

    def execute_script(self, name, args=None):
        if (args or {}).get("direction") == "down":
            self.pos += 1


class _TextEl:
    def __init__(self, text):
        self._text = text

    def get_attribute(self, name):
        if name == "text":
            return self._text
        if name == "class":
            return "android.widget.TextView"
        return ""


verify_driver = MockVerifyDriver()
result_no_search = asyncio.run(verifier.averify(verify_driver, "Payment Successful"))
assert result_no_search["passed"] is False, "plain averify() on screen 0 should NOT find screen-2-only text"

verify_driver2 = MockVerifyDriver()
result_with_search = asyncio.run(verifier.averify_with_search(verify_driver2, "Payment Successful"))
assert result_with_search["passed"] is True, "averify_with_search should scroll down and find it"
print("PASS: averify_with_search scrolled past 2 screens and correctly found the expected result "
      "that plain averify() alone would have missed\n")


# ---------------------------------------------------------------------------
# Scenario 7: brain.adiagnose_failure - returns a diagnosis when enabled
# (mocked vision call), and is a clean no-op when disabled.
# ---------------------------------------------------------------------------
print("=== Scenario 7: brain.adiagnose_failure ===")
import app.utils.screenshot as screenshot_mod


async def _fake_vision_json(system_prompt, user_prompt, image_b64):
    assert "Could not locate" in user_prompt
    return {"likely_cause": "unexpected popup/dialog",
            "explanation": "A promotional dialog appears to be covering the target.",
            "suggestion": "Dismiss the dialog first, or reword the target to be more specific."}


def _fake_take_screenshot(driver, label):
    import tempfile as _t, os
    fd, path = _t.mkstemp(suffix=".png")
    os.close(fd)
    from PIL import Image
    Image.new("RGB", (100, 100)).save(path)
    return path


_orig_vision = model_client_mod.achat_vision_json
_orig_shot = screenshot_mod.take_screenshot
brain.achat_vision_json = _fake_vision_json
brain.take_screenshot = _fake_take_screenshot

settings.brain_diagnosis_enabled = True
settings.enable_vision_fallback = True
diagnosis = asyncio.run(brain.adiagnose_failure(object(), "Apply Now button", "Could not locate element"))
assert diagnosis is not None and diagnosis["likely_cause"] == "unexpected popup/dialog"
print("PASS: adiagnose_failure returns a structured diagnosis when enabled")

settings.brain_diagnosis_enabled = False
diagnosis_off = asyncio.run(brain.adiagnose_failure(object(), "Apply Now button", "Could not locate element"))
assert diagnosis_off is None
settings.brain_diagnosis_enabled = True
print("PASS: adiagnose_failure cleanly returns None when disabled, never raises\n")

brain.achat_vision_json = _orig_vision
brain.take_screenshot = _orig_shot

# ---------------------------------------------------------------------------
# Scenario 8: acrawl_screen fails LOUDLY on an unrecognisable/empty first
# read, instead of silently completing with an empty-looking "success".
# This is exactly the failure mode the tag-name bug fixed in Scenario 1
# used to produce in practice - guarding against it recurring for ANY
# reason (a future Appium format change, a broken session, etc.), not
# just this specific one.
# ---------------------------------------------------------------------------
print("=== Scenario 8: acrawl_screen fails fast on zero parseable elements ===")


class MockEmptyDriver:
    """Simulates a page_source read that yields no recognisable elements at
    all (e.g. a genuinely blank screen, or an unrecognised XML shape)."""
    current_package = "com.test.app"
    current_activity = ".BlankActivity"

    def find_elements(self, by, xpath):
        return []  # reset_to_top's own get_state() check - irrelevant here

    def get_window_size(self):
        return {"width": 1080, "height": 2280}

    def execute_script(self, name, args=None):
        return None

    @property
    def page_source(self):
        return '<hierarchy rotation="0"></hierarchy>'


_tmp2 = Path(tempfile.mkdtemp())
_orig_base_dir = settings.base_dir
settings.base_dir = _tmp2  # so the diagnostic XML dump lands somewhere throwaway

raised = False
try:
    asyncio.run(sc.acrawl_screen(MockEmptyDriver()))
except RuntimeError as e:
    raised = True
    assert "0 elements" in str(e)
    dumped = list((_tmp2 / "logs" / "failed_resolutions").glob("*.xml"))
    assert len(dumped) == 1, f"expected the raw page_source to be dumped for diagnosis, found {dumped}"
    print(f"PASS: acrawl_screen raised a clear RuntimeError ({e}) instead of "
          f"returning an empty-looking success, and dumped the raw XML to "
          f"{dumped[0]} for diagnosis")
finally:
    settings.base_dir = _orig_base_dir

assert raised, "acrawl_screen must raise, not silently return an empty graph, when nothing parseable is found"
print()

# ---------------------------------------------------------------------------
# Scenario 9: screen_map.map_exists - the cheap check both new auto-crawl
# triggers below are built on.
# ---------------------------------------------------------------------------
print("=== Scenario 9: screen_map.map_exists ===")


class MockKeyDriver:
    current_package = "com.test.app"
    current_activity = ".FreshActivity"


_tmp3 = Path(tempfile.mkdtemp())
_orig_map_dir_module2 = screen_map.MAP_DIR
screen_map.MAP_DIR = _tmp3

key_driver = MockKeyDriver()
assert screen_map.map_exists(key_driver) is False, "a never-seen screen must report as not-yet-mapped"
screen_map.save_map(key_driver, {"k": {"fingerprint": {"class": "X"}, "path": [], "text": "x",
                                        "desc": None, "resource_id": None, "class": "X",
                                        "context": None, "last_confirmed": 0}})
assert screen_map.map_exists(key_driver) is True, "after save_map, the same screen must report as mapped"
print("PASS: map_exists correctly distinguishes an unmapped screen from an already-mapped one\n")


# ---------------------------------------------------------------------------
# Scenario 10: agent._maybe_auto_crawl - crawls a screen exactly once, ever;
# every later check on the SAME screen is then a free no-op.
# ---------------------------------------------------------------------------
print("=== Scenario 10: agent._maybe_auto_crawl only ever crawls a screen once ===")
from app.automation import agent as agent_mod

settings.screen_map_dir = _tmp3  # summarize_known_screens_for_package reads this live

auto_driver = MockCrawlDriver()
settings.auto_crawl_new_screens = True

first = asyncio.run(agent_mod._maybe_auto_crawl(auto_driver))
assert first is not None and first["status"] == "mapped" and "First time" in first["map_summary"]
print(f"PASS: first visit to an unmapped screen triggers a crawl - {first['map_summary']}")

second = asyncio.run(agent_mod._maybe_auto_crawl(auto_driver))
assert second is None, "a screen that's already mapped must NOT be crawled again"
print("PASS: a second check on the same (now-mapped) screen is a free no-op - no re-crawl\n")

settings.auto_crawl_new_screens = False
disabled_driver = MockCrawlDriver()
disabled_driver.current_activity = ".NeverCrawledBecauseDisabled"
disabled_result = asyncio.run(agent_mod._maybe_auto_crawl(disabled_driver))
assert disabled_result is None
assert disabled_driver.scroll_pos == 0 and disabled_driver.swipe_log == [], \
    "auto_crawl_new_screens=False must skip the check before ever touching the driver"
settings.auto_crawl_new_screens = True
print("PASS: auto_crawl_new_screens=False disables this entirely (no driver interaction at all)\n")

screen_map.MAP_DIR = _orig_map_dir_module2
settings.screen_map_dir = _orig_map_dir_setting


# ---------------------------------------------------------------------------
# Scenario 11: agent._resolve_or_raise escalates to ONE full crawl-and-retry
# before giving up, when normal resolution fails - the "only if useful" path.
# ---------------------------------------------------------------------------
print("=== Scenario 11: _resolve_or_raise's crawl-and-retry escalation ===")

resolve_calls = {"n": 0}
crawl_calls = {"n": 0}


async def _fake_resolve(driver, description, action=None, cache=None, direction_hint=None, gesture="scroll"):
    resolve_calls["n"] += 1
    if resolve_calls["n"] == 1:
        return None  # first attempt: normal resolution fails, as if genuinely not found yet
    return "RESOLVED_TARGET"  # second attempt (after the rescue crawl): now found


async def _fake_acrawl_screen(driver, **kwargs):
    crawl_calls["n"] += 1
    return {"total_elements": 3, "carousels": [], "activity": ".X"}


_orig_resolve = agent_mod._resolve
_orig_acrawl = agent_mod.screen_crawler.acrawl_screen
agent_mod._resolve = _fake_resolve
agent_mod.screen_crawler.acrawl_screen = _fake_acrawl_screen
settings.auto_crawl_on_resolution_failure = True

result = asyncio.run(agent_mod._resolve_or_raise(
    object(), "Apply Now button", "click", {}, None, "scroll", step_num=1,
))
assert result == "RESOLVED_TARGET"
assert resolve_calls["n"] == 2, "expected exactly one retry after the rescue crawl"
assert crawl_calls["n"] == 1, "expected exactly one rescue crawl, not a loop"
print("PASS: a target that fails normal resolution is rescued by exactly ONE full crawl-and-retry, "
      "not raised immediately and not retried more than once\n")

# And when the rescue crawl ALSO doesn't help, it must still raise (not loop
# forever, not swallow the failure).
resolve_calls["n"] = 0


async def _fake_resolve_always_fails(driver, description, action=None, cache=None,
                                      direction_hint=None, gesture="scroll"):
    resolve_calls["n"] += 1
    return None


agent_mod._resolve = _fake_resolve_always_fails
agent_mod._dump_failure_diagnostics = lambda *a, **k: asyncio.sleep(0, result=None)

raised2 = False
try:
    asyncio.run(agent_mod._resolve_or_raise(object(), "Nonexistent", "click", {}, None, "scroll", step_num=1))
except RuntimeError as e:
    raised2 = True
    assert "Could not locate" in str(e)
assert raised2, "must still raise cleanly when even the rescue crawl doesn't help"
assert resolve_calls["n"] == 2, "expected exactly 2 resolution attempts total (normal + one post-crawl retry)"
print("PASS: still raises cleanly (not silently, not in a loop) when the rescue crawl doesn't help either\n")

agent_mod._resolve = _orig_resolve
agent_mod.screen_crawler.acrawl_screen = _orig_acrawl

print("ALL SCREEN-CRAWLER / BRAIN / GROUNDING / AUTO-CRAWL CHECKS PASSED")
