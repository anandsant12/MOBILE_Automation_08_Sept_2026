"""
On-demand, EXHAUSTIVE element harvesting for a single screen - captures
every element reachable by scrolling/swiping in every direction (including
nested horizontal carousels), with every property UiAutomator2 exposes for
each one, and writes it out as a rich JSON "screen graph".

HOW THIS DIFFERS FROM page_state.py's get_state()/get_broad_state():
Those two are optimised to be CHEAP and run on every single resolution
attempt during normal execution - see page_state.py's docstring on why
"checked" is skipped for non-checkable elements, why get_broad_state() is
only ever a single last-chance fallback, etc. Each one costs roughly one
Appium HTTP round-trip PER ELEMENT (via .get_attribute() calls), which is
fine for the current viewport's handful of interactive elements but would
be far too slow to run exhaustively across an entire scrollable screen.

This module takes a different, one-off approach instead: it reads
`driver.page_source` - the FULL UI hierarchy XML - in a SINGLE HTTP round
trip per scroll/swipe position, then parses every node's attributes out of
that XML locally (no further Appium calls needed at all for this step).
That's what makes "every property of every element, at every scroll
position" cheap enough to actually do as a deliberate, on-demand action -
see _parse_page_source_elements below. (This project's per-element
live-scan approach in page_state.py was kept as-is rather than switched to
this same technique, since that scan feeds directly into live click/type
actions and swapping its underlying mechanism would need on-device
regression testing this project doesn't currently have the setup to run -
see that module's docstring. This module carries no such risk: it is
PURELY READ-ONLY - it only ever scrolls, swipes, and reads attributes, and
never types or taps anything into the app under test - so a parsing bug
here just means an incomplete/wrong JSON file to re-run, not a wrong click
against a live banking app.)

WHAT GETS CRAWLED, AND HOW FAR:
  1. Reset to the top of the screen (reuses screen_map.reset_to_top).
  2. Read the full hierarchy, record every new element (deduped by the same
     fingerprint identity screen_map.py already uses - resource-id+class,
     or class+text+desc, plus surrounding-card `context` for recycled list
     templates - see _attach_duplicate_context below).
  3. If a nested horizontal carousel row is detected at the current
     vertical position (page_state.detect_horizontal_row_band), swipe
     through it fully (bounded by settings.crawl_max_carousel_swipes),
     recording every card, then swipe back to where the vertical walk left
     off before continuing.
  4. Scroll down one step (a partial list nudge - execute_scroll - not a
     full-extent fling, so small elements between reads aren't skipped
     over) and repeat, until nothing NEW is found for two consecutive
     scrolls (this, not a raw screen-hash comparison, is the stop
     condition - more robust against minor animation/pixel jitter falsely
     looking like "still changing") or settings.crawl_max_scrolls is hit.
  5. Optionally (settings.crawl_include_root_horizontal_pass), one more
     bounded pass swiping right from the TOP position - catches a
     root-level horizontal pager/tab-strip screen, which is a different
     shape of "horizontal" than a small nested carousel row and wouldn't
     be found by step 3 alone. Mirrors screen_map.py's own documented
     "vertical first, horizontal only from the top" simplification - see
     that module's docstring for why a full 2D scroll x swipe grid isn't
     attempted here either.

DELIBERATELY NOT DONE (documented scope boundary, not an oversight):
this crawls ONE screen only - it never taps into a sub-screen to keep
going. Auto-following navigation to build a full multi-screen app map
would require clicking real buttons/links, which is a fundamentally
different (and, for a banking app under test, meaningfully riskier)
operation than the read-only scroll/swipe sweep this module performs - see
the README's "Improvement points" section for how that could be added
later behind an explicit, narrowly-scoped opt-in (e.g. only ever following
elements that look like pure in-app navigation, never anything that looks
like it submits/confirms/pays).

Every element recorded here is ALSO merged into the persistent screen map
(screen_map.py) under the same fingerprint scheme the live resolver already
reads from (tier 4) - so a single crawl of a screen immediately speeds up
and de-risks every future run that touches it, not just the JSON export.
"""

import asyncio
import json
import time
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Optional

from app.automation.page_state import (
    _clean_attr, short_class, bounds_tuple, center_from_bounds,
    detect_horizontal_row_band,
)
from app.automation.action_executor import execute_scroll, execute_swipe
from app.automation import screen_map
from config import settings

# Every attribute UiAutomator2's hierarchy XML can carry per node. Read
# defensively (see _parse_page_source_elements) - an older/different
# automation backend that omits some of these just yields an empty string/
# False for that field rather than failing the whole crawl.
_FLAG_ATTRS = (
    "checkable", "checked", "clickable", "long-clickable", "focusable",
    "focused", "scrollable", "selected", "password",
)


def _safe_name(s: str) -> str:
    return "".join(c if c.isalnum() or c in "._-" else "_" for c in (s or "unknown"))


def _parse_page_source_elements(xml_text: str) -> list:
    """Parses a full UiAutomator2 page_source XML dump into a flat list of
    dicts, one per element, regardless of nesting depth (ElementTree's
    .iter() walks the whole tree). This is the one-HTTP-call-per-screen
    technique this module exists to use - see the module docstring.

    DELIBERATELY does not filter by a specific XML tag name (e.g. "node").
    Appium's UiAutomator2 page_source does NOT use a generic
    `<node class="...">` wrapper for every element - it uses the Android
    view's own class name AS the tag itself, e.g.
    `<android.widget.TextView text="..." bounds="..." .../>` (a "class"
    attribute duplicating the same value is also present, which is what
    this function actually reads). The generic `<node>` convention is what
    the separate `adb shell uiautomator dump` CLI tool produces - a
    different tool from Appium's own page_source endpoint - and matching
    on it here found zero real elements against actual device output.
    Filtering on "has a bounds attribute" instead works correctly
    regardless of which tag-naming convention a given Appium/driver
    version/setup uses: every genuine UI element carries one; the single
    top-level <hierarchy> wrapper element does not, so this also
    naturally excludes it without needing a special case."""
    try:
        root = ET.fromstring(xml_text)
    except ET.ParseError:
        return []

    out = []
    for node in root.iter():
        attrib = node.attrib
        if "bounds" not in attrib:
            continue
        text = _clean_attr(attrib.get("text"))[:120]
        desc = _clean_attr(attrib.get("content-desc"))[:120]
        resource_id_full = _clean_attr(attrib.get("resource-id"))
        short_rid = resource_id_full.rsplit("/", 1)[-1] if resource_id_full else ""
        cls_full = _clean_attr(attrib.get("class")) or node.tag
        bounds_raw = _clean_attr(attrib.get("bounds"))

        flags = {name.replace("-", "_"): _clean_attr(attrib.get(name)).lower() == "true"
                 for name in _FLAG_ATTRS}
        enabled_raw = _clean_attr(attrib.get("enabled"))

        out.append({
            "text": text,
            "desc": desc,
            "resource_id": short_rid,
            "resource_id_full": resource_id_full,
            "class": short_class(cls_full),
            "class_full": cls_full,
            "package": _clean_attr(attrib.get("package")),
            "index": _clean_attr(attrib.get("index")),
            "enabled": (enabled_raw != "false"),
            "bounds": bounds_tuple(bounds_raw),
            "center": center_from_bounds(bounds_raw),
            **flags,
        })
    return out


def _normalize_label(el: dict) -> str:
    return (el.get("text") or el.get("desc") or "").strip().lower()


def _attach_duplicate_context(elements: list) -> None:
    """Same purpose and algorithm as page_state._enrich_duplicate_context
    (see its docstring: tags every element that shares its exact own label
    with another element on the SAME read with the surrounding on-screen
    text between it and the previous occurrence, so a recycled list-item
    template - e.g. every "Apply Now" button in a card list - gets a
    fingerprint that distinguishes each occurrence instead of collapsing
    them all into one). Recomputed here rather than reused directly because
    this module already has the ENTIRE parsed hierarchy in memory from one
    page_source read - no second live Appium query is needed the way
    page_state.py's version needs one."""
    dup_groups: dict = {}
    for i, el in enumerate(elements):
        if not el.get("center"):
            continue
        label = _normalize_label(el)
        if not label:
            continue
        dup_groups.setdefault(label, []).append(i)
    dup_groups = {label: idxs for label, idxs in dup_groups.items() if len(idxs) > 1}
    if not dup_groups:
        return

    band_texts = sorted(
        ((el["center"][1], (el["text"] or el["desc"]))
         for el in elements if el.get("center") and (el.get("text") or el.get("desc"))),
        key=lambda item: item[0],
    )

    for label, idxs in dup_groups.items():
        ordered = sorted(idxs, key=lambda i: elements[i]["center"][1])
        for pos, i in enumerate(ordered):
            y_cur = elements[i]["center"][1]
            y_prev = elements[ordered[pos - 1]]["center"][1] if pos > 0 else -1
            seen = []
            for y, txt in band_texts:
                if y_prev < y < y_cur and txt.strip().lower() != label and txt not in seen:
                    seen.append(txt)
            if seen:
                elements[i]["context"] = " | ".join(seen)[:180]


def _fingerprint_for(el: dict) -> Optional[dict]:
    """Same identity rule as screen_map.element_fingerprint, built from
    this module's (slightly differently-shaped) element dict."""
    attrs = {
        "resource_id": el.get("resource_id"),
        "class": el.get("class"),
        "text": el.get("text"),
        "desc": el.get("desc"),
        "context": el.get("context"),
    }
    return screen_map.element_fingerprint(attrs)


def _merge_elements(elements: list, path: list, seen_fp: dict, map_sink: dict,
                     carousel_group: Optional[str] = None) -> int:
    """Adds every not-yet-seen element (by fingerprint) into `seen_fp`
    (fp_key -> full crawled record, for the JSON export) and `map_sink`
    (fp_key -> screen_map.py-shaped entry, for merging into the persistent
    map via screen_map.save_map). The FIRST path an element is found via
    wins, matching screen_map.record_elements' own "shortest path" bias.
    Returns how many genuinely NEW elements were added, which the crawl
    loop uses as its stop condition."""
    added = 0
    now = time.time()
    for el in elements:
        fp = _fingerprint_for(el)
        if not fp:
            continue
        key = screen_map.fingerprint_key(fp)
        if key in seen_fp:
            continue
        record = dict(el)
        record["path"] = path
        record["carousel_group"] = carousel_group
        seen_fp[key] = record
        map_sink[key] = {
            "fingerprint": fp,
            "path": path,
            "text": el.get("text"),
            "desc": el.get("desc"),
            "resource_id": el.get("resource_id"),
            "class": el.get("class"),
            "context": el.get("context"),
            "last_confirmed": now,
        }
        added += 1
    return added


async def _read_elements(driver) -> list:
    xml_text = await asyncio.to_thread(lambda: driver.page_source)
    elements = await asyncio.to_thread(_parse_page_source_elements, xml_text)
    _attach_duplicate_context(elements)
    return elements


async def _crawl_horizontal_band(driver, anchor_y: Optional[int], base_path: list,
                                  seen_fp: dict, map_sink: dict, carousel_group: str,
                                  max_swipes: int) -> int:
    """Swipes right, recording new elements after each swipe, until nothing
    new appears for two swipes in a row or `max_swipes` is hit - then
    swipes back left the same number of times to restore the vertical
    walk's position before returning. `anchor_y`, when given, confines the
    swipe to that row's band (a nested carousel); None means a full-screen
    swipe (the root-level horizontal-pager pass)."""
    added_total = 0
    no_progress = 0
    swipes_done = 0
    while swipes_done < max_swipes and no_progress < 2:
        elements = await _read_elements(driver)
        path = base_path + [{
            "gesture": "swipe", "direction": "right",
            "count": swipes_done, "anchor_y": anchor_y,
        }]
        added = _merge_elements(elements, path, seen_fp, map_sink, carousel_group=carousel_group)
        added_total += added
        no_progress = 0 if added else no_progress + 1
        await asyncio.to_thread(execute_swipe, driver, "right", anchor_y)
        await asyncio.sleep(settings.crawl_scroll_pause_sec)
        swipes_done += 1

    for _ in range(swipes_done):
        await asyncio.to_thread(execute_swipe, driver, "left", anchor_y)
        await asyncio.sleep(settings.crawl_scroll_pause_sec)

    return added_total


def _save_graph_json(graph: dict) -> Path:
    settings.screen_graph_dir.mkdir(parents=True, exist_ok=True)
    ts_ms = int(graph["captured_at"] * 1000)
    pkg = _safe_name(graph.get("package"))
    act = _safe_name(graph.get("activity"))
    path = settings.screen_graph_dir / f"{pkg}__{act}__{ts_ms}.json"
    path.write_text(json.dumps(graph, indent=2, default=str), encoding="utf-8")
    return path


def _dump_raw_page_source(xml_text: str, tag: str) -> "str | None":
    """Saves a raw, unparsed page_source dump for diagnosis - same
    directory/naming convention as page_state.dump_failed_screen, reused
    here so a "why did mapping find nothing" question is answerable from
    real data instead of a silent, empty-looking JSON. Never raises."""
    try:
        dump_dir = settings.base_dir / "logs" / "failed_resolutions"
        dump_dir.mkdir(parents=True, exist_ok=True)
        path = dump_dir / f"{int(time.time())}_{tag}.xml"
        path.write_text(xml_text or "", encoding="utf-8")
        return str(path)
    except Exception:
        return None


async def acrawl_screen(driver, include_carousels: Optional[bool] = None,
                         max_vertical_scrolls: Optional[int] = None,
                         max_carousel_swipes: Optional[int] = None) -> dict:
    """Runs the full sweep described in this module's docstring against
    whatever screen is CURRENTLY on the device, and returns the resulting
    graph dict (also written to disk under settings.screen_graph_dir, and
    merged into the persistent screen map under settings.screen_map_dir).
    Caller is responsible for having a live `driver` session already
    (see acrawl_current_app below for a standalone, self-contained version
    that starts and stops its own session).

    Raises RuntimeError, rather than returning an empty-looking "success",
    if the very first read finds zero parseable elements - either
    page_source came back in a shape _parse_page_source_elements doesn't
    recognise (the raw XML is dumped to logs/failed_resolutions/ for
    diagnosis - same convention as page_state.dump_failed_screen), or the
    screen genuinely had nothing on it at that instant (e.g. a blank
    transition frame). Either way, a silent, "successful" empty JSON with
    empty elements/carousels lists - looking like the sweep ran fine when
    it actually found nothing at all - is the wrong failure mode for a
    utility whose whole point is capturing everything on screen."""
    include_carousels = settings.crawl_include_carousels if include_carousels is None else include_carousels
    max_vertical_scrolls = settings.crawl_max_scrolls if max_vertical_scrolls is None else max_vertical_scrolls
    max_carousel_swipes = settings.crawl_max_carousel_swipes if max_carousel_swipes is None else max_carousel_swipes

    await screen_map.reset_to_top(driver)

    try:
        package = driver.current_package
    except Exception:
        package = None
    try:
        activity = driver.current_activity
    except Exception:
        activity = None

    # Fail fast: one read, checked BEFORE committing to a full scroll
    # sweep. A zero-element result here means every later scroll/swipe
    # would find nothing too - better to say so clearly now than to spend
    # up to max_vertical_scrolls gestures producing an empty graph that
    # otherwise looks like a completed, successful crawl.
    probe_xml = await asyncio.to_thread(lambda: driver.page_source)
    probe_elements = await asyncio.to_thread(_parse_page_source_elements, probe_xml)
    if not probe_elements:
        dump_path = await asyncio.to_thread(_dump_raw_page_source, probe_xml, "crawl_empty_first_read")
        suffix = f" Raw page_source was saved to {dump_path} for diagnosis." if dump_path else ""
        raise RuntimeError(
            "Mapping found 0 elements on the very first read of this screen - "
            "either the app isn't showing anything yet (try again once it's "
            "fully loaded), or this device/Appium setup returns page_source "
            f"in a shape this crawler doesn't recognise.{suffix}"
        )

    seen_fp: dict = {}
    map_sink: dict = {}
    carousels_meta = []

    scroll_count = 0
    no_progress_scrolls = 0
    any_vertical_progress = False

    while scroll_count <= max_vertical_scrolls and no_progress_scrolls < 2:
        elements = await _read_elements(driver)
        path = [{"gesture": "scroll", "direction": "down", "count": scroll_count}] if scroll_count else []

        anchor_y = None
        if include_carousels:
            centers = {i: {"center": el["center"]} for i, el in enumerate(elements) if el.get("center")}
            anchor_y = detect_horizontal_row_band(centers)

        if anchor_y is not None:
            # IMPORTANT: exclude this row's own elements from the regular
            # merge below - they belong to the carousel and must be picked
            # up (correctly carousel_group-tagged) by _crawl_horizontal_band
            # instead. Without this exclusion, the row's FIRST-visible cards
            # would already be recorded as ordinary (non-carousel) elements
            # by the plain merge below - since it runs before the carousel
            # sub-crawl even starts - leaving _crawl_horizontal_band's own
            # first (unswiped) read finding "nothing new" for exactly the
            # cards that are actually visible at this scroll position, and
            # silently mis-tagging those specific cards' carousel_group as
            # None. Same y-bucketing formula as
            # page_state.detect_horizontal_row_band, so "in this row" here
            # means exactly what identified the row in the first place.
            band_idx = {
                i for i, el in enumerate(elements)
                if el.get("center") and round(el["center"][1] / 40) * 40 == anchor_y
            }
            regular_elements = [el for i, el in enumerate(elements) if i not in band_idx]
        else:
            regular_elements = elements

        added = _merge_elements(regular_elements, path, seen_fp, map_sink)

        if anchor_y is not None:
            group_id = f"carousel@y{anchor_y}_scroll{scroll_count}"
            carousel_added = await _crawl_horizontal_band(
                driver, anchor_y, path, seen_fp, map_sink, group_id, max_carousel_swipes,
            )
            if carousel_added:
                added += carousel_added
                carousels_meta.append({
                    "id": group_id, "path": path, "anchor_y": anchor_y,
                    "new_items_found": carousel_added,
                })

        no_progress_scrolls = 0 if added else no_progress_scrolls + 1

        await asyncio.to_thread(execute_scroll, driver, "down")
        await asyncio.sleep(settings.crawl_scroll_pause_sec)
        if scroll_count == 0:
            # Did the FIRST scroll actually move anything at all? Cheap
            # signal for whether this screen scrolls vertically to begin
            # with - informs whether the root horizontal pass below is
            # worth attempting even when it IS enabled.
            post_elements = await _read_elements(driver)
            any_vertical_progress = post_elements != elements
        scroll_count += 1

    if settings.crawl_include_root_horizontal_pass and (not any_vertical_progress or include_carousels):
        # Reset back to the top before this pass - the vertical walk above
        # may have left the screen scrolled partway down.
        await screen_map.reset_to_top(driver)
        root_added = await _crawl_horizontal_band(
            driver, None, [], seen_fp, map_sink, "root_horizontal_pager", max_carousel_swipes,
        )
        if root_added:
            carousels_meta.append({
                "id": "root_horizontal_pager", "path": [], "anchor_y": None,
                "new_items_found": root_added,
            })

    graph = {
        "package": package,
        "activity": activity,
        "captured_at": time.time(),
        "vertical_scrolls_performed": scroll_count,
        "scrolls_vertically": any_vertical_progress,
        "total_elements": len(seen_fp),
        "carousels": carousels_meta,
        "elements": list(seen_fp.values()),
    }

    if settings.screen_map_enabled and map_sink:
        await asyncio.to_thread(screen_map.save_map, driver, map_sink)

    saved_path = await asyncio.to_thread(_save_graph_json, graph)
    graph["saved_path"] = str(saved_path)
    return graph


async def acrawl_current_app() -> dict:
    """Standalone entry point: starts its own Appium session (launching the
    configured app the same way a normal run does), crawls whatever screen
    the app opens on, then quits the session. Used by the Streamlit "Map
    This Screen" button, which has no other live driver session running at
    the time. Never call this concurrently with agent.run_plan - both start
    their own Appium session and most setups only support one at a time
    (the Streamlit UI enforces this with a session-state busy flag)."""
    from app.automation.driver_manager import DriverManager  # local import: avoids a cycle
    from app.automation.popup_handler import dismiss_popups  # local import: avoids a cycle

    dm = DriverManager()
    driver = await asyncio.to_thread(dm.start)
    try:
        await asyncio.to_thread(dismiss_popups, driver)
        return await acrawl_screen(driver)
    finally:
        await asyncio.to_thread(dm.quit)


def summarize_known_screens_for_package(package: str, max_chars: Optional[int] = None) -> str:
    """Reads whatever's already in the persistent screen map for this app
    package (built by EITHER a previous acrawl_screen() call, or purely
    opportunistically by the live resolver's own auto-scroll-to-find - see
    screen_map.py's docstring) and renders a compact, per-screen bullet
    summary suitable for grounding planner.aplan()'s prompt. Pure disk
    reads - no live device needed, so this is safe/cheap to call before a
    driver session even exists (i.e. at planning time, before agent.py
    starts the Appium session). Returns "" if nothing is known yet for this
    package (e.g. first run ever against this app) - callers should treat
    that as "no grounding available", not an error."""
    max_chars = settings.screen_context_max_chars if max_chars is None else max_chars
    if not package:
        return ""

    prefix = f"{_safe_name(package)}__"
    try:
        candidates = sorted(
            settings.screen_map_dir.glob(f"{prefix}*.json"),
            key=lambda p: p.stat().st_mtime,
            reverse=True,
        )
    except Exception:
        return ""
    if not candidates:
        return ""

    lines = []
    total_len = 0
    for path in candidates:
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            continue
        activity = data.get("activity") or "unknown"
        elements = data.get("elements") or {}
        labels = []
        seen = set()
        for entry in elements.values():
            label = (entry.get("text") or entry.get("desc") or "").strip()
            if not label or label.lower() in seen:
                continue
            seen.add(label.lower())
            labels.append(label)
        if not labels:
            continue
        line = f"- Screen `{activity}`: " + ", ".join(labels[:40])
        if total_len + len(line) > max_chars:
            break
        lines.append(line)
        total_len += len(line)

    return "\n".join(lines)
