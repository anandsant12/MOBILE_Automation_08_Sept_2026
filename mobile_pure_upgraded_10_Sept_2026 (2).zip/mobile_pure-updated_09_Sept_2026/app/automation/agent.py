"""
Orchestrates the whole run:
  1. Plan ONCE, up front: raw instructions -> ordered list of atomic
     actions (planner.aplan). This does not change once the run starts.
  2. Start the driver (this launches the app under test automatically).
  3. Dismiss popups.
  4. For each planned step, IN ORDER, and nothing else:
       - dismiss popups
       - auto-map this screen, ONCE ever, if nothing knows it yet (see
         _maybe_auto_crawl below) - never repeated once it's mapped
       - read a fresh screen state
       - resolve the step's target description to a live element (one
         last-resort full crawl-and-retry if every normal tier fails -
         see _resolve_or_raise)
       - execute the action
       - verify the expected outcome, if any
       - log the result
     If a step can't be resolved or fails to execute, the run STOPS rather
     than improvising an alternative action or trying to "recover" with
     steps nobody asked for - see planner.py's docstring for why.
  5. Quit the driver.

This intentionally does NOT re-ask the model "what should I do next?" after
every step. That reactive pattern is what let the agent wander off and keep
acting after the user's actual instructions were already satisfied. Here,
the plan is fixed before a single action is taken, and the run yields
exactly one log entry per planned step, then a final "finished" entry, then
stops for good.

AUTOMATIC SCREEN MAPPING - why this lives here rather than behind a manual
button: screen_crawler.acrawl_screen is purely read-only and a screen only
ever needs mapping ONCE (the persistent map in screen_map.py is permanent
until the app's UI genuinely changes), so there's no real downside to
triggering it automatically and opportunistically rather than requiring a
person to remember to click something first. Two triggers, both bounded and
tied to genuine novelty/difficulty rather than run on a schedule:
  - _maybe_auto_crawl: at the top of every step, a CHEAP check (filesystem
    existence only) for "has this screen ever been mapped at all" - if not,
    crawl it once. Already-mapped screens (the common case after the first
    time) cost nothing extra. This is what makes new screens get mapped
    automatically as a plan naturally navigates through the app.
  - _resolve_or_raise's crawl-and-retry: if a target genuinely can't be
    found through every normal resolver tier, one full crawl is tried as a
    last resort before the step is reported as failed - the "only do it if
    it's useful" case.
Both are best-effort: a crawl failing never breaks the actual run - the
resolver's own (already robust) tiers still run exactly as before either
way. Toggle via settings.auto_crawl_new_screens /
settings.auto_crawl_on_resolution_failure.

Async so the LLM calls (network-bound) don't block; blocking Selenium/
Appium driver calls are pushed onto a thread via asyncio.to_thread so they
don't stall the event loop either.
"""

import asyncio
from pathlib import Path

from app.automation.driver_manager import DriverManager
from app.automation.page_state import get_state, dump_failed_screen
from app.automation.planner import PlannedStep
from app.automation.resolver import aresolve_by_description
from app.automation.action_executor import (
    execute_click, execute_type, execute_select, execute_toggle,
    execute_scroll, execute_swipe, execute_press_back, execute_close_app,
)
from app.automation.verifier import averify, averify_field_value, averify_with_search
from app.automation.popup_handler import dismiss_popups
from app.automation import brain
from app.automation import screen_crawler
from app.automation import screen_map
from app.utils.screenshot import take_screenshot
from config import settings

NO_TARGET_ACTIONS = {"scroll", "swipe", "wait", "press_back", "close_app"}
# Actions whose target is found by searching the screen (and can carry a
# direction_hint/gesture_hint from the plan - see resolver.py/planner.py).
SEARCHABLE_ACTIONS = {"click", "type", "select", "toggle", "wait_for"}


async def _maybe_auto_crawl(driver) -> "dict | None":
    """Crawls the CURRENT screen once, ONLY if nothing has ever mapped it
    before (screen_map.map_exists) - see this module's docstring for why
    this is safe/cheap to run at the top of every step rather than behind
    a manual button. Returns a log-shaped dict (status="mapped") to yield
    into the run's own log stream when a crawl actually happened, so the
    UI can show why that particular step took longer; returns None
    (nothing to log) when the screen was already known, or when auto-
    crawling is disabled. Never raises - a crawl failing here is not this
    step's failure; the step's own resolution still proceeds normally
    against whatever the resolver can find live either way."""
    if not settings.auto_crawl_new_screens:
        return None
    try:
        already_known = await asyncio.to_thread(screen_map.map_exists, driver)
    except Exception:
        return None
    if already_known:
        return None
    try:
        graph = await screen_crawler.acrawl_screen(driver)
    except Exception:
        return None
    return {
        "step": 0,
        "action": {"action": "auto_map_screen", "target": None},
        "verification": None,
        "screenshot": None,
        "status": "mapped",
        "error": None,
        "map_summary": (
            f"First time on `{graph.get('activity') or 'this screen'}` - "
            f"mapped {graph['total_elements']} element(s) once "
            f"({len(graph['carousels'])} carousel/pager region(s)). "
            f"Future steps/runs on this screen won't pay this cost again."
        ),
    }


async def _dump_failure_diagnostics(driver, description: str, step_num: int) -> "str | None":
    """When a target can't be found on ANY reachable screen (all resolver
    tiers exhausted), save the raw UI hierarchy XML - see
    page_state.dump_failed_screen for what this reveals and why. Never
    raises - diagnostics are a bonus, not something that should break the
    run."""
    safe_desc = "".join(c if c.isalnum() or c in "._- " else "_" for c in description)[:60].strip()
    tag = f"step{step_num}_{safe_desc}"
    return await asyncio.to_thread(dump_failed_screen, driver, tag)


async def _resolve_or_raise(driver, description: str, action: str, cache: dict,
                             direction_hint: str, gesture: str, step_num: int):
    """_resolve, but on failure saves a page_source dump and raises a
    RuntimeError that points at it - every SEARCHABLE_ACTIONS branch below
    used to raise its own near-identical error with no diagnostics; this is
    the single place that now does both consistently.

    Before giving up for real, if settings.auto_crawl_on_resolution_failure
    is on, tries ONE full crawl of the current screen (see
    screen_crawler.acrawl_screen) and re-resolves once more against
    whatever that finds - this explores further than the resolver's own
    auto-scroll-to-find (full vertical depth, nested carousels) and
    populates the persistent map for every later step/run as a side
    effect. Bounded to one extra attempt; a crawl failure here just falls
    straight through to the normal failure path below, unchanged."""
    target = await _resolve(driver, description, action=action, cache=cache,
                             direction_hint=direction_hint, gesture=gesture)
    if target is not None:
        return target

    if settings.auto_crawl_on_resolution_failure:
        try:
            await screen_crawler.acrawl_screen(driver)
        except Exception:
            pass
        else:
            target = await _resolve(driver, description, action=action, cache=cache,
                                     direction_hint=direction_hint, gesture=gesture)
            if target is not None:
                return target

    dump_path = await _dump_failure_diagnostics(driver, description, step_num)
    suffix = f" (UI hierarchy dumped to {dump_path} for diagnosis)" if dump_path else ""
    raise RuntimeError(f"Could not locate element for: {description}{suffix}")


async def _resolve(driver, description: str, action: str = None, cache: dict = None,
                    direction_hint: str = None, gesture: str = "scroll"):
    """Fresh screen read + tiered resolution (cache fast-path -> fuzzy ->
    LLM -> auto-scroll/swipe retry -> vision). `action` and `cache` are
    forwarded to the resolver for class-based tie-breaking and per-run
    caching; `direction_hint`/`gesture` steer the auto-scroll-to-find search
    when the plan named a direction or gesture for finding this target -
    see resolver.py's docstring for the full tier breakdown."""
    state_text, ref_map, attrs_map = await asyncio.to_thread(get_state, driver)
    return await aresolve_by_description(
        driver, description, state_text, ref_map, attrs_map,
        action=action, cache=cache, direction_hint=direction_hint, gesture=gesture,
    )


async def _type_and_verify(driver, target, value: str):
    """Types into `target`, then confirms via a direct field read. If the
    field reads back genuinely EMPTY, retries the WHOLE type action (not
    just the read) - a blank result right after typing often means the
    first tap didn't land focus correctly before send_keys ran (this is
    especially common behind a custom numeric keypad/dial-pad, which can
    take a beat to attach), not that typing is impossible. This is what
    stops a step from being reported "passed" while the field is visibly
    empty on screen.

    Returns the verification result dict from verifier.averify_field_value,
    or None if the field is masked (e.g. a password field) and genuinely
    can't be judged this way - the caller falls back to the general
    averify() in that case, same as before.
    """
    attempts = max(settings.type_verify_retry_attempts, 0) + 1
    interval = settings.type_verify_retry_interval_sec
    result = None
    for attempt in range(attempts):
        await asyncio.to_thread(execute_type, driver, target, value)
        await asyncio.sleep(interval)
        result = await averify_field_value(target.element, value)
        if result is None:
            return None  # masked field - can't tell either way, no point re-typing
        if result.get("method") != "field_empty":
            return result  # a definite pass, or a definite text-mismatch fail - done
        # method == "field_empty": genuinely blank - give it one more real
        # attempt (re-click + re-clear + re-send_keys) before reporting it.
    return result


async def run_plan(planned_steps: list[PlannedStep]):
    """Async generator: yields a dict per planned step, e.g.
    {"step": 1, "action": {...}, "verification": {...}, "screenshot": Path, "status": "ok"}
    Executes the fixed plan exactly once, in order, and stops - it never
    re-plans or adds steps beyond what was given to it."""
    dm = DriverManager()
    driver = await asyncio.to_thread(dm.start)

    # Per-run resolution cache: lets repeated target descriptions (e.g. the
    # same field referenced by two different steps) skip straight back to
    # the element that matched last time instead of re-running fuzzy/LLM
    # tiers. Scoped to this run only - cleared automatically when it ends.
    resolve_cache: dict = {}

    try:
        await asyncio.to_thread(dismiss_popups, driver)

        for step_num, step in enumerate(planned_steps, 1):
            await asyncio.to_thread(dismiss_popups, driver)

            # Auto-map this screen, ONCE ever, if nothing knows it yet -
            # see _maybe_auto_crawl / this module's docstring. A no-op
            # (returns None immediately) on every step after the first
            # time any given screen is seen, so this costs nothing on the
            # common path.
            map_log = await _maybe_auto_crawl(driver)
            if map_log:
                yield map_log

            log = {
                "step": step_num,
                "action": {
                    "action": step.action,
                    "target": step.target,
                    "value": step.value,
                    "direction_hint": step.direction_hint,
                    "gesture_hint": step.gesture_hint,
                    "expected_outcome": step.expected_outcome,
                },
                "verification": None,
                "screenshot": None,
                "status": "ok",
                "error": None,
            }

            gesture = step.gesture_hint or "scroll"

            try:
                if step.action == "click":
                    target = await _resolve_or_raise(driver, step.target, "click", resolve_cache,
                                                       step.direction_hint, gesture, step_num)
                    changed = await asyncio.to_thread(execute_click, driver, target, True)
                    if not changed and not step.expected_outcome:
                        # No expected_outcome to independently confirm
                        # against, AND the screen genuinely didn't change
                        # at all even after execute_click's own coordinate-
                        # tap retry (see action_executor.py). Report this
                        # honestly instead of falling through to
                        # averify()'s "No expectation given" -> passed=True
                        # default below, which would otherwise silently
                        # claim success for a tap that visibly did
                        # nothing. Not treated as a hard step failure (the
                        # run continues) - some legitimate taps genuinely
                        # produce no on-screen text change this check can
                        # see - just an honest signal instead of a
                        # rubber-stamped pass.
                        log["verification"] = {
                            "passed": False,
                            "method": "no_visible_change",
                            "score": None,
                            "reasoning": (
                                f"Tapped '{step.target}' (including a raw "
                                "coordinate-tap retry), but nothing on "
                                "screen changed afterwards - the tap may "
                                "not have registered."
                            ),
                        }

                elif step.action == "type":
                    target = await _resolve_or_raise(driver, step.target, "type", resolve_cache,
                                                       step.direction_hint, gesture, step_num)
                    if target.method == "ref" and step.value:
                        # Types, then confirms via a direct field read, retrying the
                        # WHOLE type action if the field comes back empty - see
                        # _type_and_verify's docstring. Sets verification directly
                        # here so the post-block below doesn't redo it; it's still
                        # None (masked field) for the post-block to fall back on.
                        log["verification"] = await _type_and_verify(driver, target, step.value)
                    else:
                        await asyncio.to_thread(execute_type, driver, target, step.value or "")

                elif step.action == "select":
                    target = await _resolve_or_raise(driver, step.target, "select", resolve_cache,
                                                       step.direction_hint, gesture, step_num)
                    await asyncio.to_thread(execute_select, driver, target, step.value or "", step_num)

                elif step.action == "toggle":
                    target = await _resolve_or_raise(driver, step.target, "toggle", resolve_cache,
                                                       step.direction_hint, gesture, step_num)
                    changed = await asyncio.to_thread(execute_toggle, driver, target, True)
                    if not changed and not step.expected_outcome:
                        # Same honest-reporting rationale as the "click"
                        # branch above - see its comment.
                        log["verification"] = {
                            "passed": False,
                            "method": "no_visible_change",
                            "score": None,
                            "reasoning": (
                                f"Toggled '{step.target}' (including a raw "
                                "coordinate-tap retry), but nothing on "
                                "screen changed afterwards - the toggle "
                                "may not have registered."
                            ),
                        }

                elif step.action == "wait_for":
                    # "scroll/swipe until you see X [then wait N]" - see planner.py.
                    # Reuses the exact same searching resolver as click/type/etc,
                    # just without acting on the target once found.
                    target = await _resolve_or_raise(driver, step.target, "wait_for", resolve_cache,
                                                       step.direction_hint, gesture, step_num)
                    if step.value:
                        try:
                            pause_seconds = float(step.value)
                        except ValueError:
                            pause_seconds = 0.0
                        if pause_seconds > 0:
                            await asyncio.sleep(pause_seconds)
                    # Finding the target IS the confirmation - no need to spend
                    # another LLM/fuzzy call re-verifying what we just located.
                    log["verification"] = {
                        "passed": True,
                        "method": "resolved" if target.method == "ref" else "vision_resolved",
                        "score": None,
                        "reasoning": f"'{step.target}' located on screen.",
                    }

                elif step.action == "scroll":
                    await asyncio.to_thread(execute_scroll, driver, step.value or "down")

                elif step.action == "swipe":
                    await asyncio.to_thread(execute_swipe, driver, step.value or "left")

                elif step.action == "press_back":
                    await asyncio.to_thread(execute_press_back, driver)

                elif step.action == "close_app":
                    await asyncio.to_thread(execute_close_app, driver, settings.android_app_package)

                elif step.action == "wait":
                    try:
                        seconds = float(step.value) if step.value else 2.0
                    except ValueError:
                        seconds = 2.0
                    await asyncio.sleep(seconds)

                elif step.action == "verify":
                    pass  # verification always happens below, using target/expected_outcome

                else:
                    raise RuntimeError(f"Unknown action type: {step.action}")

            except Exception as e:
                log["status"] = "error"
                log["error"] = str(e)
                log["screenshot"] = await asyncio.to_thread(take_screenshot, driver, f"step{step_num}_error")
                # Best-effort, explanatory-only diagnosis for the human
                # reading this run - see brain.py's docstring for why this
                # never feeds back into a new action of its own. Never
                # raises; returns None (silently omitted from the log) if
                # diagnosis is disabled or the call itself fails.
                diagnosis = await brain.adiagnose_failure(driver, step.target, str(e), step.expected_outcome)
                if diagnosis:
                    log["diagnosis"] = diagnosis
                yield log
                # Stop the whole run on failure rather than guessing at a
                # recovery step - "only do what we told it to do" cuts both
                # ways: it shouldn't improvise fixes either.
                return

            expected = step.expected_outcome or (step.target if step.action == "verify" else "")

            verification = log["verification"]  # already set above for "wait_for"/"type" - don't redo it
            if verification is None and expected:
                # averify_with_search: same check as averify(), but scrolls
                # a bounded amount to look for the expected result if it's
                # not on the current screen yet - see verifier.py's
                # docstring for why a plain, non-searching check can
                # otherwise report a false failure for something that's
                # genuinely there, just below the fold.
                verification = await averify_with_search(driver, expected)

            if verification is not None:
                log["verification"] = verification
            log["screenshot"] = await asyncio.to_thread(take_screenshot, driver, f"step{step_num}")

            yield log

        yield {
            "step": len(planned_steps) + 1,
            "action": {"action": "finish"},
            "verification": None,
            "screenshot": None,
            "status": "finished",
            "error": None,
        }

    finally:
        await asyncio.to_thread(dm.quit)
