import asyncio
import json

import streamlit as st
from config import settings
from app.automation.planner import aplan
from app.automation.agent import run_plan
from app.automation import screen_crawler

st.set_page_config(page_title="AI Mobile Automation", layout="wide")

st.title("AI-driven Mobile Automation")
st.caption(
    "Describe the steps in plain English. The agent PLANS the whole "
    "sequence first, shows you the plan, then executes exactly that plan - "
    "one time, in order - and stops. It will not invent extra steps or "
    "keep going once the plan is done. New screens it visits along the way "
    "are mapped automatically, once each, the first time it sees them."
)

with st.sidebar:
    st.header("Config (from .env)")
    st.text(f"LLM provider: {settings.llm_provider}")
    if settings.llm_provider == "groq":
        st.text(f"Text model: {settings.groq_model}")
        st.text(f"Vision model: {settings.groq_vision_model}")
    else:
        st.text(f"Azure deployment (text+vision): {settings.azure_openai_deployment}")
    st.text(f"App package: {settings.android_app_package}")
    st.text(f"App activity: {settings.android_app_activity}")
    st.text(f"Vision fallback: {'on' if settings.enable_vision_fallback else 'off (text-only locators)'}")
    st.text(f"Popup auto-dismiss: {'on' if settings.popup_dismiss_enabled else 'off'}")
    st.text(f"Max steps per plan: {settings.max_steps}")
    st.divider()
    st.caption("Screen mapping / planning intelligence")
    st.text(f"Auto-map new screens: {'on' if settings.auto_crawl_new_screens else 'off'}")
    st.text(f"Auto-map on resolution failure: {'on' if settings.auto_crawl_on_resolution_failure else 'off'}")
    st.text(f"Plan grounding from known screens: {'on' if settings.ground_plan_with_screen_map else 'off'}")
    st.text(f"Failure diagnosis: {'on' if settings.brain_diagnosis_enabled else 'off'}")
    st.text(f"Verify scroll-search: up to {settings.verify_scroll_max_attempts} scroll(s)")

    # Purely informational - lists whatever's already been captured
    # automatically (see agent.py's auto-crawl triggers). No button here:
    # nothing needs to be manually run to populate this, it's a byproduct
    # of ordinary "Plan & Run" use.
    st.divider()
    try:
        graph_files = sorted(
            settings.screen_graph_dir.glob("*.json"),
            key=lambda p: p.stat().st_mtime, reverse=True,
        )
    except Exception:
        graph_files = []
    st.caption(f"Screens mapped so far: {len(graph_files)}")
    if graph_files:
        with st.expander("Show mapped screens"):
            for f in graph_files[:20]:
                st.download_button(f.stem, data=f.read_bytes(), file_name=f.name,
                                    mime="application/json", key=f"dl_{f.name}")
    st.caption("Change settings above in your .env file, then restart the app.")

if "agent_running" not in st.session_state:
    st.session_state.agent_running = False

goal = st.text_area(
    "What should the agent do?",
    placeholder="e.g. Enter username 'john.doe' in the username field, enter "
                "password 'secret123' in the password field, tap Login, then "
                "verify the dashboard is shown.",
    height=100,
)

run_clicked = st.button(
    "Plan & Run",
    type="primary",
    disabled=not goal.strip() or st.session_state.agent_running,
)


def _render_plan(planned_steps, grounded: bool):
    title = f"📋 Plan ({len(planned_steps)} step(s)) — this is exactly what will run"
    if grounded:
        title += " · grounded with known screen map"
    with st.expander(title, expanded=True):
        for i, s in enumerate(planned_steps, 1):
            line = f"**{i}. {s.action}**"
            if s.target:
                line += f" → \"{s.target}\""
            if s.value:
                line += f" = \"{s.value}\""
            st.markdown(line)
            hints = []
            if s.direction_hint:
                hints.append(f"try {s.direction_hint} first")
            if s.gesture_hint:
                hints.append(f"{s.gesture_hint} gesture")
            if hints:
                st.caption(f"search hint: {', '.join(hints)}")
            if s.expected_outcome:
                st.caption(f"expects: {s.expected_outcome}")


def _render_step(log_container, log):
    status = log["status"]

    if status == "mapped":
        # A screen got auto-mapped for the first time - see agent.py's
        # _maybe_auto_crawl. Informational only, shown distinctly from a
        # real plan step since it isn't one (no step number of its own).
        with log_container:
            st.info(f"🗺️ {log['map_summary']}")
        return

    step = log["step"]
    action = log["action"]
    verification = log.get("verification")
    verification_failed = bool(verification) and not verification.get("passed")

    icon = {"ok": "🟢", "finished": "✅", "error": "⚠️"}.get(status, "•")
    if status == "ok" and verification_failed:
        # Execution didn't raise, but nothing actually confirmed the
        # action had an effect (e.g. a click that resolved and "succeeded"
        # per Appium, yet nothing changed on screen - see action_executor.
        # execute_click's verify_effect). A plain green dot here would be
        # misleading - this needs to look visibly different from a step
        # that both ran AND was confirmed.
        icon = "🟡"

    with log_container:
        if status == "finished":
            st.success("Plan complete. Agent has stopped - no further actions will run.")
            return

        label = action.get("action")
        if action.get("target"):
            label += f" → \"{action['target']}\""
        # Auto-expand whenever there's something worth looking at, not just
        # on a hard execution error - a step that "ran fine" but couldn't
        # be confirmed shouldn't be able to hide in a collapsed expander.
        expanded = status != "ok" or verification_failed
        with st.expander(f"{icon} Step {step}: {label}", expanded=expanded):
            st.json(action)

            if verification:
                v = verification
                vt = "✅ Passed" if v["passed"] else "❌ Failed"
                st.write(f"**Verification ({v['method']}, score={v['score']}):** {vt}")
                st.caption(v["reasoning"])

            if log.get("error"):
                st.error(log["error"])

            diagnosis = log.get("diagnosis")
            if diagnosis:
                # Explanatory only - see brain.py's docstring. Shown
                # distinctly from the raw error so it reads as "here's a
                # likely reason", not as a second, competing error message.
                st.info(
                    f"**Likely cause:** {diagnosis['likely_cause']}\n\n"
                    f"{diagnosis['explanation']}\n\n"
                    f"**Suggestion:** {diagnosis['suggestion']}"
                )

            if log.get("screenshot"):
                st.image(str(log["screenshot"]), width=400)

        if status == "error":
            st.error("Agent stopped — this step could not be completed.")
        elif verification_failed:
            st.warning(
                "This step ran without a technical error, but nothing "
                "confirmed it actually had the expected effect - see the "
                "verification note above before trusting this step."
            )


def _plan_and_run(goal: str, plan_container, log_container):
    """Plans once, shows the plan, then drives the fixed-plan execution to
    completion in one dedicated event loop. Guaranteed to run the plan
    exactly once per call - no re-planning, no repeat runs."""

    async def _drive():
        screen_context = ""
        if settings.ground_plan_with_screen_map:
            # Pure disk read of whatever's already known about this app's
            # screens (built up automatically by agent.py's own auto-crawl
            # triggers on past runs - see that module's docstring) - no
            # live device needed yet at planning time. "" (nothing known
            # yet, e.g. the very first ever run against a new app) leaves
            # aplan()'s behaviour unchanged.
            screen_context = await asyncio.to_thread(
                screen_crawler.summarize_known_screens_for_package, settings.android_app_package,
            )
        planned_steps = await aplan(goal, screen_context=screen_context or None)
        if not planned_steps:
            with plan_container:
                st.warning("The planner could not turn this into any actionable steps. Try rephrasing.")
            return
        with plan_container:
            _render_plan(planned_steps, grounded=bool(screen_context))
        async for log in run_plan(planned_steps):
            _render_step(log_container, log)

    asyncio.run(_drive())


if run_clicked:
    st.session_state.agent_running = True
    plan_container = st.container()
    log_container = st.container()
    with st.spinner("Planning, then running..."):
        try:
            _plan_and_run(goal, plan_container, log_container)
        finally:
            st.session_state.agent_running = False
