"""
Turns the current Android screen into a short, LLM-friendly list of
interactive elements, instead of dumping the entire UI hierarchy XML.

Each element gets a short ref tag like [E3] PLUS enough metadata for a
human (or an LLM) to tell it apart from other elements with the same
label - resource-id, class, checkable/checked state, enabled state, and
its on-screen position - so the fuzzy/LLM resolver in resolver.py can pick
the RIGHT one even when several elements share similar text.

get_state() also returns a per-ref "attrs_map" of raw, unparsed fields
(text/desc/resource_id/class/...). This lets resolver.py do fast structured
matching (class-based tie-breaking, resource-id fingerprint caching) without
re-parsing the rendered state_text lines back into fields.

Note: unlike a web DOM, only elements CURRENTLY ON SCREEN appear here -
callers are expected to scroll and re-read state if what they need isn't
listed (see resolver.py's scroll-search for how that's handled).
"""

import re
from collections import defaultdict
from selenium.webdriver.common.by import By

ANDROID_INTERACTIVE_XPATH = (
    "//*[@clickable='true' or @long-clickable='true' or @checkable='true' or "
    "contains(@class,'EditText') or contains(@class,'Button') or contains(@class,'Spinner') or "
    "contains(@class,'CheckBox') or contains(@class,'RadioButton') or contains(@class,'Switch')]"
)

_BOUNDS_RE = re.compile(r"\[(-?\d+),(-?\d+)\]\[(-?\d+),(-?\d+)\]")


def _clean_attr(value) -> str:
    """Some Appium/UiAutomator2 setups return the literal STRING "null"
    (not Python None) for attributes an element doesn't have, instead of an
    empty string. Left unguarded, `value or ""` doesn't catch this - "null"
    is a non-empty, truthy string - so it silently gets treated as real
    content. This is what corrupted this project's resource-id-based
    fingerprints: many unrelated elements without a real resource-id were
    all reading back the literal string "null", so they collapsed onto the
    SAME fingerprint ("rid::null::Button" etc) and overwrote each other in
    the screen map instead of being recorded as distinct elements. It could
    equally make a genuinely empty typed field look like it contains the
    text "null" instead of being empty. Every raw attribute read in this
    project should go through this."""
    if value is None:
        return ""
    v = str(value).strip()
    if v.lower() == "null":
        return ""
    return v


def clean_attr(value) -> str:
    """Public alias of _clean_attr, for other modules (e.g. verifier.py)
    that read raw element attributes outside of get_state()'s own attrs_map
    and need the same "null"-string guard - see _clean_attr's docstring."""
    return _clean_attr(value)


def _short_class(cls: str) -> str:
    """'android.widget.EditText' -> 'EditText' - keeps state text compact."""
    return cls.rsplit(".", 1)[-1] if cls else ""


def _center_from_bounds(bounds: str):
    m = _BOUNDS_RE.match(bounds or "")
    if not m:
        return None
    x1, y1, x2, y2 = (int(v) for v in m.groups())
    return (x1 + x2) // 2, (y1 + y2) // 2


def _element_info(el) -> dict | None:
    """One round-trip of attribute reads per element, reused for both the
    human/LLM-readable line AND the structured attrs_map entry (avoids
    fetching the same attributes twice)."""
    try:
        text = _clean_attr(el.get_attribute("text"))[:60]
        desc = _clean_attr(el.get_attribute("content-desc"))[:60]
        resource_id = _clean_attr(el.get_attribute("resource-id"))
        # Short resource-id (drop the package prefix) reads better and is
        # still enough to disambiguate - e.g. "com.sbi.lotusintouch:id/etUser" -> "etUser"
        short_rid = resource_id.rsplit("/", 1)[-1] if resource_id else ""
        cls = _short_class(_clean_attr(el.get_attribute("className")))
        checkable = (_clean_attr(el.get_attribute("checkable")).lower() == "true")
        checked = (_clean_attr(el.get_attribute("checked")).lower() == "true")
        enabled_raw = _clean_attr(el.get_attribute("enabled"))
        bounds = _clean_attr(el.get_attribute("bounds"))
        center = _center_from_bounds(bounds)

        label = text or desc or short_rid
        if not label:
            return None

        bits = []
        if short_rid and short_rid != label:
            bits.append(f"id='{short_rid}'")
        if checkable:
            bits.append(f"checkable checked={checked}")
        if enabled_raw == "false":
            bits.append("disabled")
        if center:
            bits.append(f"pos=({center[0]},{center[1]})")
        extra = (" " + " ".join(bits)) if bits else ""

        line = f"<{cls}>{label}</{cls}>{extra}"

        return {
            "line": line,
            "text": text,
            "desc": desc,
            "resource_id": short_rid,
            "class": cls,
            "checkable": checkable,
            "checked": checked,
            "enabled": (enabled_raw != "false"),
            "center": center,
        }
    except Exception:
        return None


def _screen_header(driver) -> str:
    """Best-effort package/activity header so the resolver/verifier can
    confirm which screen/app is actually on screen right now. Never raises -
    not all Appium sessions expose these the same way."""
    pkg = activity = ""
    try:
        pkg = driver.current_package
    except Exception:
        pass
    try:
        activity = driver.current_activity
    except Exception:
        pass
    if not pkg and not activity:
        return ""
    return f"Package: {pkg}  Activity: {activity}\n"


def get_state(driver, max_elements: int = 60):
    """Returns (state_text, ref_map, attrs_map):
      - state_text: human/LLM-readable listing of on-screen interactive elements
      - ref_map: 'E0','E1',... -> live WebElement
      - attrs_map: 'E0','E1',... -> dict of raw fields (text/desc/resource_id/
        class/checkable/checked/enabled/center), used by resolver.py for
        structured tie-breaking and fingerprint caching without re-parsing
        state_text.
    """
    try:
        elements = driver.find_elements(By.XPATH, ANDROID_INTERACTIVE_XPATH)
    except Exception:
        elements = []

    ref_map = {}
    attrs_map = {}
    lines = []
    idx = 0
    for el in elements:
        info = _element_info(el)
        if not info:
            continue
        ref = f"E{idx}"
        ref_map[ref] = el
        attrs_map[ref] = info
        lines.append(f"[{ref}] {info['line']}")
        idx += 1
        if idx >= max_elements:
            break

    state_text = (
        f"{_screen_header(driver)}"
        f"Interactive elements (only what's currently on screen - scroll if you "
        f"expect more):\n" + "\n".join(lines)
    )
    return state_text, ref_map, attrs_map


def detect_horizontal_row_band(attrs_map: dict, min_items: int = 2,
                                min_spread_px: int = 140, y_bucket_px: int = 40):
    """Looks for a cluster of elements sitting at roughly the same
    y-coordinate but spread out horizontally - the signature of a nested
    horizontal card carousel embedded in an otherwise vertical screen (e.g.
    "Open Savings/Current Account", "Open PPF Account", ... sitting side by
    side under a vertically-scrolling homepage). Returns that row's
    y-center in pixels, or None if no such row is present (e.g. this is a
    plain vertical list, or a genuine full-screen horizontal pager where a
    screen-wide swipe is already the right thing to do).

    Used to CONFINE a "swipe" gesture to just that row's vertical band
    instead of a full-screen swipe - a screen-wide swipe on a small nested
    carousel like this can miss it entirely or drag the wrong part of the
    page instead (this was the cause of "Could not locate element" on a
    carousel's later cards even though the earlier cards were found fine).
    See action_executor.execute_swipe's `anchor_y` parameter.
    """
    buckets = defaultdict(list)
    for attrs in attrs_map.values():
        center = attrs.get("center")
        if not center:
            continue
        y_bucket = round(center[1] / y_bucket_px) * y_bucket_px
        buckets[y_bucket].append(center[0])

    best_y, best_count, best_spread = None, 0, 0
    for y, xs in buckets.items():
        if len(xs) < min_items:
            continue
        spread = max(xs) - min(xs)
        if spread < min_spread_px:
            continue
        if len(xs) > best_count or (len(xs) == best_count and spread > best_spread):
            best_y, best_count, best_spread = y, len(xs), spread

    return best_y
