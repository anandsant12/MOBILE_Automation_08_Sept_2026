"""
Orchestrates the whole run:
  1. Plan ONCE, up front: raw instructions -> ordered list of atomic
     actions (planner.aplan). This does not change once the run starts.
  2. Start the driver (this launches the app under test automatically).
  3. Dismiss popups.
  4. For each planned step, IN ORDER, and nothing else:
       - dismiss popups
       - read a fresh screen state
       - resolve the step's target description to a live element
       - execute the action
       - verify the expected outcome, if any
       - log the result
     If a step can't be resolved or fails to execute, the run STOPS rather
     than improvising an alternative action or trying to "recover" with
     steps nobody asked for - see planner.py's docstring for why.
  5. Quit the driver.

This intentionally does NOT re-ask the model "what should I do next?" after
every step. That reactive pattern is what let the agent wander off and keep
acting after the user's actual instructions were already satisfied. Here,
the plan is fixed before a single action is taken, and the run yields
exactly one log entry per planned step, then a final "finished" entry, then
stops for good.

Async so the LLM calls (network-bound) don't block; blocking Selenium/
Appium driver calls are pushed onto a thread via asyncio.to_thread so they
don't stall the event loop either.
"""

import asyncio

from app.automation.driver_manager import DriverManager
from app.automation.page_state import get_state
from app.automation.planner import PlannedStep
from app.automation.resolver import aresolve_by_description
from app.automation.action_executor import (
    execute_click, execute_type, execute_select, execute_toggle,
    execute_scroll, execute_swipe, execute_press_back, execute_close_app,
)
from app.automation.verifier import averify, averify_field_value
from app.automation.popup_handler import dismiss_popups
from app.utils.screenshot import take_screenshot
from config import settings

NO_TARGET_ACTIONS = {"scroll", "swipe", "wait", "press_back", "close_app"}
# Actions whose target is found by searching the screen (and can carry a
# direction_hint/gesture_hint from the plan - see resolver.py/planner.py).
SEARCHABLE_ACTIONS = {"click", "type", "select", "toggle", "wait_for"}


async def _resolve(driver, description: str, action: str = None, cache: dict = None,
                    direction_hint: str = None, gesture: str = "scroll"):
    """Fresh screen read + tiered resolution (cache fast-path -> fuzzy ->
    LLM -> auto-scroll/swipe retry -> vision). `action` and `cache` are
    forwarded to the resolver for class-based tie-breaking and per-run
    caching; `direction_hint`/`gesture` steer the auto-scroll-to-find search
    when the plan named a direction or gesture for finding this target -
    see resolver.py's docstring for the full tier breakdown."""
    state_text, ref_map, attrs_map = await asyncio.to_thread(get_state, driver)
    return await aresolve_by_description(
        driver, description, state_text, ref_map, attrs_map,
        action=action, cache=cache, direction_hint=direction_hint, gesture=gesture,
    )


async def _type_and_verify(driver, target, value: str):
    """Types into `target`, then confirms via a direct field read. If the
    field reads back genuinely EMPTY, retries the WHOLE type action (not
    just the read) - a blank result right after typing often means the
    first tap didn't land focus correctly before send_keys ran (this is
    especially common behind a custom numeric keypad/dial-pad, which can
    take a beat to attach), not that typing is impossible. This is what
    stops a step from being reported "passed" while the field is visibly
    empty on screen.

    Returns the verification result dict from verifier.averify_field_value,
    or None if the field is masked (e.g. a password field) and genuinely
    can't be judged this way - the caller falls back to the general
    averify() in that case, same as before.
    """
    attempts = max(settings.type_verify_retry_attempts, 0) + 1
    interval = settings.type_verify_retry_interval_sec
    result = None
    for attempt in range(attempts):
        await asyncio.to_thread(execute_type, driver, target, value)
        await asyncio.sleep(interval)
        result = await averify_field_value(target.element, value)
        if result is None:
            return None  # masked field - can't tell either way, no point re-typing
        if result.get("method") != "field_empty":
            return result  # a definite pass, or a definite text-mismatch fail - done
        # method == "field_empty": genuinely blank - give it one more real
        # attempt (re-click + re-clear + re-send_keys) before reporting it.
    return result


async def run_plan(planned_steps: list[PlannedStep]):
    """Async generator: yields a dict per planned step, e.g.
    {"step": 1, "action": {...}, "verification": {...}, "screenshot": Path, "status": "ok"}
    Executes the fixed plan exactly once, in order, and stops - it never
    re-plans or adds steps beyond what was given to it."""
    dm = DriverManager()
    driver = await asyncio.to_thread(dm.start)

    # Per-run resolution cache: lets repeated target descriptions (e.g. the
    # same field referenced by two different steps) skip straight back to
    # the element that matched last time instead of re-running fuzzy/LLM
    # tiers. Scoped to this run only - cleared automatically when it ends.
    resolve_cache: dict = {}

    try:
        await asyncio.to_thread(dismiss_popups, driver)

        for step_num, step in enumerate(planned_steps, 1):
            await asyncio.to_thread(dismiss_popups, driver)

            log = {
                "step": step_num,
                "action": {
                    "action": step.action,
                    "target": step.target,
                    "value": step.value,
                    "direction_hint": step.direction_hint,
                    "gesture_hint": step.gesture_hint,
                    "expected_outcome": step.expected_outcome,
                },
                "verification": None,
                "screenshot": None,
                "status": "ok",
                "error": None,
            }

            gesture = step.gesture_hint or "scroll"

            try:
                if step.action == "click":
                    target = await _resolve(driver, step.target, action="click", cache=resolve_cache,
                                             direction_hint=step.direction_hint, gesture=gesture)
                    if target is None:
                        raise RuntimeError(f"Could not locate element for: {step.target}")
                    await asyncio.to_thread(execute_click, driver, target)

                elif step.action == "type":
                    target = await _resolve(driver, step.target, action="type", cache=resolve_cache,
                                             direction_hint=step.direction_hint, gesture=gesture)
                    if target is None:
                        raise RuntimeError(f"Could not locate element for: {step.target}")
                    if target.method == "ref" and step.value:
                        # Types, then confirms via a direct field read, retrying the
                        # WHOLE type action if the field comes back empty - see
                        # _type_and_verify's docstring. Sets verification directly
                        # here so the post-block below doesn't redo it; it's still
                        # None (masked field) for the post-block to fall back on.
                        log["verification"] = await _type_and_verify(driver, target, step.value)
                    else:
                        await asyncio.to_thread(execute_type, driver, target, step.value or "")

                elif step.action == "select":
                    target = await _resolve(driver, step.target, action="select", cache=resolve_cache,
                                             direction_hint=step.direction_hint, gesture=gesture)
                    if target is None:
                        raise RuntimeError(f"Could not locate element for: {step.target}")
                    await asyncio.to_thread(execute_select, driver, target, step.value or "")

                elif step.action == "toggle":
                    target = await _resolve(driver, step.target, action="toggle", cache=resolve_cache,
                                             direction_hint=step.direction_hint, gesture=gesture)
                    if target is None:
                        raise RuntimeError(f"Could not locate element for: {step.target}")
                    await asyncio.to_thread(execute_toggle, driver, target)

                elif step.action == "wait_for":
                    # "scroll/swipe until you see X [then wait N]" - see planner.py.
                    # Reuses the exact same searching resolver as click/type/etc,
                    # just without acting on the target once found.
                    target = await _resolve(driver, step.target, action="wait_for", cache=resolve_cache,
                                             direction_hint=step.direction_hint, gesture=gesture)
                    if target is None:
                        raise RuntimeError(f"Could not find on screen (searched all directions): {step.target}")
                    if step.value:
                        try:
                            pause_seconds = float(step.value)
                        except ValueError:
                            pause_seconds = 0.0
                        if pause_seconds > 0:
                            await asyncio.sleep(pause_seconds)
                    # Finding the target IS the confirmation - no need to spend
                    # another LLM/fuzzy call re-verifying what we just located.
                    log["verification"] = {
                        "passed": True,
                        "method": "resolved" if target.method == "ref" else "vision_resolved",
                        "score": None,
                        "reasoning": f"'{step.target}' located on screen.",
                    }

                elif step.action == "scroll":
                    await asyncio.to_thread(execute_scroll, driver, step.value or "down")

                elif step.action == "swipe":
                    await asyncio.to_thread(execute_swipe, driver, step.value or "left")

                elif step.action == "press_back":
                    await asyncio.to_thread(execute_press_back, driver)

                elif step.action == "close_app":
                    await asyncio.to_thread(execute_close_app, driver, settings.android_app_package)

                elif step.action == "wait":
                    try:
                        seconds = float(step.value) if step.value else 2.0
                    except ValueError:
                        seconds = 2.0
                    await asyncio.sleep(seconds)

                elif step.action == "verify":
                    pass  # verification always happens below, using target/expected_outcome

                else:
                    raise RuntimeError(f"Unknown action type: {step.action}")

            except Exception as e:
                log["status"] = "error"
                log["error"] = str(e)
                log["screenshot"] = await asyncio.to_thread(take_screenshot, driver, f"step{step_num}_error")
                yield log
                # Stop the whole run on failure rather than guessing at a
                # recovery step - "only do what we told it to do" cuts both
                # ways: it shouldn't improvise fixes either.
                return

            expected = step.expected_outcome or (step.target if step.action == "verify" else "")

            verification = log["verification"]  # already set above for "wait_for"/"type" - don't redo it
            if verification is None and expected:
                verification = await averify(driver, expected)

            if verification is not None:
                log["verification"] = verification
            log["screenshot"] = await asyncio.to_thread(take_screenshot, driver, f"step{step_num}")

            yield log

        yield {
            "step": len(planned_steps) + 1,
            "action": {"action": "finish"},
            "verification": None,
            "screenshot": None,
            "status": "finished",
            "error": None,
        }

    finally:
        await asyncio.to_thread(dm.quit)
