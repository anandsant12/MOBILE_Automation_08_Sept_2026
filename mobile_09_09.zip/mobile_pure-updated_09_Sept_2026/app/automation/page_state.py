"""
Turns the current Android screen into a short, LLM-friendly list of
interactive elements, instead of dumping the entire UI hierarchy XML.

Each element gets a short ref tag like [E3] PLUS enough metadata for a
human (or an LLM) to tell it apart from other elements with the same
label - resource-id, class, checkable/checked state, enabled state, and
its on-screen position - so the fuzzy/LLM resolver in resolver.py can pick
the RIGHT one even when several elements share similar text.

get_state() also returns a per-ref "attrs_map" of raw, unparsed fields
(text/desc/resource_id/class/...). This lets resolver.py do fast structured
matching (class-based tie-breaking, resource-id fingerprint caching) without
re-parsing the rendered state_text lines back into fields.

Note: unlike a web DOM, only elements CURRENTLY ON SCREEN appear here -
callers are expected to scroll and re-read state if what they need isn't
listed (see resolver.py's scroll-search for how that's handled).
"""

import re
import time
from collections import defaultdict
from selenium.webdriver.common.by import By

ANDROID_INTERACTIVE_XPATH = (
    "//*[@clickable='true' or @long-clickable='true' or @checkable='true' or "
    "contains(@class,'EditText') or contains(@class,'Button') or contains(@class,'Spinner') or "
    "contains(@class,'CheckBox') or contains(@class,'RadioButton') or contains(@class,'Switch')]"
)

# Deliberately much broader than ANDROID_INTERACTIVE_XPATH: ANY element with
# visible text or a content-description, regardless of clickable/checkable/
# widget-class. Used ONLY by get_broad_state() below, which is itself only
# ever called as a single last-chance fallback tier (see resolver.py) - see
# that function's docstring for why this can't just replace
# ANDROID_INTERACTIVE_XPATH as the default.
ANDROID_TEXT_XPATH = "//*[@text!='' or @content-desc!='']"

_BOUNDS_RE = re.compile(r"\[(-?\d+),(-?\d+)\]\[(-?\d+),(-?\d+)\]")


def _clean_attr(value) -> str:
    """Some Appium/UiAutomator2 setups return the literal STRING "null"
    (not Python None) for attributes an element doesn't have, instead of an
    empty string. Left unguarded, `value or ""` doesn't catch this - "null"
    is a non-empty, truthy string - so it silently gets treated as real
    content. This is what corrupted this project's resource-id-based
    fingerprints: many unrelated elements without a real resource-id were
    all reading back the literal string "null", so they collapsed onto the
    SAME fingerprint ("rid::null::Button" etc) and overwrote each other in
    the screen map instead of being recorded as distinct elements. It could
    equally make a genuinely empty typed field look like it contains the
    text "null" instead of being empty. Every raw attribute read in this
    project should go through this."""
    if value is None:
        return ""
    v = str(value).strip()
    if v.lower() == "null":
        return ""
    return v


def clean_attr(value) -> str:
    """Public alias of _clean_attr, for other modules (e.g. verifier.py)
    that read raw element attributes outside of get_state()'s own attrs_map
    and need the same "null"-string guard - see _clean_attr's docstring."""
    return _clean_attr(value)


def _short_class(cls: str) -> str:
    """'android.widget.EditText' -> 'EditText' - keeps state text compact."""
    return cls.rsplit(".", 1)[-1] if cls else ""


def _center_from_bounds(bounds: str):
    m = _BOUNDS_RE.match(bounds or "")
    if not m:
        return None
    x1, y1, x2, y2 = (int(v) for v in m.groups())
    return (x1 + x2) // 2, (y1 + y2) // 2


def _first_descendant_text(el, max_children_checked: int = 8) -> str:
    """Looks inside this element for the first usable text/content-desc/
    resource-id on a DESCENDANT. Fixes a common Android pattern: a clickable
    container (e.g. a list row - a flag icon + country-name TextView, both
    children of one clickable row) often carries NO text/desc of its own;
    the actual label lives on a child. Without this, such rows are invisible
    to fuzzy/LLM matching even though they're genuinely on screen and
    tappable - this was silently dropping every row of a country picker
    like this project's "Country" list, since the row itself (not its child
    text) is what @clickable='true' matches.

    Also falls back to a descendant's resource-id (not just text/content-
    desc) as a last resort: a purely graphical child (e.g. a nested
    ImageView icon with no text/content-desc of its own) often still has a
    resource-id (e.g. "ivSupport", "ivHeadphone") - terse, but still a real
    hint for fuzzy/LLM matching (e.g. against "support icon"), and far
    better than the row vanishing from every scan entirely. Text/desc is
    always preferred when present; the resource-id fallback is only used if
    NOTHING among the checked descendants has real text/desc.
    """
    try:
        children = el.find_elements(
            By.XPATH, ".//*[@text!='' or @content-desc!='' or @resource-id!='']"
        )
    except Exception:
        return ""
    fallback_rid = ""
    for child in children[:max_children_checked]:
        try:
            t = _clean_attr(child.get_attribute("text"))
            if t:
                return t[:60]
            d = _clean_attr(child.get_attribute("content-desc"))
            if d:
                return d[:60]
            if not fallback_rid:
                rid = _clean_attr(child.get_attribute("resource-id"))
                if rid:
                    fallback_rid = rid.rsplit("/", 1)[-1]
        except Exception:
            continue
    return fallback_rid


def _positional_label(center, screen_size) -> str:
    """Last-resort generic label for a clickable element that has NO
    text/content-desc/resource-id anywhere in itself or its descendants -
    e.g. a raw icon-only button (many real apps skip contentDescription on
    icon buttons entirely, especially in a header/toolbar). Purely
    positional (derived only from where it sits on screen relative to the
    screen's own dimensions) - no app-specific wording anywhere - so a
    target description like "the headphone icon in the top right corner"
    or "support icon top right" still has something concrete on this
    element to fuzzy/LLM-match against, instead of the element being
    silently absent from every scan (see _first_descendant_text and the
    call site below)."""
    if not center or not screen_size:
        return "(icon button)"
    x, y = center
    w, h = screen_size
    if not w or not h:
        return "(icon button)"
    vert = "top" if y < h / 3 else ("bottom" if y > 2 * h / 3 else "middle")
    horiz = "left" if x < w / 3 else ("right" if x > 2 * w / 3 else "center")
    if vert == "middle" and horiz == "center":
        return "(icon button, center of screen)"
    return f"(icon button, {vert}-{horiz} of screen)"


def _element_info(el, screen_size=None) -> dict | None:
    """One round-trip of attribute reads per element, reused for both the
    human/LLM-readable line AND the structured attrs_map entry (avoids
    fetching the same attributes twice). `screen_size` (width, height), if
    given, enables the last-resort positional label below for a
    completely unlabeled icon-only control."""
    try:
        text = _clean_attr(el.get_attribute("text"))[:60]
        desc = _clean_attr(el.get_attribute("content-desc"))[:60]
        resource_id = _clean_attr(el.get_attribute("resource-id"))
        # Short resource-id (drop the package prefix) reads better and is
        # still enough to disambiguate - e.g. "com.sbi.lotusintouch:id/etUser" -> "etUser"
        short_rid = resource_id.rsplit("/", 1)[-1] if resource_id else ""
        cls = _short_class(_clean_attr(el.get_attribute("className")))
        checkable = (_clean_attr(el.get_attribute("checkable")).lower() == "true")
        # "checked" is only ever read/displayed when checkable is true (see
        # the `if checkable:` bit below) - skip the extra Appium round-trip
        # for the large majority of elements that aren't checkable at all
        # (every plain TextView/Button/etc). This is the main per-element
        # latency win available here without a riskier rewrite: each
        # get_attribute() call is its own HTTP round-trip to the Appium
        # server, and get_state() does this for every interactive element
        # on screen, on every single resolution attempt.
        checked = (_clean_attr(el.get_attribute("checked")).lower() == "true") if checkable else False
        clickable = (_clean_attr(el.get_attribute("clickable")).lower() == "true")
        enabled_raw = _clean_attr(el.get_attribute("enabled"))
        bounds = _clean_attr(el.get_attribute("bounds"))
        center = _center_from_bounds(bounds)

        label = text or desc or short_rid

        if not label and clickable:
            # See _first_descendant_text - a clickable list-row/card wrapper
            # with no text of its own; borrow its child's label instead of
            # dropping the row entirely.
            label = _first_descendant_text(el)
            if label:
                desc = label  # feed it into the field resolver.py's fuzzy match actually reads (not just the display line)

        if not label and "EditText" in cls:
            # A blank input field legitimately has no text/desc/resource-id
            # yet (nothing typed, and a hint isn't part of UiAutomator2's
            # standard attribute set) - but it's still a real target, and
            # "type" steps inherently target EMPTY fields. Don't drop it;
            # give it a generic label so it's still visible to matching.
            # resolver.py's class-based tie-break already favors EditText
            # for "type" actions, so this alone is often enough to identify
            # it correctly - especially when it's the only empty field on
            # screen (as with a single "Mobile Number" field).
            label = "(empty input field)"
            desc = label

        if not label and clickable and center:
            # Truly unlabeled clickable control (no text/desc/resource-id
            # anywhere in itself OR its descendants) - e.g. a bare icon
            # button. Without this it's dropped from EVERY scan tier
            # (narrow AND broad both require text/desc/resource-id to
            # exist somewhere), which no amount of re-reading or scrolling
            # can ever fix since the element just isn't in the result set
            # to begin with. See _positional_label's docstring.
            label = _positional_label(center, screen_size)
            desc = label

        if not label:
            return None

        bits = []
        if short_rid and short_rid != label:
            bits.append(f"id='{short_rid}'")
        if checkable:
            bits.append(f"checkable checked={checked}")
        if enabled_raw == "false":
            bits.append("disabled")
        if center:
            bits.append(f"pos=({center[0]},{center[1]})")
        extra = (" " + " ".join(bits)) if bits else ""

        line = f"<{cls}>{label}</{cls}>{extra}"

        return {
            "line": line,
            "text": text,
            "desc": desc,
            "resource_id": short_rid,
            "class": cls,
            "checkable": checkable,
            "checked": checked,
            "clickable": clickable,
            "enabled": (enabled_raw != "false"),
            "center": center,
        }
    except Exception:
        return None


def dump_failed_screen(driver, tag: str) -> "str | None":
    """Saves the raw UI hierarchy XML (driver.page_source) to
    logs/failed_resolutions/<timestamp>_<tag>.xml, so a resolution/
    selection failure is diagnosable from real data afterwards instead of
    guessing from a screenshot - common causes this reveals directly: the
    element exists but with clickable='false' everywhere in its hierarchy
    (needs the broader fallback scan / an ancestor click, or genuinely
    isn't reachable this way), it's genuinely absent from the native tree
    (a WebView/hybrid screen - would need Appium's context-switching, a
    bigger change), or it's simply off-screen in a direction the search
    didn't expect.

    Shared by agent.py (click/type/toggle/wait_for/select target-resolution
    failures) and action_executor.execute_select (failures picking an
    option after the dropdown/picker is already open) so both failure
    paths get equally good diagnostics, not just the ones that happen to
    go through the resolver. Never raises - diagnostics are a bonus, not
    something that should break the run. Sync (not async) since both
    current callers already run this off the event loop themselves
    (asyncio.to_thread), matching how the rest of this module works.
    """
    try:
        from config import settings
        dump_dir = settings.base_dir / "logs" / "failed_resolutions"
        dump_dir.mkdir(parents=True, exist_ok=True)
        safe_tag = "".join(c if c.isalnum() or c in "._- " else "_" for c in tag)[:80].strip()
        path = dump_dir / f"{int(time.time())}_{safe_tag}.xml"

        # Best-effort context note: if this screen is (or has) a WebView,
        # none of ANDROID_INTERACTIVE_XPATH/ANDROID_TEXT_XPATH would ever
        # see its content at all (both only ever query the native
        # accessibility tree) - a stuck-looking element that's actually
        # inside a WEBVIEW_* context is a different problem entirely
        # (needs Appium context-switching, not a wider native filter).
        # Recorded as an XML comment so it's visible right alongside the
        # hierarchy dump without needing a second file.
        context_note = ""
        try:
            contexts = driver.contexts
            context_note = f"<!-- Appium contexts at failure time: {contexts} -->\n"
        except Exception:
            pass

        path.write_text(context_note + driver.page_source, encoding="utf-8")
        return str(path)
    except Exception:
        return None


def _normalize_label(attrs: dict) -> str:
    return (attrs.get("text") or attrs.get("desc") or "").strip().lower()


def _enrich_duplicate_context(driver, attrs_map: dict, lines: list, ref_line_idx: dict) -> None:
    """Post-processing pass, run AFTER a normal scan: finds elements that
    share the EXACT SAME own label with at least one other element on this
    same screen (e.g. every "Apply Now" button in a scrollable list of
    cards, every "Know more" link, every "Buy Now" button on a product
    grid) and attaches the OTHER nearby on-screen text to each one as a
    `context` field - so resolver.py's fuzzy/LLM matching has something to
    actually tell the duplicates apart with (e.g. the specific card's own
    title), instead of every occurrence looking identical and the first
    one found on screen winning by default regardless of which one the
    description actually named.

    Purely structural - keyed only off "do 2+ elements share identical
    text/desc", never off any specific app's wording - so this generalizes
    to any repeated-card/list-item UI, not just this project's current
    target app.

    Deliberately only runs a SECOND (broader, text-only) scan when a
    duplicate is actually found - most screens have none, and this keeps
    the extra Appium round-trip cost limited to the screens where it's
    actually needed, consistent with this project's existing performance
    discipline (see get_broad_state's docstring for the same reasoning).

    For each duplicate occurrence, "its context" = every OTHER piece of
    on-screen text that falls (vertically) between it and the PREVIOUS
    occurrence of that same duplicate label (or the top of the screen, for
    the first occurrence). For a card list this naturally captures "that
    whole card's own text" (title, description, price, etc.) without any
    pixel-distance tuning or app-specific layout assumptions - the
    duplicate markers themselves define each group's boundaries.
    """
    dup_groups: dict = {}
    for ref, attrs in attrs_map.items():
        if not attrs.get("center"):
            continue
        label = _normalize_label(attrs)
        if not label:
            continue
        dup_groups.setdefault(label, []).append(ref)
    dup_groups = {label: refs for label, refs in dup_groups.items() if len(refs) > 1}
    if not dup_groups:
        return

    try:
        text_elements = driver.find_elements(By.XPATH, ANDROID_TEXT_XPATH)
    except Exception:
        text_elements = []

    band_texts = []  # (y_center, label) for every text-bearing element on screen
    for el in text_elements[:250]:
        try:
            t = _clean_attr(el.get_attribute("text"))
            d = _clean_attr(el.get_attribute("content-desc"))
            txt = (t or d)[:80]
            if not txt:
                continue
            center = _center_from_bounds(_clean_attr(el.get_attribute("bounds")))
            if not center:
                continue
            band_texts.append((center[1], txt))
        except Exception:
            continue
    if not band_texts:
        return
    band_texts.sort(key=lambda item: item[0])

    for label, refs in dup_groups.items():
        ordered = sorted(refs, key=lambda r: attrs_map[r]["center"][1])
        for i, ref in enumerate(ordered):
            y_cur = attrs_map[ref]["center"][1]
            y_prev = attrs_map[ordered[i - 1]]["center"][1] if i > 0 else -1
            seen = []
            for y, txt in band_texts:
                if y_prev < y < y_cur and txt.strip().lower() != label and txt not in seen:
                    seen.append(txt)
            if not seen:
                continue
            ctx = " | ".join(seen)[:180]
            attrs_map[ref]["context"] = ctx
            idx = ref_line_idx.get(ref)
            if idx is not None:
                lines[idx] = f"{lines[idx]} ctx='{ctx}'"


def _screen_header(driver) -> str:
    """Best-effort package/activity header so the resolver/verifier can
    confirm which screen/app is actually on screen right now. Never raises -
    not all Appium sessions expose these the same way."""
    pkg = activity = ""
    try:
        pkg = driver.current_package
    except Exception:
        pass
    try:
        activity = driver.current_activity
    except Exception:
        pass
    if not pkg and not activity:
        return ""
    return f"Package: {pkg}  Activity: {activity}\n"


def get_state(driver, max_elements: int = 60):
    """Returns (state_text, ref_map, attrs_map):
      - state_text: human/LLM-readable listing of on-screen interactive elements
      - ref_map: 'E0','E1',... -> live WebElement
      - attrs_map: 'E0','E1',... -> dict of raw fields (text/desc/resource_id/
        class/checkable/checked/enabled/center), used by resolver.py for
        structured tie-breaking and fingerprint caching without re-parsing
        state_text.
    """
    try:
        elements = driver.find_elements(By.XPATH, ANDROID_INTERACTIVE_XPATH)
    except Exception:
        elements = []

    screen_size = None
    try:
        size = driver.get_window_size()
        screen_size = (size["width"], size["height"])
    except Exception:
        pass

    ref_map = {}
    attrs_map = {}
    lines = []
    ref_line_idx = {}
    idx = 0
    for el in elements:
        info = _element_info(el, screen_size)
        if not info:
            continue
        ref = f"E{idx}"
        ref_map[ref] = el
        attrs_map[ref] = info
        ref_line_idx[ref] = len(lines)
        lines.append(f"[{ref}] {info['line']}")
        idx += 1
        if idx >= max_elements:
            break

    _enrich_duplicate_context(driver, attrs_map, lines, ref_line_idx)

    state_text = (
        f"{_screen_header(driver)}"
        f"Interactive elements (only what's currently on screen - scroll if you "
        f"expect more):\n" + "\n".join(lines)
    )
    return state_text, ref_map, attrs_map


def get_broad_state(driver, max_elements: int = 120):
    """Same shape/return value as get_state() (state_text, ref_map,
    attrs_map), but scanned with ANDROID_TEXT_XPATH instead of
    ANDROID_INTERACTIVE_XPATH - i.e. EVERY element with visible text or a
    content-description, not just ones marked clickable/long-clickable/
    checkable or a known widget class.

    WHY THIS EXISTS: some tappable list rows put NO clickable/checkable
    flag anywhere in the row at all - the tap is handled by a parent's
    OnClickListener, or by the list's own item-touch handling (both common
    RecyclerView patterns) - so the row, and the text that actually
    identifies it (e.g. "Canada" in a country picker), never satisfies
    ANDROID_INTERACTIVE_XPATH. This is a DIFFERENT bug from the
    clickable-container-with-no-text-of-its-own case _first_descendant_text
    already handles above: that fix only helps once an element has already
    passed the interactive filter; this covers the row not passing that
    filter in the first place. No amount of re-reading the same filtered
    view, or scrolling around looking for it, would ever find such a row -
    it just isn't in the result set get_state() works from.

    DELIBERATELY NOT the default: on a busy screen this can return
    hundreds of plain caption/label TextViews with no interactive role at
    all. Using it for every scan would (a) multiply get_state()'s already-
    dominant per-element attribute-read cost by however many extra plain
    text nodes exist on screen, and (b) hurt fuzzy-match precision, since
    every one of those captions becomes extra near-miss text a target
    description could accidentally score well against. See resolver.py's
    single, last-chance use of this function for how the cost is kept to a
    one-off rather than a per-scan tax.

    Elements found here are frequently NOT clickable themselves
    (attrs_map[ref]["clickable"] is often False) - callers must be
    prepared to click via a clickable ANCESTOR or a raw coordinate tap
    instead of the element directly; see action_executor.execute_click.
    """
    try:
        elements = driver.find_elements(By.XPATH, ANDROID_TEXT_XPATH)
    except Exception:
        elements = []

    screen_size = None
    try:
        size = driver.get_window_size()
        screen_size = (size["width"], size["height"])
    except Exception:
        pass

    ref_map = {}
    attrs_map = {}
    lines = []
    ref_line_idx = {}
    idx = 0
    for el in elements:
        info = _element_info(el, screen_size)
        if not info:
            continue
        # 'B' prefix (vs get_state()'s 'E') keeps refs from this broader
        # scan visually distinct in logs/LLM prompts from a normal scan.
        ref = f"B{idx}"
        ref_map[ref] = el
        attrs_map[ref] = info
        ref_line_idx[ref] = len(lines)
        lines.append(f"[{ref}] {info['line']}")
        idx += 1
        if idx >= max_elements:
            break

    _enrich_duplicate_context(driver, attrs_map, lines, ref_line_idx)

    state_text = (
        f"{_screen_header(driver)}"
        f"ALL elements with visible text on screen right now (broad fallback "
        f"scan - not limited to clickable/interactive ones):\n" + "\n".join(lines)
    )
    return state_text, ref_map, attrs_map


def detect_horizontal_row_band(attrs_map: dict, min_items: int = 2,
                                min_spread_px: int = 140, y_bucket_px: int = 40):
    """Looks for a cluster of elements sitting at roughly the same
    y-coordinate but spread out horizontally - the signature of a nested
    horizontal card carousel embedded in an otherwise vertical screen (e.g.
    "Open Savings/Current Account", "Open PPF Account", ... sitting side by
    side under a vertically-scrolling homepage). Returns that row's
    y-center in pixels, or None if no such row is present (e.g. this is a
    plain vertical list, or a genuine full-screen horizontal pager where a
    screen-wide swipe is already the right thing to do).

    Used to CONFINE a "swipe" gesture to just that row's vertical band
    instead of a full-screen swipe - a screen-wide swipe on a small nested
    carousel like this can miss it entirely or drag the wrong part of the
    page instead (this was the cause of "Could not locate element" on a
    carousel's later cards even though the earlier cards were found fine).
    See action_executor.execute_swipe's `anchor_y` parameter.
    """
    buckets = defaultdict(list)
    for attrs in attrs_map.values():
        center = attrs.get("center")
        if not center:
            continue
        y_bucket = round(center[1] / y_bucket_px) * y_bucket_px
        buckets[y_bucket].append(center[0])

    best_y, best_count, best_spread = None, 0, 0
    for y, xs in buckets.items():
        if len(xs) < min_items:
            continue
        spread = max(xs) - min(xs)
        if spread < min_spread_px:
            continue
        if len(xs) > best_count or (len(xs) == best_count and spread > best_spread):
            best_y, best_count, best_spread = y, len(xs), spread

    return best_y
