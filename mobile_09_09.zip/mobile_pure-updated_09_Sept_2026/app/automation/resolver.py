"""
Resolves a plain-English target description (e.g. "the login button", from
the up-front plan in planner.py) to an actual on-screen element.

Resolution order, cheapest/fastest first:

0. Cache fast-path: if this exact description was already resolved earlier
   in THIS run, try to re-find the same element by its resource-id/class
   fingerprint on the current (freshly-read) screen - a dict lookup plus one
   cheap scan, no LLM call at all. Falls through to the normal tiers if the
   fingerprint isn't present on this screen (screen changed).

1. Fuzzy text match (thefuzz) of the description against every element's
   text/desc/resource-id/class on the CURRENT screen - fast, free, no LLM.
   Ties (or near-ties) are broken in favour of the element whose class
   matches the action being performed (an EditText for "type", a
   CheckBox/Switch/RadioButton for "toggle", a Spinner for "select") - this
   avoids an unnecessary LLM call in the common case of two similar-looking
   elements where only one is actually interactable the requested way.

2. If that's ambiguous (best score below FUZZY_TARGET_THRESHOLD), ask the
   LLM once to pick the correct ref from the list - still text-only, no
   screenshot.

Steps 0-2 are retried a few times with a short pause (RESOLVE_RETRY_*) in
case the element just hasn't rendered yet (screen transitions, network
calls) before we conclude it's genuinely not on this screen.

3. Single last-chance broader scan of the CURRENT screen (see
   page_state.get_broad_state / _resolve_broad_fallback below): tiers 1-2
   only ever look at elements matching ANDROID_INTERACTIVE_XPATH (clickable/
   long-clickable/checkable, or a known widget class). Some tappable list
   rows put NO such flag anywhere in the row at all - the tap is handled by
   a parent's OnClickListener or by the list's own item-touch handling, both
   common RecyclerView patterns - so the row (and the text that actually
   identifies it, e.g. a country name in a picker) never enters tiers 1-2's
   result set no matter how many times the screen is re-read. This tier
   re-reads the same screen with a much wider "any element with text"
   filter and re-runs the exact same fuzzy/LLM matching against that.
   Deliberately a SINGLE attempt here, not folded into every scroll-search
   direction below (see get_broad_state's docstring for the noise/latency
   cost of scanning this broadly) - and deliberately placed BEFORE the
   persistent map and scroll-search, not after: both of those can move the
   screen (a map hit replays a saved scroll path; scroll-search scrolls/
   swipes through every direction), and an element that's genuinely on
   screen right now - just filtered out by tiers 1-2 - would otherwise risk
   being scrolled straight past before a later "last chance" ever got to
   see it again. A hit here is also opportunistically saved to the
   persistent map (path=[]), so a later resolution of the same row can skip
   this broader scan entirely and jump straight to tier 4 instead.

3.5. A single vision attempt on the CURRENT, unscrolled screen - only for
   the case where tiers 1-3 found NOTHING at all (not even a near-miss),
   which is the signature of an element with no text/content-desc/
   resource-id anywhere (a bare icon button) rather than an element that's
   simply off-screen. Deliberately placed BEFORE the map/scroll-search
   tiers below, for the same "don't move the screen before giving the
   current one a fair look" reason tier 3 is placed before them - an
   unlabeled icon is usually part of a fixed header/toolbar that scrolling
   the body won't reveal any more of anyway, so scrolling first would only
   waste gestures and risk vision's screenshot no longer matching what the
   description was written against. See _resolve_by_description's tier
   3.5 comment / locator_engine.resolve_by_vision.

4. Persistent screen-map lookup (see screen_map.py): if this same screen
   was explored on an earlier run/step, a matching element may already have
   a KNOWN path (e.g. "swipe left x3"). If so, jump straight there and
   re-verify by fingerprint before trusting it - mechanical, no LLM, and
   usually far cheaper than blind scrolling. Falls through to live search
   below if there's no map yet, no good match, or the match turns out to be
   stale (screen has changed since it was recorded).

5. If it's still not found, auto-scroll-to-find: try each direction in
   SCROLL_DIRECTIONS (down, up, right, left by default - screens are usually
   vertical lists but some app UIs page sideways, e.g. tab bars, onboarding
   carousels), re-reading the screen and re-running steps 1-2 after every
   scroll/swipe. Stops a direction early once it stops changing the screen
   (reached the end) or the resulting screen has already been seen (looping).
   Elements seen along the way are opportunistically recorded into the
   persistent screen map (screen_map.py) for free, whether or not the
   target itself is found - this is how the map in 2.5 gets built up over
   time, with zero dedicated crawling cost.

   Two optional hints from the plan (see planner.py) make this faster and
   more correct instead of just guessing blindly in every direction:
     - `direction_hint`: try this direction FIRST (e.g. the instruction said
       "swipe left until..."), still falling through to the other 3 if it
       isn't actually there.
     - `gesture`: "scroll" (default - a partial-extent list nudge) or
       "swipe" (a full-extent fling, for paging through a carousel/pager) -
       which physical gesture to use for every direction tried during this
       search. Set to "swipe" when the instruction itself says "swipe"
       (e.g. "swipe through the screen until you see X"), since a small
       list-style nudge often won't advance a full-screen pager at all.
     When swiping left/right, a nested horizontal carousel row (e.g. a row
     of quick-action cards on an otherwise vertical home screen) is
     auto-detected (page_state.detect_horizontal_row_band) and the swipe is
     confined to just that row instead of the whole screen - a screen-wide
     swipe can otherwise miss a small embedded carousel entirely.

6. Only if nothing on any reachable screen matches, fall back to vision
   (screenshot + coordinates) a SECOND time, now on wherever scroll-search
   left off - same ENABLE_VISION_FALLBACK kill switch as tier 3.5. This
   catches a target that only becomes visible after scrolling (tier 3.5
   already covered the "visible right now but unlabeled" case).
"""

import asyncio
import time
from typing import Optional

from thefuzz import fuzz

from app.llm.model_client import achat_json
from app.automation.page_state import get_state, get_broad_state, detect_horizontal_row_band
from app.automation.locator_engine import resolve_by_ref, resolve_by_vision, ResolvedTarget
from app.automation import screen_map
from config import settings

FUZZY_TARGET_THRESHOLD = 70

# Small score bonus applied when an element's class matches what the action
# implies it should be - only enough to break ties/near-ties, not enough to
# override a much stronger text match on the "wrong" class.
CLASS_HINT_BONUS = 8
ACTION_CLASS_HINTS = {
    "type": {"EditText"},
    "toggle": {"CheckBox", "Switch", "RadioButton"},
    "select": {"Spinner"},
}

SCROLL_DIRECTIONS = ["down", "up", "right", "left"]

RESOLVE_SYSTEM_PROMPT = """You are matching a plain-English target
description to one specific element from a list of UI elements currently
on a mobile screen. Respond with ONLY JSON, no reasoning, no <think> tags,
no prose: {"ref": "E3" or null, "reasoning": "short reason"}
Pick the single best-matching ref. If several elements have similar text,
prefer the one whose role/class fits the description and the intended
action (e.g. an EditText for a "field" being typed into, a Button for a
"button" being clicked, a CheckBox/Switch for something being toggled).
Some elements repeat the EXACT SAME label elsewhere on the screen (e.g.
several identical "Apply Now"/"Buy Now"/"Know more" buttons, one per card
in a list). When that happens, an element may carry a `ctx='...'`
annotation listing OTHER nearby on-screen text (e.g. that specific card's
own title/name) - use it to pick the occurrence whose ctx matches any
extra qualifying detail in the description (a product/card/section name),
rather than just the repeated action word every candidate shares. If
genuinely nothing matches, set ref to null - do not guess.
"""


def _fingerprint(ref: str, attrs_map: dict) -> Optional[dict]:
    """Thin delegate to screen_map's canonical fingerprint logic, so the
    in-memory per-run cache here and the persistent on-disk map use
    IDENTICAL element-identity rules."""
    return screen_map.element_fingerprint(attrs_map.get(ref))


def _match_fingerprint(fp: dict, attrs_map: dict) -> Optional[str]:
    return screen_map.match_fingerprint(fp, attrs_map)


AMBIGUITY_MARGIN = 12
# When 2+ elements on screen share the EXACT SAME own text/desc (e.g. every
# "Apply Now" button in a scrollable card list, every "Know more" link),
# their fuzzy scores are driven almost entirely by that one shared phrase,
# not by which one actually matches the description - a repeated-label
# element only earns tier 1's "blind accept" fast path if it beats every
# OTHER element sharing its label by more than this many points (which
# page_state's `context` annotation - see _enrich_duplicate_context - makes
# achievable when the description names something that context captures,
# e.g. a specific card's title). A close call among duplicates instead
# falls through to the LLM tier below, which reads the full screen state
# (including each element's ctx='...' annotation) and can actually tell
# them apart.


def _fuzzy_scores(description: str, attrs_map: dict, action: Optional[str] = None) -> list:
    """Returns every (ref, score) pair, sorted best-first - not just the
    top one - so callers can also check how far the winner is ahead of
    its nearest same-label rival (see _is_ambiguous below)."""
    hint_classes = ACTION_CLASS_HINTS.get(action or "", set())
    scored = []
    for ref, attrs in attrs_map.items():
        haystack = " ".join(filter(None, [
            attrs.get("text"), attrs.get("desc"), attrs.get("resource_id"),
            attrs.get("class"), attrs.get("context"),
        ]))
        score = fuzz.token_set_ratio(description.lower(), haystack.lower())
        if hint_classes and attrs.get("class") in hint_classes:
            score += CLASS_HINT_BONUS
        scored.append((ref, score))
    scored.sort(key=lambda rs: rs[1], reverse=True)
    return scored


def _fuzzy_best_ref(description: str, attrs_map: dict, action: Optional[str] = None):
    scored = _fuzzy_scores(description, attrs_map, action)
    if not scored:
        return None, 0
    return scored[0]


def _own_label(ref: Optional[str], attrs_map: dict) -> str:
    if not ref:
        return ""
    attrs = attrs_map.get(ref, {})
    return (attrs.get("text") or attrs.get("desc") or "").strip().lower()


def _is_ambiguous(scored: list, attrs_map: dict) -> bool:
    """True when the top-scoring element shares its own label with another
    candidate that scored within AMBIGUITY_MARGIN of it - i.e. tier 1's
    "winner" isn't actually distinguishing them, it's just the first one
    with that shared label that happened to be read. See AMBIGUITY_MARGIN."""
    if len(scored) < 2:
        return False
    top_ref, top_score = scored[0]
    top_label = _own_label(top_ref, attrs_map)
    if not top_label:
        return False
    for ref, score in scored[1:]:
        if ref == top_ref:
            continue
        if _own_label(ref, attrs_map) == top_label and (top_score - score) <= AMBIGUITY_MARGIN:
            return True
    return False


async def _resolve_on_screen(description: str, action: Optional[str], state_text: str, ref_map: dict, attrs_map: dict):
    """Tiers 1-2 against a single, already-read screen. Returns
    (ResolvedTarget|None, fingerprint|None)."""
    if not ref_map:
        return None, None

    scored = _fuzzy_scores(description, attrs_map, action)
    ref, score = scored[0] if scored else (None, 0)
    if ref and score >= FUZZY_TARGET_THRESHOLD and not _is_ambiguous(scored, attrs_map):
        target = resolve_by_ref(ref, ref_map, attrs_map.get(ref))
        if target:
            return target, _fingerprint(ref, attrs_map)

    # Tier 2: ask the LLM to pick from the list - still no screenshot.
    try:
        action_note = f'\n\nThe action to perform on it is: "{action}".' if action else ""
        result = await achat_json(
            RESOLVE_SYSTEM_PROMPT,
            f"Target description: {description}{action_note}\n\nCURRENT SCREEN STATE:\n{state_text}\n\nWhich ref matches?",
        )
        picked_ref = result.get("ref")
        if picked_ref:
            target = resolve_by_ref(picked_ref, ref_map, attrs_map.get(picked_ref))
            if target:
                return target, _fingerprint(picked_ref, attrs_map)
    except Exception:
        pass

    return None, None


async def _resolve_broad_fallback(driver, description: str, action: Optional[str]):
    """Tier 3 (see module docstring): a single re-read of the CURRENT
    screen via page_state.get_broad_state's much wider filter, then the
    same fuzzy/LLM matching as tiers 1-2. Returns (ResolvedTarget|None,
    fingerprint|None), same shape as _resolve_on_screen."""
    state_text, ref_map, attrs_map = await asyncio.to_thread(get_broad_state, driver)

    if settings.screen_map_enabled:
        # Opportunistic, free recording of everything this broader scan
        # saw - same pattern _scroll_search uses below - so a later
        # resolution of the same (or a different) element on this screen
        # can hit the persistent map directly (tier 4) and skip this
        # broader scan entirely next time. path=[] since this is the
        # CURRENT position, not reached via any scroll/swipe.
        sink: dict = {}
        screen_map.record_elements(sink, [], attrs_map)
        if sink:
            await asyncio.to_thread(screen_map.save_map, driver, sink)

    return await _resolve_on_screen(description, action, state_text, ref_map, attrs_map)


def _ordered_directions(direction_hint: Optional[str]) -> list:
    """Puts the hinted direction first (if it's a recognized one), keeping
    the rest in the default order as a fallback - fast when the hint is
    right, still resilient when it isn't."""
    if direction_hint in SCROLL_DIRECTIONS:
        return [direction_hint] + [d for d in SCROLL_DIRECTIONS if d != direction_hint]
    return list(SCROLL_DIRECTIONS)


async def _map_search(driver, description: str, action: Optional[str]):
    """Tier 4: consult the persistent screen map before doing any blind
    scrolling. Returns (ResolvedTarget|None, fingerprint|None). Cheap when
    it misses (one file read + an in-memory fuzzy loop); potentially a big
    win when it hits (skips the entire scroll-search below)."""
    if not settings.screen_map_enabled:
        return None, None

    elements = await asyncio.to_thread(screen_map.load_map, driver)
    if not elements:
        return None, None

    entry = screen_map.find_candidate(description, elements, action)
    if not entry:
        return None, None

    await screen_map.apply_path(driver, entry.get("path") or [])
    state_text, ref_map, attrs_map = await asyncio.to_thread(get_state, driver)
    ref = _match_fingerprint(entry["fingerprint"], attrs_map)
    if not ref:
        return None, None  # stale entry (app/screen changed) - live search below will re-learn it

    target = resolve_by_ref(ref, ref_map, attrs_map.get(ref))
    if not target:
        return None, None

    entry["last_confirmed"] = time.time()
    fp_key = screen_map.fingerprint_key(entry["fingerprint"])
    await asyncio.to_thread(screen_map.save_map, driver, {fp_key: entry})
    return target, entry["fingerprint"]


async def _scroll_search(
    driver,
    description: str,
    action: Optional[str],
    direction_hint: Optional[str] = None,
    gesture: str = "scroll",
):
    """Scrolls/swipes through the screen in each direction looking for the
    target, opportunistically recording every element it sees into the
    persistent screen map along the way (see screen_map.py). Returns
    (ResolvedTarget|None, fingerprint|None)."""
    max_per_direction = settings.max_scroll_attempts_per_direction
    pause = settings.scroll_pause_sec
    seen_signatures = set()
    map_enabled = settings.screen_map_enabled
    crawl_sink: dict = {}

    from app.automation.action_executor import execute_scroll, execute_swipe  # local import: avoids a module-load cycle

    async def _finish(target, fp):
        if map_enabled and crawl_sink:
            await asyncio.to_thread(screen_map.save_map, driver, crawl_sink)
        return target, fp

    # Ground ourselves at a known reference point before exploring, so:
    #  (a) recorded paths always mean the same thing ("N scrolls/swipes from
    #      the top"), regardless of where the app happened to be scrolled to
    #      when this search started, and
    #  (b) "up" doesn't stop short if we entered this search already
    #      partway down from an earlier step.
    if map_enabled:
        await screen_map.reset_to_top(driver)

    # Always take one baseline read before exploring - it's needed both for
    # carousel-row detection on the very first left/right attempt AND for
    # map recording, and tier 3 is only reached after tiers 0-2 already
    # failed, so one extra read here is a small fraction of what we're
    # about to spend scrolling/swiping anyway.
    state_text, ref_map, attrs_map = await asyncio.to_thread(get_state, driver)
    last_attrs_map = attrs_map
    if map_enabled:
        screen_map.record_elements(crawl_sink, [], attrs_map)
    target, fp = await _resolve_on_screen(description, action, state_text, ref_map, attrs_map)
    if target:
        return await _finish(target, fp)

    for direction in _ordered_directions(direction_hint):
        prev_signature = None
        count = 0
        for _ in range(max_per_direction):
            # A nested horizontal carousel (e.g. a row of quick-action
            # cards) needs its swipe CONFINED to just that row - a
            # screen-wide swipe can miss it or drag the wrong part of the
            # page instead. Auto-detected from whatever's on screen right
            # now, and used WHENEVER a carousel row is present - not only
            # when the plan explicitly said gesture_hint="swipe". A plan
            # can't always be relied on to correctly tag every case, and a
            # scroll-nudge essentially never operates a nested carousel
            # correctly, so this is a safe override either way: if no
            # carousel row is detected, it just falls back to whatever
            # gesture was actually requested (matching a genuine full-
            # screen pager, or a plain vertical scroll for up/down).
            anchor_y = None
            effective_fn = execute_swipe if gesture == "swipe" else execute_scroll
            if direction in ("left", "right"):
                anchor_y = detect_horizontal_row_band(last_attrs_map)
                if anchor_y is not None:
                    effective_fn = execute_swipe

            try:
                await asyncio.to_thread(effective_fn, driver, direction, anchor_y)
            except Exception:
                break
            effective_gesture = "swipe" if effective_fn is execute_swipe else "scroll"
            count += 1
            await asyncio.sleep(pause)

            state_text, ref_map, attrs_map = await asyncio.to_thread(get_state, driver)
            last_attrs_map = attrs_map
            signature = hash(state_text)

            if signature == prev_signature:
                # Scrolling/swiping had no visible effect - reached the end of this direction.
                break
            prev_signature = signature

            if signature in seen_signatures:
                # We've looped back to a screen we already checked - stop this direction.
                break
            seen_signatures.add(signature)

            if map_enabled:
                # Record whatever gesture was ACTUALLY used (which may have
                # been auto-upgraded to "swipe" above), so a later replay
                # via screen_map.apply_path repeats the right physical
                # gesture rather than the originally-requested one.
                screen_map.record_elements(
                    crawl_sink, [{"gesture": effective_gesture, "direction": direction, "count": count}], attrs_map,
                )

            target, fp = await _resolve_on_screen(description, action, state_text, ref_map, attrs_map)
            if target:
                return await _finish(target, fp)

    return await _finish(None, None)


async def aresolve_by_description(
    driver,
    description: str,
    state_text: str,
    ref_map: dict,
    attrs_map: Optional[dict] = None,
    action: Optional[str] = None,
    cache: Optional[dict] = None,
    direction_hint: Optional[str] = None,
    gesture: str = "scroll",
):
    """Returns a ResolvedTarget or None.

    `state_text`/`ref_map`/`attrs_map` should be a FRESH read of the current
    screen (see agent.py's `_resolve`). `action` (click/type/toggle/select/...)
    is used only for class-based tie-breaking and LLM disambiguation hints.
    `cache`, when provided, is a per-run dict this call may read from and
    write to, keyed by the lowercased description, to skip re-resolving
    targets it has already found earlier in the same run.
    `direction_hint`/`gesture` are forwarded to the auto-scroll-to-find
    search (tier 3) - see this module's docstring.
    """
    if not description:
        return None

    attrs_map = attrs_map or {}
    cache_key = description.strip().lower()

    # Tier 0: cached fingerprint from an earlier resolution of this same
    # description in this run - try it against the CURRENT screen first.
    if cache is not None and cache_key in cache:
        ref = _match_fingerprint(cache[cache_key], attrs_map)
        if ref:
            target = resolve_by_ref(ref, ref_map, attrs_map.get(ref))
            if target:
                return target
        # Fingerprint not on this screen (screen changed) - fall through to
        # the normal tiers below rather than trusting a stale cache entry.

    # Tiers 1-2, retried a few times in case the element just hasn't
    # rendered yet (short-lived screen transitions, async content loads).
    retries = max(settings.resolve_retry_attempts, 0)
    interval = settings.resolve_retry_interval_sec
    cur_state_text, cur_ref_map, cur_attrs_map = state_text, ref_map, attrs_map
    for attempt in range(retries + 1):
        target, fp = await _resolve_on_screen(description, action, cur_state_text, cur_ref_map, cur_attrs_map)
        if target:
            if cache is not None and fp:
                cache[cache_key] = fp
            return target
        if attempt < retries:
            await asyncio.sleep(interval)
            cur_state_text, cur_ref_map, cur_attrs_map = await asyncio.to_thread(get_state, driver)

    # Tier 3: single last-chance broader scan of the CURRENT screen - catches
    # a tappable row whose text lives on a child that carries no clickable/
    # checkable flag anywhere (the tap is handled by a parent or by the list
    # itself), which tiers 1-2 above can never see no matter how many times
    # they re-read this same screen. Tried here, before the map/scroll-search
    # below, so an element that's genuinely visible right now isn't scrolled
    # straight past before getting this one broader look. See
    # _resolve_broad_fallback / page_state.get_broad_state.
    target, fp = await _resolve_broad_fallback(driver, description, action)
    if target:
        if cache is not None and fp:
            cache[cache_key] = fp
        return target

    # Tier 3.5: a single vision attempt on the CURRENT, UNSCROLLED screen -
    # only reached once tiers 0-3 have all found nothing at all. Exists for
    # elements page_state can never surface via text-based scanning no
    # matter how it's filtered - a pure icon-only control with no text, no
    # content-desc, and no resource-id anywhere in itself or its
    # descendants (some real apps genuinely ship icon buttons - e.g. a
    # header's support/headphone icon - with no accessibility label at
    # all). Scrolling would not help find such an element if it's already
    # on screen (most commonly a FIXED header/toolbar icon that doesn't
    # move when the body below it scrolls), and running scroll-search
    # first would actively hurt: vision fallback (tier 6 below) only ever
    # runs AFTER scroll-search has already explored every direction, by
    # which point several scroll/swipe gestures have been spent for
    # nothing and the screen may no longer look anything like it did when
    # this description was written. Trying vision here first, before any
    # scrolling, gives an on-screen-but-unlabeled icon a real chance while
    # it's still actually on screen. Falls straight through to the
    # map/scroll-search tiers below if this also finds nothing (e.g. the
    # target genuinely IS off-screen and needs scrolling) - tier 6 remains
    # as a final vision attempt on wherever scrolling ends up, for a
    # target that only becomes visible after scrolling.
    target = await resolve_by_vision(driver, description)
    if target:
        return target

    # Tier 4: a persisted screen map from an earlier run/step may already
    # know exactly where this element is (even off the current screen).
    target, fp = await _map_search(driver, description, action)
    if target:
        if cache is not None and fp:
            cache[cache_key] = fp
        return target

    # Tier 5: the target isn't on the current screen at all - scroll/swipe to find it.
    target, fp = await _scroll_search(driver, description, action, direction_hint, gesture)
    if target:
        if cache is not None and fp:
            cache[cache_key] = fp
        return target

    # Tier 6: vision fallback (returns None if disabled or not found).
    return await resolve_by_vision(driver, description)
