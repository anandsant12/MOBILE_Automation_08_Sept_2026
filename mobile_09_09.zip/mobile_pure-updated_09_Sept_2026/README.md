# AI Mobile Automation (Android)

An AI-driven UI automation agent for native Android apps, built on Appium.
You describe what you want done in plain English; the agent turns that
into an exact, ordered plan, shows it to you, then executes it — nothing
more, nothing less.

This project is **mobile-only**. All web/Selenium-target code has been
removed.

## What changed in this version

**1. Plan-then-act, not react-and-guess.**
Previously the agent asked the model "what's the single next action?"
after every screen change. That reactive loop had no fixed endpoint, so it
could keep proposing actions you never asked for. Now the agent calls the
planner **exactly once**, up front: your instructions are converted into a
strict, ordered list of atomic actions (`planner.py`). The run then
executes precisely that list, in order, and stops — see `agent.py`. If a
step fails, the run stops rather than improvising a "fix."

**2. The agent never launches the app itself.**
Appium already launches the app (via `ANDROID_APP_PACKAGE` /
`ANDROID_APP_ACTIVITY` in `.env`) before any planned step runs. The
planner's system prompt now explicitly says the app is already open and
in the foreground, and instructs it to never create an "open/launch app"
step — even if your instructions start with "open the app."

**3. One LLM provider toggle drives both text and vision.**
`LLM_PROVIDER=groq` or `LLM_PROVIDER=azure` in `.env` — no more separate
text/vision toggles. On `azure`, the same deployment (point it at your
gpt-4.1-mini deployment) is used for both text and vision calls, since
gpt-4.1-mini is multimodal.

**4. Locator/action fixes.**
- The vision-fallback click/type path previously used Selenium
  `ActionChains.move_by_offset`, which is a desktop-mouse concept and
  doesn't reliably drive a touch screen through Appium. It now uses
  UiAutomator2's `mobile: clickGesture` / `mobile: swipeGesture` commands.
- Screen-state extraction (`page_state.py`) now includes each element's
  short resource-id, checked/enabled state, and on-screen position, so the
  fuzzy/LLM resolver can tell apart elements that share similar text.
- A `verify` action and Android-native `select` (tap-to-open-dropdown +
  fuzzy-match-and-tap the option) are supported directly.

**5. Dead/broken code removed.**
`step_runner.py` (a manual step-builder path that referenced functions
that didn't exist in `action_executor.py` and was never wired into the
Streamlit UI), `action_schema.py` (its unused, web/mobile-mixed schema),
and `app/llm/groq_client.py` (an unused duplicate of `model_client.py`)
have all been deleted.

**6. Non-clickable list rows (e.g. a country picker) now resolve AND
click correctly, plus a safe scan-speed trim.**
- A previous fix taught the scanner to borrow a clickable row's child
  text as its label (so a flag-icon + country-name row isn't dropped for
  having no text of its own) - but that only helps when the row itself is
  marked `clickable`. Some rows aren't: the tap is instead handled by a
  parent view or by the list's own item-touch handling (both common
  RecyclerView patterns), so the row - and the text that actually
  identifies it - never satisfies the scanner's interactive-element
  filter at all, no matter how many times the screen is re-read.
- `page_state.get_broad_state()` is a new, much broader scan (any element
  with visible text, not just clickable/checkable/known-widget ones),
  used as a single last-chance fallback tier in `resolver.py` - tried
  once on the current screen, before the persistent map or auto-scroll
  search (which could otherwise scroll straight past an element that's
  already visible, just filtered out). Deliberately NOT the default scan
  everywhere else: on a busy screen it can return hundreds of plain
  caption/label elements, which would slow down every single screen read
  and hurt fuzzy-match precision if used unconditionally.
- Because an element found this way often isn't clickable itself,
  `action_executor.execute_click` now has a fallback for that case: click
  the nearest ancestor Android actually marked clickable, or, if none
  exists, tap the element's own on-screen coordinates directly (Android's
  touch dispatch bubbles an unconsumed tap up to whichever parent
  actually handles it, so this still lands correctly).
- Scan speed: `page_state.py` no longer reads an element's `checked`
  attribute unless it's already `checkable` - checked is only ever used
  for checkable elements, so this removes one Appium round-trip for every
  plain (non-checkable) element on screen, on every single scan.
- **Root cause of "select Canada still doesn't work" after the above**:
  `action_executor.execute_select` (used whenever the planner classifies a
  step as `select` - "choose X from a dropdown/list" - which a country
  picker instruction very naturally triggers) does its OWN option lookup
  after opening the dropdown/list, completely separate from
  `resolver.py`. It was still doing a narrow, clickable-only scan for the
  option text, so it never benefited from the broad-scan fix above at
  all. It now tries the same narrow scan first, then falls back to
  `get_broad_state()` if that finds nothing - and opens the dropdown/list
  itself via `execute_click` (ancestor/coordinate-tap aware) instead of a
  bare `.click()`, in case the trigger itself is ever non-clickable too.
  A failed option match now also dumps the UI hierarchy to
  `logs/failed_resolutions/` (via the new shared `page_state.
  dump_failed_screen`, also used by `agent.py`'s existing target-resolution
  failures), including a note of the live Appium contexts at that moment -
  a cheap early warning if a screen ever turns out to be a WebView/hybrid
  one, which no native scan (narrow or broad) can see into at all.

**7. Unlabeled icon buttons (e.g. a header's support/headphone icon) and
repeated-label buttons in a list (e.g. "Apply Now" on every card) now
resolve correctly.**
- **Root cause #1**: every scan tier in `page_state.py` required an
  element to have SOME text, content-desc, or resource-id (on itself or a
  descendant) before it was even included in the results - a pure
  icon-only control with none of those anywhere (common: many apps never
  set `contentDescription` on icon buttons) was silently dropped from
  *every* tier, narrow and broad alike. No amount of re-reading or
  scrolling could ever find it, because it simply wasn't in the result set
  to begin with. Fixed with a last-resort, purely positional label (e.g.
  `"(icon button, top-right of screen)"`, derived only from the element's
  on-screen position relative to screen size - no app-specific wording)
  so it now surfaces for fuzzy/LLM matching instead of vanishing.
  `_first_descendant_text`'s child-label-borrowing also now falls back to
  a descendant's resource-id (not just text/content-desc) as a secondary
  improvement.
- **Root cause #2**: `resolver.py`'s fuzzy tier scored each candidate
  purely on ITS OWN text/resource-id/class. For a list of cards that all
  share one "Apply Now" button template, every button scored identically
  - the resolver locked onto the first one found (well above the
  confidence threshold) and never got to the LLM tier or scrolled further
  to check for a differently-named card lower on the screen. Fixed with
  `page_state._enrich_duplicate_context`: when 2+ elements on screen share
  an exact label, each occurrence is tagged with the OTHER on-screen text
  around it (that card's own title, etc.) via a new `ctx='...'`
  annotation - purely structural (keyed only off "do labels match",
  never off any specific app's wording), so it generalizes to any
  repeated-card/list-item UI. `resolver.py`'s fuzzy scoring now reads this
  context, and an ambiguity-margin check defers a still-close call to the
  LLM tier (which also reads `ctx=`) instead of blind-accepting. This also
  fixed a related latent bug in the persistent screen map
  (`screen_map.py`): every card's identically-`resource-id`'d button would
  otherwise have collapsed onto ONE saved map entry, so a later run could
  have permanently "remembered" and always clicked the wrong card.
- **Vision-fallback ordering**: previously vision was only ever tried
  AFTER auto-scroll-search had already explored every direction - fine
  for a genuinely off-screen target, actively counterproductive for an
  on-screen-but-unlabeled icon (scrolling wastes gestures and risks the
  screen no longer matching what vision expects by the time it finally
  runs). `resolver.py` now tries vision once on the CURRENT, unscrolled
  screen right after the broad-scan tier and before any scrolling begins;
  the original post-scroll vision attempt still runs afterwards as a
  final fallback for a target that only appears after scrolling.
- Validated via `test_fixes_mock.py` (mock Appium driver/elements, no
  live device) - covers both root causes plus regression checks for the
  earlier fixes above (blank EditText placeholder, child-text borrowing,
  non-duplicate elements staying untouched).

## Architecture

```
streamlit_app.py
  -> planner.aplan(instructions)      # ONE call, produces the full plan
  -> agent.run_plan(planned_steps)    # executes that fixed plan, in order
       -> driver_manager.DriverManager   # starts Appium session (launches app)
       -> popup_handler.dismiss_popups   # clears permission/consent dialogs
       -> page_state.get_state           # fresh on-screen element list
       -> resolver.aresolve_by_description  # fuzzy -> LLM -> vision
       -> action_executor.execute_*       # the actual tap/type/scroll/etc.
       -> verifier.averify                # fuzzy text/field match -> vision
```

`app/llm/model_client.py` is the single place that talks to Groq/Azure —
every other module calls `achat_json` / `achat_vision_json` and doesn't
know or care which provider is behind it.

## Setup

1. `pip install -r requirements.txt`
2. Copy `.env.example` to `.env` and fill in your keys, deployment/model
   names, and `ANDROID_APP_PACKAGE` / `ANDROID_APP_ACTIVITY`.
3. Start Appium: `appium` (defaults to `http://127.0.0.1:4723`, matching
   `APPIUM_SERVER_URL`).
4. Connect a device or start an emulator.
5. `streamlit run streamlit_app.py`

## Using it

Type your steps in plain English, e.g.:

> Enter username 'john.doe' in the username field, enter password
> 'secret123' in the password field, tap Login, then verify the dashboard
> is shown.

Click **Plan & Run**. You'll first see the exact plan the agent extracted
(one line per atomic action) — review it before it executes. Then each
step runs, with a screenshot and pass/fail verification, and the run stops
automatically once the plan is complete.

### Supported actions (what the planner can produce)

| Action        | Needs target? | `value` holds                 |
|---------------|:--------------:|--------------------------------|
| `click`       | yes            | —                               |
| `type`        | yes            | text to type                    |
| `select`      | yes            | option text (dropdown/spinner)  |
| `toggle`      | yes            | — (checkbox/switch/radio)       |
| `scroll`      | no             | direction (up/down/left/right)  |
| `wait`        | no             | seconds                         |
| `press_back`  | no             | — (Android hardware Back)       |
| `close_app`   | no             | — (terminates the app)          |
| `verify`      | yes (as a description) | —                     |

## Config reference (`.env`)

See `.env.example` for the full list with defaults. Key ones:

- `LLM_PROVIDER` — `groq` or `azure`, drives both text and vision.
- `ANDROID_APP_PACKAGE` / `ANDROID_APP_ACTIVITY` — the app under test;
  launched automatically by Appium.
- `MAX_STEPS` — safety ceiling on how many steps a single plan may
  contain (not a retry loop — it caps plan length).
- `ENABLE_VISION_FALLBACK` — if `false`, resolution/verification never
  fall back to a screenshot-based vision call; a step that can't be
  resolved from the on-screen element list simply fails instead.
- `POPUP_DISMISS_ENABLED` — auto-dismiss common permission/consent
  dialogs before each step.

## Notes

- `.env` is intentionally **not** included in this delivery — keep using
  your existing one, just add/rename the variables shown in
  `.env.example` (mainly: replace `LLM_PROVIDER`/`VISION_LLM_PROVIDER` and
  any `DEEPSEEK_*` / `PLATFORM` / `TARGET_URL` vars with the new,
  simplified set above).
- `logs/screenshots/` is created automatically at startup for step
  screenshots.
