"""
Mock-driver validation for the two fixes in this update - no live device
needed, same pattern this project has already used for prior sessions'
changes (see area memory notes). Not part of the shipped app; just a
one-off sanity script.

Scenario 1: a header icon (like the SBI Card screen's headphone/support
icon) with NO text/content-desc/resource-id anywhere in itself or its
children - confirms it now gets a positional label instead of vanishing
from get_state() entirely.

Scenario 2: a scrollable list of "Apply Now" cards (ELITE / PULSE / AURUM,
matching the two attached screenshots) where every button shares the exact
same text - confirms _enrich_duplicate_context correctly tags each button
with its OWN card's title, and that the resolver's ambiguity check would
now defer a same-scoring duplicate pair to the LLM tier instead of
blind-accepting the first one found.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from app.automation import page_state as ps


class MockElement:
    def __init__(self, attrs: dict, children=None):
        self._attrs = attrs
        self._children = children or []

    def get_attribute(self, name):
        return self._attrs.get(name)

    def find_elements(self, by, xpath):
        # Extremely small stand-in: just returns children flagged as
        # matching (real XPath semantics aren't needed for this check).
        return self._children


class MockDriver:
    def __init__(self, all_elements, window_size=(1080, 2280)):
        self._all_elements = all_elements
        self._window_size = window_size

    def find_elements(self, by, xpath):
        # Simulate the two xpath filters used in page_state.py.
        if xpath == ps.ANDROID_INTERACTIVE_XPATH:
            interactive_classes = ("EditText", "Button", "Spinner", "CheckBox", "RadioButton", "Switch")
            return [e for e in self._all_elements if e._attrs.get("clickable") == "true"
                    or e._attrs.get("checkable") == "true"
                    or any(c in e._attrs.get("className", "") for c in interactive_classes)]
        if xpath == ps.ANDROID_TEXT_XPATH:
            return [e for e in self._all_elements
                    if e._attrs.get("text") or e._attrs.get("content-desc")]
        return []

    def get_window_size(self):
        return {"width": self._window_size[0], "height": self._window_size[1]}


def make_el(bounds, clickable="false", text="", desc="", rid="", cls="android.view.View", children=None):
    return MockElement({
        "text": text, "content-desc": desc, "resource-id": rid, "className": cls,
        "checkable": "false", "checked": "false", "clickable": clickable,
        "enabled": "true", "bounds": bounds,
    }, children=children)


def bounds_str(x1, y1, x2, y2):
    return f"[{x1},{y1}][{x2},{y2}]"


print("=== Scenario 1: unlabeled top-right header icon ===")
# A raw ImageView headphone icon: clickable, but genuinely no text/desc/
# resource-id anywhere on it or any child - the exact shape of the bug.
headphone_icon = make_el(bounds_str(985, 40, 1050, 100), clickable="true")
back_arrow = make_el(bounds_str(20, 40, 80, 100), clickable="true", desc="Back")
driver1 = MockDriver([headphone_icon, back_arrow])

state_text, ref_map, attrs_map = ps.get_state(driver1)
print(state_text)
assert len(ref_map) == 2, f"expected both elements to survive the scan, got {len(ref_map)}"
icon_ref = [r for r, a in attrs_map.items() if a["desc"].startswith("(icon button")][0]
print(f"-> headphone icon surfaced as {icon_ref}: {attrs_map[icon_ref]['desc']!r}")
assert "top-right" in attrs_map[icon_ref]["desc"], "expected a top-right positional label"
print("PASS: unlabeled icon now surfaces with a matchable positional label\n")


print("=== Scenario 2: three 'Apply Now' cards (ELITE / PULSE / AURUM) ===")
elite_title = make_el(bounds_str(600, 660, 1000, 700), text="SBI Card ELITE")
elite_btn = make_el(bounds_str(70, 1100, 1000, 1200), clickable="true", text="Apply Now", rid="com.sbi.lotusintouch:id/btnApplyNow")

pulse_title = make_el(bounds_str(600, 1450, 1000, 1490), text="SBI Card PULSE")
pulse_btn = make_el(bounds_str(70, 1900, 1000, 2000), clickable="true", text="Apply Now", rid="com.sbi.lotusintouch:id/btnApplyNow")

aurum_title = make_el(bounds_str(600, 2200, 1000, 2240), text="SBI Card AURUM")
aurum_btn = make_el(bounds_str(70, 2650, 1000, 2750), clickable="true", text="Apply Now", rid="com.sbi.lotusintouch:id/btnApplyNow")

all_els = [elite_title, elite_btn, pulse_title, pulse_btn, aurum_title, aurum_btn]
driver2 = MockDriver(all_els)

state_text2, ref_map2, attrs_map2 = ps.get_state(driver2)
print(state_text2)

# Find the three Apply Now button refs and check each got the RIGHT card's
# own context attached (not another card's, not the generic shared text).
btn_refs = [r for r, a in attrs_map2.items() if a["text"] == "Apply Now"]
assert len(btn_refs) == 3, f"expected 3 Apply Now buttons, found {len(btn_refs)}"
by_context = {r: attrs_map2[r].get("context", "") for r in btn_refs}
print("context per button:", by_context)

aurum_ref = [r for r, ctx in by_context.items() if "AURUM" in ctx][0]
elite_ref = [r for r, ctx in by_context.items() if "ELITE" in ctx][0]
pulse_ref = [r for r, ctx in by_context.items() if "PULSE" in ctx][0]
assert "AURUM" not in by_context[elite_ref] and "PULSE" not in by_context[elite_ref]
assert "ELITE" not in by_context[aurum_ref] and "PULSE" not in by_context[aurum_ref]
print("PASS: each Apply Now button correctly tagged with its OWN card's title only\n")

# Now confirm resolver.py's fuzzy tier picks the AURUM button (not the
# first/ELITE one) for a description naming AURUM, and that a genuinely
# ambiguous case (no qualifying detail at all) gets deferred to the LLM
# tier rather than blind-accepted.
from app.automation import resolver as res

scored = res._fuzzy_scores("Apply Now button for SBI Card AURUM", attrs_map2)
top_ref, top_score = scored[0]
print(f"fuzzy top pick for 'AURUM' query: {top_ref} (score={top_score}), "
      f"expected ref={aurum_ref}")
assert top_ref == aurum_ref, "fuzzy tier should now favour the AURUM card's own button"
assert not res._is_ambiguous(scored, attrs_map2), (
    "a clearly-qualified description (names AURUM specifically) should NOT "
    "be treated as ambiguous - context gave it a decisive margin"
)
print("PASS: fuzzy tier resolves directly to the correct card's button, "
      "confidently (no unnecessary LLM call needed)\n")

# And a generic, unqualified "Apply Now" query (no card named) SHOULD be
# flagged ambiguous, since nothing distinguishes the three at that point -
# this is the safety net for cases context enrichment alone can't resolve.
scored_generic = res._fuzzy_scores("Apply Now", attrs_map2)
assert res._is_ambiguous(scored_generic, attrs_map2), (
    "an unqualified 'Apply Now' query across 3 duplicate buttons should be "
    "flagged ambiguous and deferred to the LLM tier, not blind-accepted"
)
print("PASS: unqualified duplicate-label query correctly flagged ambiguous "
      "(safety net working)\n")

print("ALL SCENARIOS PASSED")

print("=== Regression checks (earlier fixes still intact) ===")

# 1. Blank EditText still gets its placeholder label.
blank_input = make_el(bounds_str(50, 500, 1000, 600), clickable="false", cls="android.widget.EditText")
blank_input._attrs["checkable"] = "false"
driver3 = MockDriver([blank_input])
_, ref_map3, attrs_map3 = ps.get_state(driver3)
assert len(ref_map3) == 1
assert attrs_map3["E0"]["desc"] == "(empty input field)"
print("PASS: blank EditText placeholder still works")

# 2. A clickable row whose ONLY child has real TEXT (country-picker style)
# still borrows the child's text, even though the xpath now also matches
# resource-id-only nodes - text/desc must still win over a resource-id
# fallback when both are available among descendants.
country_text_child = make_el(bounds_str(150, 800, 900, 860), text="Canada")
country_row = make_el(bounds_str(50, 780, 1000, 880), clickable="true", children=[country_text_child])
driver4 = MockDriver([country_row])
_, ref_map4, attrs_map4 = ps.get_state(driver4)
assert attrs_map4["E0"]["desc"] == "Canada", attrs_map4["E0"]
print("PASS: clickable row still borrows a child's real TEXT correctly")

# 3. A clickable row whose only child has a resource-id but NO text/desc -
# new capability: falls back to that resource-id.
icon_child = make_el(bounds_str(150, 800, 220, 860), rid="com.sbi.lotusintouch:id/ivSupport")
icon_row = make_el(bounds_str(50, 780, 260, 880), clickable="true", children=[icon_child])
driver5 = MockDriver([icon_row])
_, ref_map5, attrs_map5 = ps.get_state(driver5)
assert attrs_map5["E0"]["desc"] == "ivSupport", attrs_map5["E0"]
print("PASS: clickable row with only a resource-id'd child now surfaces via that id")

# 4. A single (non-duplicate) button should NOT get a ctx= tag - enrichment
# must stay a no-op on ordinary screens.
lone_btn = make_el(bounds_str(70, 1100, 1000, 1200), clickable="true", text="Continue")
driver6 = MockDriver([lone_btn])
state6, _, attrs_map6 = ps.get_state(driver6)
assert "context" not in attrs_map6["E0"]
assert "ctx=" not in state6
print("PASS: non-duplicate elements are untouched by context enrichment")

print("\nALL REGRESSION CHECKS PASSED")
