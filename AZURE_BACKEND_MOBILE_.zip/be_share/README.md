# AI UI Automation (Android)

Give the agent one plain-English goal ("log in and add the first item to
cart") and it plans, locates elements, acts, and verifies each step by
itself — using a hybrid of real UI locators + a screenshot/vision fallback,
and fuzzy text matching + LLM judgment for verification. Drives a real
Android device or emulator via Appium — no desktop browser involved.

## What changed in this version — the step builder is now actually wired up

`step_runner.py` (the step-builder backend described below) previously
existed but was never imported anywhere, and the old prototype UI only
ever called the older free-text single-goal loop directly. On top of
that, `step_runner.py` called executor function names (`ex.click`,
`ex.launch_app`, `ex.type_text`, ...) that `action_executor.py` never
defined — it only had the older `execute_click`/etc names — so every
dispatched step-builder action would have thrown `AttributeError` even
once wired up, and the import itself was broken (`agent.py` had no
`run_plan_loop`, which `step_runner.py` imports).

All of that's fixed now: `server.py` exposes the step builder over
HTTP/WebSocket for the Next.js frontend, `action_executor.py` implements
the full action vocabulary end-to-end for Android (including fixing a
dead `driver.swipe(...)` call — that method was removed from the Appium
Python client years ago), and `agent.py` exposes `run_plan_loop` for AI
Action steps to share.

This also fixes the main practical problem it was causing: there was no
reliable, explicit way to launch a specific app. Session-start capabilities
(`appPackage`/`appActivity`) are only a single best-effort launch attempt
with no verification — if that didn't stick, the agent was left on
whatever screen happened to be showing (often the home screen) with no
error raised, and had to *guess* its way to opening the app via clicks,
which is what could look like it "trying to find the app on the Play
Store." `driver_manager.py` now verifies the launch (polls
`current_package`, retries `activate_app`, raises a clear error instead of
silently continuing), and there's an explicit **Launch App** step you can
add from the UI that uses the same verified logic any time mid-flow — see
"Launching the app reliably" below.

Verification also got a deterministic fast path: `type`/`select` actions
now compare the field's actual value directly against what was
typed/selected (exact match, no LLM call) instead of fuzzy-matching a whole
natural-language "expected result" sentence against page text — which was
landing plenty of straightforward field checks in a fuzzy grey zone and
triggering an unnecessary, much slower vision call for something answerable
with certainty in milliseconds.

Finally, the Appium server no longer needs its own terminal —
`driver_manager.py` starts one itself if none is already running (see
"Starting the Appium server" below).

## Step builder

The single free-text prompt has been replaced with a **step builder**: you
pick an explicit action first (from the full taxonomy below), describe its
target in plain English, and add it to a visible flow. When you don't know
which action fits, or the step needs some judgment, use **AI Action** and
just describe the intent — the AI decides what to do, bounded to a few
sub-steps, sharing the same app session as the rest of your flow.

This matters because it splits responsibility cleanly: **you** decide *what*
should happen and in *what order* (deterministic, no ambiguity); the **AI**
only has to figure out *which element* matches your description — a much
narrower, more reliable job than deciding the whole plan itself.

### The action taxonomy

```
Navigation        back
Find / Locate     find, find_text, find_by_role, find_by_label, locate
Interaction       click, double_click, tap, long_press, type, clear, select, drag
Scroll / Gesture  scroll (up/down/left/right, slow/normal/fast), scroll_to,
                  swipe (direction + count), pinch, zoom
Keyboard          key_press
Extraction        get_text, get_value, get_attribute, get_url (current app
                  package), screenshot
Wait              wait, wait_for, wait_for_text, wait_for_navigation
Verification      assert_visible, assert_text, assert_value
Mobile / Device   launch_app, close_app, press_back, press_home,
                  set_orientation, device_action (AI)
```

### How target resolution works (3 tiers, cheapest first)

For any action with a target ("the login button", "the email field"):
1. **Fuzzy + semantic text match** against the on-screen element list — free/instant fuzzy matching, plus (if `AZURE_OPENAI_EMBEDDING_DEPLOYMENT` is configured) a meaning-aware embedding match layered on top, so "Open" and "Launch" resolve as the same intent even with no literal text overlap.
2. If ambiguous, **one LLM call** to pick the best match from the list — still text-only, no screenshot.
3. **Vision fallback** (screenshot + coordinates) — only if both above fail, and only if `ENABLE_VISION_FALLBACK=true`.

### How "AI Action" steps work

An AI Action step runs the same Plan → Locate → Act → Verify loop as
before, but capped at 6 sub-steps and using the *same app session* as
the rest of your flow (it doesn't restart the app or lose state). Good
for anything with some judgment involved — "log in with these credentials,"
"dismiss any leftover onboarding screens," etc.

### What's implemented vs. limited

- `pinch`/`zoom` — a real two-finger gesture via Appium's `mobile: pinchOpenGesture`/`pinchCloseGesture`.
- `select` — there's no native HTML `<select>` on Android, so this always opens whatever the target turns out to be (a native picker, a Material dropdown, ...) and searches the resulting screen for the option text — works uniformly across picker styles.
- `find`/`find_text`/`find_by_role`/`find_by_label`/`locate` — currently all resolve the same way (via the target description); they don't yet differentiate strategy (role vs. label vs. text) internally.
- `get_url` returns the current foreground app's **package name** (there's no browser URL on a native app) — useful for asserting you've navigated into a different app, or are still inside the one under test.

## What changed in earlier versions

- **The agent now reasons from accessibility-tree metadata, not just element
  text.** Every element the planner sees includes its label, hint,
  input type, current value, dropdown options, and checkbox/radio state -
  enough to decide what to type/select without ever looking at a
  screenshot.
- **Full action vocabulary**: `click`, `type`, `select` (dropdown), `toggle`
  (checkbox/radio), `submit`, `scroll` (up/down/left/right), `back`,
  `verify`, `wait`, `finish`, `fail`.
- **Verification now reads actual field values from the accessibility
  tree**, not just visible screen text. This matters: a typed value in a
  field never shows up in a screen's rendered text, and a password field
  is masked even if it did - so "does the password field contain X" was
  previously unanswerable from text alone. Now it's read directly with
  certainty, which removes most of the remaining reliance on vision.
- **The planner is told to scroll before falling back to vision** - on
  native mobile apps, only on-screen elements are visible to it, so
  scrolling often surfaces the element it needs without ever taking a
  screenshot.
- Accessibility-tree/text is trusted first, always. Vision (screenshot → LLM)
  only fires when a ref lookup fails, or a fuzzy/semantic-match score lands
  in a genuine grey zone — and you can kill it entirely with
  `ENABLE_VISION_FALLBACK=false` for max speed/min cost.
- **Runs exactly once.** The planner's prompt checks action history and
  calls `finish` the moment the goal is satisfied, plus a hard repetition
  guard force-stops the run if the same action is proposed twice in a row.
- **Popups are dismissed automatically**, before every single step.
- **Async end-to-end.** LLM calls use async clients; blocking Appium driver
  calls run on a background thread so the event loop never stalls.
- **Azure OpenAI only** — one deployment (gpt-4.1-mini) for both text/planning
  and vision calls, and a separate text-embedding-ada-002 deployment for
  semantic candidate matching (see resolver.py/semantic_matcher.py).
- **Android/Appium only** — no desktop browser mode. (Selenium is still a
  dependency because Appium's own Python client is built on top of it, but
  nothing here drives a desktop Chrome session anymore.)

## How it works (architecture)

```
server.py                   <- FastAPI layer: HTTP/WebSocket API for the Next.js frontend
config.py                   <- Settings class, reads everything from .env

app/
  llm/model_client.py        <- Azure OpenAI client (chat, vision, embeddings)
  automation/
    driver_manager.py         <- starts the Appium driver session
    page_state.py              <- condenses the accessibility tree into a short element list
    action_schema.py            <- the action taxonomy: fields, categories, needs_target
    resolver.py                  <- 3-tier target resolution: fuzzy+semantic -> LLM pick -> vision
    action_executor.py            <- implements every action (click, type, scroll, ...)
    wait_helpers.py                 <- wait/wait_for/wait_for_text/wait_for_navigation
    verifier.py                      <- hybrid: field values + text, else vision
    popup_handler.py                  <- auto-dismisses popups/permission dialogs
    planner.py                         <- AI Action steps only: "what's the ONE next action?"
    agent.py                            <- AI Action steps only: bounded plan/act/verify loop
    step_runner.py                       <- runs the whole authored flow, one driver session
  utils/screenshot.py         <- screenshot save/base64 helpers
```

`step_runner.run_flow(steps)` is the entry point: it starts one driver,
walks your step list in order, dispatches explicit actions directly via
`action_executor` (after resolving the target through `resolver`'s 3-tier
lookup), and for `ai_action` steps calls into `agent.run_plan_loop` — the
same driver session, just handing control to the AI for a few sub-steps.

## 1. Install

```bash
cd mobile-ai-automation
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

You'll also need Node.js + Appium set up for your Android device/emulator —
see step 4 below.

## 2. Configure

```bash
cp .env.example .env
```

### Configuring Azure OpenAI

This project uses **Azure OpenAI only** — one deployment for text/planning
+ vision calls, and one embedding deployment for semantic candidate
matching. Fill in these fields in `.env`:

- `AZURE_OPENAI_API_KEY`, `AZURE_OPENAI_ENDPOINT`, `AZURE_OPENAI_API_VERSION`
  — your Azure OpenAI resource's credentials.
- `AZURE_OPENAI_DEPLOYMENT` — your **deployment name** from Azure AI/OpenAI
  Studio (not the model name) for a **gpt-4.1-mini** deployment. Used for
  every text/planning call.
- `AZURE_OPENAI_VISION_DEPLOYMENT` — optional. gpt-4.1-mini is natively
  multimodal, so leave this blank to reuse `AZURE_OPENAI_DEPLOYMENT` for
  vision calls too (the locator fallback + ambiguous verification). Only
  set this if your vision-capable deployment has a different name.
- `AZURE_OPENAI_EMBEDDING_DEPLOYMENT` — your deployment name for a
  **text-embedding-ada-002** deployment. Powers tier-1 semantic candidate
  matching in `resolver.py`/`semantic_matcher.py` (meaning-aware matching
  on top of plain fuzzy text matching — e.g. recognizing "Open" and
  "Launch" as the same intent). Optional in the sense that resolution
  degrades gracefully to fuzzy-only matching if this is left blank or a
  call fails — but leaving it filled in is recommended for better accuracy.

## 3. Connect an Android device or emulator

1. Phone: Settings → About Phone → tap "Build Number" 7 times → enables
   Developer Options.
2. Settings → Developer Options → turn on **USB Debugging**.
3. Plug the phone in via USB, accept the "Trust this computer?" popup.
4. Install **Android Platform Tools** (gives you `adb`) and run
   `adb devices` — confirm it shows as `device`, not `unauthorized`.
5. Install Node.js, then:
   ```bash
   npm install -g appium
   appium driver install uiautomator2
   ```

### Starting the Appium server — you don't need a second terminal
Running the API server (see "Run" below) is the only command you run.
`driver_manager.py` checks whether a server is already reachable at
`APPIUM_SERVER_URL`; if not, it starts one itself as a subprocess (via
Appium's own `AppiumService`) and stops it again when the run finishes.
You still need Node.js + `npm install -g appium` +
`appium driver install uiautomator2` done once (above) — this only
automates *starting* the server, not installing it.

If you'd rather manage the server yourself (e.g. shared across multiple
runs, or in CI), just run `appium` in your own terminal as before — it'll
be detected as already running and reused as-is. Set
`AUTO_START_APPIUM_SERVER=false` if you want a clear error instead of an
auto-started server when none is running.

### Pick a first test target
A good option to validate everything end-to-end before pointing this at
your own app — **the Calculator app** (simplest, no APK needed, every phone
has one):
```env
ANDROID_APP_PACKAGE=com.google.android.calculator
ANDROID_APP_ACTIVITY=com.android.calculator2.Calculator
```
(If that activity doesn't launch, find the real package/activity with the
app open on the phone: `adb shell dumpsys window | grep mCurrentFocus`.)
Add a **Launch App** step (see below), then try the goal: *"Compute 7 plus
5 and verify the result shows 12."*

**Your own app.** Set `ANDROID_APP_PACKAGE` and `ANDROID_APP_ACTIVITY` to
your app's real values (same `adb shell dumpsys window | grep
mCurrentFocus` trick works with your app open).

## 4. Run

```bash
uvicorn server:app --reload --host 0.0.0.0 --port 8000
```

This is a backend API only — build a flow from the step builder (or try
an AI Action step) in the Next.js frontend (`fe_share`), pointed at this
server's URL. Watch the step-by-step log: each step shows what was
resolved/dispatched, whether verification passed (and by which method —
field value, fuzzy match, or vision), and a screenshot.

### Launching the app reliably
Session-start capabilities (`appPackage`/`appActivity`) auto-launch the app
when the driver session starts, but that's only a single best-effort
attempt — if it doesn't stick (wrong activity, slow cold start, app closing
itself — see below), the session was previously left on whatever screen
happened to be showing, with no error raised, and the agent then had to
*guess* its way to opening the app from there (which is what showed up as
it "trying to find the app on the Play Store/home screen" instead of
actually being inside it).

Two things now cover this:
- `driver_manager.py` verifies the launch after session start — it polls
  `current_package` and explicitly re-activates the app on each retry for
  up to `ANDROID_LAUNCH_VERIFY_TIMEOUT` seconds, raising a clear error
  instead of silently continuing if it never gets there.
- You can also add an explicit **Launch App** step from the step builder
  (pre-filled with `ANDROID_APP_PACKAGE`) — the same verified
  activate-and-retry logic, callable any time mid-flow, not just at
  session start. This is the reliable alternative to relying on the AI to
  click its way to opening the app.

**If launch still won't stick even with retries**, and the package/activity
are definitely correct: many banking/finance apps deliberately detect
automation/root/tamper signals (Appium instrumentation, USB debugging, an
unlocked bootloader) and force-close themselves back to the home screen as
a security measure. No code-level fix can override that — it's the app
behaving as designed. If you have a staging/QA build without that check,
test against that instead.

### Android-specific notes
- `ANDROID_AUTO_GRANT_PERMISSIONS=true` (default) pre-grants runtime
  permissions (camera, location, notifications) at session start, so those
  system dialogs mostly never appear.
- The popup handler additionally tries `mobile: acceptAlert` each pass as a
  catch-all for anything that slips through.
- `page_state.py`'s Android XPath (`clickable='true' or long-clickable='true'
  or class contains EditText/Button`) is a reasonable default but some apps
  use custom views that won't match — widen it if the agent can't see an
  element it should.

## Notes / known limitations (read before you rely on this)

- This is a working starting point, not a hardened production framework.
- The vision-fallback coordinate detection is inherently approximate —
  expect it to need retries on visually cluttered screens. Turn it off
  entirely (`ENABLE_VISION_FALLBACK=false`) if your target is well-structured
  and you'd rather it fail loudly than guess coordinates.
- `page_state.py`'s XPath selectors are a reasonable default but you may
  need to widen/narrow them for a specific app.
- The popup dismisser is a fixed English label list (`accept`, `allow`,
  `close`, `got it`, etc. — see `popup_handler.py`). Extend `DISMISS_LABELS`
  for other languages or app-specific button text.
- The repetition guard stops the run if the same action is proposed twice in
  a row — this is deliberately conservative (better to stop early than loop
  forever), but a legitimate task that requires the identical action twice
  back-to-back (rare) would need the guard loosened in `agent.py`.
- There's no retry/backoff logic yet if the LLM API call itself fails —
  add that before running long unattended sessions.
- Cost control: each step makes 1 planning call, and only sometimes a
  vision call. Keep `MAX_STEPS` sane while you're testing.
