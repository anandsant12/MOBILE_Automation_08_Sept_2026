"""
Engine + session factory. Moving from SQLite to Postgres later means
changing DATABASE_URL (one line) - nothing in models.py or
execution/manager.py needs to change, that's the actual point of going
through SQLAlchemy instead of raw sqlite3.
"""

from pathlib import Path
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, Session

from config import settings
from app.db.models import Base

DB_PATH = Path(settings.base_dir) / "orbit.db"
DATABASE_URL = f"sqlite:///{DB_PATH}"

# check_same_thread=False: the execution manager's background asyncio
# tasks and FastAPI's request handlers both touch the DB from what SQLite
# sees as different threads (asyncio.to_thread offloads, uvicorn's worker
# thread pool, etc.) - safe here because every actual call site opens and
# closes its own short-lived session rather than sharing one across
# threads/tasks.
engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(bind=engine, expire_on_commit=False)


def init_db():
    Base.metadata.create_all(bind=engine)
    # create_all doesn't add columns to an existing table; add ones introduced later.
    with engine.begin() as conn:
        cols = {r[1] for r in conn.exec_driver_sql("PRAGMA table_info(step_executions)")}
        if "resolution_extra_json" not in cols:
            conn.exec_driver_sql("ALTER TABLE step_executions ADD COLUMN resolution_extra_json TEXT")


def get_session() -> Session:
    return SessionLocal()
