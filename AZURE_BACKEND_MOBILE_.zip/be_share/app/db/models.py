"""
SQLite (via SQLAlchemy) persistence for executions - the piece the
websocket-only /ws/run never had: a run survives a page refresh, "Stop"
actually reaches the backend, and Reports/Runs have real data instead of
placeholder dashes.

Deliberately SQLite for now, not Postgres - per the "develop on your PC,
move to the SBI system later" requirement, SQLite needs no separate server
to run locally. SQLAlchemy is the actual abstraction that matters here:
moving to Postgres later is a connection-string change in session.py, not
a rewrite of this file or of execution/manager.py.
"""

from datetime import datetime, timezone
from typing import Optional

from sqlalchemy import String, Integer, Float, Boolean, DateTime, Text, ForeignKey
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship


class Base(DeclarativeBase):
    pass


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


class Execution(Base):
    __tablename__ = "executions"

    id: Mapped[str] = mapped_column(String, primary_key=True)  # e.g. "EX-000001"
    flow_name: Mapped[Optional[str]] = mapped_column(String, nullable=True, index=True)
    status: Mapped[str] = mapped_column(String, default="running")  # running|passed|failed|cancelled|error
    total_steps: Mapped[int] = mapped_column(Integer, default=0)
    passed_steps: Mapped[int] = mapped_column(Integer, default=0)
    failed_steps: Mapped[int] = mapped_column(Integer, default=0)
    started_at: Mapped[datetime] = mapped_column(DateTime, default=_utcnow)
    ended_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)

    steps: Mapped[list["StepExecution"]] = relationship(
        back_populates="execution", cascade="all, delete-orphan", order_by="StepExecution.step_index"
    )

    def to_summary_dict(self) -> dict:
        """Lightweight shape for list views (Reports/Runs tables) - no
        per-step detail, which would be wasteful to load for every row of
        a history list."""
        return {
            "id": self.id,
            "flow_name": self.flow_name,
            "status": self.status,
            "total_steps": self.total_steps,
            "passed_steps": self.passed_steps,
            "failed_steps": self.failed_steps,
            "started_at": self.started_at.isoformat() if self.started_at else None,
            "ended_at": self.ended_at.isoformat() if self.ended_at else None,
            "duration_seconds": (
                (self.ended_at - self.started_at).total_seconds()
                if self.started_at and self.ended_at else None
            ),
        }

    def to_full_dict(self) -> dict:
        """Full shape - summary plus every step's result, for a single
        execution's detail view / report."""
        d = self.to_summary_dict()
        d["steps"] = [s.to_dict() for s in self.steps]
        return d


class StepExecution(Base):
    __tablename__ = "step_executions"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    execution_id: Mapped[str] = mapped_column(ForeignKey("executions.id"), index=True)
    step_index: Mapped[int] = mapped_column(Integer)
    action_json: Mapped[str] = mapped_column(Text)          # JSON-encoded action dict, as already shown in the run log
    status: Mapped[str] = mapped_column(String)              # ok|finished|failed|error
    resolution_tier: Mapped[Optional[str]] = mapped_column(String, nullable=True)
    resolution_score: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    matched_text: Mapped[Optional[str]] = mapped_column(String, nullable=True)
    # method + per-signal timings/scores (fuzzy_ms, semantic_ms, llm_ms, ...) - see resolver.py
    resolution_extra_json: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    verification_passed: Mapped[Optional[bool]] = mapped_column(Boolean, nullable=True)
    verification_method: Mapped[Optional[str]] = mapped_column(String, nullable=True)
    verification_reasoning: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    error: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    healed: Mapped[bool] = mapped_column(Boolean, default=False)  # locator was self-healed this run - see step_runner.py
    extracted_json: Mapped[Optional[str]] = mapped_column(Text, nullable=True)  # JSON-encoded, since extracted can be any type
    # Stored inline as a data-URL string (same shape the live run already
    # streams to the frontend) rather than a separate file + path column -
    # simplest thing that works for SQLite/local dev; revisit if execution
    # volume ever makes DB size from embedded screenshots a real problem.
    screenshot: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    timestamp: Mapped[datetime] = mapped_column(DateTime, default=_utcnow)

    execution: Mapped["Execution"] = relationship(back_populates="steps")

    def to_dict(self) -> dict:
        import json
        return {
            "step": self.step_index,
            "action": json.loads(self.action_json) if self.action_json else {},
            "status": self.status,
            "resolution": (
                {"tier": self.resolution_tier, "score": self.resolution_score, "matched_text": self.matched_text,
                 **(json.loads(self.resolution_extra_json) if self.resolution_extra_json else {})}
                if self.resolution_tier else None
            ),
            "verification": (
                {"passed": self.verification_passed, "method": self.verification_method, "reasoning": self.verification_reasoning}
                if self.verification_method else None
            ),
            "error": self.error,
            "healed": self.healed,
            "extracted": json.loads(self.extracted_json) if self.extracted_json else None,
            "screenshot": self.screenshot,
        }


class ApplicationState(Base):
    """A normalized, observed UI state.  Screenshots are deliberately not
    part of its identity: the accessibility/DOM state is what makes a route
    reusable across runs and devices."""
    __tablename__ = "application_states"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    platform: Mapped[str] = mapped_column(String, index=True)
    context: Mapped[str] = mapped_column(String, index=True)  # Android package/activity or web URL
    fingerprint: Mapped[str] = mapped_column(String, unique=True, index=True)
    state_json: Mapped[str] = mapped_column(Text)
    first_seen_at: Mapped[datetime] = mapped_column(DateTime, default=_utcnow)
    last_seen_at: Mapped[datetime] = mapped_column(DateTime, default=_utcnow)

    def to_dict(self) -> dict:
        import json
        return {
            "id": self.id,
            "platform": self.platform,
            "context": self.context,
            "fingerprint": self.fingerprint,
            "state": json.loads(self.state_json),
            "first_seen_at": self.first_seen_at.isoformat() if self.first_seen_at else None,
            "last_seen_at": self.last_seen_at.isoformat() if self.last_seen_at else None,
        }


class StateTransition(Base):
    """One approved edge learned from a successful explicit flow step."""
    __tablename__ = "state_transitions"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    from_state_id: Mapped[int] = mapped_column(ForeignKey("application_states.id"), index=True)
    to_state_id: Mapped[int] = mapped_column(ForeignKey("application_states.id"), index=True)
    action_key: Mapped[str] = mapped_column(String, index=True)
    target_description: Mapped[Optional[str]] = mapped_column(String, nullable=True, index=True)
    execution_step_json: Mapped[str] = mapped_column(Text)
    flow_name: Mapped[Optional[str]] = mapped_column(String, nullable=True, index=True)
    success_count: Mapped[int] = mapped_column(Integer, default=1)
    last_succeeded_at: Mapped[datetime] = mapped_column(DateTime, default=_utcnow)

    from_state: Mapped["ApplicationState"] = relationship(foreign_keys=[from_state_id])
    to_state: Mapped["ApplicationState"] = relationship(foreign_keys=[to_state_id])

    def to_dict(self) -> dict:
        import json
        return {
            "id": self.id,
            "from_state_id": self.from_state_id,
            "to_state_id": self.to_state_id,
            "action": json.loads(self.execution_step_json),
            "flow_name": self.flow_name,
            "success_count": self.success_count,
            "last_succeeded_at": self.last_succeeded_at.isoformat() if self.last_succeeded_at else None,
        }
