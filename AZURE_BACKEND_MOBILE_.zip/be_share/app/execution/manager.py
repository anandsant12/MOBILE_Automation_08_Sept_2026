"""
Decouples "run a flow" from "a websocket happens to be open" - the gap the
review flagged: closing /ws/run's socket only stopped the frontend from
hearing about progress, it never stopped the backend's automation loop,
which kept executing real device actions regardless.

Now: POST /api/executions starts a tracked, cancellable execution and
returns an ID immediately. The frontend can disconnect and reconnect
(WS /ws/executions/{id}) without affecting the run itself, and
POST /api/executions/{id}/cancel reaches the actual asyncio Task and stops
it between steps - not just closes a connection while the device keeps
going unsupervised.
"""

import asyncio
import json
import uuid
from typing import Optional

from app.automation.step_runner import run_flow
from app.db.models import Execution, StepExecution
from app.db.session import get_session

# execution_id -> running asyncio.Task, so cancel_execution can find and
# cancel the right one. In-memory only - if the process restarts, any
# execution that was "running" is orphaned; get_execution() below treats
# a running execution found stale at startup by marking it interrupted
# (see reconcile_stale_executions).
_tasks: dict[str, asyncio.Task] = {}

# execution_id -> list of subscriber queues, for live observers (the
# WS /ws/executions/{id} endpoint). A headless caller (Run All, a table
# row's quick-run) never subscribes - it just awaits the task or polls
# get_execution() - so this stays empty for those, no wasted work.
_subscribers: dict[str, list[asyncio.Queue]] = {}


def _new_execution_id() -> str:
    return f"EX-{uuid.uuid4().hex[:8]}"


def _publish(execution_id: str, message: dict):
    for q in _subscribers.get(execution_id, []):
        q.put_nowait(message)


def subscribe(execution_id: str) -> asyncio.Queue:
    q: asyncio.Queue = asyncio.Queue()
    _subscribers.setdefault(execution_id, []).append(q)
    return q


def unsubscribe(execution_id: str, q: asyncio.Queue):
    subs = _subscribers.get(execution_id)
    if subs and q in subs:
        subs.remove(q)
        if not subs:
            _subscribers.pop(execution_id, None)


async def start_execution(steps: list, flow_name: Optional[str] = None) -> str:
    execution_id = _new_execution_id()

    session = get_session()
    try:
        session.add(Execution(id=execution_id, flow_name=flow_name, status="running", total_steps=len(steps)))
        session.commit()
    finally:
        session.close()

    task = asyncio.create_task(_run(execution_id, steps, flow_name))
    _tasks[execution_id] = task
    return execution_id


async def _run(execution_id: str, steps: list, flow_name: Optional[str]):
    passed = 0
    failed = 0
    final_status = "passed"
    try:
        async for log in run_flow(steps, flow_name=flow_name):
            _write_step(execution_id, log)
            if log["status"] in ("ok", "finished"):
                passed += 1
            elif log["status"] in ("failed", "error"):
                failed += 1
            _publish(execution_id, log)
        final_status = "failed" if failed > 0 else "passed"
    except asyncio.CancelledError:
        final_status = "cancelled"
        raise
    except Exception as e:
        final_status = "error"
        _publish(execution_id, {"status": "error", "error": str(e)})
    finally:
        _finish(execution_id, final_status, passed, failed)
        _publish(execution_id, {"status": "done"})
        _tasks.pop(execution_id, None)


def _write_step(execution_id: str, log: dict):
    session = get_session()
    try:
        resolution = log.get("resolution") or {}
        verification = log.get("verification") or {}
        session.add(StepExecution(
            execution_id=execution_id,
            step_index=log.get("step") if isinstance(log.get("step"), int) else 0,
            action_json=json.dumps(log.get("action") or {}),
            status=log.get("status", "ok"),
            resolution_tier=resolution.get("tier"),
            resolution_score=resolution.get("score"),
            matched_text=resolution.get("matched_text"),
            resolution_extra_json=json.dumps({
                k: resolution[k] for k in ("method", "fuzzy_ms", "semantic_ms", "fuzzy_score", "semantic_score", "llm_ms", "locator_used", "resolve_ms", "scroll_ms", "auto_scrolled_swipes")
                if resolution.get(k) is not None
            }) or None,
            verification_passed=verification.get("passed"),
            verification_method=verification.get("method"),
            verification_reasoning=verification.get("reasoning"),
            error=log.get("error"),
            healed=bool(log.get("healed", False)),
            extracted_json=json.dumps(log["extracted"]) if log.get("extracted") is not None else None,
            screenshot=log.get("screenshot"),
        ))
        session.commit()
    finally:
        session.close()


def _finish(execution_id: str, status: str, passed: int, failed: int):
    from datetime import datetime, timezone
    session = get_session()
    try:
        execution = session.get(Execution, execution_id)
        if execution:
            execution.status = status
            execution.passed_steps = passed
            execution.failed_steps = failed
            execution.ended_at = datetime.now(timezone.utc)
            session.commit()
    finally:
        session.close()


def cancel_execution(execution_id: str) -> bool:
    task = _tasks.get(execution_id)
    if task is None or task.done():
        return False
    task.cancel()
    return True


def get_execution(execution_id: str) -> Optional[dict]:
    session = get_session()
    try:
        execution = session.get(Execution, execution_id)
        return execution.to_full_dict() if execution else None
    finally:
        session.close()


def list_executions(flow_name: Optional[str] = None, limit: int = 50) -> list[dict]:
    session = get_session()
    try:
        query = session.query(Execution).order_by(Execution.started_at.desc())
        if flow_name:
            query = query.filter(Execution.flow_name == flow_name)
        return [e.to_summary_dict() for e in query.limit(limit).all()]
    finally:
        session.close()


def reconcile_stale_executions():
    """Call once at startup: any execution still marked "running" from a
    previous process (crashed, or the server was just restarted) can never
    actually finish - its asyncio Task doesn't exist in this process. Mark
    it interrupted rather than leaving it stuck showing "running" forever."""
    from datetime import datetime, timezone
    session = get_session()
    try:
        stale = session.query(Execution).filter(Execution.status == "running").all()
        for execution in stale:
            execution.status = "interrupted"
            execution.ended_at = datetime.now(timezone.utc)
        if stale:
            session.commit()
    finally:
        session.close()


def get_report_summary(limit_executions: int = 200) -> dict:
    """Aggregated numbers for the Reports screen, computed here (not by the
    frontend fetching raw rows and reducing them client-side) so this stays
    a single small query instead of shipping potentially hundreds of full
    execution+step rows over the wire just to count a few things.

    flaky = a flow_name with at least one PASSED and at least one FAILED
    execution within the window - the same test genuinely behaving
    differently across runs is what "flaky" means, not just "has ever
    failed once".
    """
    from app.db.models import StepExecution

    session = get_session()
    try:
        recent = (
            session.query(Execution)
            .filter(Execution.status.in_(["passed", "failed"]))
            .order_by(Execution.started_at.desc())
            .limit(limit_executions)
            .all()
        )
        total_runs = len(recent)
        passed_runs = sum(1 for e in recent if e.status == "passed")
        pass_rate = round(100 * passed_runs / total_runs, 1) if total_runs else None

        outcomes_by_flow: dict[str, set[str]] = {}
        for e in recent:
            if not e.flow_name:
                continue
            outcomes_by_flow.setdefault(e.flow_name, set()).add(e.status)
        flaky_count = sum(1 for outcomes in outcomes_by_flow.values() if {"passed", "failed"} <= outcomes)

        execution_ids = [e.id for e in recent]
        healed_count = (
            session.query(StepExecution)
            .filter(StepExecution.execution_id.in_(execution_ids), StepExecution.healed.is_(True))
            .count()
            if execution_ids else 0
        )

        return {
            "total_runs": total_runs,
            "pass_rate": pass_rate,
            "flaky_tests": flaky_count,
            "ai_healed": healed_count,
        }
    finally:
        session.close()
