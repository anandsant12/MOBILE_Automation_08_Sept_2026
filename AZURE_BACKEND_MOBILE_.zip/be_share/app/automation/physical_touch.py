"""
Captures REAL physical touches on the connected Android device's own
touchscreen - raw evdev events read via `adb shell getevent` - as an
alternative input source for recording, alongside (not replacing) the
existing click-the-mirror flow in recorder.py/server.py.

Why raw evdev instead of anything higher-level: confirmed empirically
(see abc dev notes) that `adb shell input tap` - and therefore Appium's
own touch-action injection, which goes through the same framework path -
never appears on the touchscreen's own event device at all. Only a
genuine finger touch does. That is exactly the property this feature
needs: the listener can run at the same time automation itself is
clicking things (replay, self-healing, a live driver session) without
ever mistaking a programmatic tap for a physical one - no special-casing
required to tell them apart.

Pipeline:
  adb shell getevent -lt          (background subprocess, line-buffered)
    -> parse raw ABS_MT_POSITION_X/Y + BTN_TOUCH + ABS_MT_TRACKING_ID
       lines for the ONE touchscreen device node (auto-detected via
       find_touchscreen_device() - never hardcoded, since the node
       number differs per phone model/kernel)
    -> buffer points between finger-down and finger-up
    -> classify the completed gesture as tap / long_press / swipe from
       duration + total on-screen displacement
    -> pushed onto a plain thread-safe queue.Queue as a PhysicalGesture,
       in SCREEN pixel space (already scaled from the panel's raw sensor
       range) - nothing else

Deliberately stops there. No Appium/element lookups and no LLM calls
happen on this thread - those need the shared recording driver and an
event loop, both of which belong to the FastAPI/async side. server.py
drains this queue on each poll of /api/recording/physical_events and
hands each gesture to recorder.describe_physical_gesture(), which reuses
the exact same element-lookup/classification path record_tap already
uses (_inspect_tap) - just without performing the action again, since it
already happened for real on the device.

Scope, v1: single-finger gestures only. A second simultaneous touch
(pinch/zoom, multi-finger gestures) is detected and the whole gesture is
dropped rather than merged into the first slot's data - safer to miss an
occasional pinch than to record a corrupted single-point path stitched
from two fingers' interleaved coordinates. Android only (getevent/adb are
Android-specific); on other platforms find_touchscreen_device() simply
isn't called.
"""

import re
import subprocess
import threading
import time
import queue
from dataclasses import dataclass
from typing import Optional

_TAP_MAX_DISPLACEMENT_PX = 24      # screen px - below this it's a tap/long-press, not a swipe
_LONG_PRESS_MIN_DURATION_S = 0.45

# Some touch controllers report a finger LIFT as two rapid, nearly-
# identical down/up cycles (a release "bounce") rather than one clean
# cycle - confirmed on real hardware during development: most taps
# produced a single cycle, but occasionally two arrived a few hundred ms
# apart at essentially the same point. A second gesture finalizing this
# close in time AND this close in position to the previous one is almost
# certainly that bounce, not a deliberate second tap - it's dropped
# rather than queued as its own step.
_DEBOUNCE_WINDOW_S = 0.4
_DEBOUNCE_MAX_DISPLACEMENT_PX = 40

# Matches both the timestamped ("-t") and plain getevent -l line formats:
#   [   66656.186080] /dev/input/event2: EV_ABS       ABS_MT_POSITION_X    0000170a
#   /dev/input/event2: EV_KEY       BTN_TOUCH            DOWN
_EVENT_LINE_RE = re.compile(
    r"^(?:\[\s*[\d.]+\]\s*)?(/dev/input/event\d+):\s+(EV_\w+)\s+(\S+)\s+(\S+)\s*$"
)


@dataclass
class PhysicalGesture:
    kind: str   # "tap" | "long_press" | "swipe"
    x1: int
    y1: int
    x2: int
    y2: int
    duration_s: float


def _run_adb(serial: Optional[str], *args, timeout: float = 10):
    cmd = ["adb"] + (["-s", serial] if serial else []) + list(args)
    return subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)


def detect_single_adb_serial() -> Optional[str]:
    """Best-effort: only needed when ANDROID_UDID isn't set AND more than
    one device is attached (adb itself is happy to target the sole
    attached device with no -s at all). Returns None (meaning "let adb
    pick") when there's exactly zero or one device; raises when there's a
    genuine ambiguity adb couldn't resolve on its own."""
    result = _run_adb(None, "devices")
    lines = [ln for ln in result.stdout.splitlines()[1:] if ln.strip() and "\tdevice" in ln]
    if len(lines) <= 1:
        return None
    raise RuntimeError(
        f"Multiple ADB devices attached ({len(lines)}) and ANDROID_UDID isn't "
        f"set - can't tell which one to read physical touches from. Set "
        f"ANDROID_UDID in .env to the target device's serial."
    )


def find_touchscreen_device(serial: Optional[str]):
    """One-off probe (`adb shell getevent -pl`) for the touchscreen input
    node. Picks the device that reports INPUT_PROP_DIRECT (a touchscreen,
    not a trackpad/mouse) with both ABS_MT_POSITION_X and
    ABS_MT_POSITION_Y axes, and returns (device_node, raw_max_x,
    raw_max_y) - the raw sensor range is what PhysicalTouchListener scales
    against the driver's own screen size to get real screen pixels.

    Raises RuntimeError with a specific reason on failure - physical-touch
    capture is an optional recording enhancement; callers must treat this
    as non-fatal and fall back to mirror-click recording only, never let
    it break recording altogether.
    """
    result = _run_adb(serial, "shell", "getevent", "-pl")
    if result.returncode != 0:
        raise RuntimeError(f"`adb shell getevent -pl` failed: {(result.stderr or '').strip()}")

    blocks = re.split(r"(?=^add device \d+: )", result.stdout, flags=re.MULTILINE)
    for block in blocks:
        node_m = re.search(r"^add device \d+:\s+(/dev/input/event\d+)", block)
        if not node_m or "INPUT_PROP_DIRECT" not in block:
            continue
        x_m = re.search(r"ABS_MT_POSITION_X\s*:\s*value\s+-?\d+,\s*min\s+-?\d+,\s*max\s+(\d+)", block)
        y_m = re.search(r"ABS_MT_POSITION_Y\s*:\s*value\s+-?\d+,\s*min\s+-?\d+,\s*max\s+(\d+)", block)
        if not x_m or not y_m:
            continue
        return node_m.group(1), int(x_m.group(1)), int(y_m.group(1))

    raise RuntimeError(
        "No touchscreen input device found via `adb shell getevent -pl` "
        "(none reported INPUT_PROP_DIRECT with both X/Y position axes) - "
        "physical-touch recording isn't available on this device; mirror-"
        "click recording still works independently."
    )


def _safe_hex(value: str) -> int:
    try:
        return int(value, 16)
    except ValueError:
        return 0


class PhysicalTouchListener:
    """Reads real finger touches straight off the device's touchscreen
    driver on a background thread and turns each completed gesture into a
    PhysicalGesture in screen-pixel space on self.gestures (a thread-safe
    queue.Queue) for the async side to drain. See module docstring for the
    full pipeline and why this stays deliberately dumb (no driver/LLM
    calls in here).
    """

    def __init__(self, serial: Optional[str], screen_width: int, screen_height: int):
        if not screen_width or not screen_height:
            raise RuntimeError("Screen size unknown - can't scale raw touch coordinates.")
        node, raw_max_x, raw_max_y = find_touchscreen_device(serial)
        self._serial = serial
        self._node = node
        self._raw_max_x = raw_max_x
        self._raw_max_y = raw_max_y
        self._screen_w = screen_width
        self._screen_h = screen_height
        self.gestures: "queue.Queue[PhysicalGesture]" = queue.Queue()
        # Fires the INSTANT a finger's first position is known - well
        # before the gesture completes, let alone before its kind (tap/
        # swipe/long_press) can be determined. See _read_loop: Android
        # only fires a click (and whatever screen transition follows it)
        # on the UP event, never on DOWN - so a lookup kicked off from
        # this queue at down-time is guaranteed to run before the app has
        # any chance to react, no matter how fast that reaction is.
        # gestures above is still what carries the finished result
        # (kind, endpoint, duration); this is purely a head start signal.
        self.touch_starts: "queue.Queue[tuple]" = queue.Queue()  # (x, y) in screen px
        self._proc: Optional[subprocess.Popen] = None
        self._thread: Optional[threading.Thread] = None
        self._stop_flag = threading.Event()
        self._last_end_time: Optional[float] = None
        self._last_end_xy: Optional[tuple] = None

    def start(self):
        cmd = ["adb"] + (["-s", self._serial] if self._serial else []) + ["shell", "getevent", "-lt"]
        self._proc = subprocess.Popen(
            cmd, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
            text=True, bufsize=1,
        )
        self._thread = threading.Thread(target=self._read_loop, daemon=True)
        self._thread.start()

    def stop(self):
        self._stop_flag.set()
        if self._proc is not None:
            try:
                self._proc.terminate()
            except Exception:
                pass
        self._proc = None

    def is_alive(self) -> bool:
        return self._proc is not None and self._proc.poll() is None

    def _to_screen(self, raw_x: int, raw_y: int):
        sx = round(raw_x / (self._raw_max_x + 1) * self._screen_w)
        sy = round(raw_y / (self._raw_max_y + 1) * self._screen_h)
        return sx, sy

    def _read_loop(self):
        active = False           # a finger is currently down (slot 0)
        multi = False            # a second slot appeared during this gesture - drop it
        slot = 0
        start_time = None
        first_xy = None
        cur_x = cur_y = None
        last_xy = None

        proc = self._proc
        if proc is None or proc.stdout is None:
            return

        for line in proc.stdout:
            if self._stop_flag.is_set():
                break
            m = _EVENT_LINE_RE.match(line.rstrip("\n"))
            if not m:
                continue
            node, ev_type, code, value = m.groups()
            if node != self._node:
                continue

            if ev_type == "EV_ABS" and code == "ABS_MT_SLOT":
                slot = _safe_hex(value)
                if slot != 0:
                    multi = True
                continue

            if slot != 0:
                continue

            if ev_type == "EV_ABS" and code == "ABS_MT_TRACKING_ID":
                if _safe_hex(value) == 0xFFFFFFFF:
                    self._finalize(active, multi, start_time, first_xy, last_xy)
                    active = multi = False
                    start_time = first_xy = last_xy = None
                    cur_x = cur_y = None
                else:
                    active, multi = True, False
                    start_time = time.monotonic()
                    first_xy = last_xy = None
                    cur_x = cur_y = None
                continue

            if ev_type == "EV_KEY" and code == "BTN_TOUCH":
                if value == "UP":
                    self._finalize(active, multi, start_time, first_xy, last_xy)
                    active = multi = False
                    start_time = first_xy = last_xy = None
                    cur_x = cur_y = None
                continue

            if not active:
                continue

            if ev_type == "EV_ABS" and code == "ABS_MT_POSITION_X":
                cur_x = _safe_hex(value)
                continue
            if ev_type == "EV_ABS" and code == "ABS_MT_POSITION_Y":
                cur_y = _safe_hex(value)
                continue

            if ev_type == "EV_SYN" and code == "SYN_REPORT" and cur_x is not None and cur_y is not None:
                sx, sy = self._to_screen(cur_x, cur_y)
                if first_xy is None:
                    first_xy = (sx, sy)
                    self.touch_starts.put((sx, sy))
                last_xy = (sx, sy)

    def _finalize(self, active, multi, start_time, first_xy, last_xy):
        if not active or multi or first_xy is None or start_time is None:
            return
        end_time = time.monotonic()
        duration = end_time - start_time
        x1, y1 = first_xy
        x2, y2 = last_xy or first_xy

        # Release-bounce guard - see _DEBOUNCE_WINDOW_S. Checked against
        # the END of the previous gesture (not its start), since a bounce
        # is specifically a second lift/settle right after the finger
        # actually left the screen.
        if self._last_end_time is not None and self._last_end_xy is not None:
            since_last = end_time - self._last_end_time
            if since_last <= _DEBOUNCE_WINDOW_S:
                lx, ly = self._last_end_xy
                from_last = ((x1 - lx) ** 2 + (y1 - ly) ** 2) ** 0.5
                if from_last <= _DEBOUNCE_MAX_DISPLACEMENT_PX:
                    self._last_end_time = end_time
                    self._last_end_xy = (x2, y2)
                    return

        displacement = ((x2 - x1) ** 2 + (y2 - y1) ** 2) ** 0.5
        if displacement > _TAP_MAX_DISPLACEMENT_PX:
            kind = "swipe"
        elif duration >= _LONG_PRESS_MIN_DURATION_S:
            kind = "long_press"
        else:
            kind = "tap"

        self._last_end_time = end_time
        self._last_end_xy = (x2, y2)
        self.gestures.put(PhysicalGesture(kind, x1, y1, x2, y2, duration))
