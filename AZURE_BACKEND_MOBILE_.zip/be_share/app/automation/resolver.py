"""
Resolves a plain-English target description (e.g. "the login button") to
an actual element - used by explicit user-authored steps, where there's no
LLM-suggested ref to start from (the user typed the description directly).

Three tiers, cheapest first:
1. Fuzzy text match (thefuzz) of the description against every element's
   rendered line in CURRENT SCREEN STATE - fast, free, no LLM call at all.
2. If that's ambiguous (best score below FUZZY_TARGET_THRESHOLD), ask the
   LLM once to pick the correct ref from the list - still text-only, no
   screenshot.
3. If neither finds it, fall back to vision (screenshot + coordinates),
   same ENABLE_VISION_FALLBACK kill switch as everywhere else.
"""

"""
Resolves a plain-English target description (e.g. "the login button") to
an actual element - used by explicit user-authored steps, where there's no
LLM-suggested ref to start from (the user typed the description directly).

Three tiers, cheapest first:
1. Tier-1 text/semantic match (see _tier1_best_ref) of the description
   against every element's label in CURRENT SCREEN STATE - fast, free, no
   LLM call at all.
2. If that's ambiguous (nothing clears its threshold), ask the LLM once to
   pick the correct ref from the list - still text-only, no screenshot.
3. If neither finds it, fall back to vision (screenshot + coordinates),
   same ENABLE_VISION_FALLBACK kill switch as everywhere else.
"""

import time

from thefuzz import fuzz

from app.llm.model_client import achat_json
from app.automation.locator_engine import resolve_by_ref, resolve_by_vision, resolve_by_locator
from app.automation.text_utils import line_for_ref, label_for_ref
from app.automation.semantic_matcher import asemantic_best_ref
from app.automation.popup_handler import detect_session_expired, detect_system_overlay


class SessionExpiredError(RuntimeError):
    """Raised instead of a normal resolution failure when the screen itself
    is a session-expiry interstitial (see popup_handler.detect_session_expired) -
    lets a caller tell "the target genuinely isn't findable" apart from
    "the whole app logged itself out mid-run", which needs a completely
    different response (re-authenticate / abort the run), not a locator fix."""


class SystemOverlayError(RuntimeError):
    """Raised instead of a normal resolution failure when a system-level
    overlay (e.g. Android's Circle to Search/Assistant gesture UI) is
    covering the screen (see popup_handler.detect_system_overlay) - the app
    itself is still there underneath, but temporarily inaccessible to the
    automation, which needs a different response (dismiss the overlay,
    e.g. via 'back' or tapping its own close control, and retry) than a
    locator/matching fix."""

FUZZY_TARGET_THRESHOLD = 70
# At or above this fuzzy score, semantic matching is skipped entirely (see _tier1_best_ref).
FUZZY_SKIP_SEMANTIC_SCORE = 100
# Cosine similarity * 100, same 0-100 scale as FUZZY_TARGET_THRESHOLD so
# the two are directly comparable in _tier1_best_ref. Tuned looser than
# the fuzzy threshold on purpose: embeddings for two SHORT phrases that
# are genuinely unrelated UI labels still often land in the 30-50 range
# (short-text cosine similarity compresses less informatively than long-
# text), while genuine matches/paraphrases ("Open" vs "Launch") typically
# clear 65-75+. This is a starting point, not a proven-optimal number -
# worth tuning against your own app's real descriptions once you have a
# few resolution logs to look at.
SEMANTIC_TARGET_THRESHOLD = 65

# Floor for _tier1_best_ref's "fuzzy and semantic independently agree"
# corroboration case - see its own comment there. 50 sits right at the top
# of the "genuinely unrelated UI labels" 30-50 range this file's own
# SEMANTIC_TARGET_THRESHOLD comment above describes: below it, two signals
# agreeing is no longer good evidence, just as likely to be two weak
# scorers converging on "least bad of a small pool" as an actual match.
MIN_CORROBORATED_SCORE = 50

# Passed through to achat_json's own `timeout=` (see app/llm/model_client.py,
# which now owns the actual client-level timeout + retry logic this used to
# band-aid locally) - this call's own measured/reasoned budget, tighter than
# the module's generic default since a tier-2 text-only resolve is normally
# fast.
LLM_CALL_TIMEOUT_S = 15
# When the LLM says the user typed a NAME (label) rather than describing an
# element, the element it picked must actually carry that name: its own fuzzy
# score against the description must reach this. Backstop for the small model
# guessing the "least bad" element (confirmed: "bubbles" -> "Incoming messages"
# 26, "advanced" -> "Additional settings in the app" 33 - both passed a run).
# Not applied to descriptive references ("the last one"), which have no text
# overlap by nature.
LLM_LABEL_MIN_FUZZY = 50

RESOLVE_SYSTEM_PROMPT = """You resolve a user's target description to one
element from a list of what is on screen. Respond with ONLY JSON, no
reasoning, no <think> tags, no prose:
{"reference_type": "label" or "descriptive", "ref": "E3" or null, "reasoning": "short reason"}

First decide what kind of description it is.
- "descriptive": it points at an element by position, order, relation or an
  indirect clue instead of by its exact name - e.g. "the last option", "the
  third item", "the one with additional settings", "the toggle next to
  Bubbles", "the button below the title". Reason over the list (the order of
  the list is the on-screen order) and pick the element it refers to.
- "label": it is a name - a word or phrase the user expects to see as an
  element's visible text, e.g. "Advanced", "Messages settings", "Submit". The
  chosen element's own text must be that same name (ignore case, typos,
  plurals, punctuation and minor wording like "Log in" vs "Login"). An element
  that is merely related, similar in meaning, or on a broader/narrower topic is
  NOT a match. If no element carries that name, the user most likely typed
  something that is not on this screen (or is on another page): set ref to null.
If unsure, treat a short bare word or phrase with no position or relation
words as a label. If nothing fits, ref is null. Never pick the "least bad"
element just to return something.
"""

RESOLVE_JSON_SCHEMA = {
    "name": "target_resolution",
    "schema": {
        "type": "object",
        "properties": {
            "reference_type": {"type": "string", "enum": ["label", "descriptive"]},
            "ref": {"type": ["string", "null"]},
            "reasoning": {"type": "string"},
        },
        "required": ["reference_type", "ref", "reasoning"],
        "additionalProperties": False,
    },
}


def _fuzzy_score(description: str, label: str) -> float:
    """One label's blended fuzzy score (70% token_sort_ratio, 30% ratio) - see
    _fuzzy_best_ref for why these two metrics."""
    d, l = description.lower(), label.lower()
    return fuzz.token_sort_ratio(d, l) * 0.7 + fuzz.ratio(d, l) * 0.3


def _fuzzy_best_ref(description: str, state_text: str, ref_map: dict):
    """
    Scores every candidate with TWO fuzzy metrics, chosen after checking
    actual numbers across several real failure cases (typos, superstrings,
    reordered words) rather than picking metrics by name alone:

      - token_sort_ratio: sorts both strings' words before comparing, so
        word ORDER doesn't matter, but - unlike token_set_ratio - it does
        NOT ignore extra words in the candidate. This is what actually
        fixes the original bug: token_set_ratio scores 100 whenever the
        query's words are merely a SUBSET of the candidate's, so a plain
        query like "mutual fund" tied at 100 against both the exact
        "Mutual Fund" AND a longer, more specific "Loan Against Mutual
        Fund" - a real false-positive this produced in practice.
        token_sort_ratio instead scores that same pair ~63, clearly below
        the exact match's 100.
      - ratio: whole-string similarity. Mainly here for single-word/short
        descriptions, where it makes near-exact typos ("submit" vs the
        target having a typo like "Submitt" on the actual UI) still score
        very high (~92) rather than being penalized - a UI-side typo
        shouldn't cause a match failure, only genuinely different/extra
        words should.

    partial_ratio was tested and deliberately excluded: it scores 100 for
    every "query is a substring of candidate" case regardless of how much
    extra content the candidate has, which is the same class of false-
    positive as the original token_set_ratio bug, just via a different
    mechanism - it would have reintroduced the exact problem being fixed.

    The 70/30 weighting keeps token_sort_ratio as the primary signal
    (reordering- and extra-word-aware) while ratio's typo tolerance still
    meaningfully lifts near-exact single/few-word matches.

    Purely a STRING-DISTANCE signal - has no notion that "Open" and
    "Launch" mean the same thing, only that they share/don't share
    characters. See semantic_matcher.py for the meaning-aware counterpart
    this is now paired with in _tier1_best_ref below.
    """
    best_ref, best_score = None, 0
    for ref in ref_map:
        label = label_for_ref(state_text, ref)
        combined = _fuzzy_score(description, label)
        if combined > best_score:
            best_ref, best_score = ref, combined
    return best_ref, best_score


async def _tier1_best_ref(description: str, state_text: str, ref_map: dict, allow_semantic_alone: bool = True,
                    timings: dict | None = None):
    """
    Combines the fuzzy (string-distance) and semantic (meaning/embedding)
    signals into one tier-1 decision. Returns (ref, score, method) - method
    is "fuzzy+semantic" | "fuzzy" | "semantic" | None, purely informational
    (resolution_info still reports tier="fuzzy" for any tier-1 match, to
    keep step_runner.py's self-healing check - which looks for
    tier in ("fuzzy", "llm") - and any frontend "resolution tier" badge
    working unchanged regardless of which signal actually won).

    Decision order:
    1. Both signals independently pick the SAME ref - strong corroborating
       evidence (one caught by spelling/wording overlap, the other by
       meaning), accepted even if either score is individually borderline.
    2. Otherwise, whichever candidate clears ITS OWN threshold with the
       higher score wins. A candidate that doesn't clear its own
       threshold is not considered at all, even if it's the highest
       number on the table - an unclearing score is exactly what tier 2
       (the LLM) exists to catch instead of guessing.

    allow_semantic_alone=False restricts case 2 to fuzzy only - semantic
    can still WIN via case 1 (corroborated by fuzzy agreeing), just never
    as the sole basis for a match. This matters specifically for
    resolve_fuzzy_only's callers (the swipe search loops): there, a false
    positive is silent and much more costly than elsewhere - it makes the
    loop report "found it" on attempt 0, before any swipe has happened at
    all, with no visible sign anything went wrong (unlike a wrong CLICK,
    which at least shows up doing something in the screenshot/run log). A
    general-purpose embedding model isn't fine-tuned on any specific app's
    vocabulary, and two UI labels that are only THEMATICALLY related (e.g.
    "Open Savings/Current Account" and "Register", both loosely "about"
    starting a banking relationship) can score high enough to clear
    SEMANTIC_TARGET_THRESHOLD alone despite being genuinely different
    targets - observed in practice, not just theoretical. Requiring fuzzy
    corroboration in this specific context keeps semantic's benefit (it
    still helps the search loop recognize an already-good textual match
    faster/more reliably) without letting it single-handedly short-circuit
    a swipe that still needed to happen.

    Falls back to fuzzy-only behavior automatically if Azure OpenAI
    embeddings aren't configured, or the embedding call fails for any
    reason (asemantic_best_ref returns (None, 0) in that case, which never
    wins case 1 or clears case 2's threshold) - no separate on/off flag
    needed for THAT, it degrades on its own; allow_semantic_alone is a
    separate, deliberate choice about risk tolerance per call site.
    """
    # timings (optional out-param) records how long each signal took and what
    # it scored, so the UI can show which one is costing time. Note the first
    # semantic call in a process can include model warm-up.
    t0 = time.perf_counter()
    fuzzy_ref, fuzzy_score = _fuzzy_best_ref(description, state_text, ref_map)
    t1 = time.perf_counter()
    if timings is not None:
        timings.update({"fuzzy_ms": round((t1 - t0) * 1000, 1), "fuzzy_score": round(fuzzy_score, 1)})
    # A perfect fuzzy score can't be beaten: semantic scores cap at 100 and
    # ties go to fuzzy (it's first in the candidate list below), so making
    # the embeddings API call here would only cost time (and money).
    if fuzzy_ref is not None and fuzzy_score >= FUZZY_SKIP_SEMANTIC_SCORE:
        return fuzzy_ref, fuzzy_score, "fuzzy"
    semantic_ref, semantic_score = await asemantic_best_ref(description, state_text, ref_map)
    if timings is not None:
        timings.update({
            "semantic_ms": round((time.perf_counter() - t1) * 1000, 1),
            "semantic_score": round(semantic_score, 1),
        })

    # _fuzzy_best_ref (and semantic_best_ref) always return the BEST OF
    # WHATEVER'S ON SCREEN, however bad - there's no floor in either, by
    # design, so tier 2 (the LLM) can see the same ranked candidates tier 1
    # rejected. That's fine when each signal is checked against its OWN
    # threshold below (case 2) - a low score there is correctly rejected.
    # But this corroboration case had no floor of its own: two signals
    # merely agreeing on the same ref was treated as "strong evidence"
    # regardless of how low the agreed-on score actually was. Confirmed in
    # practice: with only a few interactive elements on screen, fuzzy and
    # semantic independently landed on the same wrong element with scores
    # of 11 and 40 (out of 100) - both "best of a bad lot", not a real
    # match - and this branch accepted them anyway, clicking "Exit"/
    # "Register" for descriptions ("Current account for new customer"/
    # "deposit") that named neither. MIN_CORROBORATED_SCORE keeps the
    # actual intent of this case (let a match through even if it's below
    # either signal's OWN solo threshold, provided both signals agree) —
    # while still refusing to call a coincidental double-low a match.
    if semantic_ref is not None and semantic_ref == fuzzy_ref:
        corroborated_score = max(fuzzy_score, semantic_score)
        if corroborated_score >= MIN_CORROBORATED_SCORE:
            return fuzzy_ref, corroborated_score, "fuzzy+semantic"

    candidates = []
    if fuzzy_ref is not None and fuzzy_score >= FUZZY_TARGET_THRESHOLD:
        candidates.append((fuzzy_ref, fuzzy_score, "fuzzy"))
    if allow_semantic_alone and semantic_ref is not None and semantic_score >= SEMANTIC_TARGET_THRESHOLD:
        candidates.append((semantic_ref, semantic_score, "semantic"))

    if not candidates:
        return None, 0, None
    candidates.sort(key=lambda c: c[1], reverse=True)
    return candidates[0]


async def aresolve_by_description(driver, description: str, state_text: str, ref_map: dict,
                                   platform: str = "android", locator: dict = None, fingerprint: dict = None,
                                   attrs_map: dict = None):
    """
    Returns (ResolvedTarget | None, resolution_info: dict). resolution_info
    always has "tier" ("locator" | "fuzzy" | "llm" | "vision" | "none"),
    "score" (the tier-1 blended score, only set for the fuzzy tier - see
    _tier1_best_ref's "method" for which signal actually won, folded into
    matched_text's context if you need to distinguish them), and
    "matched_text" (the actual on-screen line that was matched, only
    available for fuzzy/LLM tiers - vision resolves to a coordinate, not a
    labelled element, so there's no text to report for it). Surfaced in the
    step log so a wrong match is visible and debuggable ("it matched X, not
    what I expected") instead of only showing up indirectly as a wrong click.

    locator and fingerprint are optional, populated by the recorder (see
    app/automation/recorder.py) - hand-authored steps never set them, and
    every tier below still runs exactly as before in that case.
      - locator: tried FIRST, before any text matching, via
        locator_engine.resolve_by_locator. Fails soft (falls through to the
        tiers below) if it doesn't resolve - e.g. a recorded resource-id
        that went stale after an app rebuild - never a hard failure just
        because a locator aged out.
      - fingerprint: structural context captured alongside the locator
        (element class, clickable/selected state, on-screen position) -
        folded into the tier-2 LLM prompt as corroborating evidence
        alongside the text description, not matched on its own. This is
        what gives the LLM tier a way to prefer the recorded candidate over
        a same-named-but-wrong element elsewhere on screen (the "Personal
        Finance" tab vs. "Fixed Deposit" list item confusion from earlier).
    """
    if not description:
        return None, {"tier": "none", "score": None, "matched_text": None}

    # Fail fast and HONEST if the screen itself is a session-expiry
    # interstitial: every tier below is about to search state_text for
    # `description` against a screen that provably cannot contain it (the
    # real app is fully covered), so there's no point burning an LLM call
    # and a vision/screenshot call chasing it - and if we let it run
    # anyway, the eventual "not found" reads exactly like an ordinary
    # locator/matching failure, hiding the actual cause. Confirmed in
    # practice: a click_within step failed with "Could not locate
    # 'Investments' within 'View All'" while the on-device screenshot
    # showed the app's own "Session Expired" dialog covering the entire
    # dashboard - a completely different problem than "matching is wrong",
    # that this generic message gave no hint of.
    if detect_session_expired(state_text):
        raise SessionExpiredError(
            "The app appears to have logged itself out mid-run (a session-expiry "
            "dialog is covering the screen) - this is not a locator/matching "
            "problem, the target genuinely cannot be on screen right now. "
            "Re-authenticate and re-run, or add a 'Launch App'/login step "
            "before this point if session timeouts happen mid-flow regularly."
        )

    # Same idea, for a system-level overlay (e.g. Android's Circle to
    # Search/Assistant gesture UI) instead of an app-level dialog. Confirmed
    # in practice: a click on "Messages settings" failed to resolve with the
    # on-device screenshot showing exactly this overlay covering the whole
    # screen, even though "Messages settings" was still visibly painted
    # through it - the accessibility tree being queried at that moment is
    # this overlay's own window, not the app's underneath it. Most likely
    # trigger: the target sat close to the device's own system navigation/
    # gesture area, and a tap/swipe there got interpreted as a system
    # gesture instead of reaching the app.
    if detect_system_overlay(state_text):
        raise SystemOverlayError(
            "A system-level overlay (e.g. Android's Circle to Search/Assistant "
            "gesture UI) appears to be covering the screen - this is not a "
            "locator/matching problem, the app is still there underneath but "
            "temporarily inaccessible to the automation. This is usually "
            "triggered by a gesture landing too close to the device's own "
            "navigation bar/edge - if the target sits near the bottom of the "
            "screen, consider scrolling to bring it further from that edge "
            "before interacting with it."
        )

    # Tier 0: recorded locator, if any.
    locator_target = resolve_by_locator(driver, platform, locator)
    if locator_target:
        return locator_target, {"tier": "locator", "score": None, "matched_text": None,
                                "locator_used": locator_target.locator_used}

    if ref_map:
        timings: dict = {}
        ref, score, method = await _tier1_best_ref(description, state_text, ref_map, timings=timings)
        if ref:
            target = resolve_by_ref(ref, ref_map)
            if target:
                return target, {
                    "tier": "fuzzy", "score": round(score, 1), "method": method,
                    "matched_text": line_for_ref(state_text, ref).strip(),
                    **timings,
                }

        # Tier 2: ask the LLM to pick from the list - still no screenshot.
        # If a fingerprint was captured at record time, it's included as
        # extra corroborating context alongside the text description.
        try:
            user_prompt = f"Target description: {description}\n\nCURRENT SCREEN STATE:\n{state_text}\n\nWhich ref matches?"
            if attrs_map:
                # Richer per-candidate attributes (hint, password,
                # max-text-length, bounds, ...) from page_state's single
                # page_source parse. Deliberately included HERE and not in
                # state_text: state_text is what fuzzy matching scores
                # against, and padding it with attribute text shifts those
                # scores unpredictably. The LLM tier has no such constraint
                # and benefits from everything available - two identical-
                # looking EditTexts are trivially distinguishable by
                # hint='CIF' vs hint='Mobile No', where their own typed
                # values ("85002394046" vs "8155077563") say nothing.
                detail_lines = []
                for ref in ref_map:
                    attrs = attrs_map.get(ref)
                    if attrs:
                        useful = {k: v for k, v in attrs.items()
                                  if v not in ("", "false", None) and k != "class"}
                        if useful:
                            detail_lines.append(f"[{ref}] {useful}")
                if detail_lines:
                    user_prompt += (
                        "\n\nFull attributes for each candidate (use these to tell "
                        "otherwise-similar elements apart - 'hint' is the field's "
                        "placeholder and is especially reliable for identifying "
                        "which input is which):\n" + "\n".join(detail_lines)
                    )
            if fingerprint:
                user_prompt += (
                    f"\n\nThe element originally recorded for this step had this profile "
                    f"(use it as supporting evidence alongside the description above, not "
                    f"instead of it - prefer a candidate matching BOTH): {fingerprint}"
                )
            t_llm = time.perf_counter()
            result = await achat_json(
                RESOLVE_SYSTEM_PROMPT, user_prompt, schema=RESOLVE_JSON_SCHEMA, timeout=LLM_CALL_TIMEOUT_S
            )
            timings["llm_ms"] = round((time.perf_counter() - t_llm) * 1000, 1)
            picked_ref = result.get("ref")
            # Anything but an explicit "descriptive" is treated as a label - the
            # strict reading, so a missing/garbled type can't wave a guess through.
            is_descriptive = str(result.get("reference_type", "")).strip().lower() == "descriptive"
            if picked_ref and not is_descriptive:
                picked_label = label_for_ref(state_text, picked_ref)
                if _fuzzy_score(description, picked_label) < LLM_LABEL_MIN_FUZZY:
                    picked_ref = None  # a named target that isn't on this screen
            if picked_ref:
                target = resolve_by_ref(picked_ref, ref_map)
                if target:
                    return target, {
                        "tier": "llm", "score": None,
                        "matched_text": line_for_ref(state_text, picked_ref).strip(),
                        **timings,
                    }
        except Exception:
            pass

    # Tier 3: vision fallback (returns None if disabled or not found).
    vision_target = await resolve_by_vision(driver, description)
    if vision_target:
        return vision_target, {"tier": "vision", "score": None, "matched_text": None}
    return None, {"tier": "none", "score": None, "matched_text": None, **(timings if ref_map else {})}


async def resolve_fuzzy_only(description: str, state_text: str, ref_map: dict):
    """
    Tier-1-only check (no LLM call, no vision/screenshot call) - the
    combined fuzzy+semantic signal (_tier1_best_ref), not fuzzy alone,
    despite the name (kept for now to avoid touching every call site's
    import; consider renaming to resolve_tier1_only in a follow-up).
    Async because the semantic half of tier 1 now calls the Azure OpenAI
    embeddings API (see semantic_matcher.py) - every call site already
    awaits this from inside an async function.

    Used by the swipe_up_to/swipe_down_to and swipe_within-to interim
    search-while-swiping loops, which call this once per scroll step just
    to check "is it visible yet" - repeating the full 3-tier resolve
    (including a screenshot + vision LLM call) on every single scroll step
    is what was making that loop painfully slow. The full
    aresolve_by_description is still used for one last full-tier attempt
    after scrolling is exhausted, so an element with no fuzzy/semantic-
    matchable text at all (e.g. an icon-only control) can still be found
    by vision as a final resort - just not repeatedly during the blind
    search.

    Passes allow_semantic_alone=False - a semantic-ALONE match is NOT
    accepted here (only semantic corroborated by fuzzy, or fuzzy alone,
    are). A false positive in this specific context is uniquely bad: it
    makes the search loop report "found it" on attempt 0, before any
    swipe has happened, with no visible sign anything's wrong (unlike a
    wrong CLICK elsewhere, which at least visibly does something in the
    screenshot) - observed in practice as a swipe_up_to/swipe_left_within_to
    step "passing" while never actually swiping, because a thematically-
    related-but-wrong element (e.g. "Register" for a target description
    of "Open Savings/Current Account") cleared the semantic threshold
    alone on the very first, pre-swipe check.
    """
    if not description or not ref_map:
        return None
    ref, score, method = await _tier1_best_ref(description, state_text, ref_map, allow_semantic_alone=False)
    if ref:
        return resolve_by_ref(ref, ref_map)
    return None
