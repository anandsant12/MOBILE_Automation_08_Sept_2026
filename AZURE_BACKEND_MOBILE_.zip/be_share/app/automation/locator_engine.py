"""
Hybrid element resolution.

Path 1 (preferred, fast, reliable, no LLM vision call at all): the planner
already gave us a ref like "E3" that points straight at a real element from
page_state.get_state() - a plain dict lookup, done.

Path 2 (fallback, slower, only used when ref is null/stale AND
settings.enable_vision_fallback is True): take a screenshot, ask the
Azure OpenAI vision deployment for normalized (0-1) coordinates, convert
to real pixels.
"""

import asyncio
import base64
import io
import re
from dataclasses import dataclass
from typing import Optional

from selenium.webdriver.common.by import By
from selenium.common.exceptions import NoSuchElementException, WebDriverException
from openai import RateLimitError as OpenAIRateLimitError

from app.llm.model_client import achat_vision_json
from app.utils.screenshot import take_screenshot, screenshot_to_b64
from config import settings

# The openai SDK (which AsyncAzureOpenAI is part of) raises RateLimitError
# for a 429 - caught specifically (not lumped in with ordinary "vision
# call failed" exceptions) everywhere below: confirmed in practice, an
# exhausted quota was silently swallowed and retried/reported as an
# ordinary "element not found" - completely indistinguishable from vision
# genuinely not seeing the element, which wasted a long debugging session
# chasing a precision problem that didn't exist; every call in that
# window was simply being rejected outright. This should never be
# silently absorbed - retrying against an exhausted quota is pointless
# (it'll reject the same way again), and the caller deserves to know the
# REAL reason resolution failed.
_RATE_LIMIT_ERRORS = (OpenAIRateLimitError,)

# The Azure client isn't constructed with an explicit `timeout=` (see
# app/llm/model_client.py) - the SDK defaults to a very long client-level
# timeout (minutes) when unset. A single slow/stuck vision call - and
# _vision_locate_retrying below tries up to 2 attempts, and resolve_by_vision
# can run that twice (a hinted/full pass, then a cropped fallback pass).
# Passed through to achat_vision_json's own `timeout=` (see
# app/llm/model_client.py, which now owns the actual client-level timeout +
# retry logic this used to band-aid locally) - this call's own measured/
# reasoned budget. Originally added after a confirmed real incident: with
# no bound at all, a genuinely bad response once silently stalled a single
# resolve_by_vision call for MULTIPLE MINUTES with nothing externally
# distinguishing it from "still legitimately searching." By the time it
# gave up, the app's own idle-session timeout had fired, making the
# eventual on-screen state look like the cause when it was actually a
# symptom. A bounded per-call timeout here means a stuck call fails fast
# (falls through to the next tier/attempt, exactly like any other failure
# already does) instead of quietly eating the app's own session window.
VISION_CALL_TIMEOUT_S = 20

VISION_SYSTEM_PROMPT = """You are looking at a screenshot of an app/website.
Find the single UI element described by the user and return ONLY JSON, no
reasoning, no <think> tags, no explanation outside the JSON:
{"found": true|false, "x": 0.0-1.0, "y": 0.0-1.0, "reasoning": "short reason"}
x and y are the NORMALIZED center coordinates of the element (0,0 = top-left,
1,1 = bottom-right).

A thin magenta grid is overlaid on the image at every 0.1 step along both
axes, each line labeled with its own coordinate value (0.1, 0.2, 0.3, ...) -
this is NOT part of the actual UI, it is a coordinate reference added only
to help you read off x/y precisely. Use the nearest grid lines around the
element to read its position directly (e.g. an element sitting roughly a
third of the way between the "0.4" and "0.5" vertical lines is at
approximately x=0.43) rather than estimating purely from visual proportions.

Only set found=true if you can clearly see THIS SPECIFIC element's own text
or icon in the screenshot - not a similar or related one. For example, if
asked to find "Recurring Deposit" and the screenshot shows "Fixed Deposit"
or "Tax Saver FD" instead, that is NOT a match, even though it's a similar
kind of product on the same screen - do not guess the closest-looking
option. If the described element is not clearly visible in this exact
screenshot (e.g. it may require scrolling first), set found=false and x/y
to 0. A false negative is far better than a wrong guess - the caller can
scroll and try again; a confident wrong coordinate cannot be undone.

Watch for icons that are visually similar but mean different things - a
"play" button (a triangle, typically centered inside or over a circle) is
NOT the same as an "info" button (a circle with an "i"), a "pause" button
(two bars), a generic round badge/avatar, or any other roundish icon. Read
what the icon actually depicts, not just its rough silhouette.
"""

VISION_LOCATE_JSON_SCHEMA = {
    "name": "element_location",
    "schema": {
        "type": "object",
        "properties": {
            "found": {"type": "boolean"},
            "x": {"type": "number"},
            "y": {"type": "number"},
            "reasoning": {"type": "string"},
        },
        "required": ["found", "x", "y", "reasoning"],
        "additionalProperties": False,
    },
}

READ_TEXT_VISION_PROMPT = """You are looking at a screenshot of an app/website.
Find the single UI element described by the user and report back its exact
visible text content (not a paraphrase or description of it). Return ONLY
JSON, no reasoning, no <think> tags, no explanation outside the JSON:
{"found": true|false, "text": "the exact text shown, or empty string if none", "reasoning": "short reason"}
If you cannot find the element, set found=false and text to "".
"""

READ_TEXT_JSON_SCHEMA = {
    "name": "element_text",
    "schema": {
        "type": "object",
        "properties": {
            "found": {"type": "boolean"},
            "text": {"type": "string"},
            "reasoning": {"type": "string"},
        },
        "required": ["found", "text", "reasoning"],
        "additionalProperties": False,
    },
}

DESCRIBE_ELEMENT_VISION_PROMPT = """You are looking at a cropped screenshot
of an app/website, zoomed in on ONE specific UI element (the one roughly
centered in this crop - the surrounding content is just visual context, not
the target). Describe what that element IS, the way a person would describe
it to someone else looking at their own screen - e.g. "the headphones icon",
"the back arrow", "the video play button", "the search magnifying glass
icon", "the profile picture thumbnail". Return ONLY JSON, no reasoning, no
<think> tags, no explanation outside the JSON:
{"description": "<short plain-English description>", "confidence": "high"|"low"}

Describe the element's own icon/shape/visual role - not unrelated text or
icons elsewhere in the crop that clearly belong to a different element.
Watch for icons that are visually similar but mean different things - a
"play" button (a triangle) is NOT the same as an "info" button (a circle
with an "i"), a "pause" button (two bars), or a generic round avatar/badge -
read what the icon actually depicts.

If the crop is genuinely blank/empty or nothing identifiable is at the
center, still return your best-effort description of whatever IS there
(e.g. "a plain colored panel") with confidence "low" - never return an
empty description.
"""

DESCRIBE_ELEMENT_JSON_SCHEMA = {
    "name": "element_description",
    "schema": {
        "type": "object",
        "properties": {
            "description": {"type": "string"},
            "confidence": {"type": "string", "enum": ["high", "low"]},
        },
        "required": ["description", "confidence"],
        "additionalProperties": False,
    },
}


@dataclass
class ResolvedTarget:
    method: str  # "ref" or "vision"
    element = None
    x_px: Optional[int] = None
    y_px: Optional[int] = None
    locator_used: Optional[str] = None  # which stored locator key resolved it (tier 0 only)


def resolve_by_ref(ref: str, ref_map: dict) -> Optional[ResolvedTarget]:
    el = ref_map.get(ref)
    if el is None:
        return None
    target = ResolvedTarget(method="ref")
    target.element = el
    return target


def _xpath_literal(value: str) -> str:
    """Quotes a value as an XPath string literal, handling embedded quotes."""
    if "'" not in value:
        return f"'{value}'"
    if '"' not in value:
        return f'"{value}"'
    return "concat(" + ", \"'\", ".join(f"'{part}'" for part in value.split("'")) + ")"


# Priority order per platform. Most specific/stable first; positional xpath last.
_ANDROID_LOCATOR_ORDER = ("resource_id", "content_desc", "text", "hint", "xpath")


def _locator_query(key: str, value: str):
    """(By strategy, selector) for one stored locator key."""
    if key == "resource_id":
        return By.ID, value
    if key == "content_desc":
        return By.XPATH, f"//*[@content-desc={_xpath_literal(value)}]"
    if key == "text":
        return By.XPATH, f"//*[@text={_xpath_literal(value)}]"
    if key == "hint":
        return By.XPATH, f"//*[@hint={_xpath_literal(value)}]"
    return By.XPATH, value  # xpath


def resolve_by_locator(driver, platform: str, locator: Optional[dict]) -> Optional[ResolvedTarget]:
    """
    Tier 0: try the recorded locators directly, in priority order (see
    _ANDROID_LOCATOR_ORDER), before any text matching at
    all. Fast (no LLM call) and free when it works.

    Ids keep their original behavior (first match wins). Every other
    locator must match exactly ONE element - a text/xpath/css that matches
    several is ambiguous, so it is skipped rather than guessed at.

    Deliberately fails soft, not hard: a locator captured at RECORD time
    can go stale by REPLAY time - Compose-based Android UIs in particular
    routinely regenerate resource-ids across builds. Each stale locator just
    moves on to the next one, and if none resolve it returns None so the
    existing fuzzy/LLM/vision chain runs using the recorded description -
    never a hard failure just because a locator aged out.
    """
    if not locator:
        return None
    order = _ANDROID_LOCATOR_ORDER
    id_key = order[0]
    for key in order:
        value = locator.get(key)
        if not value:
            continue
        try:
            by, selector = _locator_query(key, value)
            if key == id_key:
                el = driver.find_element(by, selector)
            else:
                found = driver.find_elements(by, selector)
                if len(found) != 1:
                    continue
                el = found[0]
        except (NoSuchElementException, WebDriverException):
            continue
        target = ResolvedTarget(method="ref")
        target.element = el
        target.locator_used = key
        return target
    return None


# Small icon-locating phrase -> crop box, as (x1, y1, x2, y2) fractions of the
# full screenshot. Generous enough to comfortably contain the described
# corner/edge even on a differently-proportioned screen, while still being a
# meaningful "zoom in" over the full image.
#
# The "top" crops deliberately start at y=0.045, not y=0.0: a naive crop
# from the very top pulls in the phone's own OS status bar (clock, wifi,
# battery, bluetooth...) - confirmed in practice to backfire, not just be
# harmless extra content: with the status bar included, the model's guess
# got WORSE (y=69, even further from the real icon at y>=110) than the
# uncropped full-screenshot pass (y=94) - it visually dominates a crop this
# short and is an easy thing to mistake for "the icon" when asked for one
# near the top of the screen. 0.045 clears a typical status bar height
# (110px of 2372px here, ~4.6%) without needing the real device-specific
# figure.
_CORNER_CROPS = {
    frozenset({"top", "right"}): (0.5, 0.045, 1.0, 0.18),
    frozenset({"top", "left"}): (0.0, 0.045, 0.5, 0.18),
    frozenset({"bottom", "right"}): (0.5, 0.86, 1.0, 1.0),
    frozenset({"bottom", "left"}): (0.0, 0.86, 0.5, 1.0),
    frozenset({"top"}): (0.0, 0.045, 1.0, 0.18),
    frozenset({"bottom"}): (0.0, 0.86, 1.0, 1.0),
}


def _crop_box_for_description(description: str):
    """
    A small icon (a help/headphone icon, a hamburger menu, a notification
    bell...) tucked into a screen corner is a needle in a haystack for a
    vision model asked to place it precisely somewhere on a whole, often
    tall, screenshot - confirmed in practice: asked for "Headphone icon on
    top right corner" against a 1080x2372 image, the model placed it at
    y=94, 16px above the icon's real position (y>=110) - a plausible-
    looking miss on a screen this tall, not a wild one.

    When the description itself names a corner/edge, crop the screenshot
    to roughly that region before asking - giving the model a much less
    ambiguous, effectively "zoomed in" image to place the point in. Returns
    None (no crop, use the full screenshot exactly as before) when the
    description doesn't mention a recognized position.
    """
    words = set(re.findall(r"[a-z]+", description.lower()))
    sides = [w for w in ("top", "bottom", "left", "right") if w in words]
    if not sides:
        return None
    if len(sides) >= 2:
        combo = frozenset(sides[:2])
        if combo in _CORNER_CROPS:
            return _CORNER_CROPS[combo]
    # Fall back to a single vertical-edge crop (top/bottom only - a lone
    # "left"/"right" without a paired vertical side is too wide a guess).
    for side in sides:
        single = frozenset({side})
        if single in _CORNER_CROPS:
            return _CORNER_CROPS[single]
    return None


# Half-width/height of the refinement window, as a fraction of the full
# screenshot - a 24%x24% window is a meaningful ~4x zoom for a typical
# icon-sized target while comfortably tolerant of the FIRST guess being
# somewhat off (as opposed to pixel-perfect already, which would need no
# refining at all).
REFINE_HALF_SIZE = 0.12


def _crop_around(frac_x: float, frac_y: float):
    """Box (x1, y1, x2, y2), as fractions of the full image, centered on
    a normalized point and clamped to stay within the image."""
    x1 = max(0.0, frac_x - REFINE_HALF_SIZE)
    y1 = max(0.0, frac_y - REFINE_HALF_SIZE)
    x2 = min(1.0, frac_x + REFINE_HALF_SIZE)
    y2 = min(1.0, frac_y + REFINE_HALF_SIZE)
    return x1, y1, x2, y2


# Proportional pad added to a crop_hint box, as a fraction of the box's
# OWN size in each dimension - scales with a bigger box instead of always
# using the same fixed margin.
PAD_PROPORTION = 0.5
# Floor on that padding, as a fraction of the FULL image - a fallback for
# when the box itself is razor-thin in one dimension (e.g. a header strip
# 72px tall out of a 2372px-tall screen, ~3%), where a purely proportional
# pad would still leave almost no surrounding visual context to anchor on.
MIN_PAD_FRACTION = 0.04

# Padding a box near the top of the screen must never reach up into the
# phone's own OS status bar - confirmed in practice (twice) to make
# vision's guess WORSE, not just include harmless extra content: a short
# crop that includes it lets the status bar's own icons (clock, wifi,
# battery...) visually dominate and get mistaken for the actual target.
# Matches the same clearance _CORNER_CROPS's own "top" buckets use.
STATUS_BAR_CLEARANCE = 0.045


def _pad_box(box):
    """Expands an exact (x1, y1, x2, y2) crop_hint box outward for
    surrounding visual context, clamped to stay within the image (and
    never above STATUS_BAR_CLEARANCE) - without this, a vision model
    asked to place a point inside a crop with (close to) zero margin
    around the actual target has nothing to anchor its estimate against."""
    x1, y1, x2, y2 = box
    pad_x = max((x2 - x1) * PAD_PROPORTION, MIN_PAD_FRACTION)
    pad_y = max((y2 - y1) * PAD_PROPORTION, MIN_PAD_FRACTION)
    return (
        max(0.0, x1 - pad_x), max(y1 - pad_y, STATUS_BAR_CLEARANCE),
        min(1.0, x2 + pad_x), min(1.0, y2 + pad_y),
    )


def _add_coordinate_grid_b64(b64_image: str) -> str:
    """Overlays a light coordinate grid (normalized 0.0-1.0 labels,
    matching the x/y fraction format VISION_SYSTEM_PROMPT asks the model
    to output) onto a screenshot before it's sent to the vision model - a
    well-established technique for improving a vision model's spatial
    grounding: reading coordinates directly off visible reference lines is
    far more reliable than estimating them purely from visual proportions
    with nothing to anchor against.

    Purely ADDITIVE to resolve_by_vision's existing crop-and-refine
    strategy (see its own docstring), not an alternative to it - this
    improves the accuracy of any SINGLE vision call's own coordinate
    guess (full image or a crop), which the existing refinement pass then
    narrows down further from there.

    Lines are deliberately thin and labels small, in a color unlikely to
    already appear as real UI chrome - visible enough for the model to
    read off coordinates without meaningfully obscuring the actual
    content being searched (a heavy overlay could itself hide the very
    element being looked for). Falls back to the UNMODIFIED original
    image on any failure (a corrupt/unexpected image format, a PIL
    hiccup) rather than raising - a vision call proceeding without the
    grid is strictly better than the whole resolve attempt failing
    outright over what's meant to be a pure accuracy improvement, not a
    hard requirement."""
    try:
        from PIL import Image, ImageDraw

        raw = base64.b64decode(b64_image)
        img = Image.open(io.BytesIO(raw)).convert("RGB")
        width, height = img.size
        draw = ImageDraw.Draw(img)

        grid_color = (255, 0, 255)  # magenta - rare in real UI chrome, reads clearly against most backgrounds
        step = 0.1
        steps = int(round(1 / step))
        for i in range(1, steps):
            frac = round(i * step, 1)
            x = int(frac * width)
            draw.line([(x, 0), (x, height)], fill=grid_color, width=1)
            draw.text((x + 2, 2), f"{frac:.1f}", fill=grid_color)
            y = int(frac * height)
            draw.line([(0, y), (width, y)], fill=grid_color, width=1)
            draw.text((2, y + 2), f"{frac:.1f}", fill=grid_color)

        buf = io.BytesIO()
        img.save(buf, format="PNG")
        return base64.b64encode(buf.getvalue()).decode("ascii")
    except Exception:
        return b64_image


async def _vision_locate(b64: str, description: str):
    """One vision call, returning (x_frac, y_frac) normalized to the image
    actually sent, or None if the model reports the element isn't visible
    in it. Bounded by VISION_CALL_TIMEOUT_S, passed through to
    achat_vision_json's own `timeout=` (see app/llm/model_client.py, which
    now owns the actual client-level timeout + retry logic this used to
    band-aid locally)."""
    result = await achat_vision_json(
        VISION_SYSTEM_PROMPT,
        f"Find this element: {description}",
        _add_coordinate_grid_b64(b64),
        schema=VISION_LOCATE_JSON_SCHEMA,
        timeout=VISION_CALL_TIMEOUT_S,
    )
    if not result.get("found"):
        return None
    return float(result["x"]), float(result["y"])


async def _vision_locate_retrying(b64: str, description: str, attempts: int = 2):
    """_vision_locate, retried up to `attempts` times on exception before
    giving up. A reasoning model (qwen3.6-27b - see VISION_MAX_TOKENS's
    own comment) can run out of its token budget mid-response - more so
    against a full, complex screenshot than a tight crop - and raise
    instead of cleanly returning found=false. How much it needs to
    "think" varies call to call, so this is a transient, retriable
    failure, not a deterministic one.

    A rate-limit error is deliberately NOT retried here and NOT swallowed
    into a `None` ("not found") result - see _RATE_LIMIT_ERRORS's own
    comment for why silently doing either was actively misleading in
    practice. It propagates straight out to the caller instead."""
    located = None
    for _attempt in range(attempts):
        try:
            located = await _vision_locate(b64, description)
            return located
        except _RATE_LIMIT_ERRORS:
            raise
        except Exception:
            located = None
    return located


async def resolve_by_vision(driver, description: str, region_hint: Optional[str] = None,
                             crop_hint: Optional[tuple] = None) -> Optional[ResolvedTarget]:
    """
    Three different priority orders, from most to least confident about
    WHERE the element is:

    - crop_hint given (x1, y1, x2, y2 fractions): the caller has an
      EXACT, verified location - not a guessed screen region, but the
      real bounds of an element resolution already matched by other
      means (e.g. step_runner.py, escalating a failed click against the
      exact element page_state's synthetic label matched - see
      _synthetic_label_for_unlabeled). Tried first, padded out a bit for
      surrounding visual context (see _pad_box) - a razor-tight crop
      with zero context can be as hard to place a point in as too little
      information the other way. Confirmed in practice to matter, not
      just be theoretically tidier: asking a screen-corner-sized region
      (_CORNER_CROPS) to find a specific icon within it, repeated 4
      times, landed in a tight, consistently-biased cluster ~50-90px
      off the icon's real position every time - a real element's own
      exact bounds removes that guesswork entirely.

    - No crop_hint but region_hint given ("top"/"bottom"): weaker than
      exact bounds - a coarse screen-edge guess, not this element's own
      measured position - but still much stronger than nothing. Also
      tried before the full image, for the same reason: trying the full
      image first let vision confidently return a coordinate elsewhere
      on the screen rather than reporting not-found, so the
      (occasionally more accurate) hinted pass never even ran.

    - Neither given (the common case: resolver.py's own tier-3 fallback,
      nothing structural has any idea where the element is beyond the
      description): tries the PLAIN description against the full
      screenshot FIRST - finding an element by what it actually looks
      like is the more general path, working for any element regardless
      of where it sits, and is exactly what a layman user's plain-
      English description ("video play button" - no backend text, no
      position) needs to work through on its own. Only falls back to a
      cropped/zoomed-in attempt - toward a corner/edge word PARSED from
      the description itself - if that comes back not-found.
    """
    if not settings.enable_vision_fallback:
        return None

    screenshot_path = await asyncio.to_thread(take_screenshot, driver, "locator_fallback")
    size = await asyncio.to_thread(driver.get_window_size)
    width, height = size["width"], size["height"]
    b64 = await asyncio.to_thread(screenshot_to_b64, screenshot_path)

    if crop_hint is not None:
        hinted_crop_box = _pad_box(crop_hint)
    elif region_hint:
        hinted_crop_box = _CORNER_CROPS.get(frozenset({region_hint}))
    else:
        hinted_crop_box = None

    async def _try_crop(crop_box):
        if crop_box is None:
            return None
        try:
            cropped_b64 = await asyncio.to_thread(_crop_screenshot_b64, screenshot_path, crop_box)
        except Exception:
            return None
        located = await _vision_locate_retrying(cropped_b64, description)
        if located is None:
            return None
        cx1, cy1, cx2, cy2 = crop_box
        lx, ly = located
        return cx1 + (cx2 - cx1) * lx, cy1 + (cy2 - cy1) * ly

    async def _try_full():
        located = await _vision_locate_retrying(b64, description)
        return located if located is not None else None

    if hinted_crop_box is not None:
        result = await _try_crop(hinted_crop_box)
        if result is None:
            result = await _try_full()
    else:
        result = await _try_full()
        if result is None:
            result = await _try_crop(_crop_box_for_description(description))

    if result is None:
        return None
    frac_x, frac_y = result

    # Refine: whichever pass found it, its answer is only as precise as a
    # small icon's coordinate can be within a comparatively large image -
    # confirmed in practice, a full-screenshot guess for a mid-screen play
    # button landed 580px off (correct on the x-axis, well off on y), with
    # no corner/edge to crop toward since the element isn't near one. So
    # take that first answer purely as a rough locale - the same "position
    # as a disambiguation aid, not the primary search" principle used
    # above, just using vision's OWN first guess as the position hint
    # instead of a screen edge - and zoom tightly into it for one refining
    # pass. Falls back to the un-refined coordinate (not a failure) if the
    # element isn't visible in that tight a crop - the first guess being
    # somewhat off doesn't mean it was uselessly wrong.
    refine_box = _crop_around(frac_x, frac_y)
    try:
        refine_b64 = await asyncio.to_thread(_crop_screenshot_b64, screenshot_path, refine_box)
        refined = await _vision_locate_retrying(refine_b64, description, attempts=1)
    except Exception:
        refined = None
    if refined is not None:
        rx1, ry1, rx2, ry2 = refine_box
        r_frac_x, r_frac_y = refined
        frac_x, frac_y = rx1 + (rx2 - rx1) * r_frac_x, ry1 + (ry2 - ry1) * r_frac_y

    x_px = int(frac_x * width)
    y_px = int(frac_y * height)
    return ResolvedTarget(method="vision", x_px=x_px, y_px=y_px)


def _crop_screenshot_b64(screenshot_path, box_fractions) -> str:
    """Crops the saved screenshot to box_fractions (x1, y1, x2, y2), each a
    0-1 fraction of the image's own width/height, and returns the result
    as base64 PNG bytes - never touches the original file."""
    from PIL import Image

    with Image.open(screenshot_path) as img:
        w, h = img.size
        x1, y1, x2, y2 = box_fractions
        box = (int(x1 * w), int(y1 * h), int(x2 * w), int(y2 * h))
        cropped = img.crop(box)
        buf = io.BytesIO()
        cropped.save(buf, format="PNG")
        return base64.b64encode(buf.getvalue()).decode("utf-8")


def capture_screenshot_for_describe(driver) -> str:
    """Synchronous screenshot capture ONLY - deliberately split out from
    describe_element_via_vision below so a caller recording a PHYSICAL
    tap (recorder.py's _locate_tap) can take the screenshot immediately,
    in its fast/timing-critical phase, before the app has any chance to
    visibly move on from the screen that was actually tapped - and defer
    the slow vision LLM call itself (which only needs this already-
    captured file, never the live device again) to later. Same race the
    rest of that module's docstrings describe for page_source; a
    screenshot is subject to the exact same timing pressure."""
    return str(take_screenshot(driver, "recorder_describe"))


async def describe_element_via_vision(screenshot_path: str, bounds_relative: dict) -> Optional[str]:
    """Reverse of resolve_by_vision: given WHERE an element already is
    (recorder.py already found it via the accessibility tree - this
    isn't a search), crop a screenshot tightly around it and ask vision
    what it visually IS. For an icon-only button, a decorative container,
    or any other element with no accessible text/hint/nearby-label at
    all, the accessibility tree has nothing to describe it with -
    producing a useless generic fallback ("the container layout", "an
    element with no visible text") - vision can actually look at it.

    screenshot_path: from capture_screenshot_for_describe, taken
    immediately after the element was found (see its docstring for why
    that timing matters) - this function itself has no such time
    pressure, since a screenshot file doesn't change after the fact.
    bounds_relative: {"x_pct", "y_pct", "w_pct", "h_pct"} - exactly what
    recorder.py's _relative_bounds already computes.

    Returns the description string, or None if vision fallback is
    disabled or the call didn't produce anything usable. Raises
    _RATE_LIMIT_ERRORS rather than swallowing them - same reasoning as
    everywhere else in this module (see its own docstring above): a
    quota exhaustion silently returning None would look identical to a
    real "nothing to see here" and hide the actual cause from the
    caller.
    """
    if not settings.enable_vision_fallback:
        return None

    x1 = bounds_relative["x_pct"]
    y1 = bounds_relative["y_pct"]
    x2 = x1 + bounds_relative["w_pct"]
    y2 = y1 + bounds_relative["h_pct"]
    box = _pad_box((x1, y1, x2, y2))

    cropped_b64 = await asyncio.to_thread(_crop_screenshot_b64, screenshot_path, box)
    result = await achat_vision_json(
        DESCRIBE_ELEMENT_VISION_PROMPT, "Describe this element.", cropped_b64,
        schema=DESCRIBE_ELEMENT_JSON_SCHEMA,
    )
    description = (result.get("description") or "").strip()
    return description or None


async def aresolve_target(driver, ref: Optional[str], ref_map: dict, description: str) -> Optional[ResolvedTarget]:
    """Fast path first (no LLM call). Only calls vision if that fails AND vision fallback is enabled."""
    if ref:
        target = resolve_by_ref(ref, ref_map)
        if target:
            return target
    return await resolve_by_vision(driver, description)


async def read_text_via_vision(driver, description: str) -> Optional[str]:
    """
    Last-resort text extraction for get_text/get_value: used when resolution
    could only find the element via vision (a coordinate, not a real element
    handle) - most often because the element genuinely has no accessible
    text/label/resource-id at all (e.g. a canvas-rendered toast), so tier
    1/2 fuzzy+LLM matching against the accessible element list had nothing
    to find. Rather than fail outright, ask the vision model to directly
    read the text off the screenshot instead of just locating it.
    Returns None if vision fallback is disabled or the element genuinely
    isn't found - never fabricates an answer.
    """
    if not settings.enable_vision_fallback:
        return None

    screenshot_path = await asyncio.to_thread(take_screenshot, driver, "read_text_fallback")
    b64 = await asyncio.to_thread(screenshot_to_b64, screenshot_path)

    result = await achat_vision_json(
        READ_TEXT_VISION_PROMPT,
        f"Find this element and report its exact text: {description}",
        b64,
        schema=READ_TEXT_JSON_SCHEMA,
    )

    if not result.get("found"):
        return None
    return result.get("text", "")