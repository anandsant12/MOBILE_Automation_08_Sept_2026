"""
Embedding-based candidate matching - an alternative to resolver.py's
_fuzzy_best_ref for tier 1 of aresolve_by_description.

WHY: fuzzy matching (thefuzz's token_sort_ratio/ratio) is pure character/
word-overlap - it has no idea "Open" and "Launch" mean the same thing, or
that "A/c" means "Account". It only measures string edit distance. That
makes it blind to any genuine paraphrase between how a step's description
is worded and how the actual on-screen label reads, even when a person
would obviously call them the same thing.

This scores candidates by MEANING instead: embeds the description and
every candidate label into vectors via Azure OpenAI's embeddings
deployment (AZURE_OPENAI_EMBEDDING_DEPLOYMENT - a text-embedding-ada-002
deployment), then ranks by cosine similarity.

Unlike the local sentence-transformers model this replaced, every call
here is a real network round trip - so two things matter that didn't
before:
  1. An in-process cache (_embedding_cache) keyed by exact string, so the
     same recurring labels (a screen's own element text tends to repeat
     across several resolve attempts within one run) are only ever
     embedded once each, not re-sent on every call.
  2. One batched embeddings.create() call per asemantic_best_ref
     invocation (the description plus every not-yet-cached candidate
     label together), never one call per candidate - the whole point of
     batching an API call.

Deliberately a SEPARATE module from resolver.py, not folded into
_fuzzy_best_ref: resolver.py calls this as one candidate signal among
others (see asemantic_best_ref's use in resolver.py) and needs to keep
working, falling back to fuzzy-only, if Azure OpenAI embeddings aren't
configured or a call fails for any reason (no AZURE_OPENAI_EMBEDDING_DEPLOYMENT
set, a network hiccup, an exhausted quota, ...) - a resolution feature
should never hard-fail because an optional accuracy upgrade couldn't
reach the API.
"""

import asyncio

from app.automation.text_utils import label_for_ref
from app.llm.model_client import aembed_texts
from config import settings

# Simple in-process cache: exact string -> embedding vector. Never evicted -
# a single test run only ever sees a small, bounded set of distinct
# descriptions/labels (one app's worth of screens), so this stays tiny for
# the life of the process. Guarded by _cache_lock so concurrent resolve
# calls (e.g. two steps racing, or a retry) don't both kick off the same
# embed request for the same brand-new string.
_embedding_cache: dict[str, list[float]] = {}
_cache_lock = asyncio.Lock()


def semantic_available() -> bool:
    """Whether Azure OpenAI embeddings are configured at all (cheap, no
    network call) - lets a caller check/report why semantic matching may
    be sitting out, rather than silently always falling back to fuzzy-only."""
    return bool(
        settings.azure_openai_api_key
        and settings.azure_openai_endpoint
        and settings.azure_openai_embedding_deployment
    )


async def _get_embeddings(texts: list[str]) -> list[list[float]] | None:
    """Returns one embedding per text, in order - reusing _embedding_cache
    for anything already seen and making ONE batched API call for
    whatever's missing. Returns None (never a partial list) if embeddings
    aren't configured or the call fails for any reason - callers must
    treat that as "no signal" and fall back to fuzzy, exactly like the old
    local-model-unavailable case."""
    if not semantic_available():
        return None
    async with _cache_lock:
        missing = [t for t in texts if t not in _embedding_cache]
        if missing:
            try:
                fresh = await aembed_texts(missing)
            except Exception:
                # Network error, bad/expired key, exhausted quota, wrong
                # deployment name, etc. - never let an embeddings hiccup
                # break resolution; the caller's fuzzy fallback carries
                # this one call instead.
                return None
            for text, vector in zip(missing, fresh):
                _embedding_cache[text] = vector
        return [_embedding_cache[t] for t in texts]


def semantic_best_ref(description: str, state_text: str, ref_map: dict):
    """Synchronous callers are gone (Azure embeddings need a network call,
    so this is async-only now) - kept as a clear pointer rather than
    silently removed, in case anything still imports the old name."""
    raise RuntimeError(
        "semantic_best_ref is now async - call `await asemantic_best_ref(...)` instead."
    )


async def asemantic_best_ref(description: str, state_text: str, ref_map: dict):
    """
    Returns (ref, score) - score on a 0-100 scale (cosine similarity * 100)
    to match resolver.py's existing FUZZY_TARGET_THRESHOLD convention, so
    the two can be compared or blended directly. Returns (None, 0) if
    embeddings aren't available/configured (see semantic_available), the
    API call fails for any reason, or ref_map is empty - callers must
    treat that as "no signal", not as "definitely no match", and fall
    back to fuzzy accordingly.

    Encodes the description and every candidate's extracted label
    (text_utils.label_for_ref - same extraction the fuzzy matcher uses, so
    the two scorers are working from identical input and are meaningfully
    comparable) in ONE batched embeddings call rather than one call per
    candidate (see _get_embeddings) - batching is what keeps this from
    turning into N network round trips per resolve attempt.
    """
    if not description or not ref_map:
        return None, 0

    refs = list(ref_map.keys())
    labels = [label_for_ref(state_text, ref) for ref in refs]

    embeddings = await _get_embeddings([description] + labels)
    if embeddings is None:
        return None, 0

    try:
        import numpy as np
        vecs = np.array(embeddings, dtype=float)
        norms = np.linalg.norm(vecs, axis=1, keepdims=True)
        norms[norms == 0] = 1  # guard a degenerate all-zero embedding, never divide by 0
        vecs = vecs / norms
        desc_vec = vecs[0]
        label_vecs = vecs[1:]
        # Vectors are normalized above, so dot product IS cosine similarity -
        # no separate norm division needed at this point.
        sims = label_vecs @ desc_vec
        best_idx = int(np.argmax(sims))
        return refs[best_idx], float(sims[best_idx]) * 100
    except Exception:
        # Never let a scoring hiccup (malformed response, shape mismatch)
        # break resolution - just report "no signal" and let the caller's
        # fuzzy fallback carry this one call.
        return None, 0
