"""
Creates and owns the underlying Appium driver session for the Android
device/emulator under test.

Two things this module specifically fixes over a naive setup:

1. **No more running `appium` in a separate terminal.** `_ensure_appium_server()`
   checks whether a server is already reachable at APPIUM_SERVER_URL; if not,
   and AUTO_START_APPIUM_SERVER=true (default), it starts one itself via
   Appium's own `AppiumService` and tears it down again on `quit()` -- but
   only if THIS process was the one that started it, so it plays nicely if
   you (or CI) already have a shared server running.

2. **Launching a specific app reliably.** Passing appPackage/appActivity as
   session capabilities is the standard way to auto-launch an app, but it's
   a single best-effort attempt with no verification -- if the target
   activity is briefly wrong, the app is slow to cold-start, or (common with
   banking/finance apps) the app itself detects automation/tampering and
   force-closes back to the home screen, that single attempt can silently
   leave you somewhere other than the target app with no error raised.
   `activate_and_verify_app()` polls `current_package` and explicitly
   re-activates on each retry, raising a clear, actionable error instead of
   silently continuing on the wrong screen.
"""

import socket
import time
from urllib.parse import urlparse

from config import settings


def _find_free_port() -> int:
    """Binds to port 0 to let the OS assign a free one, then releases it -
    the standard, race-tolerant way to reserve a port before handing it to
    a separate process (here, the MJPEG server Appium starts)."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("", 0))
        return s.getsockname()[1]


def _server_reachable(url: str, timeout: float = 1.5) -> bool:
    try:
        parsed = urlparse(url)
        host = parsed.hostname or "127.0.0.1"
        port = parsed.port or 4723
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except OSError:
        return False


def activate_and_verify_app(driver, package: str, timeout: int = 15):
    """
    Polls current_package and explicitly calls driver.activate_app(package)
    on every retry until it sticks, or raises a clear error naming the most
    likely causes if it never does. Used both right after session start
    (driver_manager) and by the explicit "Launch App" step (action_executor),
    so either path gets the same reliability instead of a single silent
    best-effort attempt.
    """
    deadline = time.time() + timeout
    last_seen = None
    while time.time() < deadline:
        try:
            current = driver.current_package
        except Exception:
            current = None
        last_seen = current
        if current == package:
            return
        try:
            driver.activate_app(package)
        except Exception:
            pass
        time.sleep(0.5)

    raise RuntimeError(
        f"Could not bring '{package}' to the foreground within {timeout}s "
        f"(last seen foreground package: '{last_seen}'). If this package name "
        f"is correct and the app is installed, the most common causes are: "
        f"(1) the app itself detected automation/root/an unlocked bootloader "
        f"and force-closed back to the home screen -- common with banking/"
        f"finance apps' anti-tamper checks; no code-level fix can override "
        f"that, so test against a non-production/staging build if one "
        f"exists, or (2) ANDROID_APP_ACTIVITY is wrong -- verify it by "
        f"opening the app manually and running "
        f"`adb shell dumpsys window | grep mCurrentFocus`."
    )


class DriverManager:
    def __init__(self, enable_mjpeg: bool = False):
        self.driver = None
        self._appium_service = None
        self.mjpeg_port = None  # set after start() if enable_mjpeg=True and platform is android
        self._enable_mjpeg = enable_mjpeg
        self._we_started_appium = False

    def start(self):
        self._ensure_appium_server()
        self.driver = self._start_android()
        return self.driver

    def _ensure_appium_server(self):
        if _server_reachable(settings.appium_server_url):
            return  # already running (you started it, or CI did) -- use it as-is

        if not settings.auto_start_appium_server:
            raise RuntimeError(
                f"No Appium server reachable at {settings.appium_server_url} and "
                f"AUTO_START_APPIUM_SERVER=false. Either start one yourself "
                f"(`appium`) or set AUTO_START_APPIUM_SERVER=true in .env."
            )

        from appium.webdriver.appium_service import AppiumService

        parsed = urlparse(settings.appium_server_url)
        host = parsed.hostname or "127.0.0.1"
        port = str(parsed.port or 4723)

        args = ["--address", host, "--port", port]
        if settings.appium_server_log_path:
            args += ["--log", settings.appium_server_log_path]

        self._appium_service = AppiumService()
        self._appium_service.start(
            args=args, timeout_ms=settings.appium_server_startup_timeout * 1000
        )
        self._we_started_appium = True

        deadline = time.time() + settings.appium_server_startup_timeout
        while time.time() < deadline:
            if _server_reachable(settings.appium_server_url):
                return
            time.sleep(0.3)

        raise RuntimeError(
            f"Appium server did not come up at {settings.appium_server_url} "
            f"within {settings.appium_server_startup_timeout}s. Check that "
            f"Node.js is installed, `npm install -g appium` has been run, and "
            f"the uiautomator2 driver is installed "
            f"(`appium driver install uiautomator2`)."
        )

    def _start_android(self):
        from appium import webdriver as appium_webdriver
        from appium.options.android import UiAutomator2Options

        options = UiAutomator2Options()
        options.device_name = settings.android_device_name
        options.automation_name = "UiAutomator2"
        options.platform_name = "Android"
        options.auto_grant_permissions = settings.android_auto_grant_permissions
        options.no_reset = settings.android_no_reset
        options.new_command_timeout = settings.android_new_command_timeout
        if settings.android_udid:
            options.udid = settings.android_udid
        if settings.android_platform_version:
            options.platform_version = settings.android_platform_version
        if settings.android_app_package:
            options.app_package = settings.android_app_package
        if settings.android_app_activity:
            options.app_activity = settings.android_app_activity
        if settings.android_app_wait_activity:
            options.app_wait_activity = settings.android_app_wait_activity

        if self._enable_mjpeg:
            # UiAutomator2's built-in live MJPEG stream - a real, documented
            # Appium capability ("live viewing / custom tools" is an
            # explicitly supported use case), not a separate tool. Only
            # requested when actually needed (recording sessions) since it
            # has a small overhead normal runs shouldn't pay. Port is
            # arbitrary/free on the host; the frontend fetches it from
            # DriverManager.mjpeg_port after start() to know where to embed
            # the stream from.
            self.mjpeg_port = _find_free_port()
            options.set_capability("mjpegServerPort", self.mjpeg_port)

        if settings.android_fast_session:
            fast = UiAutomator2Options().load_capabilities(options.to_capabilities())
            fast.set_capability("appium:skipServerInstallation", True)
            fast.set_capability("appium:skipDeviceInitialization", True)
            try:
                driver = appium_webdriver.Remote(settings.appium_server_url, options=fast)
            except Exception:
                # e.g. server APKs not on this device yet - do it the normal way once.
                driver = appium_webdriver.Remote(settings.appium_server_url, options=options)
        else:
            driver = appium_webdriver.Remote(settings.appium_server_url, options=options)

        # Session capabilities above are only a single best-effort launch
        # attempt -- verify it actually landed on the target app (with
        # retries) rather than silently trusting it and letting the agent
        # loose on whatever screen happens to be showing.
        if settings.android_app_package:
            activate_and_verify_app(
                driver, settings.android_app_package, settings.android_launch_verify_timeout
            )

        return driver

    def quit(self):
        if self.driver:
            try:
                self.driver.quit()
            except Exception:
                pass
        if self._we_started_appium and self._appium_service:
            try:
                self._appium_service.stop()
            except Exception:
                pass
