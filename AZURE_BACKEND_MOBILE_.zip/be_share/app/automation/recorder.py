"""
Recording: capture a live tap/interaction against the real device, PERFORM
it for real via action_executor (so the mirror reflects what actually
happens next), and turn it into a step dict in the EXACT SAME shape "Add a
step" already produces by hand - nothing downstream (step_runner.py,
resolver.py) can tell a recorded step apart from a typed one.

For each tap:
  1. find_element_at_point (page_state.py) - reverse lookup from the
     coordinate tapped on the live screenshot to the real element.
  2. Extract a locator (resource-id / DOM id, tier 0 in resolver.py) and a
     fingerprint (class, clickable/selected state, on-screen position -
     folded into resolver.py's tier-2 LLM prompt as corroborating
     evidence). Both normalized/relative, never raw device-specific
     values, so a recorded step stays meaningful on a different device.
  3. Ask the LLM: does this element's own text look like it will change
     between runs (a balance, a timestamp, a transaction id - vs. a fixed
     label like "Balance" or "Submit")? And: describe it in plain English,
     the same way a person would type it into "Add a step" by hand.
  4. If dynamic AND a nearby stable label can be found, emit a
     get_value_within step (scope = the label, value_description = the
     dynamic element) instead of a plain click/get_text - reusing the
     exact scoped-subtree action already built and tested for the
     Savings-vs-Expense Balance disambiguation problem, rather than
     inventing new resolution machinery for this.

A failed/uncertain LLM classification never blocks recording - it just
falls back to a plain, non-dynamic-aware step (the safer default: treating
something dynamic as static is recoverable by hand-editing later; guessing
a WRONG dynamic scope is more likely to just be wrong).
"""

import asyncio
import re
import time

from selenium.webdriver.common.by import By

from app.automation.locator_engine import _xpath_literal
from app.automation.page_state import find_element_at_point, get_state, get_state_full, _sanitize, _parse_android_bounds
from app.automation.locator_engine import (
    ResolvedTarget, capture_screenshot_for_describe, describe_element_via_vision, _RATE_LIMIT_ERRORS,
)
from app.automation import action_executor as ex
from app.llm.model_client import achat_json

# Physical-touch recording processes gestures ONE AT A TIME, in order (see
# server.py's _physical_touch_pump) - a single slow classification call
# blocks every gesture queued behind it from even starting. Confirmed in
# practice: the vision-describe call can take 10-30s on its own (a
# reasoning model occasionally returns an empty response and gets retried
# internally - see describe_element_via_vision's caller below), and a
# handful of icon-only taps in a row compounded into steps only showing
# up "2 minutes or so" later. These timeouts cap each individual LLM call
# so one slow/stuck call can only ever cost a bounded amount of the whole
# pump's throughput, never an unbounded pile-up - a timeout is treated
# exactly like any other classification failure (falls through to the
# next, cheaper option; see _classify_located).
VISION_DESCRIBE_TIMEOUT_S = 7
TEXT_CLASSIFY_TIMEOUT_S = 5

CLASSIFY_SYSTEM_PROMPT = """You are helping build a mobile/web test automation
step from a single tapped UI element's attributes. Respond with ONLY JSON, no
reasoning, no <think> tags, no prose:
{
  "description": "<how a person would describe this element in plain English, e.g. 'the Mutual Fund banner' or 'the Submit button'>",
  "is_dynamic": true|false,
  "dynamic_reason": "<short reason if is_dynamic, else empty string>"
}

is_dynamic means: this element's OWN text/value is likely to be different
the next time this screen is viewed - a balance, a running total, a
timestamp, a transaction ID, an order number, "3 items in cart", etc.
is_dynamic is FALSE for fixed labels, button text, static headings, and
navigation items ("Balance" the LABEL is not dynamic; the NUMBER next to it is).

Watch out for ordinal/position indicators that LOOK like counters but
aren't: a tab or page's own "Tab 3 of 5" / "Step 2 of 4" / "Page 1 of 10"
is a FIXED structural label describing that tab/step/page's permanent
position - it reads the same on every run, unlike a genuine dynamic count
("3 items in cart", "5 unread") which changes based on live data. A tab
being selected/highlighted is also not dynamism - is_dynamic is about
whether the TEXT differs run to run, never about interaction/selection
state. Tabs, nav items, and other "N of M" position labels are FALSE.

The description should describe what the element IS or its role, not its
current changing value - e.g. for a dynamic balance figure, describe it as
"the account balance amount", not by including today's specific number.
"""

CLASSIFY_JSON_SCHEMA = {
    "name": "element_classification",
    "schema": {
        "type": "object",
        "properties": {
            "description": {"type": "string"},
            "is_dynamic": {"type": "boolean"},
            "dynamic_reason": {"type": "string"},
        },
        "required": ["description", "is_dynamic", "dynamic_reason"],
        "additionalProperties": False,
    },
}


def _relative_bounds(el_rect: dict, screen_size: dict) -> dict:
    """Normalizes pixel bounds against the recording device's own screen
    size, so the fingerprint stays meaningful on a different device/
    resolution at replay - consistent with vision coordinates and swipe
    distances elsewhere in this pipeline, which are also relative, never
    raw pixels."""
    w = screen_size.get("width") or 1
    h = screen_size.get("height") or 1
    return {
        "x_pct": round(el_rect["x"] / w, 3),
        "y_pct": round(el_rect["y"] / h, 3),
        "w_pct": round(el_rect["width"] / w, 3),
        "h_pct": round(el_rect["height"] / h, 3),
    }


def _raw_attr(el, name: str) -> str:
    """Attribute as-is (stripped only) - unlike _sanitize, keeps embedded
    newlines, so an exact-match locator built from it still matches."""
    try:
        value = (el.get_attribute(name) or "").strip()
    except Exception:
        return ""
    # Appium returns the literal string "null" for an attribute that isn't set.
    return "" if value.lower() == "null" else value


def _extract_locator(el, platform: str) -> dict:
    """Best-effort: every stable locator we can read off the element, not
    just its id. resolve_by_locator (locator_engine.py) tries them in
    priority order, so a changed resource-id can still be found by
    content-desc/text/xpath instead of dropping straight to fuzzy/LLM.
    Empty dict (not None) if nothing stable is available - that is treated as
    "nothing to try" and falls through cleanly to description-based
    resolution, so an empty result here is never an error.

    Keys: resource_id, content_desc, text, hint, xpath (class + 2 or more
    of resource-id/content-desc/text|hint). Text is skipped for EditText
    (it's the typed value)."""
    try:
        loc: dict = {}
        resource_id = _sanitize(el.get_attribute("resource-id") or "")
        content_desc = _raw_attr(el, "content-desc")
        cls = _raw_attr(el, "className")
        is_input = "EditText" in cls
        text = "" if is_input else _raw_attr(el, "text")
        hint = _raw_attr(el, "hint") if is_input else ""
        if resource_id:
            loc["resource_id"] = resource_id
        if content_desc and len(content_desc) <= 120:
            loc["content_desc"] = content_desc
        if text and len(text) <= 80:
            loc["text"] = text
        if hint:
            loc["hint"] = hint
        conds = []
        if resource_id:
            conds.append(f"@resource-id={_xpath_literal(resource_id)}")
        if "content_desc" in loc:
            conds.append(f"@content-desc={_xpath_literal(content_desc)}")
        if "text" in loc:
            conds.append(f"@text={_xpath_literal(text)}")
        if hint:
            conds.append(f"@hint={_xpath_literal(hint)}")
        if cls and len(conds) >= 2:
            loc["xpath"] = f"//{cls}[{' and '.join(conds)}]"
        return loc
    except Exception:
        return {}


def _extract_fingerprint(el, platform: str, screen_size: dict) -> dict:
    """Structural context: class, interaction/state flags, input
    constraints, normalized position, and (Android) the hint/placeholder.
    Deliberately excludes the element's own CURRENT text/value - that's
    what the description is for, and a fingerprint is meant to keep
    meaning even after the value changes between runs.

    hint is the exception: it's Android's placeholder-text attribute,
    static regardless of what's typed into the field ("Mobile No" doesn't
    change even though the number typed into it does) - genuinely the most
    reliable single signal for disambiguating two similar input fields,
    more trustworthy than the nearby-label proximity heuristic since it's
    guaranteed by the OS to belong to this specific field, not a guess.

    password / multiline / max_text_length are captured for the same
    reason: they're stable properties OF THE FIELD, not of its contents -
    a max_text_length=6 field is very likely an OTP box and stays
    identifiable as one no matter what's currently typed in it.
    """
    try:
        bounds_relative = _relative_bounds(el.rect, screen_size)
        if platform == "android":
            cls = el.get_attribute("className") or ""
            fingerprint = {
                "class": cls,
                "clickable": el.get_attribute("clickable") or "false",
                "long_clickable": el.get_attribute("long-clickable") or "false",
                "checkable": el.get_attribute("checkable") or "false",
                "scrollable": el.get_attribute("scrollable") or "false",
                "selected": el.get_attribute("selected") or "false",
                "hint": _sanitize(el.get_attribute("hint") or ""),
                "password": el.get_attribute("password") or "false",
                "bounds_relative": bounds_relative,
            }
            # multiline/max-text-length are ONLY queryable on genuine text
            # input elements - confirmed live: UiAutomator2 raises
            # NoSuchAttributeException for both on a plain
            # android.view.View (or any other non-EditText element).
            # Almost every tapped element ISN'T an EditText, so letting
            # that propagate out of this function used to silently
            # discard the ENTIRE fingerprint - bounds_relative included -
            # for nearly every click ever recorded, not just these two
            # fields. bounds_relative in particular being lost is what
            # was silently breaking recorder.py's vision-fallback
            # trigger for icon-only elements (it needs bounds_relative to
            # know what to crop).
            if "EditText" in cls:
                try:
                    fingerprint["multiline"] = el.get_attribute("multiline") or "false"
                    fingerprint["max_text_length"] = el.get_attribute("max-text-length") or ""
                except Exception:
                    pass
            return fingerprint
        return {"tag": el.tag_name, "bounds_relative": bounds_relative}
    except Exception:
        return {}


def _element_own_text(el, platform: str) -> str:
    """Sanitized via page_state._sanitize for the same reason state_text is:
    a real content-desc CAN contain embedded newlines (seen in practice:
    "Banking\\nTab 1 of 3" on a tab control). Left raw, that newline ends up
    inside a recorded assert_text's expected value, where it can never
    match the single-line text read back at replay time."""
    try:
        if platform == "android":
            return _sanitize(el.text) or _sanitize(el.get_attribute("content-desc") or "")
        return _sanitize(el.text)
    except Exception:
        return ""


def _descendant_text(el, platform: str) -> str:
    """When a clickable element has no text/content-desc of its OWN, its
    visible LABEL very often lives on a child node instead - a standard
    Android pattern: a Button/clickable ViewGroup wrapping a plain,
    non-clickable TextView for the label. Confirmed in practice: a real
    "Proceed" button's own accessible text was empty (its label was on an
    inner TextView child), which meant _locate_tap had nothing to
    describe it with and it fell back to a generic placeholder.

    Searches the element's own SUBTREE only (not the whole screen) for
    the first descendant with non-empty text/content-desc - cheap,
    targeted, and deliberately does NOT change which element gets
    clicked (that stays whatever find_element_at_point/the actionable-
    preference already resolved) - only what's used to DESCRIBE it.
    Used only from _locate_tap's own-text fallback, not from
    _element_own_text itself: the other callers of that function (typed-
    field diffing, get_text/assert_text) need the element's OWN value,
    where pulling in an unrelated child's text would be wrong, not just
    unhelpful."""
    if platform != "android":
        return ""
    try:
        for c in el.find_elements(By.XPATH, ".//*[@text!='' or @content-desc!='']"):
            text = _sanitize(c.get_attribute("text") or c.get_attribute("content-desc") or "")
            if text:
                return text
    except Exception:
        pass
    return ""


def _element_hint(el, platform: str) -> str:
    """Android's placeholder-text attribute - like HTML's placeholder.
    Deliberately kept separate from _element_own_text: a hint describes
    what the field IS ("Mobile No"), never what's currently typed into it.
    Never use this as a stand-in for the field's actual value (e.g. for an
    assertion's expected text) - only as identifying context for the
    description."""
    if platform != "android":
        return ""
    try:
        return _sanitize(el.get_attribute("hint") or "")
    except Exception:
        return ""


async def _classify_and_describe(el, platform: str, hint: str = None, nearby_label: str = None,
                                  own_text: str = None) -> dict:
    """Returns {"description": str, "is_dynamic": bool, "dynamic_reason": str}.

    hint (Android's placeholder-text attribute) is authoritative when
    present - guaranteed by the OS to belong to this exact field, not a
    guess - and takes priority. nearby_label (see _find_nearby_label) is
    the fallback for elements with no hint concept at all (buttons,
    non-input elements). Either one solves the same problem: two similar,
    otherwise-unlabeled fields (e.g. two plain EditText inputs whose only
    content is a typed number - "85002394046" vs "8155077563" tells the
    LLM nothing to tell them apart by on its own) need SOME distinguishing
    context beyond their own current text/value to describe correctly.

    own_text: pass the caller's ALREADY-COMPUTED value (e.g.
    _locate_tap's, which also tries _descendant_text when the element's
    OWN text is empty) rather than re-deriving it here from just the
    element's own attributes - re-deriving it duplicated the extraction
    and meant a caller's descendant-text fallback never actually reached
    the classification prompt. Falls back to a fresh _element_own_text
    call only when the caller genuinely has nothing better (own_text is
    still None, not just empty - an empty string IS a real answer, "no
    text at all", and must be kept as such)."""
    if own_text is None:
        own_text = _element_own_text(el, platform)
    try:
        cls = el.get_attribute("className") if platform == "android" else el.tag_name
    except Exception:
        cls = ""

    user_prompt = f"Element text/content: {own_text!r}\nElement type: {cls}"
    if hint:
        user_prompt += (
            f"\nPlaceholder/hint text for this EXACT field (authoritative - this IS "
            f"what this specific field is for, not a guess): {hint!r}. Prefer this "
            f"over anything else when writing the description, e.g. hint='Mobile No' "
            f"-> \"the Mobile Number field\"."
        )
    elif nearby_label:
        user_prompt += (
            f"\nNearest label found near this element on screen (best guess, may or "
            f"may not actually label this field): {nearby_label!r} - if this reads "
            f"like it labels this specific field, use it to make the description "
            f"specific (e.g. 'the Account Number field') rather than generic (e.g. "
            f"'an input field') - a generic description can't be told apart from "
            f"another similar field elsewhere on the same screen."
        )

    try:
        result = await achat_json(CLASSIFY_SYSTEM_PROMPT, user_prompt, schema=CLASSIFY_JSON_SCHEMA)
        return {
            "description": result.get("description") or (own_text or "the tapped element"),
            "is_dynamic": bool(result.get("is_dynamic")),
            "dynamic_reason": result.get("dynamic_reason") or "",
        }
    except Exception:
        # LLM call failed - fall back to the element's own text verbatim,
        # and assume NOT dynamic. See module docstring for why that's the
        # safer default direction to fail in.
        return {"description": own_text or "the tapped element", "is_dynamic": False, "dynamic_reason": ""}


def _find_nearby_label(driver, platform: str, el):
    """
    Best-effort heuristic search for a stable label near a tapped element -
    used two ways: (1) folded into _classify_and_describe's prompt for
    EVERY tap, so a description can distinguish two similar unlabeled
    fields by proximity to different labels; (2) as the SCOPE for a
    get_value_within step when the element turns out to be dynamic (reuses
    the existing, already-tested scoped-subtree search - page_state.
    get_state_within / step_runner.py's get_value_within dispatch - rather
    than inventing new resolution machinery here).

    Looks for nearby visible elements whose own text is short and non-
    numeric (reads like a label - "Balance" - not a value - "45,230.50"),
    positioned above or level with the tapped element (the conventional
    position for a field's label), and picks whichever is closest.
    Returns (ref, label_text, element) or None if nothing plausible was
    found - callers fall back to their non-label-aware behavior rather
    than guessing at a wrong label/scope.

    On Android, reads each candidate's bounds/text straight out of the
    attrs_map that get_state_full already builds from a single
    page_source call, rather than a live .rect/.text property fetch per
    candidate (each of which was its own HTTP round trip) - this was the
    other big contributor, alongside find_element_at_point_android, to
    every recorded tap taking a second or more.
    """
    try:
        target_rect = el.rect
    except Exception:
        return None

    attrs_map = {}
    if platform == "android":
        state_text, ref_map, attrs_map = get_state_full(driver, platform)
    else:
        state_text, ref_map = get_state(driver, platform)

    target_cx = target_rect["x"] + target_rect["width"] / 2
    target_cy = target_rect["y"] + target_rect["height"] / 2

    best = None
    best_distance = None
    for ref, candidate_el in ref_map.items():
        try:
            attrs = attrs_map.get(ref)
            if attrs:
                bounds = _parse_android_bounds(attrs.get("bounds") or "")
                if not bounds:
                    continue
                x1, y1, x2, y2 = bounds
                r = {"x": x1, "y": y1, "width": x2 - x1, "height": y2 - y1}
                text = (attrs.get("text") or attrs.get("content-desc") or "").strip()
            else:
                r = candidate_el.rect
                text = (candidate_el.text or "").strip()
            if not text or len(text) > 40:
                continue
            if re.fullmatch(r"[\d,.\s₹$€£%-]+", text):
                continue  # looks numeric/currency -- not a label
            if r["y"] > target_rect["y"] + target_rect["height"]:
                continue  # label should be above/level, not clearly below
            cx = r["x"] + r["width"] / 2
            cy = r["y"] + r["height"] / 2
            distance = ((cx - target_cx) ** 2 + (cy - target_cy) ** 2) ** 0.5
            if best_distance is None or distance < best_distance:
                best_distance = distance
                best = (ref, text, candidate_el)
        except Exception:
            continue

    return best


def _is_editable_element(el, platform: str) -> bool:
    """Deterministic, non-LLM check for 'is this a text input' - same
    signal page_state.py's own _is_actionable already uses for Android
    (EditText in the class name), extended with a web equivalent. Used to
    decide, right after a plain tap, whether to prompt for text instead of
    silently recording a bare click - see peek_tap()."""
    try:
        if platform == "android":
            cls = el.get_attribute("className") or ""
            return "EditText" in cls
        tag = (el.tag_name or "").lower()
        if tag in ("input", "textarea"):
            return True
        return (el.get_attribute("contenteditable") or "").lower() == "true"
    except Exception:
        return False


_ROOT_LIKE_MIN_COVERAGE = 0.95   # fraction of screen width/height
_ROOT_LIKE_RETRY_DELAY_S = 0.1
_LOCATE_RETRY_ATTEMPTS = 2


def _looks_incomplete_root(el, platform: str, screen_size: dict) -> bool:
    """A non-actionable element whose bounds cover essentially the whole
    screen is a very unlikely genuine tap target - nobody means to tap
    "the screen's root container". Far more likely: the accessibility
    tree simply hadn't finished rendering real content yet at the exact
    instant it was queried - confirmed in practice on an animated
    onboarding screen (a real "Proceed" tap resolved to a non-clickable,
    100%x100% FrameLayout - the screen's bare root, nothing else had
    rendered into the tree yet). find_element_at_point_android's
    smallest-match logic has nothing better to fall back to than the
    root itself when that happens."""
    try:
        if platform != "android":
            return False
        if el.get_attribute("clickable") == "true" or el.get_attribute("long-clickable") == "true" \
                or el.get_attribute("checkable") == "true":
            return False
        rect = el.rect
        w_frac = rect["width"] / (screen_size.get("width") or 1)
        h_frac = rect["height"] / (screen_size.get("height") or 1)
        return w_frac >= _ROOT_LIKE_MIN_COVERAGE and h_frac >= _ROOT_LIKE_MIN_COVERAGE
    except Exception:
        return False


def _locate_tap(driver, platform: str, x: int, y: int) -> dict:
    """The FAST half of element inspection: element lookup plus every-
    thing derived from reading ITS current attributes - no LLM call. Only
    talks to the device, never an LLM, so this is the part that MUST run
    immediately after a tap - see _inspect_tap's docstring for why that
    timing matters at all for physical-touch recording specifically.

    Synchronous on purpose (no `await` inside) - keeps the caller in
    control of exactly when this runs relative to anything else, rather
    than an event-loop scheduling decision. describe_physical_gesture
    below runs this via asyncio.to_thread for that reason - a threaded
    sleep (see the incomplete-tree retry below) only blocks that worker
    thread, never the event loop.

    Raises a plain, clear RuntimeError if nothing was found at that point
    (a mis-tap, or coordinates that landed on empty space)."""
    screen_size = driver.get_window_size()
    el = find_element_at_point(driver, x, y, platform)

    # Retry a couple of times, short delay each, when the tree looks
    # like it hadn't finished rendering yet - covers BOTH ways that
    # showed up in practice: find_element_at_point returning NOTHING at
    # all (nothing in the tree overlapped the tap point yet - a real
    # "Let's get started" tap went missing entirely this way), and
    # returning only the screen's bare root (see _looks_incomplete_root).
    # Same underlying cause either way, just manifesting as a different
    # fraction of the tree existing at that exact instant. Negligible
    # next to the LLM classification time this whole function exists to
    # stay ahead of; never applied on an ordinary successful lookup.
    attempts = 0
    while (el is None or _looks_incomplete_root(el, platform, screen_size)) and attempts < _LOCATE_RETRY_ATTEMPTS:
        time.sleep(_ROOT_LIKE_RETRY_DELAY_S)
        el = find_element_at_point(driver, x, y, platform)
        attempts += 1

    if el is None:
        raise RuntimeError(f"No element found at ({x}, {y}) - try tapping more precisely on the target.")

    locator = _extract_locator(el, platform)
    fingerprint = _extract_fingerprint(el, platform, screen_size)
    hint = _element_hint(el, platform)
    nearby = _find_nearby_label(driver, platform, el)
    own_text = _element_own_text(el, platform) or _descendant_text(el, platform)
    is_editable = _is_editable_element(el, platform)
    try:
        cls = el.get_attribute("className") if platform == "android" else el.tag_name
    except Exception:
        cls = ""

    # No own text/hint at all -> the ordinary LLM classification (which
    # leans on those two strings) has NOTHING solid to work with and
    # would just produce a generic placeholder ("the container layout",
    # "an element with no visible text") - confirmed in practice to be
    # most of what a real recording session's icon-only/unlabeled taps
    # were coming back as. Deliberately NOT also requiring nearby-label to
    # be empty here - nearby-label is a best-effort proximity GUESS (see
    # _find_nearby_label's own docstring: "may or may not actually label
    # this field"), reliable enough to help disambiguate two similar
    # INPUT FIELDS but not to justify skipping vision for a genuinely
    # icon-only button just because some unrelated text happened to sit
    # nearby on screen.
    #
    # Screenshot it NOW, in this same fast phase, for _classify_located to
    # hand to vision later - a screenshot is subject to the exact same
    # "must be taken before the screen moves on" timing as everything
    # else in this function (see this function's own docstring), even
    # though the vision LLM CALL itself is safe to defer.
    screenshot_path = None
    if not (own_text or hint):
        try:
            screenshot_path = capture_screenshot_for_describe(driver)
        except Exception:
            screenshot_path = None  # best-effort - falls through to the ordinary text-based classify

    return {
        "el": el, "locator": locator, "fingerprint": fingerprint, "hint": hint,
        "nearby": nearby, "own_text": own_text, "is_editable": is_editable, "cls": cls,
        "screenshot_path": screenshot_path,
        "bounds_relative": fingerprint.get("bounds_relative"),
    }


async def _classify_located(loc: dict, platform: str) -> dict:
    """The SLOW half: the actual LLM classification call. Deliberately
    takes only the strings/screenshot _locate_tap already extracted -
    never touches the live element or the device again - so it's safe to
    run any time after _locate_tap, no matter how long the LLM call takes
    or how much the screen has changed by the time it returns.

    When _locate_tap found no text/hint/nearby-label at all, it will have
    stashed a screenshot instead (loc["screenshot_path"]) - vision gets
    tried first in that case, since the ordinary text-based classify
    below has nothing to work with and would just produce a generic
    placeholder. Falls through to the ordinary path if vision itself
    doesn't come back with anything usable (fallback disabled, or a
    genuinely blank crop) - same "never leave a step half-built" spirit
    as everywhere else in this module."""
    nearby_label_text = loc["nearby"][1] if loc["nearby"] else None

    if loc.get("screenshot_path") and loc.get("bounds_relative"):
        try:
            vision_description = await asyncio.wait_for(
                describe_element_via_vision(loc["screenshot_path"], loc["bounds_relative"]),
                timeout=VISION_DESCRIBE_TIMEOUT_S,
            )
        except _RATE_LIMIT_ERRORS:
            raise  # a quota exhaustion deserves to surface, not be silently absorbed - see locator_engine.py's own docstring
        except (Exception, asyncio.TimeoutError):
            # The underlying reasoning model occasionally returns an
            # empty response (confirmed - "Empty response from model
            # after stripping reasoning") and/or runs long, unrelated to
            # whether the element itself was describable. Fall through
            # to the ordinary text-based classify below rather than
            # losing the step entirely OR blocking every later gesture
            # queued behind this one - see VISION_DESCRIBE_TIMEOUT_S.
            vision_description = None
        if vision_description:
            return {
                "description": vision_description,
                "is_dynamic": False,  # no text to have ever compared across runs - an icon-only element is never meaningfully "dynamic"
                "dynamic_reason": "",
                "is_editable": loc["is_editable"],
            }

    try:
        classification = await asyncio.wait_for(
            _classify_and_describe(
                loc["el"], platform, hint=loc["hint"], nearby_label=nearby_label_text, own_text=loc["own_text"],
            ),
            timeout=TEXT_CLASSIFY_TIMEOUT_S,
        )
    except asyncio.TimeoutError:
        # Same bounded-latency reasoning as the vision timeout above -
        # _classify_and_describe already has its own internal fallback
        # for an outright LLM failure, but that can't help against a
        # call that's simply still running; this is the same safe
        # fallback it would have produced on failure, just triggered by
        # a deadline instead.
        classification = {"description": loc["own_text"] or "the tapped element", "is_dynamic": False, "dynamic_reason": ""}
    classification["is_editable"] = loc["is_editable"]
    return classification


async def _inspect_tap(driver, platform: str, x: int, y: int):
    """Shared lookup used by every record_* entry point below: composes
    _locate_tap (element + its attributes) and _classify_located (the LLM
    description) back-to-back. Fine for every caller EXCEPT physical-
    touch recording: those all inspect BEFORE anything has happened on
    the device yet (peek_tap/record_tap perform the action only after
    this returns), so there's no race to worry about - the screen is
    still showing whatever was on it when the request arrived, and stays
    that way until this function's own caller acts.

    Physical-touch recording is the opposite: the tap has ALREADY
    happened for real by the time this could even be called, so calling
    _locate_tap late (e.g. after an LLM call, a slow HTTP poll cycle) risks
    finding whatever's on the NEXT screen instead of the one that was
    actually tapped. See describe_physical_gesture below, which calls
    _locate_tap directly and immediately instead of going through here.

    Purely a lookup - performs NO action on the device. Raises a plain,
    clear RuntimeError if nothing was found at that point (a mis-tap, or
    coordinates that landed on empty space)."""
    loc = _locate_tap(driver, platform, x, y)
    classification = await _classify_located(loc, platform)
    return loc["el"], loc["locator"], loc["fingerprint"], classification, loc["own_text"], loc["nearby"]


async def peek_tap(driver, platform: str, x: int, y: int):
    """Inspection-only - same element lookup record_tap uses, but performs
    NO action on the device. Lets the frontend ask 'what's here?' before
    doing anything for real, so a freeform tap can be routed correctly:
    editable field -> show a text prompt; anything else -> tap
    immediately. Without this, distinguishing the two would mean either
    tapping twice (once to look, once for real) or guessing blind.

    Returns the same tuple _inspect_tap does (not just a summary) - the
    caller (server.py) caches it and, if the very next action at this
    exact point is a tap/type, reuses it via execute_tap()/execute_type()
    instead of inspecting (and re-classifying via the LLM) a second time."""
    return await _inspect_tap(driver, platform, x, y)


def _as_target(el) -> ResolvedTarget:
    """Wraps a raw element the recorder already found (via
    find_element_at_point) as a ResolvedTarget, so it can be handed
    straight to action_executor's already-tested click/type_text -
    exactly the same code path a replayed step uses, rather than a
    second, separate way of tapping/typing that only exists for
    recording."""
    target = ResolvedTarget(method="ref")
    target.element = el
    return target


def _build_element_step(action: str, locator: dict, fingerprint: dict, classification: dict,
                         nearby, extra_params: dict = None) -> dict:
    """Shared step-dict shape for every action that resolves to a plain
    element (click/long_press today) - extracted out of execute_tap so
    describe_physical_gesture (physical-touch recording, below) can build
    the exact same step shape without also calling execute_tap's
    ex.click() - the tap already happened for real on the device there,
    performing it again would be a second, spurious action.

    "click" alone gets the dynamic-value rewrite into get_value_within
    (see execute_tap's docstring) - a long_press on a dynamic value isn't
    a meaningful thing to have happen at all, so it's left as a plain
    long_press step rather than silently reinterpreted."""
    if action == "click" and classification["is_dynamic"] and nearby:
        _ref, label_text, _label_el = nearby
        return {
            "action": "get_value_within",
            "target_description": label_text,
            "params": {"value_description": classification["description"]},
        }
    return {
        "action": action,
        "target_description": classification["description"],
        "params": dict(extra_params or {}),
        "locator": locator,
        "fingerprint": fingerprint,
    }


async def locate_at(driver, platform: str, x: int, y: int) -> dict:
    """Thin async wrapper running _locate_tap off the event loop. Exists
    for server.py's physical-touch pump to call at TOUCH-DOWN time
    (PhysicalTouchListener.touch_starts), rather than waiting for the
    gesture to complete (locate_physical_gesture below, which runs the
    same _locate_tap but at touch-UP time instead).

    Down-time is strictly earlier and strictly safer: Android only fires
    a click - and whatever screen transition follows it - on the UP
    event, never on DOWN, so a lookup started here is GUARANTEED to run
    before the app has any chance to react, no matter how fast that
    reaction turns out to be. Confirmed necessary in practice: even
    starting the lookup at touch-UP (immediately, with no frontend-poll
    delay in between) still occasionally lost the race on a screen that
    transitions fast enough - down-time is the only trigger that's
    guaranteed correct by Android's own event ordering, not just "fast
    enough in practice"."""
    return await asyncio.to_thread(_locate_tap, driver, platform, x, y)


async def locate_physical_gesture(driver, platform: str, gesture) -> dict:
    """The FAST half of physical-touch recording, keyed off touch-UP
    (gesture completion) rather than touch-DOWN. MUST be called
    immediately after a gesture comes off PhysicalTouchListener.gestures -
    before the app has any chance to visibly move on from the screen the
    gesture actually happened on. Prefer locate_at (above) when possible -
    it starts at touch-DOWN instead, which closes the race even tighter;
    this remains the fallback for describe_physical_gesture and for a
    completion that arrives with no matching touch-down signal.

    Why this split exists at all: a physical tap already happened for
    real on the device by the time ANYTHING here could even run - unlike
    every other recording path (peek_tap/record_tap etc.), which inspect
    BEFORE performing the action, so the screen is guaranteed to still be
    showing what was tapped. Here, the real device is free to react
    (navigate, animate) the instant the finger lifts, fully independent
    of us. _locate_tap's page_source fetch is the only part of this whole
    pipeline that reads the CURRENT screen - so it's the only part that
    has to happen fast; the LLM classification in finish_physical_gesture
    only reads strings already captured by then, so it can take as long
    as it needs without the screen having moved on underneath it.

    Runs _locate_tap via asyncio.to_thread (it's a synchronous device
    call) so this coroutine yields as little as possible before making
    that call - server.py's physical-touch pump calls this the moment a
    gesture is dequeued, with nothing else awaited first.

    Returns a dict for finish_physical_gesture:
      - {"ready_step": step_dict_or_None} - a swipe (built directly, no
        element lookup needed - so no race to avoid) or a mis-tap that
        landed on empty space (dropped; see finish_physical_gesture).
      - {"loc": ..., "gesture": ...} - loc is exactly what _locate_tap
        returned, frozen at this moment, for a tap/long_press that DID
        find an element.
    """
    if gesture.kind == "swipe":
        dx, dy = gesture.x2 - gesture.x1, gesture.y2 - gesture.y1
        if abs(dx) >= abs(dy):
            direction = "right" if dx > 0 else "left"
        else:
            direction = "down" if dy > 0 else "up"
        return {"ready_step": {
            "action": "swipe",
            "target_description": f"Swipe {direction}",
            "params": {"direction": direction, "count": 1},
        }}

    try:
        loc = await asyncio.to_thread(_locate_tap, driver, platform, gesture.x1, gesture.y1)
    except RuntimeError:
        return {"ready_step": None}

    return {"loc": loc, "gesture": gesture}


async def finish_physical_gesture(platform: str, prepared: dict):
    """The SLOW half: the LLM classification call, and everything that
    depends on it. Safe to run any time after locate_physical_gesture
    already ran for this same gesture - reads only the strings already
    captured in prepared["loc"], never touches the live device again, so
    it's immune to however long the app has had to react by the time this
    finishes.

    Returns (step_dict_or_None, pending_edit_or_None):
      - swipe / long_press / a non-editable tap -> (step_dict, None)
      - a tap landing on an EDITABLE field -> (None, pending_edit) - no
        step yet, since nothing has been typed as of this tap. Caller
        (server.py) holds pending_edit and calls flush_pending_edit() once
        it knows typing has finished (the next gesture, or recording
        stop) so the eventual 'type' step carries the finished text, not
        whatever was there mid-keystroke.
      - a mis-tap that landed on empty space -> (None, None), silently
        dropped rather than surfaced as an error - a physical recording
        session has no UI to show a per-tap error to, unlike a deliberate
        click on the mirror.
    """
    if "ready_step" in prepared:
        return prepared["ready_step"], None

    loc, gesture = prepared["loc"], prepared["gesture"]
    classification = await _classify_located(loc, platform)

    if gesture.kind == "long_press":
        return _build_element_step(
            "long_press", loc["locator"], loc["fingerprint"], classification, loc["nearby"],
            {"duration_ms": int(gesture.duration_s * 1000)},
        ), None

    # Plain tap.
    if classification["is_editable"]:
        return None, {
            "el": loc["el"], "platform": platform, "locator": loc["locator"], "fingerprint": loc["fingerprint"],
            "classification": classification, "text_before": loc["own_text"],
        }

    return _build_element_step("click", loc["locator"], loc["fingerprint"], classification, loc["nearby"]), None


async def describe_physical_gesture(driver, platform: str, gesture):
    """Convenience wrapper composing locate_physical_gesture +
    finish_physical_gesture back-to-back. NOT what server.py's live
    physical-touch pump actually uses - it calls the two phases
    separately, with nothing else awaited between dequeuing a gesture and
    calling locate_physical_gesture, specifically to close the race the
    split exists for (see locate_physical_gesture's docstring). Kept
    here for any caller that doesn't need that guarantee."""
    prepared = await locate_physical_gesture(driver, platform, gesture)
    return await finish_physical_gesture(platform, prepared)


def flush_pending_edit(pending: dict):
    """Reads the pending editable element's CURRENT text and compares it
    against what it held at the moment it was tapped (see
    describe_physical_gesture). Returns a 'type' step if something was
    actually typed; None if the field was tapped but left unchanged (a
    mis-tap, or the user just looked at/tapped away from it) - dropped
    silently, same 'skip rather than guess wrong' reasoning the rest of
    this module uses (see module docstring)."""
    try:
        current = _element_own_text(pending["el"], pending["platform"])
    except Exception:
        return None
    if not current or current == pending["text_before"]:
        return None
    return {
        "action": "type",
        "target_description": pending["classification"]["description"],
        "params": {"text": current},
        "locator": pending["locator"],
        "fingerprint": pending["fingerprint"],
    }


async def record_tap(driver, platform: str, x: int, y: int) -> dict:
    """Returns a step dict in the exact shape "Add a step" produces -
    step_runner.py cannot tell a recorded step apart from a hand-built one.

    Also performs the real tap on the connected device via the same
    action_executor.click() a replay uses, so the live mirror reflects
    what just happened (next screen, opened menu, etc.) instead of only
    describing the element without the app actually responding to it.

    This runs a FRESH _inspect_tap (one LLM classification call). When the
    frontend already peeked at this exact point moments ago (the normal
    freeform-tap flow), server.py's /api/recording/action reuses that
    peek's result via execute_tap() below instead of calling this - so a
    plain tap only ever pays for classification once, not twice."""
    el, locator, fingerprint, classification, _own_text, nearby = await _inspect_tap(driver, platform, x, y)
    return execute_tap(driver, el, locator, fingerprint, classification, nearby)


def execute_tap(driver, el, locator, fingerprint, classification, nearby) -> dict:
    """The half of record_tap that comes after inspection - performs the
    real click and builds the step dict, given materials already known
    (either just-computed by record_tap, or reused from an earlier peek_tap
    to avoid a second LLM classification call for the same element)."""
    try:
        ex.click(driver, _as_target(el))
    except Exception as e:
        raise RuntimeError(f"Found the element but the tap itself failed: {e}")

    # No plausible nearby label found for a dynamic element -> falls
    # through to a plain click below rather than guessing at a wrong
    # scope; still a normal click, editable by hand afterward if needed.
    return _build_element_step("click", locator, fingerprint, classification, nearby)


async def record_swipe(driver, platform: str, x1: int, y1: int, x2: int, y2: int) -> dict:
    """Performs the real drag the user made (via the same raw coordinate
    primitive action_executor's own swipe() uses internally), then emits a
    step in the exact schema the standalone "Swipe" action already uses
    (direction + count) - deliberately NOT a percent/distance derived from
    the drag: step_runner.py's replay of a "swipe" step ignores any such
    value and always uses action_executor.swipe()'s fixed 0.75-of-screen
    default, so recording one here would silently do nothing on replay -
    misleading rather than useful. direction is inferred from whichever
    axis moved further, matching the same left/right/up/down convention
    action_executor.swipe() itself uses."""
    dx, dy = x2 - x1, y2 - y1
    if abs(dx) < 4 and abs(dy) < 4:
        raise RuntimeError("That drag was too short to register as a swipe - try a longer gesture.")

    if abs(dx) >= abs(dy):
        direction = "right" if dx > 0 else "left"
    else:
        direction = "down" if dy > 0 else "up"

    try:
        ex._swipe_coords(driver, x1, y1, x2, y2)
    except Exception as e:
        raise RuntimeError(f"Swipe gesture failed: {e}")

    return {
        "action": "swipe",
        "target_description": f"Swipe {direction}",
        "params": {"direction": direction, "count": 1},
    }


async def record_type(driver, platform: str, x: int, y: int, text: str) -> dict:
    """Same element lookup as record_tap, emits a 'type' step with the
    given text instead of a click - and, like record_tap, actually types
    it into the live field on the connected device via action_executor's
    real type_text, not just a description of the intent.

    Runs a fresh _inspect_tap; server.py reuses execute_type() with a
    cached peek instead, for the same reason record_tap does - one
    classification call per gesture, not two."""
    el, locator, fingerprint, classification, _own_text, _nearby = await _inspect_tap(driver, platform, x, y)
    return execute_type(driver, el, locator, fingerprint, classification, text)


def execute_type(driver, el, locator, fingerprint, classification, text: str) -> dict:
    """The half of record_type after inspection - performs the real typing
    and builds the step dict, given materials already known."""
    try:
        ex.type_text(driver, _as_target(el), text)
    except Exception as e:
        raise RuntimeError(f"Found the field but typing into it failed: {e}")

    return {
        "action": "type",
        "target_description": classification["description"],
        "params": {"text": text},
        "locator": locator,
        "fingerprint": fingerprint,
    }


async def record_assert(driver, platform: str, x: int, y: int, mode: str = "auto") -> dict:
    """
    mode: "auto" (default - dynamic content -> assert_visible, static
    content -> assert_text with the CURRENT live value auto-filled),
    "text" (force assert_text regardless of classification), "visible"
    (force assert_visible).
    """
    _el, _locator, _fingerprint, classification, own_text, _nearby = await _inspect_tap(driver, platform, x, y)

    use_visible = (mode == "visible") or (mode == "auto" and classification["is_dynamic"])
    if use_visible:
        return {
            "action": "assert_visible",
            "target_description": classification["description"],
            "params": {},
        }

    return {
        "action": "assert_text",
        "target_description": classification["description"],
        "params": {"expected_text": own_text},
    }


async def record_capture(driver, platform: str, x: int, y: int, variable_name: str) -> dict:
    """Explicit "Capture Value" mode: emits a get_text step with store_as
    set, so a LATER Assert step (hand-edited, or recorded with a
    {{variable_name}} placeholder typed in) can compare against it instead
    of a hardcoded value."""
    _el, _locator, _fingerprint, classification, _own_text, _nearby = await _inspect_tap(driver, platform, x, y)
    return {
        "action": "get_text",
        "target_description": classification["description"],
        "params": {"store_as": variable_name},
    }
