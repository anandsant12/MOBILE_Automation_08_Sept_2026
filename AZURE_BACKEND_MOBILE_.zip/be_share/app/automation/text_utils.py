"""
Shared text-extraction helpers for matching a plain-English description
against a state_text line. Pulled out of resolver.py (rather than left
private there) so both the fuzzy matcher and the semantic matcher can use
the exact same label extraction - keeping them scored against identical
input is what makes it meaningful to compare their scores head-to-head or
combine them.
"""

import re

_LABEL_PATTERN = re.compile(r">(.*?)</[^>]*>")


def line_for_ref(state_text: str, ref: str) -> str:
    """Returns the full state_text line for a given ref, e.g.
    "[E12] <android.widget.TextView id='...'>Open Savings/Current Account</TextView>".
    Used for diagnostic display (resolution_info's matched_text) - NOT for
    scoring, see label_for_ref below."""
    marker = f"[{ref}]"
    for line in state_text.splitlines():
        if line.strip().startswith(marker):
            return line
    return ""


def label_for_ref(state_text: str, ref: str) -> str:
    """Extracts just the human-readable label from a state_text line for
    SCORING purposes - e.g. "Open Savings/Current Account" out of
    "[E12] <android.widget.TextView id='com.sbi.yono:id/tv_open_savings_current_acct'>Open Savings/Current Account</TextView>".

    The full line (tag, class, resource-id, hint=... suffix and all) used
    to be fed directly into scoring. A long or noisy resource-id is often
    LONGER than the actual label text itself, and every extra token in it
    drags a string-similarity score down - so an on-screen label that
    matches the description word for word could still score poorly purely
    because of surrounding markup, not because of any real mismatch.

    Falls back to the raw line if no `>...<` label is found (regex miss on
    an unexpected format) - never worse than scoring the raw line, just
    not improved for that line."""
    line = line_for_ref(state_text, ref)
    match = _LABEL_PATTERN.search(line)
    return match.group(1) if match else line
