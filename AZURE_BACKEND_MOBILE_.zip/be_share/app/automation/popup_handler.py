"""
Best-effort automatic popup/consent-banner/permission-dialog dismissal.

Called before every planning step (and right after the driver starts), so
the LLM never has to reason about "close this popup first" - by the time
it sees the screen, common popups are already gone. This is intentionally
NOT LLM-based: it's a fast, cheap, deterministic pass using plain locators.
"""

from selenium.webdriver.common.by import By
from config import settings
from app.automation.page_state import parse_android_page_source, read_page_source

# Packages/resource ids that only appear when an OS-level permission/system
# dialog (the kind mobile: acceptAlert handles) is on screen.
_OS_DIALOG_MARKERS = (
    "permissioncontroller", "packageinstaller",
    "android:id/alertTitle", "android:id/parentPanel",
)

DISMISS_LABELS = {
    "accept all", "accept", "agree", "i agree", "allow", "allow all",
    "allow while using app", "while using the app", "got it", "no thanks",
    "not now", "i understand", "understood",
}
# Deliberately NOT here, even though they're common consent-banner labels
# too: "ok", "okay", "close", "dismiss", "continue", "×", "x" - these are
# also exactly the kind of bare, generic label a legitimate in-app control
# uses (a menu/panel's own Close button, a wizard's Continue button, ...).
# ANDROID_CANDIDATE_XPATH below matches EVERY clickable element on the
# whole screen with no concept of "this is actually an unwanted overlay"
# vs "this is normal app content" - it can't tell a nag popup's "OK" apart
# from a screen the flow just deliberately opened on purpose. Confirmed in
# practice: dismiss_popups runs before EVERY step (see step_runner.py/
# agent.py), including the step immediately after one that intentionally
# opened a menu/panel - if that panel had so much as a small "×"/"Close"
# affordance, the very next step's pre-check auto-clicked it and closed
# the panel before that step's own action ever ran, regardless of what
# kind of action it was (a swipe or an unrelated click) - which looked
# like "whatever step runs after opening the profile menu just closes it
# and returns home". Trading away catching a bare "OK"-only cookie banner
# for not blowing away legitimate in-flow menus is the right default here;
# add a more specific phrase back (e.g. a particular banner's exact
# wording) if a real one turns out to need it.

ANDROID_CANDIDATE_XPATH = "//*[@clickable='true']"


def _matches_dismiss_label(text: str) -> bool:
    t = (text or "").strip().lower()
    return t in DISMISS_LABELS


def _dismiss_android(driver, max_dismissals: int) -> list:
    """
    Runs before EVERY step (step_runner.py/agent.py) - so its cost in the
    overwhelmingly common case (nothing on screen actually needs
    dismissing) matters a lot more than its cost on the rare pass that
    finds something. The original implementation always paid for a live
    find_elements() scan of every clickable element on screen, THEN up to
    2 separate get_attribute() round trips PER candidate just to check its
    label - one full WebDriver round trip per attribute per element (see
    parse_android_page_source's own docstring for why that's expensive)
    - meaning a screen with 20-40 clickable elements and nothing to
    dismiss could cost 40-80+ round trips just to conclude "nothing here",
    every single step, in every run. Confirmed as a major, not marginal,
    contributor to per-step overhead: profiling real run history showed
    even actions with NO target resolution and NO LLM/vision call at all
    (a plain "Swipe" or "Back") still averaging several seconds each -
    this scan is one of the few things that runs unconditionally on every
    step regardless of action type.

    Rewritten to spend ONE page_source call (the same batched-parse
    primitive page_state.py's own element extraction uses) instead: every
    candidate's text/content-desc comes from that single parse, with zero
    per-element round trips. A live find_elements() call - and the
    corresponding real WebElement handle - is now only paid for on the
    rare pass that actually found something worth clicking, not on every
    candidate just to inspect it.

    Same external behavior as before: same candidate definition
    (clickable='true', matching ANDROID_CANDIDATE_XPATH), same
    DISMISS_LABELS matching, same one-dismissal-per-pass/max_dismissals
    loop, same return value - this only changes HOW the check is done,
    not what it decides.
    """
    closed_labels = []

    # Android runtime-permission dialogs are OS-level, not part of the app's
    # own UI tree - try the alert-style dismissal first (harmless if there's
    # no alert; with ANDROID_AUTO_GRANT_PERMISSIONS=true these mostly won't
    # appear at all since the driver pre-grants permissions at session start).
    # Only make the call when the screen dump we need anyway shows an OS-level
    # dialog. Called unconditionally (as before) it cost a ~300ms Appium round
    # trip that fails on nearly every step, and - not being a read-only
    # command - also threw away the shared page dump, forcing a fresh one.
    # If the dump can't be read, fall back to trying it like before.
    try:
        source = read_page_source(driver)
        alert_maybe_present = any(marker in source for marker in _OS_DIALOG_MARKERS)
    except Exception:
        alert_maybe_present = True
    if alert_maybe_present:
        try:
            driver.execute_script("mobile: acceptAlert")
            closed_labels.append("(native alert)")
        except Exception:
            pass

    for _ in range(max_dismissals):
        try:
            parsed = parse_android_page_source(read_page_source(driver))
        except Exception:
            break

        # Mirrors ANDROID_CANDIDATE_XPATH's own filter (clickable='true'
        # only - deliberately narrower than page_state's own "interactive"
        # definition, which also counts long-clickable/checkable/EditText/
        # Button/Spinner - staying exact here keeps this pass's candidate
        # set identical to what it was before this rewrite).
        clickable_attrs = [a for a in parsed if a.get("clickable") == "true"]

        match_index = None
        matched_label = ""
        for i, attrs in enumerate(clickable_attrs):
            label = attrs.get("text") or attrs.get("content-desc") or ""
            if _matches_dismiss_label(label):
                match_index = i
                matched_label = label
                break

        if match_index is None:
            break  # nothing to dismiss this pass - the common case, and now just ONE round trip to learn that

        # Only now touch a live element - and only the ONE we already know,
        # from the parse above, is worth clicking. find_elements() with the
        # SAME clickable='true' filter returns elements in the same
        # document order as the parsed list, so match_index lines up with
        # candidates[match_index] the same way get_android_state_full
        # aligns its own parsed attrs with its own find_elements() call.
        try:
            candidates = driver.find_elements(By.XPATH, ANDROID_CANDIDATE_XPATH)
            if match_index >= len(candidates):
                break  # screen changed between the parse and this call - bail rather than risk clicking the wrong element
            candidates[match_index].click()
            closed_labels.append(matched_label.strip())
        except Exception:
            break

    return closed_labels


def dismiss_popups(driver, platform: str, max_dismissals: int = 3) -> list:
    """Try to close up to `max_dismissals` popups. Returns the list of
    labels actually clicked (empty if none) - kept, not just a count, so a
    caller that suspects this closed something it shouldn't have (see
    DISMISS_LABELS's own comment on the risk of that) has concrete evidence
    of exactly what happened instead of having to guess. Never raises - a
    failed dismissal attempt should never break the agent run."""
    if not settings.popup_dismiss_enabled:
        return []
    try:
        return _dismiss_android(driver, max_dismissals)
    except Exception:
        return []


# Full-screen "you're logged out, nothing else on this screen is real
# anymore" interstitials - deliberately NOT in DISMISS_LABELS/auto-
# dismissed like an ordinary cookie banner or permission dialog: tapping
# its OK button doesn't return you to where you were, it drops you back to
# a login/splash screen, so the rest of an in-progress flow can never
# succeed from here regardless of how well it's dismissed. Detected, not
# auto-handled, so a resolution failure caused by one of these produces an
# accurate, honest error ("the app logged itself out mid-run") instead of
# a misleading "could not locate <target>" that looks like a locator/
# matching bug when the target was never findable in the first place -
# confirmed in practice: a click_within step failed with exactly that
# generic message while the actual screen (visible in the saved failure
# screenshot) was entirely covered by this app's own "Session Expired"
# dialog ("Your session has expired. Please login again to continue using
# the app.").
SESSION_EXPIRED_PATTERNS = (
    "session expired",
    "session has expired",
    "session timed out",
    "session timeout",
    "please login again",
    "please log in again",
    "login again to continue",
)


def detect_session_expired(state_text: str) -> bool:
    """True if state_text (from page_state.get_state/get_state_full/
    get_state_within) looks like a session-expiry interstitial is covering
    the screen - a best-effort text match, not a guarantee. Extend
    SESSION_EXPIRED_PATTERNS above if your app's actual wording differs."""
    if not state_text:
        return False
    lowered = state_text.lower()
    return any(p in lowered for p in SESSION_EXPIRED_PATTERNS)


# Android's own system-level "Circle to Search"/Assistant gesture overlay -
# a SEPARATE system window drawn on top of whatever app is running, not
# part of the app's own UI at all. Same category of problem as
# SESSION_EXPIRED_PATTERNS above (a resolution failure caused by this looks
# exactly like an ordinary "could not locate" locator/matching bug, with no
# hint that the real screen is temporarily inaccessible underneath a
# foreign overlay) - confirmed in practice: a click on "Messages settings"
# failed to resolve while the on-device screenshot showed this exact
# overlay ("Circle or tap anywhere to search") covering the whole screen,
# even though "Messages settings" was still visibly painted through it.
# Most likely trigger: "Messages settings" sits right at the bottom of a
# scrollable panel, close to the device's own system navigation/gesture
# area - a tap or swipe landing in that reserved strip can be interpreted
# as a system gesture (e.g. press-and-hold near the home button/nav area)
# instead of reaching the app underneath.
SYSTEM_OVERLAY_PATTERNS = (
    "circle or tap anywhere to search",
    "circle to search",
)


def detect_system_overlay(state_text: str) -> bool:
    """True if state_text looks like a system-level overlay (e.g. Android's
    Circle to Search/Assistant gesture UI) is covering the screen, drawn on
    top of the app rather than being part of it - a best-effort text match,
    not a guarantee. Extend SYSTEM_OVERLAY_PATTERNS above for other known
    system overlays (e.g. a different OEM's equivalent gesture UI)."""
    if not state_text:
        return False
    lowered = state_text.lower()
    return any(p in lowered for p in SYSTEM_OVERLAY_PATTERNS)