"""
Turns a resolved action into a real driver interaction. Purely mechanical
-- no decision-making happens here (that's planner.py/resolver.py's job).

Function names here match what step_runner.py's _dispatch() calls by name
(ex.click, ex.launch_app, ex.type_text, ...) -- that mapping used to be
broken (step_runner called names like `click`/`launch_app` that this file
never defined, only `execute_click`/etc for the older single-goal agent
loop), so every dispatched action threw AttributeError. This file is now
the single source of truth for action names; agent.py imports from here too.

Android/Appium only -- every action here is a real touch gesture or a
native-accessibility-tree interaction. Appium's Python client is itself
built on top of Selenium's WebDriver protocol (AppiumWebDriver subclasses
selenium.webdriver.remote.webdriver.WebDriver), which is why a handful of
Selenium imports (By, the W3C ActionBuilder/PointerInput primitives,
StaleElementReferenceException) are still used below -- they're the
underlying transport Appium itself is built on, not browser automation.
"""

import base64
import time

from selenium.common.exceptions import StaleElementReferenceException

from app.automation.locator_engine import ResolvedTarget
from app.automation.page_state import read_page_source
from app.automation.driver_manager import activate_and_verify_app
from config import settings

_SPEED_DURATION_MS = {"slow": 900, "normal": 400, "fast": 200}
# Separate mapping for Appium's OWN 'mobile: swipeGesture'/'mobile: scrollGesture'
# commands, which take a "speed" argument in pixels/second, not a duration -
# used by scroll()'s primary gesture path (see its own comment). Deliberately
# well below Appium's own default (routinely several thousand px/s, scaled by
# display density) for "slow"/"normal": a fast device-driven swipe is exactly
# what a real Appium support thread ("Motion Gestures Swipe skips over the
# area I want to reach") reports skipping straight past the target area, the
# same failure this whole speed-control effort exists to avoid.
_GESTURE_SPEED_PX_PER_S = {"slow": 800, "normal": 2000, "fast": 4000}

# Standard Android keyevent codes (adb/UiAutomator2 press_keycode).
_ANDROID_KEYCODE_MAP = {
    "enter": 66, "return": 66, "back": 4, "home": 3, "tab": 61,
    "escape": 111, "backspace": 67, "delete": 112, "space": 62,
    "up": 19, "down": 20, "left": 21, "right": 22,
}


# ---------------------------------------------------------------------------
# Platform helpers
# ---------------------------------------------------------------------------

def _is_android(driver) -> bool:
    # Every session is Android/Appium now, but kept as a real check (reading
    # the driver's own reported capability) rather than a bare `True`, so a
    # session that somehow isn't a real Android/UiAutomator2 session fails
    # via its actual downstream errors instead of silently pretending to be one.
    try:
        return str(driver.capabilities.get("platformName", "")).lower() == "android"
    except Exception:
        return False


def verify_action_effect(driver, action_fn):
    """
    Shared verification primitive: captures driver.page_source before
    calling action_fn() (a zero-arg callable - wrap with a lambda at the
    call site), captures it again after, and returns
    (result, changed: bool | None). changed is None if page_source
    couldn't be read - callers should treat None as "unknown", never as
    "definitely no-op". page_source works on both Appium/Android and
    Selenium/web drivers, so this is not platform-gated; a caller that
    only cares about one platform decides that itself.

    This does NOT decide whether "no change" counts as a failure -
    different callers have different tolerance (a click on a toggle might
    legitimately not change page_source; a swipe search loop tolerates one
    transient flake before concluding it's hit an edge; a standalone
    swipe/scroll step wants to fail immediately). Centralizing the CAPTURE
    here - so every caller does it exactly the same, foolproof way - while
    leaving the DECISION to the caller is what stops verification from
    being something that has to be hand-rolled correctly, from scratch,
    every single time a new action is added - which is exactly how
    scroll(), _tap_coords(), and the standalone "Swipe" action each ended
    up with the same class of bug (a silently-swallowed gesture failure
    reported as success) independently, on different occasions.
    """
    try:
        # "before" may be the dump the resolver/popup check just took of
        # this same unchanged screen (see page_state.read_page_source);
        # "after" must always be a fresh read.
        before = read_page_source(driver)
    except Exception:
        before = None

    result = action_fn()

    try:
        after = read_page_source(driver, fresh=True)
    except Exception:
        after = None

    if before is None or after is None:
        return result, None
    return result, (before != after)


def _center_of(driver, target: ResolvedTarget):
    """Pixel center of a resolved target, whichever resolution method found it."""
    if target.method == "ref":
        rect = target.element.rect
        return rect["x"] + rect["width"] // 2, rect["y"] + rect["height"] // 2
    return target.x_px, target.y_px


# Reserved for Android's own system navigation bar/gesture-handle strip at
# the very bottom of the screen - not part of any app's touchable content,
# regardless of what the app nominally renders there. Confirmed in
# practice as a real failure mode, not theoretical: a swipe gesture's
# pointer-down-then-pause-before-moving (see _swipe_coords' 400ms hold)
# starting in this zone was interpreted by the OS as a long-press-and-hold
# on the home button, launching Android's Gemini/Circle-to-Search overlay
# instead of reaching the app - happened while searching for "Message
# Settings", an item sitting right at the bottom of its list, close to
# this reserved strip. Conservative (bigger than any known 3-button nav
# bar's actual height) since it's cheap insurance - almost no real app UI
# is meaningfully interactive in the very bottom few percent of the screen
# anyway, on any device.
_NAV_BAR_SAFE_MARGIN_FRACTION = 0.08


def _clamp_y_away_from_nav_bar(driver, y):
    """Pulls a Y coordinate up out of the reserved bottom strip if it falls
    inside it - a no-op for any Y that's already clear of it. Silently
    leaves y unchanged if window size can't be read, rather than failing
    the gesture over a purely defensive check.

    Prefers the driver's own live system-bar geometry ('mobile:
    getSystemBars', UiAutomator2) over the fixed % fallback below - the
    real nav bar height varies by device/OS (confirmed in practice: this
    device's is 132px, 5.57% of its 2372px screen, which the previous
    fixed 5% margin clamped JUST inside rather than clear of - a real
    element right at the boundary still got misclicked). Exact device
    geometry has no such margin-of-error problem."""
    if _is_android(driver):
        try:
            nav = driver.execute_script("mobile: getSystemBars").get("navigationBar") or {}
            if nav.get("visible") and isinstance(nav.get("y"), (int, float)):
                return min(y, int(nav["y"]) - 1)
        except Exception:
            pass
    try:
        height = driver.get_window_size()["height"]
    except Exception:
        return y
    max_y = int(height * (1 - _NAV_BAR_SAFE_MARGIN_FRACTION))
    return min(y, max_y)


def _ref_center_in_nav_bar_zone(driver, target: ResolvedTarget) -> bool:
    """True if a ref-resolved element's own center sits inside the reserved
    nav-bar strip - confirmed to happen for real, legitimate app elements
    whose accessibility bounds extend to the physical bottom edge of the
    screen (a settings-menu row that's the last item in its list, for
    example), which the accessibility tree still reports as 'displayed'.
    element.click() dispatches ACTION_CLICK, not a raw coordinate tap, but
    on this device/driver combination it was confirmed to still resolve to
    a real touch at the element's bounds center - so an element whose
    center falls in this strip is exactly as unsafe to click() as tapping
    that same coordinate directly (see _NAV_BAR_SAFE_MARGIN_FRACTION's own
    comment for the underlying gesture/overlay failure mode)."""
    if target.method != "ref":
        return False
    try:
        _, y = _center_of(driver, target)
        height = driver.get_window_size()["height"]
    except Exception:
        return False
    return y > height * (1 - _NAV_BAR_SAFE_MARGIN_FRACTION)


def _tap_coords(driver, x, y):
    y = _clamp_y_away_from_nav_bar(driver, y)
    gesture_error = None
    try:
        driver.execute_script("mobile: clickGesture", {"x": x, "y": y})
        return
    except Exception as e:
        gesture_error = e

    # Fallback for when the gesture command above failed: a proper
    # ABSOLUTE-coordinate W3C pointer-action tap. The previous fallback
    # used ActionChains.move_by_offset, which moves RELATIVE to wherever
    # the pointer currently is - an arbitrary, undefined starting position
    # in a mobile session - so it did not reliably land on (x, y) at all,
    # and any failure here was silently swallowed with no way to tell
    # whether the tap actually registered anywhere near the intended
    # target. This is the same move-to-location + pointer-down/up
    # mechanism _swipe_coords already uses correctly for absolute-
    # coordinate swiping (confirmed working), just without the drag.
    try:
        from selenium.webdriver.common.actions.action_builder import ActionBuilder
        from selenium.webdriver.common.actions.pointer_input import PointerInput

        pointer = PointerInput("touch", "finger")
        actions = ActionBuilder(driver, mouse=pointer)
        actions.pointer_action.move_to_location(x, y)
        actions.pointer_action.pointer_down()
        actions.pointer_action.pause(0.05)
        actions.pointer_action.pointer_up()
        actions.perform()
    except Exception as e2:
        raise RuntimeError(
            f"Tap failed: 'mobile: clickGesture' raised ({gesture_error}), "
            f"and the coordinate-tap fallback also raised ({e2})."
        )


def _swipe_coords(driver, x1, y1, x2, y2, move_duration_ms: int = 400, settle_ms: int = 150):
    """Raw W3C-actions coordinate swipe -- fallback for when the higher-level
    `mobile: swipeGesture` command isn't available/supported.

    move_duration_ms controls how long the actual drag from (x1,y1) to
    (x2,y2) takes. This didn't used to be true: Selenium's ActionBuilder
    gives every pointer move a fixed 250ms duration unless the builder
    itself is constructed with an explicit `duration=`, which this
    function never did - the old `duration_ms` parameter here only
    delayed the pointer-DOWN pause before the move even started, so every
    drag actually ran at a fixed 250ms regardless of what the caller
    asked for or how far it traveled. A 250ms drag across a large
    distance (a search swipe, a full-screen "Swipe" step) is fast enough
    that Android's own scroll views frequently read it as a FLING and
    keep scrolling well past where the drag itself ended, from residual
    momentum - confirmed in practice as the actual cause of a dropdown/
    picker search overshooting straight past the very option it was
    looking for, not a distance or timing issue on this function's
    caller side at all. Passing `duration=move_duration_ms` into the
    ActionBuilder below is what actually fixes that: the drag itself now
    takes as long as the caller's speed setting says it should.

    settle_ms is a short pause held at the END position, pointer still
    down, before releasing - lets the scroll view settle into its true
    rest position while a touch is still actively pinning it down (which
    cancels/dampens any fling momentum, unlike releasing while the
    gesture is still carrying velocity) rather than after, when it's too
    late to stop. Without this, code that reads screen state immediately
    after a swipe returns can be reading a still-settling, not-yet-final
    layout, or a match can be found and clicked just as the list is still
    drifting underneath it.

    Only the START point (y1) is clamped away from the system nav bar
    zone, not the end point - y1 is where the pointer goes DOWN and PAUSES
    before moving (see below), the actual risk window for the OS to
    interpret a held touch as a long-press-on-home gesture; y2 is just a
    quick release, not a hold, and swiping deliberately TOWARD the bottom
    edge (e.g. a downward swipe legitimately ending there) is normal,
    intended behavior that clamping the end point would wrongly interfere
    with. All current callers are Android-only already (this function is
    never reached from a web code path), so no platform check needed here.
    """
    y1 = _clamp_y_away_from_nav_bar(driver, y1)

    from selenium.webdriver.common.actions.action_builder import ActionBuilder
    from selenium.webdriver.common.actions.pointer_input import PointerInput

    finger = PointerInput("touch", "finger")
    actions = ActionBuilder(driver, mouse=finger, duration=move_duration_ms)
    actions.pointer_action.move_to_location(x1, y1)
    actions.pointer_action.pointer_down()
    actions.pointer_action.pause(0.05)  # brief hold so Android registers a real touch-down before dragging
    actions.pointer_action.move_to_location(x2, y2)
    if settle_ms:
        actions.pointer_action.pause(settle_ms / 1000)
    actions.pointer_action.pointer_up()
    actions.perform()


# ---------------------------------------------------------------------------
# Navigation
# ---------------------------------------------------------------------------

def go_back(driver):
    driver.press_keycode(_ANDROID_KEYCODE_MAP["back"])


# ---------------------------------------------------------------------------
# Interaction
# ---------------------------------------------------------------------------

def click(driver, target: ResolvedTarget):
    if target.method == "ref":
        if _ref_center_in_nav_bar_zone(driver, target):
            # Reposition via the same nav-bar-safe nudge scroll_to() already
            # uses for exactly this case (see its own comment - it names
            # "the Messages settings case" directly) rather than a fresh
            # gesture here: an earlier version of this fix used Appium's
            # 'mobile: swipeGesture' over the full screen, whose internally
            # -computed start point isn't clamped away from the nav-bar
            # strip either, and reproduced the very same launcher-exit
            # failure it was meant to prevent. scroll_to()'s _swipe_coords-
            # based nudge is the one primitive already confirmed safe here.
            scroll_to(driver, target)
            if _ref_center_in_nav_bar_zone(driver, target):
                # Still unsafe after scrolling (nothing left to scroll, or
                # the element didn't move) - fall back to a clamped
                # coordinate tap. Worse than a correctly-repositioned
                # click, but strictly better than element.click() with no
                # protection at all.
                x, y = _center_of(driver, target)
                _tap_coords(driver, x, y)
                return
        try:
            target.element.click()
        except StaleElementReferenceException:
            # The scroll above legitimately recreated this row (a
            # RecyclerView, unlike a plain ScrollView, replaces View
            # instances on scroll) - the original handle is gone, and
            # there's no description here to re-resolve it by. Fall back
            # to tapping where it should now be, best-effort.
            x, y = _center_of(driver, target)
            _tap_coords(driver, x, y)
    else:
        _tap_coords(driver, target.x_px, target.y_px)


def click_at_center(driver, target: ResolvedTarget):
    """
    Taps a REAL touch gesture at the target's own center, instead of
    target.element.click()'s accessibility ACTION_CLICK - a fallback for
    an element that reports clickable=true but doesn't actually respond
    to that accessibility action.

    Confirmed in practice on a header icon UiAutomator2 flags NAF ("Not
    Accessibility-Friendly"): a real, correctly-resolved element handle,
    genuinely clickable on-screen (a manual coordinate tap at the same
    spot opens the screen it should), but target.element.click() itself
    was a silent no-op - almost certainly a custom view that only handles
    raw touch events (onTouchEvent) rather than exposing a proper
    accessibility click action, which NAF-flagged elements are exactly
    the kind prone to.
    """
    x, y = _center_of(driver, target)
    _tap_coords(driver, x, y)


def double_click(driver, target: ResolvedTarget):
    if target.method == "ref":
        # Appium WebElements don't expose a native double-click action --
        # two quick real taps is the standard mobile equivalent.
        target.element.click()
        target.element.click()
    else:
        _tap_coords(driver, target.x_px, target.y_px)
        _tap_coords(driver, target.x_px, target.y_px)


def long_press(driver, target: ResolvedTarget, duration_ms: int = 800):
    x, y = _center_of(driver, target)
    try:
        driver.execute_script("mobile: longClickGesture", {"x": x, "y": y, "duration": duration_ms})
    except Exception as e:
        raise RuntimeError(f"Long press gesture failed: {e}")


def type_text(driver, target: ResolvedTarget, text: str):
    if target.method == "ref":
        try:
            target.element.click()
        except Exception:
            pass
        try:
            target.element.clear()
        except Exception:
            pass  # not all elements support clear(); harmless to skip
        target.element.send_keys(text)
    else:
        _tap_coords(driver, target.x_px, target.y_px)
        driver.execute_script("mobile: type", {"text": text})


def clear_field(target: ResolvedTarget):
    if target.method != "ref":
        raise RuntimeError("Clear needs a real element reference, not a screenshot coordinate.")
    target.element.clear()


def _is_checked(target: ResolvedTarget) -> bool:
    """Best-effort read of a checkable element's current boolean state.
    Different platforms/widgets surface it through different attributes:
    web checkboxes via is_selected(), Android CheckBox/Switch/checkable
    rows via the 'checked' (or sometimes 'selected') a11y attribute, iOS
    switches via a '0'/'1' 'value' attribute."""
    el = target.element
    checked_attr = el.get_attribute("checked")
    if checked_attr is not None and str(checked_attr).lower() in ("true", "false"):
        return str(checked_attr).lower() == "true"
    value_attr = el.get_attribute("value")
    if value_attr in ("0", "1"):
        return value_attr == "1"
    selected_attr = el.get_attribute("selected")
    if selected_attr is not None and str(selected_attr).lower() in ("true", "false"):
        return str(selected_attr).lower() == "true"
    try:
        return bool(el.is_selected())
    except Exception:
        return False


def _checkable_target(driver, target: ResolvedTarget) -> ResolvedTarget:
    """Android settings rows usually resolve to the row container, whose own
    'checked' attribute never tracks the Switch inside it - so reading it
    made set_checked believe the toggle was already in the desired state and
    silently do nothing (confirmed: both toggles still ON after steps asking
    for OFF, reported as passed). Use the row itself if it is checkable,
    otherwise its checkable descendant; if neither exists the state can't be
    read at all, so fail loudly instead of passing without checking."""
    if not _is_android(driver):
        return target
    el = target.element
    try:
        if str(el.get_attribute("checkable")).lower() == "true":
            return target
        inner = el.find_elements("xpath", ".//*[@checkable='true']")
    except Exception:
        return target  # can't inspect - keep the previous behavior
    if not inner:
        raise RuntimeError(
            "set_checked: the matched element has no checkable control (switch/checkbox) "
            "inside it, so its state can't be read - target the toggle itself."
        )
    resolved = ResolvedTarget(method="ref")
    resolved.element = inner[0]
    return resolved


def set_checked(driver, target: ResolvedTarget, desired: bool) -> bool:
    """Ensures a checkbox/switch/checkable list row ends up in the desired
    boolean state, instead of blindly clicking it (which just flips
    whatever state it happens to be in). Makes a flow idempotent and safe
    to re-run: if the target is already in the desired state (e.g. a
    contact already selected in a group-chat picker, or a settings toggle
    already ON), this is a no-op instead of silently flipping it the wrong
    way - the exact class of bug a plain 'click' step can't avoid.
    Returns True if a click was performed, False if already correct.
    """
    if target.method != "ref":
        raise RuntimeError("set_checked needs a real element reference, not a screenshot coordinate.")
    target = _checkable_target(driver, target)
    if _is_checked(target) == desired:
        return False
    click(driver, target)
    # A single fixed-delay check can race the UI: confirmed in practice -
    # a toggle read back checked=False immediately after a genuinely
    # successful click (raising a false failure here), while a screenshot
    # taken moments later, for the SAME run's next step, showed it
    # correctly ON. Retries a few times with short pauses instead of
    # trusting one read taken right after the touch event, rather than
    # weakening the check itself - it still fails loudly if the state
    # genuinely never updates.
    now_checked = None
    for _ in range(4):
        time.sleep(0.3)
        try:
            now_checked = _is_checked(target)
        except Exception:
            # Element went stale after the click (common when the click also
            # re-renders the row) - the click itself is the source of truth here.
            return True
        if now_checked == desired:
            return True
    raise RuntimeError(
        f"Tried to set checked={desired} but the element still reports "
        f"checked={now_checked} after clicking."
    )


def drag(driver, target: ResolvedTarget, dest: ResolvedTarget):
    sx, sy = _center_of(driver, target)
    dx, dy = _center_of(driver, dest)
    try:
        driver.execute_script("mobile: dragGesture", {"startX": sx, "startY": sy, "endX": dx, "endY": dy})
    except Exception as e:
        raise RuntimeError(f"Drag gesture failed: {e}")


def submit(driver, target: ResolvedTarget = None):
    """Submit the current field - there's no HTML form to submit on
    Android, so send the hardware ENTER keycode instead."""
    driver.press_keycode(_ANDROID_KEYCODE_MAP["enter"])


# ---------------------------------------------------------------------------
# Scroll / Gesture
# ---------------------------------------------------------------------------

def _find_scrollable_rect(driver):
    """Best-effort: find the actual scrollable container on screen and
    return its (left, top, width, height). A fixed header/banner (e.g. a
    profile summary at the top of a screen) isn't part of the scrollable
    content and doesn't move when swiped - confining the gesture to the
    real scrollable element's bounds avoids the swipe start/end points
    landing inside that fixed area and silently doing nothing.

    When multiple elements report scrollable=true (e.g. a horizontal image
    carousel AND the main vertical list), picks the LARGEST by area rather
    than just the first match in document order - a small nested carousel
    is a common false-positive for "the" scrollable container, and
    confining the gesture to it instead of the real list is exactly the
    kind of failure that looks like "scroll does nothing"."""
    try:
        els = driver.find_elements("xpath", "//*[@scrollable='true']")
        if not els:
            return None
        rects = [el.rect for el in els]
        best = max(rects, key=lambda r: r["width"] * r["height"])
        return best["x"], best["y"], best["width"], best["height"]
    except Exception:
        return None


def scroll(driver, platform: str, direction: str = "down", speed: str = "normal"):
    def _do_android_scroll():
        area = _find_scrollable_rect(driver)
        gesture_params = {
            "direction": direction, "percent": 0.75,
            "speed": _GESTURE_SPEED_PX_PER_S.get(speed, _GESTURE_SPEED_PX_PER_S["normal"]),
        }
        if area:
            left, top, width, height = area
            gesture_params.update({"left": left, "top": top, "width": width, "height": height})

        primary_error = None
        try:
            driver.execute_script("mobile: swipeGesture", gesture_params)
        except Exception as e:
            primary_error = e
            # Fallback: raw coordinate swipe, confined to the scrollable area
            # if one was found, else the whole screen.
            if area:
                x, y, w, h = area
            else:
                size = driver.get_window_size()
                x, y, w, h = 0, 0, size["width"], size["height"]
            start_x, start_y, end_x, end_y = x + w // 2, y + h // 2, x + w // 2, y + h // 2
            if direction == "up":
                start_y, end_y = y + int(h * 0.8), y + int(h * 0.2)
            elif direction == "down":
                start_y, end_y = y + int(h * 0.2), y + int(h * 0.8)
            elif direction == "left":
                start_x, end_x = x + int(w * 0.8), x + int(w * 0.2)
            elif direction == "right":
                start_x, end_x = x + int(w * 0.2), x + int(w * 0.8)
            try:
                _swipe_coords(driver, start_x, start_y, end_x, end_y, _SPEED_DURATION_MS.get(speed, 400))
            except Exception as e2:
                raise RuntimeError(
                    f"Scroll failed: 'mobile: swipeGesture' raised ({primary_error}), "
                    f"and the coordinate-swipe fallback also raised ({e2})."
                )
        return area

    area, changed = verify_action_effect(driver, _do_android_scroll)

    # A gesture that raises no error but doesn't change anything on
    # screen (e.g. confined to the wrong element's bounds, or there's
    # genuinely nothing left to scroll in that direction) is
    # indistinguishable from a real, successful scroll unless checked -
    # this makes that failure visible instead of silently reporting
    # "ok" and letting the caller find out later, indirectly, as
    # "element never found".
    if changed is False:
        raise RuntimeError(
            f"Scroll executed with no driver error, but nothing on screen "
            f"changed (direction={direction}"
            + (f", confined to scrollable area x={area[0]} y={area[1]} "
               f"w={area[2]} h={area[3]}" if area else ", used the full screen "
               "- no element with scrollable=true was found")
            + "). Likely causes: the confined area doesn't match the real "
              "scrollable content, or there's nothing further to scroll in "
              "that direction."
        )


def scroll_to(driver, target: ResolvedTarget):
    """
    By the time this is called, the target has ALREADY been found - it was
    resolved from get_state's element list, which by construction only
    contains elements currently on screen. So there is no legitimate case
    for a large scroll here; this used to unconditionally fire a full
    (percent=1.0) scroll in a HARDCODED "down" direction "to center it",
    regardless of which direction the search was actually swiping - which
    could (and did) scroll a just-found element straight back off screen
    in the wrong direction, immediately undoing the search that just
    found it and breaking the very next step that expected it to still
    be visible.

    Now only nudges - a small percent, and only if the element is close
    enough to a screen edge that it might be partially clipped/hard to
    tap reliably - in whichever direction actually brings it further into
    view, derived from the element's own position, not a fixed guess.
    """
    if target.method != "ref":
        return  # nothing more to do -- vision resolution already reflects the current viewport
    try:
        rect = target.element.rect
        size = driver.get_window_size()
        width, height = size["width"], size["height"]
        edge_margin = height * 0.08
        top_space = rect["y"]
        bottom_space = height - (rect["y"] + rect["height"])
        cx = width // 2
        nudge_half = 0.1  # a 0.2 "percent" nudge, expressed the same way ex.swipe() computes its own half-travel
        if top_space < edge_margin:
            # Reveal more space above the target - same full-screen-
            # centered primitive ex.swipe()'s "down" case already uses
            # (and _swipe_coords already clamps away from the bottom
            # nav zone), NOT Appium's own 'mobile: scrollGesture'
            # confined to the element's own bounds, which computes its
            # OWN internal gesture coordinates we can't see or protect.
            # Confirmed in practice as a real problem, not theoretical:
            # that confined gesture - nudging an element sitting right
            # at the screen's edge, exactly the case this branch exists
            # for - was the actual cause of a long-press-on-home
            # mis-trigger that opened Android's Gemini/Circle-to-Search
            # overlay mid-run, while search-loop swipes elsewhere (safely
            # mid-screen) never were the problem.
            _swipe_coords(driver, cx, int(height * (0.5 - nudge_half)), cx, int(height * (0.5 + nudge_half)))
        elif bottom_space < edge_margin:
            # Reveal more space below the target (the "Messages
            # settings" case: an element found right at the bottom
            # edge, closest to the reserved nav-bar zone this whole
            # rewrite exists to stay clear of).
            _swipe_coords(driver, cx, int(height * (0.5 + nudge_half)), cx, int(height * (0.5 - nudge_half)))
        # else: already comfortably within the visible area -- no nudge needed
    except Exception:
        pass  # best effort; the element was already findable on/near screen
    # No horizontal (left/right) equivalent here on purpose - see
    # _swipe_within_with_search in step_runner.py, which handles a
    # horizontally-clipped find with one more small swipe_within in the
    # same, already-established search direction instead. swipe_within
    # confines its gesture to the element's OWN bounds - fine vertically
    # since a row is normally full-width, but exactly wrong here: the whole
    # reason a horizontal nudge is needed is that the element can be a
    # sliver just a few pixels wide, leaving the gesture nowhere real to
    # travel. Confirmed in practice: that produced a TAP instead of a
    # scroll, silently clicking into "View All Products" instead of merely
    # revealing it. (The vertical case above deliberately does NOT confine
    # to the element's own bounds either, for a similar reason plus one
    # more: it used to go through Appium's own elementId-scoped
    # "mobile: scrollGesture", whose internally-computed touch coordinates
    # we can't see or protect - confirmed to be what actually triggered a
    # long-press-on-home mis-trigger for an element sitting right at the
    # screen's edge. Full-screen-centered _swipe_coords calls give the
    # gesture real travel room AND go through the one primitive that's
    # already clamped away from the reserved nav-bar zone.)


def swipe(driver, platform: str, direction: str = "left", count: int = 1, percent: float = 0.75,
          speed: str = "normal"):
    """percent controls how far each swipe travels (fraction of screen
    dimension, 0-1). Defaults to 0.75 for the standalone "Swipe" action.
    The search-while-swiping loop (_swipe_to_with_search) calls this with a
    smaller percent - a 75%-of-screen jump is large enough to leap clean
    over an element sitting just past the current fold in a single step,
    before the interim resolve check between swipes ever gets a chance to
    see it.

    speed controls the drag's actual duration (see _swipe_coords -
    "slow"/"normal"/"fast" via _SPEED_DURATION_MS), not just how far it
    travels. Precision-sensitive callers - most notably the "select"
    dropdown/picker option search in step_runner.py, which needs every
    option to actually register on screen rather than being flung past -
    should pass speed="slow" explicitly rather than relying on the
    default; a fast drag over any real distance risks Android reading it
    as a fling and overshooting past the very option being searched for.

    Goes straight to the raw W3C coordinate primitive (_swipe_coords) -
    the same one record_swipe/swipe_within/scroll's own fallback already
    use successfully - rather than trying Appium's 'mobile: swipeGesture'
    first. That gesture command is the same one scroll()'s history above
    already found to be unreliable on this device/driver combination (see
    its docstring); the difference is scroll() only trusts it behind a
    fallback-on-exception AND an after-the-fact "did the screen actually
    change" check, while this only had the fallback-on-exception half - if
    the gesture returned successfully but only moved a small fraction of
    the requested percent (observed in practice, not merely theoretical),
    nothing here ever caught it. Going straight to the primitive that's
    already proven reliable removes the unreliable path entirely instead
    of trying to detect when it's silently underperforming.

    Deliberately does NOT verify the swipe registered anything itself -
    _swipe_to_with_search already wraps its own calls to this with a more
    nuanced before/after check (tolerating one transient flake before
    concluding it's hit a genuine edge, then still trying the full-tier
    fallback). A hard fail-on-first-no-op here would short-circuit that
    two-strikes tolerance for the search loop specifically. The standalone
    "Swipe" action (nothing else watching it) gets its own verification at
    its step_runner.py dispatch site instead, so each caller's verification
    matches what that caller actually needs."""
    move_duration_ms = _SPEED_DURATION_MS.get(speed, _SPEED_DURATION_MS["normal"])
    half = percent / 2
    for _ in range(max(1, int(count))):
        size = driver.get_window_size()
        width, height = size["width"], size["height"]
        cx, cy = width // 2, height // 2
        if direction == "left":
            _swipe_coords(driver, int(width * (0.5 + half)), cy, int(width * (0.5 - half)), cy, move_duration_ms)
        elif direction == "right":
            _swipe_coords(driver, int(width * (0.5 - half)), cy, int(width * (0.5 + half)), cy, move_duration_ms)
        elif direction == "up":
            _swipe_coords(driver, cx, int(height * (0.5 + half)), cx, int(height * (0.5 - half)), move_duration_ms)
        else:
            _swipe_coords(driver, cx, int(height * (0.5 - half)), cx, int(height * (0.5 + half)), move_duration_ms)


def swipe_row(driver, y: int, direction: str = "left", percent: float = 0.2):
    """
    Left/right swipe spanning the FULL SCREEN WIDTH at a fixed vertical
    position - unlike swipe_within, deliberately NOT confined to any
    element's own bounds.

    Exists for exactly the case where that confinement backfires: once a
    carousel item (or even the carousel's own container, if that's what
    resolved for a container_description) has mostly scrolled off-screen,
    its remaining bounds can be a sliver just a few pixels wide - giving
    swipe_within nowhere real to travel. A "swipe" squeezed into that
    little room reliably registers as a TAP instead: confirmed in
    practice, it opened the tapped card's own detail screen rather than
    scrolling the carousel any further. Using the full screen width here
    always leaves real room to travel regardless of how thin the element
    that motivated the swipe has become.

    Unlike the plain swipe() action (which always targets the screen's
    vertical/horizontal CENTER), this takes an explicit y so the gesture
    can be aimed at whichever row is actually being searched - e.g. a
    carousel sitting well below screen center - rather than wherever the
    center of the whole screen happens to land.
    """
    size = driver.get_window_size()
    width = size["width"]
    half = percent / 2
    if direction == "left":
        _swipe_coords(driver, int(width * (0.5 + half)), y, int(width * (0.5 - half)), y)
    else:  # "right"
        _swipe_coords(driver, int(width * (0.5 - half)), y, int(width * (0.5 + half)), y)


def swipe_within(driver, target: ResolvedTarget, direction: str = "left", percent: float = 0.6,
                  speed: str = "normal"):
    """
    Swipe (any of left/right/up/down) CONFINED TO a specific element's own
    bounds (e.g. a carousel, or a small anchored dropdown/menu panel) - a
    plain up/down/left/right swipe anywhere on screen isn't scoped to any
    particular widget, which is wrong for anything that doesn't span the
    whole screen. Confirmed in practice as more than theoretical: a plain
    unconfined "swipe up" aimed at scrolling a small account/profile
    dropdown menu anchored near the top-right corner instead landed on the
    backdrop BEHIND it (the gesture always targets full-screen center,
    nowhere near a corner-anchored panel) - which on Android dismisses the
    dropdown outright (tap/swipe-outside-to-close), so the flow just closed
    the menu and landed back on the previous screen instead of scrolling
    it, with no error raised anywhere to explain why.

    speed behaves exactly as in ex.swipe (see its own comment) - a
    precision search loop confined to a small container is if anything
    MORE prone to overshooting past a target than a full-screen swipe
    (less travel room to begin with), so callers searching for a specific
    item should pass speed="slow".

    Deliberately uses REAL bounds (target.element.rect) plus the raw W3C
    pointer-action swipe (_swipe_coords) - NOT Appium's own gesture area-
    confinement (passing left/top/width/height to mobile: swipeGesture),
    which was found to silently do nothing on this device/driver
    combination for scroll() (see scroll()'s history above). This computes
    the confinement ourselves instead of trusting Appium's.
    """
    if target.method != "ref":
        raise RuntimeError(
            "Swipe within a carousel/container needs a real element reference, "
            "not a screenshot coordinate - vision resolution has no bounds to confine to."
        )
    move_duration_ms = _SPEED_DURATION_MS.get(speed, _SPEED_DURATION_MS["normal"])
    rect = target.element.rect
    x, y, w, h = rect["x"], rect["y"], rect["width"], rect["height"]
    half = percent / 2
    if direction in ("left", "right"):
        cy = y + h // 2
        if direction == "left":
            start_x, end_x = int(x + w * (0.5 + half)), int(x + w * (0.5 - half))
        else:  # "right"
            start_x, end_x = int(x + w * (0.5 - half)), int(x + w * (0.5 + half))
        _swipe_coords(driver, start_x, cy, end_x, cy, move_duration_ms)
    elif direction in ("up", "down"):
        cx = x + w // 2
        if direction == "up":
            start_y, end_y = int(y + h * (0.5 + half)), int(y + h * (0.5 - half))
        else:  # "down"
            start_y, end_y = int(y + h * (0.5 - half)), int(y + h * (0.5 + half))
        _swipe_coords(driver, cx, start_y, cx, end_y, move_duration_ms)
    else:
        raise RuntimeError(f"swipe_within: unknown direction '{direction}' - expected left/right/up/down.")


def pinch(driver, platform: str, mode: str = "in"):
    if platform != "android":
        raise RuntimeError("Pinch is only supported on Android.")
    gesture = "mobile: pinchCloseGesture" if mode == "in" else "mobile: pinchOpenGesture"
    try:
        driver.execute_script(gesture, {"percent": 0.75})
    except Exception as e:
        raise RuntimeError(f"Pinch gesture failed: {e}")


def zoom(driver, platform: str, mode: str = "in"):
    if platform != "android":
        raise RuntimeError("Zoom is only supported on Android.")
    gesture = "mobile: pinchOpenGesture" if mode == "in" else "mobile: pinchCloseGesture"
    try:
        driver.execute_script(gesture, {"percent": 0.75})
    except Exception as e:
        raise RuntimeError(f"Zoom gesture failed: {e}")


# ---------------------------------------------------------------------------
# Keyboard
# ---------------------------------------------------------------------------

def key_press(driver, key: str):
    key = (key or "").strip().lower()
    code = _ANDROID_KEYCODE_MAP.get(key)
    if code is None:
        raise RuntimeError(f"Unmapped Android key: '{key}'. Add it to _ANDROID_KEYCODE_MAP.")
    driver.press_keycode(code)


# ---------------------------------------------------------------------------
# Extraction
# ---------------------------------------------------------------------------

def get_text(target: ResolvedTarget) -> str:
    """Reads an element's visible text. Two behaviors that matter for
    matching against a recorded expected value:

    1. On Android, falls back to content-desc when text is empty: many
       elements (icon buttons, tabs, image-backed controls) carry their
       only human-readable label in content-desc, not text. Without this,
       get_text returned "" for them - silently breaking every assert_text
       against such an element, since recording DOES read content-desc
       (see recorder._element_own_text).
    2. Collapses embedded whitespace/newlines, exactly as recording does.
       A real content-desc can contain newlines ("Banking\\nTab 1 of 3" on
       a tab control); if only ONE side normalizes them, the recorded
       expected value and the replayed actual value can never match even
       though they're the same string.
    """
    if target.method != "ref":
        raise RuntimeError("get_text needs a real element reference, not a screenshot coordinate.")
    text = target.element.text or ""
    if not text.strip():
        try:
            text = target.element.get_attribute("content-desc") or ""
        except Exception:
            pass
    return " ".join(text.split())


def get_value(target: ResolvedTarget) -> str:
    if target.method != "ref":
        raise RuntimeError("get_value needs a real element reference, not a screenshot coordinate.")
    return target.element.get_attribute("value") or target.element.get_attribute("text") or ""


def get_attribute(target: ResolvedTarget, attribute: str) -> str:
    if target.method != "ref":
        raise RuntimeError("get_attribute needs a real element reference, not a screenshot coordinate.")
    return target.element.get_attribute(attribute) or ""


def get_current_package(driver) -> str:
    """The foreground app's package name - the mobile equivalent of a web
    "current URL" check (e.g. asserting you've navigated into a different
    app, or are still inside the one under test)."""
    try:
        return driver.current_package or ""
    except Exception:
        return ""


# ---------------------------------------------------------------------------
# Mobile / Device
# ---------------------------------------------------------------------------

def launch_app(driver, package: str = ""):
    """The direct fix for 'the agent can't find/click the app': this
    deterministically activates the app via the driver (with verification +
    retries, see driver_manager.activate_and_verify_app) instead of relying
    on the AI to click its way to opening it from the home screen."""
    if not _is_android(driver):
        raise RuntimeError("'Launch App' is Android-only.")
    package = (package or settings.android_app_package or "").strip()
    if not package:
        raise RuntimeError("No package name given and ANDROID_APP_PACKAGE isn't set either.")
    activate_and_verify_app(driver, package, settings.android_launch_verify_timeout)


def close_app(driver, package: str = ""):
    if not _is_android(driver):
        raise RuntimeError("'Close App' is Android-only.")
    package = (package or settings.android_app_package or "").strip()
    if not package:
        raise RuntimeError("No package name given and ANDROID_APP_PACKAGE isn't set either.")
    driver.terminate_app(package)


def hide_keyboard_if_shown(driver, platform: str) -> bool:
    """
    Returns True if the soft keyboard was showing and has now been
    dismissed, False otherwise (not showing, not Android, or the attempt
    failed). Used as a recovery step when resolution finds nothing: an
    open keyboard covers the lower part of the screen, and anything behind
    it is genuinely ABSENT from the accessibility tree - so a Submit
    button sitting under the keyboard is not "matched badly", it is not
    there to match at all, and no amount of better matching would find it.

    Deliberately reports whether it actually did anything, so the caller
    can decide whether a retry is even worth attempting rather than
    blindly re-running an expensive resolve.
    """
    if platform != "android":
        return False
    try:
        if not driver.is_keyboard_shown():
            return False
    except Exception:
        return False  # driver doesn't support the check - don't guess
    try:
        driver.hide_keyboard()
        return True
    except Exception:
        # Some Android keyboards/skins reject hide_keyboard(); the BACK
        # key is the conventional fallback for dismissing them.
        try:
            driver.press_keycode(_ANDROID_KEYCODE_MAP["back"])
            return True
        except Exception:
            return False


def press_back(driver):
    if not _is_android(driver):
        raise RuntimeError("'Press Back' is Android-only.")
    driver.press_keycode(_ANDROID_KEYCODE_MAP["back"])


def press_home(driver):
    if not _is_android(driver):
        raise RuntimeError("'Press Home' is Android-only.")
    driver.press_keycode(_ANDROID_KEYCODE_MAP["home"])


def set_orientation(driver, orientation: str = "portrait"):
    if not _is_android(driver):
        raise RuntimeError("'Set Orientation' is Android-only.")
    driver.orientation = "LANDSCAPE" if orientation.lower().startswith("l") else "PORTRAIT"


def open_deep_link(driver, url: str, package: str = ""):
    """Opens an Android deep link (a custom URI scheme like
    'myapp://product/123', or an App Links https:// URL the app has
    registered to handle) directly - jumping straight to whatever screen
    the app maps that URI to, skipping however many taps it would
    otherwise take to navigate there manually. Uses Appium's
    'mobile: deepLink' command, which runs the equivalent of
    `adb shell am start -a android.intent.action.VIEW -d <url> <package>`
    on the device.

    package defaults to ANDROID_APP_PACKAGE if not given explicitly -
    almost always what you want, since a deep link step is normally
    opening a link INTO the app already under test, not a different one."""
    pkg = (package or settings.android_app_package or "").strip()
    if not pkg:
        raise RuntimeError(
            "No package given and ANDROID_APP_PACKAGE isn't set in .env - a "
            "deep link needs to know which app should handle the URI."
        )
    try:
        driver.execute_script("mobile: deepLink", {"url": url, "package": pkg})
    except Exception as e:
        raise RuntimeError(
            f"Deep link '{url}' failed for package '{pkg}': {e}. Common causes: "
            f"the app has no <intent-filter> registered for this URI's scheme/host, "
            f"or the package name is wrong."
        )


def open_notifications(driver):
    """Pulls down the Android notification shade - the same gesture a user
    swiping down from the top edge would do, but via Appium's own
    dedicated command rather than a raw coordinate swipe (reliable
    regardless of exactly where the status bar sits or how tall it is)."""
    try:
        driver.execute_script("mobile: openNotifications", {})
    except Exception as e:
        raise RuntimeError(f"Opening the notification shade failed: {e}")


# ---------------------------------------------------------------------------
# WebView (hybrid-app) context switching
# ---------------------------------------------------------------------------
#
# A native Android app can embed a genuine WebView anywhere - a payment
# gateway page, a Terms & Conditions screen, an OTP verification page - and
# content genuinely RENDERED INSIDE one is invisible to the native
# accessibility tree no matter how the target description is worded; it
# structurally isn't part of that tree at all. Appium exposes this as a
# separate CONTEXT ("NATIVE_APP" vs one "WEBVIEW_<package>" per open
# WebView) - switching context changes what find_element/page_source-style
# calls operate against, chromedriver-proxied to the WebView's own real DOM
# once switched. Every existing ref-based action (click, type_text, ...)
# already works unchanged once switched - target.element.click()/
# .send_keys() are plain WebElement calls that work identically whether the
# element came from the native tree or a WebView's DOM.

def list_webview_contexts(driver) -> list:
    """All WEBVIEW_* context names currently available - a hybrid screen
    can have zero, one, or several (e.g. one per open WebView/tab within
    the app). Empty list is the common case: most screens are purely
    native with no WebView loaded at all."""
    try:
        return [c for c in (driver.contexts or []) if c != "NATIVE_APP"]
    except Exception:
        return []


def is_in_webview(driver) -> bool:
    try:
        return str(driver.context or "").upper() != "NATIVE_APP"
    except Exception:
        return False


def switch_to_webview(driver, url_contains: str = ""):
    """Switches into a WebView context, so every subsequent resolve/action
    call operates against that WebView's real HTML DOM instead of the
    native accessibility tree - see this section's own header comment for
    why that's necessary at all, not just an alternative way to reach the
    same content.

    url_contains: optional - if more than one WebView context is open,
    switches to the one whose CURRENTLY LOADED page URL contains this
    substring (checked by actually switching and reading current_url for
    each candidate - the context NAMEs alone don't reveal which page each
    one has loaded). Raises if given but nothing matches, leaving the
    driver back in native context rather than stuck on a non-matching one.
    Left blank, switches to the first WebView context found - the common
    case has exactly one open at a time anyway.

    Raises a clear error if no WebView context is available at all, rather
    than silently doing nothing - a step author should find out
    immediately that the screen they expected a WebView on doesn't have
    one loaded (yet - a short Wait step first may help), rather than have
    every following step quietly resolve against the wrong (native)
    context instead."""
    webviews = list_webview_contexts(driver)
    if not webviews:
        raise RuntimeError(
            "No WebView context is currently available - either this screen has no "
            "embedded WebView loaded, or it hasn't finished loading yet (try adding "
            "a short 'Wait' step before this one)."
        )
    if not url_contains:
        driver.switch_to.context(webviews[0])
        return
    for ctx in webviews:
        driver.switch_to.context(ctx)
        try:
            if url_contains.lower() in (driver.current_url or "").lower():
                return
        except Exception:
            continue
    driver.switch_to.context(None)  # leave back in native rather than stuck on a non-matching webview
    raise RuntimeError(f"No open WebView's URL contains '{url_contains}'. Available contexts: {webviews}")


def switch_to_native(driver):
    """Switches back to the native Android accessibility tree - the
    default/starting context for every session. Always safe to call even
    if already in native context."""
    driver.switch_to.context(None)


# ---------------------------------------------------------------------------
# Clipboard / text selection
# ---------------------------------------------------------------------------
#
# No Selenium-style Ctrl+C/Ctrl+V here - Android has no keyboard modifier
# concept to send those to. UiAutomator2 exposes the clipboard directly via
# its own 'mobile: setClipboard'/'mobile: getClipboard' commands (the same
# system clipboard the on-screen "Copy"/"Paste" long-press menu items use),
# which is what copy_text/paste_text below actually use - not a simulated
# keypress.

def select_all_text(driver, target: ResolvedTarget):
    """Selects all text in a field via a long press (opens the standard
    Android text-selection handles + context menu), then taps "Select all"
    if that specific menu item is visible. Falls back to just leaving the
    long-press selection as-is (typically already selects the surrounding
    word/line) if no "Select all" menu item appears - some keyboards/OEM
    skins don't show one, but a real cursor selection still exists at that
    point for a subsequent copy_text to act on."""
    if target.method != "ref":
        raise RuntimeError("Select All needs a real element reference, not a screenshot coordinate.")
    x, y = _center_of(driver, target)
    try:
        driver.execute_script("mobile: longClickGesture", {"x": x, "y": y, "duration": 600})
    except Exception as e:
        raise RuntimeError(f"Long press to open text selection failed: {e}")
    try:
        for el in driver.find_elements(By.XPATH, "//*[@text='Select all' or @content-desc='Select all']"):
            el.click()
            return
    except Exception:
        pass  # no "Select all" menu item found/clickable - the long-press's own selection still stands


def copy_text(driver, target: ResolvedTarget = None):
    """Copies the current text SELECTION to the clipboard. If `target` is
    given and nothing is already selected, long-presses it first (the same
    selection long_press/select_all_text opens) so there's something to
    copy; if a selection already exists (e.g. a prior select_all_text
    step), reuses it as-is rather than clobbering it with a fresh
    long-press at the field's center, which could land outside the
    existing selection's own handles and collapse it back to a single
    word.

    Reads the system clipboard back after the gesture and returns it as
    plain text (rather than just returning None on success) so a caller
    can confirm the copy actually captured real text, not silently
    succeed with an empty/stale clipboard. 'mobile: getClipboard' returns
    its content base64-encoded (confirmed in the driver's own docs, not
    an assumption) - decoded here so callers/store_as always see the
    actual readable text, never base64 gibberish."""
    if target is not None:
        try:
            already_selected = bool(driver.find_elements(
                By.XPATH, "//*[@text='Copy' or @content-desc='Copy']"
            ))
        except Exception:
            already_selected = False
        if not already_selected:
            x, y = _center_of(driver, target)
            try:
                driver.execute_script("mobile: longClickGesture", {"x": x, "y": y, "duration": 600})
            except Exception as e:
                raise RuntimeError(f"Long press to select text before copying failed: {e}")
    try:
        for el in driver.find_elements(By.XPATH, "//*[@text='Copy' or @content-desc='Copy']"):
            el.click()
            break
    except Exception:
        pass  # no explicit "Copy" menu item found - some flows copy on selection alone
    try:
        raw = driver.execute_script("mobile: getClipboard", {"contentType": "plaintext"}) or ""
    except Exception as e:
        raise RuntimeError(f"Reading the clipboard after copy failed: {e}")
    if not raw:
        return ""
    try:
        return base64.b64decode(raw).decode("utf-8", errors="replace")
    except Exception:
        return raw  # wasn't base64 after all (some driver versions vary) - return as-is rather than lose it


def set_clipboard_text(driver, text: str):
    """Sets the system clipboard directly to `text`, without needing
    anything already selected on screen first. A useful ALTERNATIVE to
    type_text for a field that mishandles programmatic send_keys (heavy
    autocomplete/auto-formatting that mangles typed input, or an app that
    blocks synthetic keyboard input outright), or for a value that's
    awkward to type character-by-character (a long token, special
    characters an on-screen keyboard buries in a sub-menu). Pair with
    paste_text to actually put it into a field - this only sets the
    clipboard, it doesn't touch any element itself.

    'mobile: setClipboard' requires its content base64-encoded (confirmed
    in the driver's own docs, not an assumption) - encoded here so the
    caller only ever deals in plain text."""
    encoded = base64.b64encode(text.encode("utf-8")).decode("ascii")
    try:
        driver.execute_script("mobile: setClipboard", {"content": encoded, "contentType": "plaintext"})
    except Exception as e:
        raise RuntimeError(f"Setting the clipboard failed: {e}")


def paste_text(driver, target: ResolvedTarget):
    """Pastes the current clipboard contents into `target`. Focuses the
    field first with a plain tap (not a long-press - a long-press opens
    the selection/context menu instead of just placing the cursor), then
    checks for an already-visible "Paste" suggestion (common right after a
    copy elsewhere in the same app puts one in a suggestion strip) before
    falling back to a long-press to open the context menu and clicking
    "Paste" there - the conventional way to reach it when no suggestion is
    already showing."""
    if target.method != "ref":
        raise RuntimeError("Paste needs a real element reference, not a screenshot coordinate.")
    try:
        target.element.click()
    except Exception as e:
        raise RuntimeError(f"Tapping the field to focus it before pasting failed: {e}")
    try:
        for el in driver.find_elements(By.XPATH, "//*[@text='Paste' or @content-desc='Paste']"):
            el.click()
            return
    except Exception:
        pass
    x, y = _center_of(driver, target)
    try:
        driver.execute_script("mobile: longClickGesture", {"x": x, "y": y, "duration": 600})
    except Exception as e:
        raise RuntimeError(f"Long press to open the Paste menu failed: {e}")
    try:
        for el in driver.find_elements(By.XPATH, "//*[@text='Paste' or @content-desc='Paste']"):
            el.click()
            return
    except Exception:
        pass
    raise RuntimeError(
        "Long-pressed the field but no 'Paste' menu item appeared - the clipboard may be "
        "empty, or this keyboard/OEM skin labels it differently."
    )
