"""
Hybrid verification.

Step 0 (deterministic, always runs when applicable, no fuzzy scoring, no
LLM/vision call at all): for "type"/"select" actions specifically, read the
resolved element's ACTUAL current value directly and compare it to exactly
what was typed/selected. This is the fast path that matters most for
speed -- a typed/selected value has a ground truth you can read with
certainty, so there's no reason to ever fuzzy-match a whole natural-language
"expected_result" sentence against page text for it (which is what was
previously landing these in the grey zone and triggering an unnecessary,
much slower vision call -- see verify_field_value()).

Step 1 (cheap, deterministic, no LLM): fuzzy string match (thefuzz) between
the "expected_result" the planner gave us and the screen's own accessibility-
tree dump - both the visible text/content-desc of every element AND the
actual current VALUES held in editable fields, plus (separately) any
currently-showing Android Toast popup. Used for actions where there's no
single field value to check directly (click, navigation, etc).

The field-values part matters a lot: a typed value in an EditText never
appears elsewhere in the screen's own rendered text (and a password field
is masked even if it did) - so without reading it directly, "does the
password field contain X" is genuinely unanswerable from text alone.
Reading it directly answers it with certainty and skips the LLM/vision
call entirely. The Toast part matters for a different reason: a Toast
popup often renders in a system-level window outside the app's own
accessibility tree, so a confirmation message ("Item added to cart") can
be genuinely invisible to the general on-screen-text check even though
it's the exact thing "expected_result" is asking about.

Step 2 (only if the fuzzy score lands in a genuine grey zone, AND
settings.enable_vision_fallback is True): ask the vision model to look at
a screenshot and judge whether the expected result actually happened. If
vision fallback is disabled, a grey-zone score is treated as a fail rather
than guessed at - the accessibility tree is the source of truth. This is
the slowest and least certain tier (a screenshot round-trip + a full
vision LLM call), so it should only ever fire for outcomes that genuinely
have no textual/accessibility-tree evidence to check against - not for
things step 0/1 could already answer.
"""

import asyncio
from thefuzz import fuzz
from selenium.webdriver.common.by import By

from app.llm.model_client import achat_vision_json
from app.automation.wait_helpers import _read_toast_text
from app.utils.screenshot import take_screenshot, screenshot_to_b64
from config import settings

VERIFY_SYSTEM_PROMPT = """You are verifying whether a UI automation step
succeeded. You'll be given the expected result and a screenshot. Respond
with ONLY JSON, no reasoning, no <think> tags, no explanation outside the
JSON: {"passed": true|false, "reasoning": "short reason"}
"""

VERIFY_JSON_SCHEMA = {
    "name": "step_verification",
    "schema": {
        "type": "object",
        "properties": {
            "passed": {"type": "boolean"},
            "reasoning": {"type": "string"},
        },
        "required": ["passed", "reasoning"],
        "additionalProperties": False,
    },
}

GREY_ZONE_LOW = 40


def verify_field_value(target, expected_value: str, platform: str) -> dict:
    """Deterministic fast path for type/select actions: read the resolved
    element's actual current value directly and compare it EXACTLY (not
    fuzzy-matched) to what was typed/selected - no LLM call, no vision call,
    no threshold to tune. Trims whitespace and ignores case (some platforms/
    widgets normalize these), but otherwise a near-miss like 'user12' vs
    'user123' correctly fails rather than scoring high enough on string
    similarity to pass. Call this instead of averify() whenever you already
    have the resolved target and the value that was just typed/selected
    into it."""
    if not expected_value:
        return {"passed": True, "method": "skipped", "score": None, "reasoning": "No value to verify."}

    if target is None or getattr(target, "method", None) != "ref":
        # Vision-only resolution has no element handle to read a value back
        # from - fall back to the caller using averify() for this one.
        return {
            "passed": False, "method": "field_value", "score": None,
            "reasoning": "No real element reference available to read the field's value from.",
        }

    try:
        actual = target.element.get_attribute("text") or ""
    except Exception:
        actual = ""

    passed = expected_value.strip().lower() == actual.strip().lower()
    return {
        "passed": passed,
        "method": "field_value",
        "score": 100 if passed else 0,
        "reasoning": (
            "Field value matches exactly what was typed/selected."
            if passed else
            f"Expected '{expected_value}' but field actually contains '{actual}'."
        ),
    }


def _page_visible_text(driver) -> str:
    """Android has no <body>/DOM text concept - the raw accessibility-tree
    XML dump (driver.page_source) is the equivalent: every on-screen text/
    content-desc value is embedded in it as attribute content, which is
    enough for fuzz.partial_ratio's substring-style matching below to find
    a real phrase inside the surrounding XML noise (the same reasoning
    wait_helpers.wait_for_text already relies on for its own plain
    substring check against the same kind of dump)."""
    try:
        return driver.page_source
    except Exception:
        return ""


def _android_field_values(driver) -> str:
    parts = []
    try:
        for el in driver.find_elements(By.XPATH, "//*[contains(@class,'EditText')]"):
            try:
                val = el.get_attribute("text") or ""
                rid = el.get_attribute("resource-id") or ""
                if val:
                    parts.append(f"{rid}={val}")
            except Exception:
                continue
    except Exception:
        pass
    return "; ".join(parts)


def _combined_state_text(driver, platform: str) -> str:
    visible_text = _page_visible_text(driver)
    field_values = _android_field_values(driver)
    toast_text = _read_toast_text(driver)
    return f"{visible_text}\nField values: {field_values}\nToast: {toast_text}"


async def averify(driver, expected_result: str, platform: str) -> dict:
    """Returns {"passed": bool, "method": "fuzzy"|"vision"|"skipped", "score": int|None, "reasoning": str}"""
    if not expected_result:
        return {"passed": True, "method": "skipped", "score": None, "reasoning": "No expectation given."}

    combined_text = await asyncio.to_thread(_combined_state_text, driver, platform)
    score = fuzz.partial_ratio(expected_result.lower(), combined_text.lower())
    threshold = settings.fuzzy_match_threshold

    if score >= threshold:
        return {
            "passed": True,
            "method": "fuzzy",
            "score": score,
            "reasoning": f"Fuzzy match score {score} >= threshold {threshold} (text + field values).",
        }

    if score <= GREY_ZONE_LOW or not settings.enable_vision_fallback:
        return {
            "passed": False,
            "method": "fuzzy",
            "score": score,
            "reasoning": f"Fuzzy match score {score} below threshold {threshold} (text + field values).",
        }

    # Grey zone AND vision fallback enabled: ask the vision model to judge.
    screenshot_path = await asyncio.to_thread(take_screenshot, driver, "verify")
    b64 = await asyncio.to_thread(screenshot_to_b64, screenshot_path)
    result = await achat_vision_json(
        VERIFY_SYSTEM_PROMPT,
        f"Expected result: {expected_result}\nDid this happen?",
        b64,
        schema=VERIFY_JSON_SCHEMA,
    )
    return {
        "passed": bool(result.get("passed")),
        "method": "vision",
        "score": score,
        "reasoning": result.get("reasoning", ""),
    }