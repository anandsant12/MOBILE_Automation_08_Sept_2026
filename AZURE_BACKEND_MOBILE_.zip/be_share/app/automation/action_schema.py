"""
Declares the full automation action taxonomy: what each action is called,
which category it belongs to, whether it needs a target element, and what
extra parameters it needs. Drives both the frontend's step-builder UI
(dynamic fields per action, via GET /api/actions) and step_runner's
dispatch logic.
"""

from dataclasses import dataclass, field as dc_field


@dataclass
class ActionField:
    name: str
    label: str
    kind: str  # "text" | "number" | "select"
    options: list | None = None
    default: object = None
    help: str = ""


@dataclass
class ActionDef:
    key: str
    label: str
    category: str
    needs_target: bool = False
    fields: list = dc_field(default_factory=list)
    android_only: bool = False


AI_ACTION_KEY = "ai_action"

CATEGORY_ORDER = [
    "Navigation", "Find / Locate", "Interaction", "Scroll / Gesture",
    "Keyboard", "Clipboard", "Extraction", "Wait", "Verification",
    "WebView", "Mobile / Device",
]

_DIRECTIONS = ["up", "down", "left", "right"]
_SPEEDS = ["slow", "normal", "fast"]

ACTIONS: dict = {}


def _register(a: ActionDef):
    ACTIONS[a.key] = a


# ---- Navigation ----
_register(ActionDef("back", "Back", "Navigation"))

# ---- Find / Locate ----
for _k, _lbl in [("find", "Find"), ("find_text", "Find by Text"),
                  ("find_by_role", "Find by Role"), ("find_by_label", "Find by Label"),
                  ("locate", "Locate")]:
    _register(ActionDef(_k, _lbl, "Find / Locate", needs_target=True))

# ---- Interaction ----
_register(ActionDef("click", "Click", "Interaction", needs_target=True))
_register(ActionDef("double_click", "Double Click", "Interaction", needs_target=True))
_register(ActionDef("tap", "Tap", "Interaction", needs_target=True))
_register(ActionDef("long_press", "Long Press", "Interaction", needs_target=True, fields=[
    ActionField("duration_ms", "Duration (ms)", "number", default=800),
]))
_register(ActionDef("type", "Type", "Interaction", needs_target=True, fields=[
    ActionField("text", "Text to type", "text"),
]))
_register(ActionDef("clear", "Clear Field", "Interaction", needs_target=True))
_register(ActionDef("select", "Select Dropdown Option", "Interaction", needs_target=True, fields=[
    ActionField("value", "Option text", "text"),
]))
_register(ActionDef("set_checked", "Set Checked / Toggle State", "Interaction", needs_target=True, fields=[
    ActionField("checked", "Target state", "select", options=["true", "false"], default="true",
                help="Ensures a checkbox/switch/checkable row ends up in this state. "
                     "Unlike Click, this is a no-op if it's already there - use this "
                     "instead of Click for checkboxes, switches, and multi-select rows "
                     "(e.g. picking contacts for a group chat) so re-running the flow "
                     "can't accidentally flip it the wrong way."),
]))
_register(ActionDef("drag", "Drag", "Interaction", needs_target=True, fields=[
    ActionField("dest_description", "Drop onto (describe target)", "text"),
]))
_register(ActionDef("click_within", "Click Within", "Interaction", needs_target=True, fields=[
    ActionField(
        "click_description", "Element to click (within the Target above)", "text",
        help="e.g. 'Apply Now' - use this when the same button/label appears "
             "more than once on screen (e.g. one per row in a list of cards). "
             "Target above = the containing section that's unique ('the "
             "SimplySAVE Advantage SBI Card row'); this field = what to click "
             "within it, so the click can never land on a different row's "
             "identical-looking button.",
    ),
]))

# ---- Scroll / Gesture ----
_register(ActionDef("scroll", "Scroll", "Scroll / Gesture", fields=[
    ActionField("direction", "Direction", "select", options=_DIRECTIONS, default="down"),
    ActionField("speed", "Speed", "select", options=_SPEEDS, default="normal"),
]))
_register(ActionDef("swipe_up_to", "Swipe Up To", "Scroll / Gesture", needs_target=True))
_register(ActionDef("swipe_down_to", "Swipe Down To", "Scroll / Gesture", needs_target=True))
_register(ActionDef("swipe_left_within_to", "Swipe Left Within To", "Scroll / Gesture", needs_target=True, fields=[
    ActionField("container_description", "Carousel / container", "text",
                help="Plain English description of the scrollable container to search inside, e.g. 'the Accounts carousel'. The target above is the item to find within it."),
]))
_register(ActionDef("swipe_right_within_to", "Swipe Right Within To", "Scroll / Gesture", needs_target=True, fields=[
    ActionField("container_description", "Carousel / container", "text",
                help="Plain English description of the scrollable container to search inside, e.g. 'the Accounts carousel'. The target above is the item to find within it."),
]))
_register(ActionDef("swipe_left_within", "Swipe Left Within", "Scroll / Gesture", needs_target=True, android_only=True, fields=[
    ActionField("count", "Number of swipes", "number", default=1,
                help="Target above = the carousel/container (e.g. 'the product image carousel'). "
                     "Confined to that element's own bounds, not the whole screen."),
]))
_register(ActionDef("swipe_right_within", "Swipe Right Within", "Scroll / Gesture", needs_target=True, android_only=True, fields=[
    ActionField("count", "Number of swipes", "number", default=1,
                help="Target above = the carousel/container (e.g. 'the product image carousel'). "
                     "Confined to that element's own bounds, not the whole screen."),
]))
_register(ActionDef("swipe_up_within", "Swipe Up Within", "Scroll / Gesture", needs_target=True, android_only=True, fields=[
    ActionField("count", "Number of swipes", "number", default=1,
                help="Target above = the panel/menu/list to scroll (e.g. 'the account menu dropdown'). "
                     "Confined to that element's own bounds, not the whole screen - use this instead of the "
                     "plain 'Swipe' action for any panel that doesn't span the full screen (a small anchored "
                     "dropdown/menu), where a screen-center swipe can miss it and land on the backdrop instead, "
                     "closing it rather than scrolling it."),
]))
_register(ActionDef("swipe_down_within", "Swipe Down Within", "Scroll / Gesture", needs_target=True, android_only=True, fields=[
    ActionField("count", "Number of swipes", "number", default=1,
                help="Target above = the panel/menu/list to scroll (e.g. 'the account menu dropdown'). "
                     "Confined to that element's own bounds, not the whole screen."),
]))
_register(ActionDef("swipe", "Swipe", "Scroll / Gesture", fields=[
    ActionField("direction", "Direction", "select", options=_DIRECTIONS, default="left"),
    ActionField("count", "Number of swipes", "number", default=1),
    ActionField("speed", "Speed", "select", options=_SPEEDS, default="normal",
                help="Use 'slow' when precision matters (e.g. searching for a specific "
                     "item) - a fast swipe risks the device reading it as a fling and "
                     "scrolling past the target."),
]))
_register(ActionDef("pinch", "Pinch", "Scroll / Gesture", android_only=True, fields=[
    ActionField("mode", "In / Out", "select", options=["in", "out"], default="in"),
]))
_register(ActionDef("zoom", "Zoom", "Scroll / Gesture", android_only=True, fields=[
    ActionField("mode", "In / Out", "select", options=["in", "out"], default="in"),
]))

# ---- Keyboard ----
_register(ActionDef("key_press", "Key Press", "Keyboard", fields=[
    ActionField("key", "Key (e.g. enter, tab, escape)", "text"),
]))

# ---- Clipboard ----
# No Ctrl+C/Ctrl+V here - Android has no keyboard-modifier concept to send
# those to. These use the device's real system clipboard (the same one the
# on-screen long-press Copy/Paste menu uses) via Appium's own commands.
_register(ActionDef("select_all", "Select All", "Clipboard", needs_target=True))
_register(ActionDef("copy", "Copy", "Clipboard", needs_target=True,
                     fields=[ActionField("store_as", "Save copied text as variable (optional)", "text")]))
_register(ActionDef("paste", "Paste", "Clipboard", needs_target=True))
_register(ActionDef("set_clipboard", "Set Clipboard", "Clipboard", fields=[
    ActionField("text", "Text to put on the clipboard", "text",
                help="Sets the clipboard directly, without needing anything selected first. Pair with "
                     "a following 'Paste' step. Useful as an alternative to 'Type' for a field that "
                     "mishandles typed input, or a value that's awkward to type character-by-character."),
]))

# ---- Extraction ----
_register(ActionDef("get_text", "Get Text", "Extraction", needs_target=True, fields=[
    ActionField("store_as", "Save as variable (optional)", "text",
                help="e.g. 'transaction_balance' - saves the extracted text so a "
                     "later Assert step can compare against it via {{transaction_balance}}, "
                     "instead of hardcoding today's value."),
]))
_register(ActionDef("get_value", "Get Value", "Extraction", needs_target=True, fields=[
    ActionField("store_as", "Save as variable (optional)", "text",
                help="e.g. 'transaction_balance' - saves the extracted value so a "
                     "later Assert step can compare against it via {{transaction_balance}}, "
                     "instead of hardcoding today's value."),
]))
_register(ActionDef("get_attribute", "Get Attribute", "Extraction", needs_target=True, fields=[
    ActionField("attribute", "Attribute name", "text", help="e.g. href, class"),
]))
_register(ActionDef("get_url", "Get Current App Package", "Extraction"))
_register(ActionDef("get_value_within", "Get Value Within", "Extraction", needs_target=True, fields=[
    ActionField(
        "value_description", "Value to find (within the Target above)", "text",
        help="e.g. 'the Balance amount' - use this when a label like "
             "'Balance' appears more than once on screen (e.g. Savings vs "
             "Expense accounts). Target above = the containing section "
             "('the Expense account row'); this field = what to read within "
             "it, so the search never leaves that section.",
    ),
    ActionField("store_as", "Save as variable (optional)", "text",
                help="e.g. 'transaction_balance' - saves the extracted value so a "
                     "later Assert step can compare against it via {{transaction_balance}}, "
                     "instead of hardcoding today's value."),
]))
_register(ActionDef("screenshot", "Screenshot", "Extraction"))

# ---- Wait ----
_register(ActionDef("wait", "Wait (seconds)", "Wait", fields=[
    ActionField("seconds", "Seconds", "number", default=2),
]))
_register(ActionDef("wait_for", "Wait For Element", "Wait", needs_target=True, fields=[
    ActionField("timeout", "Timeout (seconds)", "number", default=10),
]))
_register(ActionDef("wait_for_text", "Wait For Text", "Wait", fields=[
    ActionField("text", "Text to wait for", "text",
                help="Also checks Android Toast popups specifically (e.g. \"Item added to cart\"), "
                     "not just ordinary on-screen text - useful for confirmation messages that "
                     "briefly appear and disappear on their own."),
    ActionField("timeout", "Timeout (seconds)", "number", default=10),
]))
_register(ActionDef("wait_for_navigation", "Wait For Navigation", "Wait", fields=[
    ActionField("timeout", "Timeout (seconds)", "number", default=10),
]))

# ---- Verification ----
_register(ActionDef("assert_visible", "Assert Visible", "Verification", needs_target=True))
_register(ActionDef("assert_text", "Assert Text", "Verification", needs_target=True, fields=[
    ActionField("expected_text", "Expected text", "text",
                help="Supports {{variable_name}} to compare against a value saved "
                     "earlier via a 'Save as variable' field, instead of a fixed string."),
]))
_register(ActionDef("assert_value", "Assert Value", "Verification", needs_target=True, fields=[
    ActionField("expected_value", "Expected value", "text",
                help="Supports {{variable_name}} to compare against a value saved "
                     "earlier via a 'Save as variable' field, instead of a fixed string."),
]))

# ---- Mobile / Device ----
_register(ActionDef("launch_app", "Launch App", "Mobile / Device", android_only=True, fields=[
    ActionField("package", "App package name", "text"),
]))
_register(ActionDef("close_app", "Close App", "Mobile / Device", android_only=True, fields=[
    ActionField("package", "App package name", "text"),
]))
_register(ActionDef("press_back", "Press Back (hardware)", "Mobile / Device", android_only=True))
_register(ActionDef("press_home", "Press Home", "Mobile / Device", android_only=True))
_register(ActionDef("set_orientation", "Set Orientation", "Mobile / Device", android_only=True, fields=[
    ActionField("orientation", "Orientation", "select", options=["portrait", "landscape"], default="portrait"),
]))
_register(ActionDef("open_deep_link", "Open Deep Link", "Mobile / Device", android_only=True, fields=[
    ActionField("url", "URL / URI (e.g. myapp://product/123)", "text"),
    ActionField("package", "App package (optional - defaults to ANDROID_APP_PACKAGE)", "text"),
]))
_register(ActionDef("open_notifications", "Open Notification Shade", "Mobile / Device", android_only=True))
_register(ActionDef("device_action", "Device Action (AI)", "Mobile / Device", fields=[
    ActionField("instruction", "Describe the device action", "text"),
]))

# ---- WebView ----
# For content genuinely rendered INSIDE an embedded WebView within the
# native app (a payment page, a T&C screen, an OTP page) - see
# action_executor.py's WebView section for why this is a separate,
# necessary context switch rather than just another way to find the same
# element. Every ordinary action (click, type, assert_text, ...) works
# the same way once switched; these two just control which context
# they're operating against.
_register(ActionDef("switch_to_webview", "Switch to WebView", "WebView", android_only=True, fields=[
    ActionField("url_contains", "URL contains (optional, if more than one WebView is open)", "text"),
]))
_register(ActionDef("switch_to_native", "Switch to Native", "WebView", android_only=True))

NEEDS_TARGET_ACTIONS = {k for k, a in ACTIONS.items() if a.needs_target}


def actions_in_category(category: str, platform: str) -> list:
    return [a for a in ACTIONS.values() if a.category == category and (platform == "android" or not a.android_only)]


def get_action(key: str) -> ActionDef:
    return ACTIONS[key]
