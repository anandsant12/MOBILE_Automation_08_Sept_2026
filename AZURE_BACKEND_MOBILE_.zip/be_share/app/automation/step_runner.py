"""
Executes a fixed, user-authored sequence of steps against ONE shared
app session for the whole flow.

Each explicit step looks like:
    {"action": "click", "target_description": "the login button", "params": {}}
An AI Action step looks like:
    {"action": "ai_action", "instruction": "Log in with ..."}

Async generator - yields one log dict per step (or per AI sub-step within
an ai_action step), so the frontend can render progress live.
"""

import asyncio
import re
import time

from selenium.common.exceptions import StaleElementReferenceException, WebDriverException


class ResolutionError(RuntimeError):
    """
    Raised when a target/scope couldn't be located. Carries whatever
    resolution_info was already gathered (which tier was tried, any near-
    miss score/matched_text) as an attribute, so it survives the exception
    unwind - a plain RuntimeError would lose it, since _dispatch's normal
    (extracted, resolution_info) return is never reached once an exception
    is raised. Without this, the single most useful diagnostic for a
    "could not locate" failure (what did it try, how close did it get) was
    being silently discarded exactly when it mattered most - a failed step
    is precisely when you need to see this, not only a successful one.
    """
    def __init__(self, message: str, resolution_info: dict | None = None):
        super().__init__(message)
        self.resolution_info = resolution_info

from app.automation.driver_manager import DriverManager
from app.automation.page_state import (get_state, get_state_full, get_state_within, invalidate_page_source,
                                       read_page_source, SYNTHETIC_LABEL_PREFIX)
from app.automation.popup_handler import detect_session_expired, detect_system_overlay, dismiss_popups
from app.automation.resolver import aresolve_by_description, resolve_fuzzy_only
from app.automation.locator_engine import read_text_via_vision, resolve_by_locator, resolve_by_vision, ResolvedTarget
from app.automation.text_utils import label_for_ref
from app.automation.agent import run_plan_loop
from app.automation import action_executor as ex
from app.automation import wait_helpers as wt
from app.automation.action_schema import NEEDS_TARGET_ACTIONS
from app.automation.recorder import _extract_locator, _extract_fingerprint
from app.automation.flow_graph import capture_state_safely, find_known_route, record_transition
from app.utils.screenshot import take_screenshot, screenshot_to_b64
from app.utils.recording import start_recording, stop_recording_and_save

# ---------------------------------------------------------------------------
# Session recovery
# ---------------------------------------------------------------------------
#
# The underlying Appium session itself can die mid-flow - the app crashes,
# the device/emulator disconnects, the on-device UiAutomator2 instrumentation
# process gets killed - as distinct from an ORDINARY step failure (element
# not found, assertion failed), which is expected, common, and already
# handled by simply logging an error and moving on to the next step. A dead
# session is different: every remaining step would fail with the exact same
# underlying error, one after another, for a reason that has nothing to do
# with any of them individually - without this, that showed up as a wall of
# identical-looking failures with no indication the actual problem was the
# session itself, not the flow.

MAX_SESSION_RECOVERIES_PER_RUN = 1  # a flow needing more than one has a
# persistent problem (a genuinely disconnected device, a server that's
# down) that retrying again won't fix - see _dispatch_with_recovery's own
# handling of what happens once this is exhausted.

_SESSION_DEATH_MESSAGE_MARKERS = (
    "session not found", "session is either terminated or not started",
    "invalid session id", "instrumentation process is not running",
    "cannot be proxied to uiautomator2 server", "socket hang up",
    "connection refused", "econnrefused",
)


class _SessionUnrecoverable(RuntimeError):
    """Raised by _dispatch_with_recovery when a dead Appium session could
    not be revived at all (see MAX_SESSION_RECOVERIES_PER_RUN and
    _recover_session's own docstring) - the caller (run_flow) must stop
    the WHOLE run at that point, not just log this one step as failed and
    move to the next, since there is no working driver left for anything
    after it to run against either."""


def _is_session_dead(exc: Exception) -> bool:
    """Best-effort detection of 'the underlying Appium session itself is
    gone', as opposed to an ordinary step-level failure. False negatives
    here just mean a genuinely dead session gets treated as an ordinary
    step failure for one more step (safe, if suboptimal - the NEXT step
    hits the same session-death error and gets another chance to be
    recognized); false positives would trigger a disruptive, unnecessary
    session restart for what was actually a normal step failure, which is
    the worse mistake - stays conservative (specific known exception types
    and message markers) rather than pattern-matching broadly."""
    if isinstance(exc, (ConnectionError, ConnectionRefusedError, TimeoutError)):
        return True
    if isinstance(exc, WebDriverException):
        msg = str(exc).lower()
        return any(marker in msg for marker in _SESSION_DEATH_MESSAGE_MARKERS)
    return False


async def _recover_session(dm: "DriverManager", platform: str, original_error: Exception):
    """Attempts to recover from a dead Appium session: quits the old
    (already-broken) session best-effort, starts a completely fresh one,
    and dismisses any startup popups on it. Returns (new_dm, new_driver).
    Raises RuntimeError, chained from the original failure for context, if
    a fresh session can't even be started - at that point there is no
    working driver left to retry anything on, so the caller must stop the
    run entirely rather than continue.

    Honest about what this can and cannot restore: a fresh session starts
    the app from its own launch point (ANDROID_APP_PACKAGE/ACTIVITY), NOT
    from wherever the flow was mid-navigation when the old session died -
    there is no way to reconstruct that lost state. What this DOES
    restore is a WORKING DRIVER, so the step that was running when the
    session died gets one retry against a live app, instead of every
    remaining step in the flow failing identically against a session that
    no longer exists."""
    try:
        await asyncio.to_thread(dm.quit)
    except Exception:
        pass  # best effort - the old session may already be unreachable, that's fine

    try:
        new_dm = DriverManager()
        new_driver = await asyncio.to_thread(new_dm.start)
        await asyncio.to_thread(dismiss_popups, new_driver, platform)
    except Exception as restart_error:
        raise RuntimeError(
            f"Lost the app session ({original_error}) and could not start a new one to "
            f"recover ({restart_error}). Check that the device/emulator is still "
            f"connected and the Appium server is reachable."
        ) from original_error

    return new_dm, new_driver


async def _dispatch_with_recovery(dm: "DriverManager", driver, platform: str, action_key: str,
                                   step: dict, flow_variables: dict, recoveries_used: list):
    """Wraps _dispatch with the existing stale-element retry AND, if the
    session itself died, one session-recovery-and-retry (see this
    module's Session recovery section above). Returns (extracted,
    resolution_info, dm, driver) - dm/driver are returned back out since a
    recovery replaces both with fresh ones that the rest of run_flow must
    keep using for every subsequent step, not just this one.

    recoveries_used is a one-element list used as a mutable int cell (a
    plain int argument's increment wouldn't be visible back in run_flow's
    own copy) - shared and updated across the whole run, since the limit
    (MAX_SESSION_RECOVERIES_PER_RUN) is per RUN, not per step.

    Raises _SessionUnrecoverable if a dead session could not be revived at
    all, or was already revived once this run and died again - run_flow
    must stop the whole run at that point, not just this step."""
    try:
        try:
            extracted, resolution_info = await _dispatch(driver, platform, action_key, step, flow_variables)
        except StaleElementReferenceException:
            # The resolved element stopped existing between being found
            # and being acted on - Appium/UiAutomator2's own signal that
            # the screen structurally changed out from under us, not that
            # the target was ever wrong. Common, genuine causes: an
            # app-initiated dialog/prompt appearing asynchronously
            # mid-step (confirmed in practice - a Messages settings
            # toggle click hit this right as the app's own "confirm your
            # country" dialog popped up unprompted, unrelated to any
            # gesture this flow made), a screen transition still
            # settling, or a RecyclerView row getting recycled during a
            # scroll. _dispatch re-resolves the target from scratch every
            # call (nothing here is reused/cached), so simply retrying
            # once gives it a fresh look at whatever's ACTUALLY on screen
            # now - recovers cleanly in the common case instead of
            # failing on what's really a timing issue. A second stale hit
            # (or any other failure) falls through to the session-death
            # check below, unchanged.
            extracted, resolution_info = await _dispatch(driver, platform, action_key, step, flow_variables)
        return extracted, resolution_info, dm, driver
    except Exception as e:
        if not _is_session_dead(e):
            raise
        if recoveries_used[0] >= MAX_SESSION_RECOVERIES_PER_RUN:
            raise _SessionUnrecoverable(
                f"Lost the app session again ({e}) after already using this run's one "
                f"recovery attempt - stopping rather than let every remaining step fail "
                f"the same way. This usually means a persistent problem (device/emulator "
                f"disconnected, Appium server down), not something a retry will fix."
            ) from e
        recoveries_used[0] += 1
        try:
            dm, driver = await _recover_session(dm, platform, e)
        except Exception as recovery_error:
            raise _SessionUnrecoverable(str(recovery_error)) from recovery_error
        try:
            extracted, resolution_info = await _dispatch(driver, platform, action_key, step, flow_variables)
        except Exception as retry_error:
            raise RuntimeError(
                f"Reconnected after losing the app session, but this step failed again "
                f"on the fresh session: {retry_error}"
            ) from retry_error
        return extracted, resolution_info, dm, driver


from config import settings

# Passed as include_text_only=True to _resolve (see page_state's
# ANDROID_INTERACTIVE_OR_TEXT_XPATH) - these are the actions whose target
# is a piece of on-screen TEXT to read/verify, not something to click/type
# into, so it's routinely a plain, non-interactive status/message/banner
# element (a "Please insert a SIM card to continue" toast, an error label,
# ...) that the default interactive-only candidate search can never find
# at all, no matter how well the description matches what's on screen.
# Every other NEEDS_TARGET_ACTIONS entry (click, type, swipe_*_to, drag,
# ...) deliberately keeps the narrower default - broadening it there would
# just add noisy non-interactive text candidates to searches that only
# ever want something genuinely tappable.
READ_ONLY_TARGET_ACTIONS = {"get_text", "get_value", "assert_visible", "assert_text", "assert_value"}

MAX_AI_SUBSTEPS = 6
# How many independent, fresh vision resolve+click attempts to make for an
# unlabeled element before giving up - see the escalation block in
# _dispatch. Each is a real screenshot + model call, not a cached replay,
# so more attempts genuinely improve the odds for an element with per-call
# variance rather than a deterministic miss.
VISION_ESCALATION_ATTEMPTS = 3


async def _screenshot_data_url(driver, label: str) -> str:
    """take_screenshot() returns a raw filesystem Path - not something a
    browser can use as an <img src> at all. This was previously sent
    as-is (just str()'d), meaning run-log screenshots never actually
    rendered in the Next.js frontend. Encode to a real data URL here, once,
    so every caller (live run, now persisted executions too) gets
    something that actually displays."""
    path = await asyncio.to_thread(take_screenshot, driver, label)
    b64 = await asyncio.to_thread(screenshot_to_b64, path)
    return f"data:image/png;base64,{b64}"


async def _read_text_with_vision_fallback(driver, target, desc: str, reader) -> str:
    """
    Try the deterministic reader first (ex.get_text/ex.get_value - needs a
    real element reference). If resolution only found the element via
    vision (a coordinate, not a handle - most often because it has no real
    accessible text/label/resource-id at all, e.g. a canvas-rendered toast),
    fall back to asking the vision model to read the text directly off the
    screenshot instead of failing outright.
    """
    try:
        return await asyncio.to_thread(reader, target)
    except RuntimeError:
        text = await read_text_via_vision(driver, desc)
        if text is None:
            raise RuntimeError(
                f"Could not read text for: {desc} (no element reference, and "
                f"vision could not read it either)."
            )
        return text


def _saved_flow_path(flow_name: str):
    """Path of a saved flow's file - same naming as server.py's _safe_flow_path
    (see _persist_healed_flow for why it's duplicated)."""
    import re
    from pathlib import Path

    safe_name = re.sub(r"[^a-zA-Z0-9_-]", "_", flow_name) or "flow"
    return Path(settings.base_dir) / "flows" / f"{safe_name}.json"


def _should_record_graph(steps: list, flow_name: str | None) -> bool:
    """The learned graph only comes from real, saved test cases. Skipped for:
    ad-hoc runs (no flow_name, or a name with no saved flow file) and flows
    generated via "Generate with AI" (steps tagged _from_ai by
    /api/assist/plan) - those replay an existing route, so recording them
    would only reinforce what the graph already returned."""
    if not flow_name or not _saved_flow_path(flow_name).exists():
        return False
    return not any(s.get("_from_ai") for s in steps)


async def run_flow(steps: list, flow_name: str | None = None):
    """Runs the whole authored flow once, start to finish, on one driver
    session. When flow_name is given (the flow was loaded from a saved
    file, not an ad-hoc unsaved list), any steps healed via self-healing
    locators (see the NEEDS_TARGET_ACTIONS block in _dispatch) are written
    back to that flow's file once the run finishes - ad-hoc runs have
    nowhere to persist a healed locator to, so healing still happens
    in-memory for that run but isn't saved."""
    dm = DriverManager()
    driver = await asyncio.to_thread(dm.start)
    platform = settings.platform
    flow_variables: dict = {}  # values captured via a "Save as variable" field, referenced later as {{name}}
    record_graph = _should_record_graph(steps, flow_name)
    recoveries_used = [0]  # mutable cell shared with _dispatch_with_recovery - see its own docstring

    recording_active = False
    if settings.enable_screen_recording:
        recording_active = await asyncio.to_thread(
            start_recording, driver, settings.screen_recording_time_limit
        )
    recording_path = None

    try:
        await asyncio.to_thread(dismiss_popups, driver, platform)

        prev_graph_after = None
        for i, step in enumerate(steps, start=1):
            action_key = step.get("action")

            if action_key in ("ai_action", "device_action"):
                instruction = step.get("instruction") or (step.get("params") or {}).get("instruction", "")
                async for log in run_plan_loop(driver, instruction, MAX_AI_SUBSTEPS, platform, step_prefix=f"{i}."):
                    yield log
                continue

            dismissed = await asyncio.to_thread(dismiss_popups, driver, platform)

            log = {
                "step": i,
                "action": {"action": action_key, "target_description": step.get("target_description"),
                           **(step.get("params") or {})},
                "status": "ok", "screenshot": None, "verification": None, "error": None,
                "extracted": None, "resolution": None, "healed": False,
            }
            if dismissed:
                # Visible evidence in the run log of exactly what this
                # pre-step cleanup pass clicked, right before dispatching
                # THIS step - see DISMISS_LABELS's own comment for why this
                # matters: it's possible (confirmed, in fact, at least once)
                # for this pass to close something the flow needed left
                # open, e.g. a menu/panel a previous step deliberately
                # opened. If a step's target goes missing right after this
                # fires, this is where to look first.
                log["popups_dismissed"] = dismissed

            # A graph node is captured from the same live UI structure the
            # resolver is about to use. It is optional diagnostic state, not
            # a screenshot, and a capture failure never changes test result.
            # The screen after the previous step IS this step's starting
            # screen, unless the popup pass just clicked something - reuse
            # that snapshot instead of capturing the same screen again.
            if prev_graph_after is not None and not dismissed:
                graph_before = prev_graph_after
            else:
                graph_before = await asyncio.to_thread(capture_state_safely, driver, platform)
            prev_graph_after = None

            try:
                extracted, resolution_info, dm, driver = await _dispatch_with_recovery(
                    dm, driver, platform, action_key, step, flow_variables, recoveries_used
                )
                if extracted is not None:
                    log["extracted"] = extracted
                if resolution_info is not None:
                    log["resolution"] = resolution_info
                log["healed"] = bool(step.get("_healed", False))
                graph_after = await asyncio.to_thread(capture_state_safely, driver, platform)
                prev_graph_after = graph_after
                if record_graph and graph_before and graph_after:
                    try:
                        await asyncio.to_thread(record_transition, graph_before, graph_after, step, flow_name)
                    except Exception:
                        pass  # persistence/locking failure must not affect the test result
            except _SessionUnrecoverable as e:
                # No working driver left (or a persistently dead one) -
                # stop the WHOLE run here rather than let every remaining
                # step fail identically against a session that's gone.
                log["status"] = "error"
                log["error"] = str(e)
                yield log
                break
            except Exception as e:
                log["status"] = "error"
                log["error"] = str(e)
                if isinstance(e, ResolutionError) and e.resolution_info is not None:
                    log["resolution"] = e.resolution_info
                log["screenshot"] = await _screenshot_data_url(driver, f"step{i}_error")
                yield log
                continue

            log["screenshot"] = await _screenshot_data_url(driver, f"step{i}")
            yield log

    finally:
        if recording_active:
            recording_path = await asyncio.to_thread(stop_recording_and_save, driver, flow_name or "adhoc")
        await asyncio.to_thread(dm.quit)
        # Pop the flag from EVERY step (a bare any() over a generator stops at the first healed one).
        healed_flags = [s.pop("_healed", False) for s in steps]
        if flow_name and any(healed_flags):
            try:
                _persist_healed_flow(flow_name, steps)
            except Exception:
                pass  # healing persistence is a bonus - never let it fail the run itself

    if recording_path:
        # A distinctly-shaped final entry (no numeric "step") rather than
        # attaching this to the last step's own log - the recording covers
        # the WHOLE run, not that one step, and a consumer that only cares
        # about per-step results can just ignore anything without one.
        # recording_path from stop_recording_and_save is the full
        # server-side path (useful for server-side logging) - the
        # frontend only ever needs the bare filename, to pass straight
        # back to GET /api/run-video/{filename} (see server.py).
        from pathlib import Path
        yield {"step": "recording", "status": "info", "recording_path": Path(recording_path).name}


async def generate_plan_from_graph(instruction: str) -> list[dict] | None:
    """Looks up a verified route for `instruction` in the learned graph
    (see flow_graph.find_known_route), for the "Generate with AI" test-case
    creation path - returns real, editable flow steps instead of executing
    anything. Pure DB lookup, no device/driver involved: the route is
    replayed from its own recorded flow's starting point, not matched
    against the live device's current screen (see find_known_route's own
    comment for why that used to be required, and why it was dropped).
    Tries an LLM call first to pick among candidate recorded flows, with
    a deterministic fallback (see find_known_route's own comment) -
    returns None if no recorded route matches the instruction."""
    return await find_known_route(instruction)


def _persist_healed_flow(flow_name: str, steps: list):
    """Writes healed steps back to their flow file. Mirrors server.py's own
    save_flow exactly - including its on-disk format, which is the raw
    steps LIST with no wrapper (load_flow is what wraps it into
    {"steps": [...]} for the API response - that wrapping happens at read
    time, not in the file itself). Writing {"steps": steps} here instead
    of just steps would double-wrap it on the next load, handing the
    frontend an object where it expects an array.

    Doesn't import from server.py (which would be circular - server.py is
    what imports step_runner, not the other way round), so the path
    computation is duplicated here rather than shared; see
    server.py's _safe_flow_path for the source of truth this must keep
    matching."""
    import json
    import re
    from pathlib import Path

    safe_name = re.sub(r"[^a-zA-Z0-9_-]", "_", flow_name) or "flow"
    flows_dir = Path(settings.base_dir) / "flows"
    flows_dir.mkdir(parents=True, exist_ok=True)
    path = flows_dir / f"{safe_name}.json"
    if not path.exists():
        return  # ad-hoc/unsaved flow of the same name coincidentally - don't create a new file
    path.write_text(json.dumps(steps, indent=2))


def _confirm_dialog_if_present(driver, platform) -> bool:
    """Some native pickers apply immediately on tapping an option (the
    country list, most full-screen lists) - but others are a modal
    AlertDialog (radio buttons, e.g. Messages settings' 'Choose theme')
    where tapping an option only updates the dialog's own selection state;
    nothing is committed until a positive button ('OK'/'Save'/'Apply'/
    'Done') is pressed, and the change is silently discarded if the dialog
    is left open or backed out of instead. Android's AlertDialog always
    exposes its positive button at the same standard id regardless of
    label text or hosting app, so this is a reliable, generic check - not
    specific to any one app or dialog. Returns True if a dialog was
    found and confirmed."""
    if platform != "android":
        return False
    try:
        btn = driver.find_element("id", "android:id/button1")
        btn.click()
        return True
    except Exception:
        return False


def _find_option_matches(driver, platform, value: str):
    """
    Strict text match (case-insensitive, on an element's OWN rendered
    label) against every candidate CURRENTLY on screen - deliberately NOT
    thefuzz/semantic scoring, for one specific reason: option-matching
    (picking one entry out of a list of short, mutually-exclusive,
    structurally-similar strings - a country list, a list of dates, ...)
    is exactly the scenario where fuzzy+semantic corroboration's normally-
    reasonable tolerance becomes dangerous instead of helpful. Confirmed in
    practice, not theoretical: selecting "India" from a country picker
    fuzzy+semantic-corroborated onto "Bolivia" instead - raw fuzzy alone
    scored only 50 (below FUZZY_TARGET_THRESHOLD's solo-acceptance bar of
    70), but the embedding model apparently clusters short, single-
    word country names close together regardless of which country, pushing
    the corroborated score to ~60 - clearing _tier1_best_ref's lower
    corroboration bar (MIN_CORROBORATED_SCORE=50) despite naming a
    completely different, wrong country.

    Returns (exact_target, substring_target) for the CURRENT screen only -
    either may be None. Deliberately does NOT collapse these into one
    "best" pick itself: a substring hit found while scrolling can be a
    genuine false lead (confirmed in practice, a second time, immediately
    after fixing the fuzzy/semantic one above - "India" is a literal
    substring of "Indian", so "British Indian Ocean Territory" - which
    sorts alphabetically BEFORE "India" itself - matched first while
    scrolling down and got clicked instead of the real "India" a few
    entries later). The caller (the "select" dispatch's scroll loop) keeps
    scrolling for an exact match as long as there's more list left to
    check, and only settles for a remembered substring match once the
    search is actually exhausted - "keep scrolling until the exact target
    turns up, then click" - rather than stopping at the first plausible-
    looking substring hit regardless of where in the list it happened to
    sort.
    """
    state_text, ref_map = get_state(driver, platform)
    needle = value.strip().lower()
    if not needle:
        return None, None

    exact_ref = None
    substring_ref = None
    for ref in ref_map:
        label = label_for_ref(state_text, ref).strip().lower()
        if not label:
            continue
        if label == needle:
            exact_ref = ref
            break
        if substring_ref is None and needle in label:
            substring_ref = ref

    def _target(ref):
        if ref is None:
            return None
        t = ResolvedTarget(method="ref")
        t.element = ref_map[ref]
        return t

    return _target(exact_ref), _target(substring_ref)


# Separate attempt budget for the "select" fallback's option search (see
# _find_option_matches) - deliberately NOT reusing MAX_SWIPE_TO_ATTEMPTS
# below, which is tuned for a typical settings-menu-sized list (~20-30
# items). A picker/dropdown's option list can be much longer (a country
# list has ~195 short, single-line entries), and now that the search
# covers BOTH directions (see _scroll_search_option), each direction
# needs enough budget to genuinely reach that end of the list, not just
# "probably enough for a normal-sized menu". Swipe distance itself reuses
# SWIPE_TO_SEARCH_PERCENT - same gesture, same primitive, already proven.
MAX_OPTION_SEARCH_ATTEMPTS = 20


async def _scroll_search_option(driver, platform, value: str):
    """
    Searches for `value` (see _find_option_matches) by scrolling in BOTH
    directions, not just one. Confirmed in practice as a real, not
    theoretical, failure mode: a picker/dropdown very often opens
    pre-scrolled to whatever's CURRENTLY selected, not to the top of the
    list - searching for "Brazil" while "Italy" was the current selection
    opened the picker already showing entries around "I", and a search
    that only ever scrolled "up" (revealing content alphabetically AFTER
    the start point) could never reach "Brazil" no matter how far or how
    many times it scrolled, since "Brazil" sorts BEFORE "Italy" - it ran
    straight past the far end of the list ("Senegal"..."Solomon Islands")
    without ever having a chance to find something behind its own
    starting point.

    Tries "up" first (arbitrary but consistent - matches swipe_up_to's own
    default sense of "search forward"), and if that's exhausted (budget
    used up or genuinely hit that direction's edge) without finding an
    exact match, tries "down" from wherever that left off - which
    naturally passes back through the original starting point and on
    toward the other end of the list. Returns (target, resolution_info);
    target is None if truly nothing matched in either direction, in which
    case resolution_info still carries the best substring seen (if any)
    via its "matched_text", left for the caller to decide whether to fall
    back to.

    Edge detection tolerates ONE transient flake (two consecutive
    no-change swipes, not just one) before concluding a direction is
    genuinely exhausted - same reasoning as _swipe_to_with_search's own
    edge detection: a single no-op swipe (a slow frame, a momentarily
    stuck gesture) isn't reliable enough evidence on its own that the true
    end of the list has been reached, and stopping on it prematurely means
    switching direction (or giving up) before ever actually seeing the
    list's real last/first item.
    """
    best_substring = None
    for direction in ("up", "down"):
        stuck_count = 0
        for _attempt in range(MAX_OPTION_SEARCH_ATTEMPTS):
            # speed="slow": a fast drag here risks Android reading it as a
            # fling and overshooting straight past the option being
            # searched for (see _swipe_coords/ex.swipe's own comments) -
            # exactly the failure mode this loop exists to avoid.
            _, swiped_changed = await asyncio.to_thread(
                ex.verify_action_effect, driver,
                lambda: ex.swipe(driver, platform, direction, 1, SWIPE_TO_SEARCH_PERCENT, speed="slow"),
            )
            option_target, substring_target = await asyncio.to_thread(
                _find_option_matches, driver, platform, value
            )
            if best_substring is None and substring_target is not None:
                best_substring = substring_target
            if option_target is not None:
                return option_target, {"tier": "exact", "score": None, "matched_text": value}
            if platform == "android" and swiped_changed is False:
                stuck_count += 1
                if stuck_count >= 2:
                    break  # genuinely hit this direction's edge - try the other direction next
            else:
                stuck_count = 0

    if best_substring is not None:
        # Exhausted both directions with no exact match anywhere - only
        # NOW settle for the best substring seen along the way (handles an
        # option rendered with extra text, e.g. a country name suffixed
        # with a calling code, where no entry will ever match exactly).
        return best_substring, {"tier": "substring", "score": None, "matched_text": value}
    return None, {"tier": "none", "score": None, "matched_text": value}

MAX_SWIPE_TO_ATTEMPTS = 8
# Each search step travels a SMALLER distance than the standalone "Swipe"
# action's default (0.75) - a 75%-of-screen jump is large enough to leap
# clean over an element sitting just past the current fold before the
# interim resolve check between swipes ever gets a chance to see it, which
# is exactly what was causing "swiped past it" failures on elements that
# were genuinely on screen the whole time, just briefly skipped over.
SWIPE_TO_SEARCH_PERCENT = 0.35


async def _swipe_to_with_search(driver, platform, desc: str, direction: str):
    """
    Backs the explicit "Swipe Up To" / "Swipe Down To" actions - direction
    is fixed by which action was picked (never a param the caller has to
    get right), which removes the up/down ambiguity that a single generic
    "scroll_to with a direction option" had (whether "direction" meant the
    physical swipe or the resulting content movement was genuinely unclear
    on-device - see action_executor.py's scroll() for the related history).

    Unlike every other needs-target action, the target here is expected to
    be OFF-screen. Resolving it once against the current viewport (like
    _resolve does for everything else) either finds it by accident - it
    was already visible, so there was nothing to swipe to anyway - or, when
    it genuinely isn't there yet, can latch onto an unrelated already-
    visible element with superficially similar text and swipe relative to
    THAT instead.

    This searches WHILE swiping instead: try to resolve against the
    current screen, if found bring it fully into view (ex.scroll_to's
    element-id-based centring) and stop; if not, take one incremental
    swipe step (ex.swipe - a plain, unconfined gesture, confirmed working
    on-device; ex.scroll's area-confined gesture was found to silently do
    nothing on some screens/driver combinations) and try again.

    The interim per-step check uses resolve_fuzzy_only (cheap, no LLM/
    vision call) rather than the full 3-tier resolve - the real target
    legitimately isn't on screen for most of these steps, so escalating to
    an LLM call plus a full screenshot+vision call on every single one of
    up to MAX_SWIPE_TO_ATTEMPTS steps was making this action very slow (up
    to ~16 LLM/vision calls just to determine "not found yet, keep
    swiping"). Once swiping is exhausted, ONE final full-tier resolve
    (including vision) is tried as a last resort, so an icon-only element
    with no fuzzy-matchable text can still be found - just not on every
    interim step.

    Also compares page_source before/after each swipe: two swipes in a row
    that change nothing means we've hit the edge of the scrollable content
    (or the gesture stopped registering on this screen), so it stops
    swiping early instead of grinding through all MAX_SWIPE_TO_ATTEMPTS
    against a frozen screen. Either way - hit an edge early, or exhausted
    the full swipe budget - the full-tier fallback below still always runs
    before giving up: skipping it just because swiping stopped early would
    throw away exactly the tier (LLM/vision) most likely to actually find
    a genuine match the cheap per-step check missed.
    """
    stuck_count = 0
    hit_edge_at = None  # set if the edge-detection above triggers a break

    for attempt in range(MAX_SWIPE_TO_ATTEMPTS):
        state_text, ref_map = await asyncio.to_thread(get_state, driver, platform)
        target = await resolve_fuzzy_only(desc, state_text, ref_map)
        if target is not None:
            await asyncio.to_thread(ex.scroll_to, driver, target)
            return

        # speed="slow": a fast drag risks Android reading it as a fling and
        # overshooting past the very element being searched for (see
        # _swipe_coords/ex.swipe's own comments) - the same failure mode
        # _scroll_search_option's dropdown/picker search guards against.
        _, changed = await asyncio.to_thread(
            ex.verify_action_effect, driver,
            lambda: ex.swipe(driver, platform, direction, 1, SWIPE_TO_SEARCH_PERCENT, speed="slow"),
        )

        # Edge-detection is Android-only: page_source means different things
        # per platform for a scroll/swipe-type action - Android's is the
        # live accessibility tree, which genuinely changes when you swipe;
        # web's is the raw HTML DOM, which normally does NOT change just
        # from moving the viewport, so this would otherwise falsely detect
        # "stuck at the edge" after 2 swipes on every ordinary web page,
        # regardless of how much further the real target actually was.
        if platform == "android" and changed is False:
            stuck_count += 1
            if stuck_count >= 2:
                hit_edge_at = attempt + 1
                break
        else:
            stuck_count = 0

    # Whether we stopped early (hit an edge) or exhausted the full swipe
    # budget, ALWAYS give the full-tier resolve (LLM + vision) one last
    # shot before giving up.
    state_text, ref_map, attrs_map = await asyncio.to_thread(get_state_full, driver, platform)
    target, _resolution_info = await aresolve_by_description(
        driver, desc, state_text, ref_map, platform=platform, attrs_map=attrs_map
    )
    if target is not None:
        await asyncio.to_thread(ex.scroll_to, driver, target)
        return

    if hit_edge_at is not None:
        opposite = "down" if direction == "up" else "up"
        raise RuntimeError(
            f"Could not locate element for: {desc} (swiped {direction} "
            f"{hit_edge_at} time(s), but the screen stopped changing - "
            f"likely reached the edge of the scrollable content in that "
            f"direction. If the element should be further {opposite}, "
            f"try 'Swipe {opposite.capitalize()} To' instead.)"
        )

    raise RuntimeError(
        f"Could not locate element for: {desc} (swiped {direction} "
        f"{MAX_SWIPE_TO_ATTEMPTS} times without finding it - it may not "
        f"exist on this screen, or may be in the opposite direction)."
    )


MAX_SWIPE_WITHIN_ATTEMPTS = 8
# Deliberately its OWN constant, not reused from SWIPE_TO_SEARCH_PERCENT
# above. That vertical search swipes as a fraction of the FULL SCREEN
# height, where 0.35 is a meaningful jump. This one (ex.swipe_within)
# computes its distance as a fraction of the CONTAINER's own bounds - a
# carousel/tab-strip is typically much narrower than the full screen, so
# the same 0.35 used against a much smaller base produced only a tiny
# on-screen movement per attempt ("barely moves" - the percent was fine
# in isolation, just applied to the wrong base for what a person expects
# a left/right search-swipe to cover). Raised to comfortably clear a
# typical carousel item's width in one step, matching the intent (not
# literal number) of the vertical search's 0.35-of-full-screen sizing.
SWIPE_WITHIN_SEARCH_PERCENT = 0.65


# Matches action_executor.scroll_to's own vertical edge_margin fraction.
HORIZONTAL_EDGE_MARGIN_FRACTION = 0.08
# Small - just enough to pull a just-found sliver comfortably into view
# without a second full search-sized swipe overshooting past it again.
HORIZONTAL_NUDGE_PERCENT = 0.15


async def _nudge_further_into_view_within(driver, target, direction):
    """
    resolve_fuzzy_only only requires the item to be PRESENT with a real
    (non-collapsed) size - see page_state._is_visibly_sized - not
    comfortably placed. So the very first swipe that reveals a carousel
    item at all can leave it hugging the edge as a thin sliver (seen in
    practice: "View All Products" found at bounds 21px wide, flush against
    the screen's right edge). If that's still true here, take one more
    small swipe in the SAME direction the search has been going.

    Uses ex.swipe_row (full screen width, aimed at the target's own row),
    NOT ex.swipe_within(container, ...) or action_executor.scroll_to's
    elementId-scoped nudge - both confine the gesture to an element's OWN
    bounds, which by this point can be just as thin as the target itself:
    a container_description like "Open Savings" often has no distinct
    on-screen text of its own (only the individual cards do), so it
    resolves to one of the cards - which, once scrolled mostly off-screen
    searching for a LATER item, is by then just as much a sliver as the
    thing being searched for. A swipe confined to either one has nowhere
    real to travel and reliably registers as a TAP instead - confirmed in
    practice twice: it opened "View All Products"' own screen, and
    separately the "Open Savings/Current Account" card's own screen,
    instead of merely scrolling either into view.
    """
    try:
        rect = target.element.rect
        size = await asyncio.to_thread(driver.get_window_size)
        width = size["width"]
    except Exception:
        return  # best effort; the item was already findable on/near screen
    edge_margin = width * HORIZONTAL_EDGE_MARGIN_FRACTION
    left_space = rect["x"]
    right_space = width - (rect["x"] + rect["width"])
    if left_space < edge_margin or right_space < edge_margin:
        try:
            row_y = int(rect["y"] + rect["height"] / 2)
            await asyncio.to_thread(ex.swipe_row, driver, row_y, direction, HORIZONTAL_NUDGE_PERCENT)
        except Exception:
            pass  # best effort; the item was already findable on/near screen


async def _swipe_within_with_search(driver, platform, container_desc: str, item_desc: str, direction: str):
    """
    Carousel/horizontal-scroll counterpart to _swipe_to_with_search above -
    same search-while-swiping pattern (cheap fuzzy-only check between
    swipes, edge detection via page_source comparison, one full-tier
    resolve as a last resort), generalized to swipe WITHIN a specific
    container's bounds (ex.swipe_within) instead of the whole screen
    (ex.swipe) - so finding an off-screen carousel item doesn't risk
    scrolling the containing page or triggering unrelated navigation from
    an unconfined whole-screen gesture (see swipe_within's own docstring).

    Unlike the item, the CONTAINER (a carousel, tab strip, etc.) is
    expected to already be visible - it's resolved once up front via the
    normal full-tier resolve, not searched for.
    """
    state_text, ref_map, attrs_map = await asyncio.to_thread(get_state_full, driver, platform)
    container, container_info = await aresolve_by_description(
        driver, container_desc, state_text, ref_map, platform=platform, attrs_map=attrs_map
    )
    if container is None:
        raise ResolutionError(f"Could not locate the container: {container_desc}", container_info)

    stuck_count = 0
    hit_edge_at = None

    for attempt in range(MAX_SWIPE_WITHIN_ATTEMPTS):
        state_text, ref_map = await asyncio.to_thread(get_state, driver, platform)
        target = await resolve_fuzzy_only(item_desc, state_text, ref_map)
        if target is not None:
            await _nudge_further_into_view_within(driver, target, direction)
            await asyncio.to_thread(ex.scroll_to, driver, target)
            return

        # speed="slow": same overshoot risk as every other search-scroll
        # loop here - see _swipe_coords/ex.swipe's own comments. A container-
        # confined swipe has even less travel room to work with, so this
        # matters at least as much here as anywhere else.
        _, changed = await asyncio.to_thread(
            ex.verify_action_effect, driver,
            lambda: ex.swipe_within(driver, container, direction, SWIPE_WITHIN_SEARCH_PERCENT, speed="slow"),
        )

        # Same Android-only caveat as _swipe_to_with_search: page_source is
        # the live accessibility tree on Android (genuinely changes when
        # content scrolls) but the raw DOM on web (doesn't change just from
        # moving a viewport/carousel), so this check would misfire on web.
        if platform == "android" and changed is False:
            stuck_count += 1
            if stuck_count >= 2:
                hit_edge_at = attempt + 1
                break
        else:
            stuck_count = 0

    # Whether we stopped early (hit an edge) or exhausted the swipe budget,
    # always give the full-tier resolve one last shot before giving up -
    # covers an icon-only carousel item with no fuzzy-matchable text.
    state_text, ref_map, attrs_map = await asyncio.to_thread(get_state_full, driver, platform)
    target, _resolution_info = await aresolve_by_description(
        driver, item_desc, state_text, ref_map, platform=platform, attrs_map=attrs_map
    )
    if target is not None:
        await _nudge_further_into_view_within(driver, target, direction)
        await asyncio.to_thread(ex.scroll_to, driver, target)
        return

    if hit_edge_at is not None:
        opposite = "right" if direction == "left" else "left"
        raise RuntimeError(
            f"Could not locate element for: {item_desc} (swiped {direction} "
            f"{hit_edge_at} time(s) within '{container_desc}', but it stopped "
            f"changing - likely reached the edge of the carousel in that "
            f"direction. If the item should be further {opposite}, try "
            f"'Swipe {opposite.capitalize()} Within To' instead.)"
        )
    raise RuntimeError(f"Could not locate element for: {item_desc} after searching within '{container_desc}'")


def _maybe_store(flow_variables: dict, name, value):
    """Writes an extracted value into the run's variable store if the step
    had a non-empty "store_as" param. No-op otherwise - hand-built steps
    that never set store_as are unaffected."""
    if name:
        flow_variables[name] = value


_VARIABLE_PATTERN = re.compile(r"\{\{\s*([A-Za-z0-9_]+)\s*\}\}")

# Unicode whitespace that renders like a normal space but isn't one -
# non-breaking space, narrow/thin spaces. Apps use these freely in labels,
# and two strings differing only by these look IDENTICAL in an error
# message while comparing as unequal, which is maddening to debug.
_UNICODE_SPACES = "\u00a0\u1680\u2000\u2001\u2002\u2003\u2004\u2005\u2006\u2007\u2008\u2009\u200a\u202f\u205f\u3000"
# Zero-width characters are invisible JOINERS, not spaces - they're removed
# entirely rather than turned into a space, since "Banking\u200bTab" is
# meant to read as "BankingTab", not "Banking Tab".
_ZERO_WIDTH = "\u200b\u200c\u200d\ufeff"


def _normalize_for_comparison(text: str) -> str:
    """
    Collapses all whitespace (including the Unicode space variants above)
    to single spaces, drops zero-width characters, strips, and lowercases -
    applied to BOTH sides of an assertion comparison.

    Normalizing only at capture time isn't enough: a stored expected value
    can arrive un-normalized from a step recorded before that fix existed,
    from hand-typing, or from a copy-paste carrying a non-breaking space.
    Normalizing at COMPARISON time makes the assertion robust regardless of
    how the value got there, rather than depending on every possible entry
    path having cleaned it correctly first.
    """
    if not text:
        return ""
    for ch in _ZERO_WIDTH:
        text = text.replace(ch, "")
    for ch in _UNICODE_SPACES:
        text = text.replace(ch, " ")
    return " ".join(text.split()).strip().lower()


def _resolve_variables(text: str, flow_variables: dict) -> str:
    """Replaces every {{name}} placeholder in text with the matching stored
    variable's value. A placeholder referencing a name that was never
    stored (typo, or the capture step hasn't run yet) is left as-is rather
    than silently becoming an empty string - that makes the mistake visible
    as an obviously-wrong assertion failure instead of a quietly-wrong
    always-passing one."""
    if not text or "{{" not in text:
        return text

    def _sub(match):
        name = match.group(1)
        return str(flow_variables[name]) if name in flow_variables else match.group(0)

    return _VARIABLE_PATTERN.sub(_sub, text)


async def _resolve(driver, platform, description, locator: dict = None, fingerprint: dict = None,
                    include_text_only: bool = False):
    """
    Resolves a target description to an element, retrying for a short
    window if it's not found immediately, instead of giving up on a single
    attempt. Covers the common case where a screen is still transitioning/
    rendering right after the previous action (e.g. a toast or the next
    screen taking a moment to appear) - previously this required an
    explicit manual 'wait' step before the affected action every time.

    locator/fingerprint are optional, set on a step by the recorder (see
    app/automation/recorder.py) - passed straight through to
    aresolve_by_description's tier 0/tier 2, see there for what each does.
    None for any hand-authored step, which behaves exactly as before.

    Returns (target, resolution_info) - resolution_info is surfaced in the
    step log (see run_flow) so which tier matched, its score, and the
    actual matched on-screen text are visible for debugging a wrong match,
    rather than only showing up indirectly as an action on the wrong element.

    If every tier comes up empty AND the soft keyboard is open, it hides
    the keyboard and retries once before giving up: an open keyboard
    covers the lower part of the screen, and anything behind it is
    genuinely absent from the accessibility tree - a Submit button under
    the keyboard isn't matched badly, it isn't there to match at all.
    This is a pure recovery path - it only ever runs after a real failure,
    so it can't disrupt a flow that deliberately leaves the keyboard up
    (e.g. to tap the keyboard's own "Done" key).

    include_text_only widens candidate search to non-interactive text
    elements too (see page_state.get_android_state_full) - pass True for
    read/verify actions (assert_text, get_text, ...), which often target a
    plain status/message element with no clickable affordance at all; left
    False (default) for click/type-type actions, where only genuinely
    interactive candidates make sense.
    """
    deadline = time.time() + settings.dynamic_resolve_timeout
    last_info = {"tier": "none", "score": None, "matched_text": None}
    keyboard_retry_used = False
    # Tier 0 fast path: a recorded locator needs only the driver and the
    # locator itself (locator_engine.resolve_by_locator) - yet the full
    # screen capture below (findElements + per-element work) was being paid
    # in full first, only for aresolve_by_description to try the locator
    # before ever looking at it. The two "is the screen even usable"
    # guards that normally run ahead of tier 0 are kept, matched against
    # the shared page dump (already warm from this step's popup check, so
    # normally free) instead of the built state_text - both are plain
    # substring matches, and the dump carries the same text.
    if locator:
        try:
            source = await asyncio.to_thread(read_page_source, driver)
        except Exception:
            source = ""
        if source and not detect_session_expired(source) and not detect_system_overlay(source):
            locator_target = await asyncio.to_thread(resolve_by_locator, driver, platform, locator)
            if locator_target is not None:
                return locator_target, {"tier": "locator", "score": None, "matched_text": None,
                                        "locator_used": locator_target.locator_used}

    first_attempt = True
    while True:
        if not first_attempt:
            # Retrying because the screen may still be changing - a shared
            # cached dump would just hand back the same stale screen.
            invalidate_page_source(driver)
        first_attempt = False
        state_text, ref_map, attrs_map = await asyncio.to_thread(
            get_state_full, driver, platform, include_text_only
        )
        target, resolution_info = await aresolve_by_description(
            driver, description, state_text, ref_map, platform=platform,
            locator=locator, fingerprint=fingerprint, attrs_map=attrs_map
        )
        last_info = resolution_info
        if target is not None:
            return target, resolution_info
        if time.time() >= deadline:
            if not keyboard_retry_used:
                keyboard_retry_used = True
                hid = await asyncio.to_thread(ex.hide_keyboard_if_shown, driver, platform)
                if hid:
                    # Give the layout a moment to reflow now that the
                    # keyboard is gone, then allow one more resolve pass.
                    await asyncio.sleep(0.5)
                    deadline = time.time() + settings.dynamic_resolve_timeout
                    continue
            return None, last_info
        await asyncio.sleep(0.5)


async def _scroll_search_for_target(driver, platform, desc: str, include_text_only: bool):
    """Last-resort search for a needs-target element that isn't on the
    CURRENT screen: swipe forward (revealing content further down) a few
    times, re-checking after each swipe, before the step is allowed to fail.

    Why this exists: whether a given element is on screen at all is a
    property of the DEVICE, not of the flow. A flow authored on a screen
    where "Help and feedback" sits below the fold carries an explicit
    "Swipe Up To" step; the same flow authored on a taller screen doesn't -
    and then fails on any smaller device, at a plain click step, with
    "could not locate", even though the element is simply further down.
    The reverse direction already works: _swipe_to_with_search resolves
    against the current screen BEFORE swiping, so an explicit swipe step
    is a no-op when the element is already visible.

    Deliberately forward-only (and bounded): a screen normally opens at the
    top, so "not visible yet" almost always means "further down". Searching
    backwards too would double the cost of every genuine not-found failure,
    and leaves the screen further from where it started for the error
    screenshot. If a target really is above the current position, the
    explicit "Swipe Down To" action still covers it.

    Same primitives as _swipe_to_with_search: cheap fuzzy-only checks per
    swipe (no LLM/vision per attempt), 2-strike edge detection so a list
    already at its end stops immediately instead of swiping into a frozen
    screen, and ex.scroll_to to bring a found element fully into view.
    """
    stuck_count = 0
    for _attempt in range(max(0, settings.auto_scroll_max_swipes)):
        # speed="slow": same overshoot risk as every other search-scroll
        # loop here - see _swipe_coords/ex.swipe's own comments.
        _, changed = await asyncio.to_thread(
            ex.verify_action_effect, driver,
            lambda: ex.swipe(driver, platform, "up", 1, SWIPE_TO_SEARCH_PERCENT, speed="slow"),
        )
        if platform == "android" and changed is False:
            stuck_count += 1
            if stuck_count >= 2:
                return None, None
        else:
            stuck_count = 0

        state_text, ref_map, attrs_map = await asyncio.to_thread(
            get_state_full, driver, platform, include_text_only
        )
        # resolve_fuzzy_only returns the target only - it doesn't report
        # which ref won, so there's no matched_text to surface here.
        target = await resolve_fuzzy_only(desc, state_text, ref_map)
        if target is not None:
            await asyncio.to_thread(ex.scroll_to, driver, target)
            return target, {
                "tier": "fuzzy", "score": None, "method": "auto_scroll",
                "matched_text": None, "auto_scrolled_swipes": _attempt + 1,
            }
    return None, None


async def _dispatch(driver, platform, action_key, step, flow_variables: dict):
    """Returns (extracted, resolution_info). extracted is the action's
    return value if it has one (get_text, assert_*, etc.) else None.
    resolution_info is the target-resolution diagnostic from _resolve
    (tier/score/matched_text) if this action resolved a target, else None -
    surfaced in the step log so a wrong match is visible and debuggable.
    flow_variables is the whole run's variable store (see run_flow) -
    extraction actions with a "store_as" param write into it; assertion
    actions resolve {{name}} placeholders in their expected value against it."""
    params = step.get("params", {}) or {}
    desc = step.get("target_description") or ""
    extracted = None
    resolution_info = None

    # swipe_up_to / swipe_down_to are deliberately handled BEFORE the
    # generic upfront-resolve below: their whole point is finding something
    # NOT currently on screen, so resolving against the current (unswiped)
    # viewport first - like every other needs-target action does - can only
    # ever find it by accident, or worse, latch onto an unrelated already-
    # visible element with superficially similar text instead of actually
    # swiping toward the real target. See _swipe_to_with_search. Direction
    # is fixed by which action was picked, not a param - that's the whole
    # point of having two explicit actions instead of one with a direction
    # option (which up/down value meant which physical gesture was
    # genuinely ambiguous on-device).
    if action_key in ("swipe_up_to", "swipe_down_to"):
        direction = "up" if action_key == "swipe_up_to" else "down"
        await _swipe_to_with_search(driver, platform, desc, direction)
        return None, None

    if action_key in ("swipe_left_within_to", "swipe_right_within_to"):
        direction = "left" if action_key == "swipe_left_within_to" else "right"
        container_desc = params.get("container_description", "")
        await _swipe_within_with_search(driver, platform, container_desc, desc, direction)
        return None, None

    target = None
    if action_key in NEEDS_TARGET_ACTIONS:
        t_resolve = time.perf_counter()
        target, resolution_info = await _resolve(
            driver, platform, desc, locator=step.get("locator"), fingerprint=step.get("fingerprint"),
            include_text_only=(action_key in READ_ONLY_TARGET_ACTIONS),
        )
        resolve_ms = round((time.perf_counter() - t_resolve) * 1000)
        if target is None and settings.auto_scroll_to_find and action_key not in READ_ONLY_TARGET_ACTIONS:
            t_scroll = time.perf_counter()
            scrolled_target, scrolled_info = await _scroll_search_for_target(
                driver, platform, desc, include_text_only=False
            )
            if scrolled_target is not None:
                target, resolution_info = scrolled_target, scrolled_info
                # Where the time went: the failed normal resolve (retries + LLM +
                # vision) vs the swipe-and-recheck loop.
                resolution_info["resolve_ms"] = resolve_ms
                resolution_info["scroll_ms"] = round((time.perf_counter() - t_scroll) * 1000)
        if target is None:
            raise ResolutionError(f"Could not locate element for: {desc}", resolution_info)

        # Self-healing: the recorded locator (if any) didn't work directly -
        # fuzzy/LLM found the element anyway. Extract a fresh locator from
        # the ACTUAL live element and overwrite the step's, so the next
        # replay starts from something that currently works instead of
        # paying for the same fallback search again. Vision matches are
        # skipped - "vision" means there's no live element reference to
        # extract from, only a screen coordinate. Mutating `step` here
        # mutates the same dict object sitting in run_flow's `steps` list -
        # run_flow persists it back to the flow file once the run finishes.
        # Refuse to heal onto an element from a DIFFERENT APP entirely.
        # Confirmed in practice: a flow that had gone off-track elsewhere
        # ended up on the phone's HOME SCREEN, where "Video play button"
        # fuzzy-matched the Play Store icon there (shared word "Play",
        # nothing else in common) - self-healing then silently locked
        # THAT icon's locator (com.android.launcher:id/icon) into the
        # flow file, corrupting every future run of this step regardless
        # of whether the app under test is even in the foreground by
        # then. A step's locator should only ever point at the app under
        # test - a match outside it is itself strong evidence something
        # upstream already went wrong, not something worth remembering.
        same_app = True
        if platform == "android" and settings.android_app_package and target.method == "ref" \
                and target.element is not None:
            try:
                element_package = target.element.get_attribute("package")
            except Exception:
                element_package = None
            same_app = not element_package or element_package == settings.android_app_package

        # Also refresh when tier 0 only worked via a fallback locator (e.g. the
        # resource-id went stale but content-desc still found it), so the
        # stale primary is replaced instead of failing every run.
        used_fallback = (resolution_info and resolution_info.get("tier") == "locator"
                         and resolution_info.get("locator_used") not in (None, "resource_id", "id"))
        if (resolution_info and (resolution_info.get("tier") in ("fuzzy", "llm") or used_fallback)
                and target.method == "ref" and target.element is not None and same_app):
            try:
                screen_size = await asyncio.to_thread(driver.get_window_size)
                new_locator = _extract_locator(target.element, platform)
                new_fingerprint = _extract_fingerprint(target.element, platform, screen_size)
                if new_locator:
                    step["locator"] = new_locator
                    step["fingerprint"] = new_fingerprint
                    step["_healed"] = True  # lets run_flow know to persist; stripped before saving
            except Exception:
                pass  # healing is a bonus - never let it break the actual step

    # ---- Navigation ----
    if action_key == "back":
        await asyncio.to_thread(ex.go_back, driver)

    # ---- Find / Locate ----
    elif action_key in ("find", "find_text", "find_by_role", "find_by_label", "locate"):
        extracted = "found" if target else "not found"

    # ---- Interaction ----
    elif action_key in ("click", "double_click", "long_press", "tap"):
        # Soft diagnostic, not a hard failure: many legitimate actions
        # (toggles, actions that only change internal state) don't change
        # page_source at all, so "nothing changed" isn't reliable enough to
        # treat as an error the way it is for scroll (where "nothing moved"
        # always means the gesture failed). Instead this is just recorded
        # in resolution_info so it's visible in the step log when a click
        # that SHOULD have navigated somewhere silently didn't - the exact
        # gap that made a wrong-match/no-op click show up as a false "ok".
        # Not platform-gated like scroll/swipe are: a click that navigates
        # genuinely should change page_source on web too, unlike scrolling
        # the viewport, which doesn't change the HTML at all.
        if action_key == "double_click":
            _, changed = await asyncio.to_thread(
                ex.verify_action_effect, driver, lambda: ex.double_click(driver, target)
            )
        elif action_key == "long_press":
            duration_ms = int(params.get("duration_ms", 800))
            _, changed = await asyncio.to_thread(
                ex.verify_action_effect, driver, lambda: ex.long_press(driver, target, duration_ms)
            )
        else:
            _, changed = await asyncio.to_thread(
                ex.verify_action_effect, driver, lambda: ex.click(driver, target)
            )

            # A vision-resolved click has no real element handle to sanity-
            # check against - it's a best-effort coordinate guess (vision
            # coordinate detection is inherently approximate - see the
            # README), unlike a ref-resolved click, where "nothing changed"
            # can legitimately mean a toggle or other click with no visual
            # effect. So for THIS method specifically, "screen never
            # changed" is itself meaningful evidence the guess missed, not
            # just a soft diagnostic - retry with completely fresh resolve +
            # click attempts (each is an independent screenshot + model
            # call, so a miss on one doesn't mean the next will miss too -
            # confirmed in practice: the same element passed on some runs
            # and failed on others with no code change in between) before
            # failing loudly rather than silently reporting "ok" on a click
            # that never actually landed anywhere.
            if target.method == "vision" and changed is False:
                for _attempt in range(VISION_ESCALATION_ATTEMPTS - 1):
                    retry_target, retry_resolution_info = await _resolve(driver, platform, desc)
                    if retry_target is None:
                        continue
                    target = retry_target
                    if retry_resolution_info is not None:
                        resolution_info = retry_resolution_info
                    _, changed = await asyncio.to_thread(
                        ex.verify_action_effect, driver, lambda: ex.click(driver, target)
                    )
                    if changed:
                        break
                if changed is False:
                    # ResolutionError, not a plain RuntimeError: carries
                    # resolution_info (tier/score/matched_text) through the
                    # exception unwind - see the class's own docstring. A
                    # plain RuntimeError here would silently drop exactly
                    # the diagnostic needed to debug WHY this failed, right
                    # when it matters most.
                    raise ResolutionError(
                        f"Clicked '{desc}' at a vision-estimated coordinate {VISION_ESCALATION_ATTEMPTS} "
                        f"times, but the screen never visibly changed once - the guess likely missed "
                        f"the real element every time. Vision-based coordinate detection is inherently "
                        f"approximate (see README) - try rephrasing the description to be more "
                        f"visually specific (shape, color, position) if this keeps happening.",
                        resolution_info,
                    )
            elif target.method == "ref" and changed is False:
                # target.element.click() (an accessibility ACTION_CLICK) can
                # be a silent no-op on a custom view that only handles raw
                # touch events itself - confirmed in practice on a header
                # icon UiAutomator2 flags NAF ("Not Accessibility-Friendly"):
                # a real, correctly-resolved element (a manual coordinate tap
                # at the same spot opens the screen it should), but .click()
                # itself did nothing. One retry with an actual touch gesture
                # at the element's own center before accepting "no visible
                # change" - which, for a REAL element, is still allowed to be
                # the ordinary, legitimate case (e.g. a toggle) that this
                # branch does NOT hard-fail on, unlike the vision case above.
                try:
                    _, changed = await asyncio.to_thread(
                        ex.verify_action_effect, driver, lambda: ex.click_at_center(driver, target)
                    )
                except Exception:
                    pass  # best effort - keep the original .click() outcome

                # A match against a SYNTHETIC positional label (see
                # page_state._synthetic_label_for_unlabeled) carries none of
                # the corroborating evidence an ordinary text/content-desc
                # match does - it was already a guess that this particular
                # unlabeled element is the right one, filled in only because
                # nothing else on screen looked more likely. Confirmed in
                # practice: for such a match, even the element's own
                # geometric center can be a dead zone - a header's NAF icon
                # strip reports bounds spanning the WHOLE top of the screen,
                # but only a small portion of that width (where the icon is
                # actually drawn) responds to touch at all. Two real taps
                # having failed is real evidence THIS match was wrong, so -
                # unlike an ordinary ref click, which stays a soft diagnostic
                # - escalate to genuine vision attempts (with the crop-
                # toward-the-described-corner precision improvement, see
                # locator_engine.resolve_by_vision) before giving up loudly.
                matched_text = str((resolution_info or {}).get("matched_text") or "")
                if changed is False and SYNTHETIC_LABEL_PREFIX in matched_text:
                    # The synthetic label itself already says roughly WHERE
                    # this element is ("... (top of screen)" / "(bottom of
                    # screen)") - pass that through as a region hint so
                    # vision gets a crop-toward-the-right-area precision
                    # boost even when desc itself names no position at all
                    # (e.g. "headphones icon"). This deliberately stays the
                    # coarse screen-edge crop, NOT the element's own exact
                    # bounds - an exact-bounds variant was tried and, across
                    # several full runs, made this LESS reliable, not more:
                    # for an element whose accessible bounds already don't
                    # correspond to its real tap area (the whole reason this
                    # escalation path exists at all), its exact bounds
                    # aren't a trustworthy crop target either.
                    region_hint = "top" if "top of screen" in matched_text \
                        else "bottom" if "bottom of screen" in matched_text else None

                    # Multiple FRESH vision attempts, not just one - each
                    # call is an independent screenshot + model call, so a
                    # miss on one attempt doesn't mean the next will miss
                    # too (confirmed in practice: this exact element passed
                    # on some runs and failed on others with no code change
                    # in between - genuine per-call variance, not a
                    # deterministic miss). Stays within live, description-
                    # based resolution the whole time - no coordinate is
                    # ever remembered/reused between attempts or runs.
                    for _attempt in range(VISION_ESCALATION_ATTEMPTS):
                        vision_target = await resolve_by_vision(driver, desc, region_hint=region_hint)
                        if vision_target is None:
                            continue
                        target = vision_target
                        _, changed = await asyncio.to_thread(
                            ex.verify_action_effect, driver, lambda: ex.click(driver, target)
                        )
                        if changed:
                            break
                    if changed is False:
                        raise ResolutionError(
                            f"Clicked '{desc}' several different ways (an unlabeled element's "
                            f"accessibility click, a real touch at its own center, and "
                            f"{VISION_ESCALATION_ATTEMPTS} independent vision-estimated coordinates) "
                            f"but the screen never visibly changed any time - the only match found "
                            f"for this description was an unlabeled icon whose accessible bounds "
                            f"don't appear to correspond to a real tappable area.",
                            resolution_info,
                        )

        if resolution_info is not None:
            resolution_info["screen_changed"] = changed
    elif action_key == "type":
        await asyncio.to_thread(ex.type_text, driver, target, params.get("text", ""))
        # Typing opens the soft keyboard, which then covers the lower part
        # of the screen - and anything behind it is genuinely ABSENT from
        # the accessibility tree, not just hard to match. A Submit button
        # under the keyboard can't be found by any tier, and vision (seeing
        # only a screenshot with the keyboard in it) is prone to guessing a
        # plausible-looking coordinate for it anyway, producing a tap that
        # silently does nothing. Closing it right here, at the source,
        # keeps every following step working against the full screen.
        await asyncio.to_thread(ex.hide_keyboard_if_shown, driver, platform)
    elif action_key == "clear":
        await asyncio.to_thread(ex.clear_field, target)
    elif action_key == "select":
        value = params.get("value", "")
        # No real HTML <select> on Android - every native picker, Material
        # dropdown, or custom widget that LOOKS like a dropdown needs the
        # same treatment: click to open whatever it turns out to be, then
        # search the resulting screen for `value` the same way any other
        # target gets resolved, and click that. Works uniformly for a
        # native picker dialog, a Material dropdown, or any other "opens
        # something, then you pick from it" pattern - the caller never
        # needs to know or care which one this particular field is.
        _, changed = await asyncio.to_thread(
            ex.verify_action_effect, driver, lambda: ex.click(driver, target)
        )

        # Strict match first (see _find_option_matches' own comment for
        # why option-matching specifically avoids fuzzy/semantic
        # scoring) - check what's already on screen before scrolling
        # at all (the common case: the picker opens already showing
        # or close to the target), then search in BOTH directions if
        # it's not there - see _scroll_search_option's own comment for
        # why a one-directional search isn't enough here.
        option_target, best_substring = await asyncio.to_thread(_find_option_matches, driver, platform, value)
        option_info = {"tier": "exact", "score": None, "matched_text": value}
        if option_target is None:
            option_target, option_info = await _scroll_search_option(driver, platform, value)
            if option_target is None and best_substring is not None and option_info.get("tier") != "substring":
                option_target, option_info = best_substring, {"tier": "substring", "score": None, "matched_text": value}

        if option_target is None:
            # Last resort: the full fuzzy/LLM/vision path, for
            # genuinely fuzzy cases a strict text match can't be
            # expected to catch (abbreviations, paraphrases) - only
            # reached here since every safer, stricter option already
            # came up empty.
            option_state_text, option_ref_map = await asyncio.to_thread(get_state, driver, platform)
            option_target, option_info = await aresolve_by_description(
                driver, value, option_state_text, option_ref_map, platform=platform
            )
        if option_target is None:
            raise ResolutionError(
                f"'{desc}' isn't a real dropdown - opened it (click) and searched "
                f"(including scrolling), but couldn't find an option matching '{value}'.",
                option_info,
            )
        await asyncio.to_thread(
            ex.verify_action_effect, driver, lambda: ex.click(driver, option_target)
        )
        # Some pickers are a confirm-style AlertDialog (radio buttons +
        # OK/Cancel) rather than an apply-immediately list - see
        # _confirm_dialog_if_present's own comment for why this check
        # is needed at all. A no-op on every other picker shape.
        await asyncio.to_thread(_confirm_dialog_if_present, driver, platform)
        resolution_info = option_info
    elif action_key == "set_checked":
        desired_raw = params.get("checked", True)
        desired = str(desired_raw).strip().lower() in ("true", "1", "yes", "on")
        await asyncio.to_thread(ex.set_checked, driver, target, desired)
    elif action_key == "drag":
        dest, dest_resolution_info = await _resolve(driver, platform, params.get("dest_description", ""))
        if dest is None:
            raise ResolutionError(
                f"Could not locate drag destination: {params.get('dest_description')}",
                dest_resolution_info,
            )
        await asyncio.to_thread(ex.drag, driver, target, dest)
    elif action_key == "click_within":
        # target (above) is the SCOPE - e.g. "the SimplySAVE Advantage SBI
        # Card row" - already resolved against the full screen by the
        # generic upfront resolve. Search only WITHIN its subtree for
        # click_description, exactly like get_value_within does for
        # reading a value - so a button/label repeated once per row in a
        # list (a generic "Apply Now" on every card, "Edit"/"Delete" on
        # every list item, ...) can never resolve to the WRONG row's
        # copy just because it's the first or best-scoring match on the
        # whole screen. Confirmed as a real, not hypothetical, failure
        # mode: a plain click on "Apply Now" with no scope landed on
        # whichever card happened to be in view, not necessarily the one
        # actually intended.
        if target.method != "ref":
            raise RuntimeError(
                f"Scope '{desc}' must resolve to a real element (found only "
                f"via vision, which has no subtree to search within)."
            )
        click_desc = params.get("click_description", "")
        inner_state_text, inner_ref_map = await asyncio.to_thread(get_state_within, driver, target.element, platform)
        click_target, click_resolution_info = await aresolve_by_description(
            driver, click_desc, inner_state_text, inner_ref_map, platform=platform
        )
        if click_target is None:
            raise ResolutionError(f"Could not locate '{click_desc}' within '{desc}'.", click_resolution_info)
        _, changed = await asyncio.to_thread(
            ex.verify_action_effect, driver, lambda: ex.click(driver, click_target)
        )
        click_resolution_info["screen_changed"] = changed
        resolution_info = click_resolution_info  # the inner click's match info is what's actually useful to see

    # ---- Scroll / Gesture ----
    elif action_key == "scroll":
        await asyncio.to_thread(ex.scroll, driver, platform, params.get("direction", "down"), params.get("speed", "normal"))
    elif action_key == "swipe":
        # Uses the shared ex.verify_action_effect primitive (same one
        # scroll() now uses) rather than ex.swipe() verifying itself -
        # ex.swipe() is also used by _swipe_to_with_search's search loop,
        # which needs its OWN, more tolerant policy (allow one transient
        # flake before concluding it's hit a genuine edge, then still try
        # a full-tier fallback); a hard fail-on-first-no-op baked into
        # ex.swipe() itself would short-circuit that. Each caller decides
        # its own policy on top of the same shared capture - this one
        # fails immediately, matching scroll()'s policy, since nothing
        # else is watching a standalone "Swipe" step.
        swipe_direction = params.get("direction", "left")
        swipe_count = max(1, int(params.get("count", 1)))
        swipe_speed = params.get("speed", "normal")
        for i in range(swipe_count):
            _, changed = await asyncio.to_thread(
                ex.verify_action_effect, driver,
                lambda: ex.swipe(driver, platform, swipe_direction, 1, speed=swipe_speed),
            )
            if platform == "android" and changed is False:
                raise RuntimeError(
                    f"Swipe {i + 1}/{swipe_count} ({swipe_direction}) executed "
                    f"with no driver error, but nothing on screen changed - "
                    f"likely reached the edge of the scrollable content, or the "
                    f"gesture didn't register."
                )
    elif action_key in ("swipe_left_within", "swipe_right_within", "swipe_up_within", "swipe_down_within"):
        direction = action_key[len("swipe_"):-len("_within")]  # "left"/"right"/"up"/"down"
        count = max(1, int(params.get("count", 1)))
        for _ in range(count):
            await asyncio.to_thread(ex.swipe_within, driver, target, direction)
    elif action_key == "pinch":
        await asyncio.to_thread(ex.pinch, driver, platform, params.get("mode", "in"))
    elif action_key == "zoom":
        await asyncio.to_thread(ex.zoom, driver, platform, params.get("mode", "in"))

    # ---- Keyboard ----
    elif action_key == "key_press":
        await asyncio.to_thread(ex.key_press, driver, params.get("key", ""))

    # ---- Clipboard ----
    elif action_key == "select_all":
        await asyncio.to_thread(ex.select_all_text, driver, target)
    elif action_key == "copy":
        extracted = await asyncio.to_thread(ex.copy_text, driver, target)
        _maybe_store(flow_variables, params.get("store_as"), extracted)
    elif action_key == "paste":
        await asyncio.to_thread(ex.paste_text, driver, target)
    elif action_key == "set_clipboard":
        await asyncio.to_thread(ex.set_clipboard_text, driver, params.get("text", ""))

    # ---- Extraction ----
    elif action_key == "get_text":
        extracted = await _read_text_with_vision_fallback(driver, target, desc, ex.get_text)
        _maybe_store(flow_variables, params.get("store_as"), extracted)
    elif action_key == "get_value":
        extracted = await _read_text_with_vision_fallback(driver, target, desc, ex.get_value)
        _maybe_store(flow_variables, params.get("store_as"), extracted)
    elif action_key == "get_attribute":
        # Vision can only read visible TEXT off a screenshot, not an
        # arbitrary DOM attribute (href, class, ...) - no fallback possible
        # here; a real element reference is required.
        extracted = await asyncio.to_thread(ex.get_attribute, target, params.get("attribute", ""))
    elif action_key == "get_value_within":
        # target (above) is the SCOPE - e.g. "the Expense account row" -
        # already resolved against the full screen by the generic upfront
        # resolve. Search only WITHIN its subtree for value_description,
        # so a repeated label like "Balance" (once per account) can be
        # disambiguated by which account's section it's actually inside,
        # rather than picking whichever "Balance" happens to fuzzy-match
        # best or appears first on the whole screen.
        if target.method != "ref":
            raise RuntimeError(
                f"Scope '{desc}' must resolve to a real element (found only "
                f"via vision, which has no subtree to search within)."
            )
        value_desc = params.get("value_description", "")
        inner_state_text, inner_ref_map = await asyncio.to_thread(get_state_within, driver, target.element, platform)
        value_target, value_resolution_info = await aresolve_by_description(driver, value_desc, inner_state_text, inner_ref_map, platform=platform)
        if value_target is None:
            raise ResolutionError(f"Could not locate '{value_desc}' within '{desc}'.", value_resolution_info)
        extracted = await _read_text_with_vision_fallback(driver, value_target, value_desc, ex.get_text)
        resolution_info = value_resolution_info  # the inner value's match info is what's actually useful to see
        _maybe_store(flow_variables, params.get("store_as"), extracted)
    elif action_key == "get_url":
        extracted = await asyncio.to_thread(ex.get_current_package, driver)
    elif action_key == "screenshot":
        extracted = await _screenshot_data_url(driver, "manual")

    # ---- Wait ----
    elif action_key == "wait":
        await wt.wait_seconds(float(params.get("seconds", 2)))
    elif action_key == "wait_for":
        await wt.wait_for_element(driver, platform, desc, float(params.get("timeout", 10)))
    elif action_key == "wait_for_text":
        await wt.wait_for_text(driver, params.get("text", ""), float(params.get("timeout", 10)))
    elif action_key == "wait_for_navigation":
        await wt.wait_for_navigation(driver, float(params.get("timeout", 10)))

    # ---- Verification ----
    elif action_key == "assert_visible":
        if target is None:
            raise AssertionError(f"Not visible: {desc}")
        extracted = "visible"
    elif action_key == "assert_text":
        actual = await _read_text_with_vision_fallback(driver, target, desc, ex.get_text)
        expected = _resolve_variables(params.get("expected_text", ""), flow_variables)
        if _normalize_for_comparison(expected) not in _normalize_for_comparison(actual):
            raise AssertionError(f"Expected text '{expected}' not found (actual: '{actual}').")
        extracted = actual
    elif action_key == "assert_value":
        actual = await _read_text_with_vision_fallback(driver, target, desc, ex.get_value)
        expected = _resolve_variables(params.get("expected_value", ""), flow_variables)
        if _normalize_for_comparison(expected) not in _normalize_for_comparison(actual):
            raise AssertionError(f"Expected value '{expected}' not found (actual: '{actual}').")
        extracted = actual

    # ---- Mobile / Device ----
    elif action_key == "launch_app":
        await asyncio.to_thread(ex.launch_app, driver, params.get("package", ""))
    elif action_key == "close_app":
        await asyncio.to_thread(ex.close_app, driver, params.get("package", ""))
    elif action_key == "press_back":
        await asyncio.to_thread(ex.press_back, driver)
    elif action_key == "press_home":
        await asyncio.to_thread(ex.press_home, driver)
    elif action_key == "set_orientation":
        await asyncio.to_thread(ex.set_orientation, driver, params.get("orientation", "portrait"))
    elif action_key == "open_deep_link":
        await asyncio.to_thread(ex.open_deep_link, driver, params.get("url", ""), params.get("package", ""))
    elif action_key == "open_notifications":
        await asyncio.to_thread(ex.open_notifications, driver)

    # ---- WebView ----
    elif action_key == "switch_to_webview":
        await asyncio.to_thread(ex.switch_to_webview, driver, params.get("url_contains", ""))
    elif action_key == "switch_to_native":
        await asyncio.to_thread(ex.switch_to_native, driver)

    else:
        raise RuntimeError(f"Unknown action: {action_key}")

    return extracted, resolution_info
