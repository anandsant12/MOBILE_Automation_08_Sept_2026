"""Learn and reuse verified navigation routes from normal flow execution.

The graph is intentionally based on UI structure, not screenshots. A state
is a compact accessibility snapshot plus its Android activity; an edge is
an exact saved flow step that completed successfully.
"""

from __future__ import annotations

import hashlib
import json
import math
import re
from datetime import datetime, timezone
from typing import Any, Optional

from app.automation.page_state import get_android_state_light, get_state
from app.db.models import ApplicationState, StateTransition
from app.db.session import get_session
from app.llm.model_client import achat_json

# Same reasoning/value as resolver.py's own LLM_CALL_TIMEOUT_S: without an
# explicit bound, a slow/stuck response could stall route selection
# indefinitely instead of falling back to the deterministic heuristic below.
LLM_CALL_TIMEOUT_S = 30  # bigger route model: measured 2-17s per call

# Param keys that hold a literal DATA VALUE a step acts on/asserts against
# (what a user typed, selected, or expected to see) - as opposed to keys
# like "duration_ms", "seconds", "direction", "count" that configure HOW
# an action runs, not WHAT it's about. Only these (plus target_description
# itself) are eligible for value_replacements substitution - see
# action_schema.py's own field definitions for the full action vocabulary
# this is drawn from.
DATA_VALUE_PARAM_KEYS = ("text", "value", "expected_text", "expected_value")

ROUTE_SELECT_SYSTEM_PROMPT = """You are choosing which ALREADY-VERIFIED \
recorded flow (if any) accomplishes a requested instruction, and how many \
of its steps from the start are needed to reach it.

Treat a recorded flow as a TEMPLATE: the graph only tells you the real,
proven STRUCTURE - which screens to navigate through and which actions
to perform in what order (open a new chat, type into a search field,
click a result, select a payment mode, type an amount, ...). It is NOT a
source of truth for any actual DATA VALUE within that structure - a
recipient name, a search term, an amount, a date, a payment mode, a
selected option - those came from whatever the ORIGINAL flow happened to
be testing at the time, and almost never match what THIS instruction is
actually asking for. Your job is to pick the right template
(flow_name + steps_needed, exactly as given - never invent a new kind of
step or reorder/skip steps within it) and then supply, in
value_replacements, the correct value for every step whose recorded data
value differs from what the instruction specifies for that same role.

Example: a flow that opens a new chat, types "AL" to filter contacts,
then clicks "AL cricket" - for an instruction about messaging "AL
entertainment" instead, reuse all three steps but replace "AL cricket"
with "AL entertainment"; do not drop the click, and do not leave "AL
cricket" in place, since either would make the test do something other
than what was actually asked. The same applies to any other kind of
recorded value: a flow that transfers money to "Rahul", amount "500",
via "UPI" is a valid template for transferring to a different person, a
different amount, or a different payment mode - replace whichever of
those the instruction specifies, leave whichever it doesn't mention as
recorded. If the instruction doesn't specify what a given step's value
should be at all, leave that one as recorded. If no flow's STRUCTURE
fits the request at all, return null/null rather than a misleading
match.

Respond with ONLY JSON, no reasoning, no prose:
{"flow_name": "<exact name>" or null, "steps_needed": <int> or null,
 "value_replacements": {"<old value from a step, verbatim>": "<new value from the instruction>"}}
value_replacements may be an empty object {} when nothing needs
substituting. Set flow_name and steps_needed to null if none of the
given flows actually reach what was asked."""


def _context(driver, platform: str) -> str:
    try:
        # Package is on the root node of the page dump we already hold
        # (shared read - no extra round trip); only the activity needs a call.
        # Each mobile: getCurrentPackage/Activity was ~150-300ms.
        from app.automation.page_state import read_current_activity, read_page_source
        match = re.search(r'package="([^"]+)"', read_page_source(driver)[:4000])
        package = match.group(1) if match else (driver.current_package or "")
        return f"{package}/{read_current_activity(driver)}"
    except Exception:
        return ""


def _normalized_state_text(state_text: str) -> str:
    # Element reference numbers are generated per capture and must not affect
    # identity. Keep labels, roles/classes, IDs and checked state intact.
    text = re.sub(r"\[E\d+\]", "[E]", state_text or "")
    return "\n".join(line.strip() for line in text.splitlines() if line.strip())[:16000]


def capture_state(driver, platform: str) -> dict[str, str]:
    """Capture a serializable state snapshot from the already-open driver."""
    if platform == "android":
        state_text = get_android_state_light(driver, include_text_only=True)
    else:
        state_text, _ = get_state(driver, platform, include_text_only=True)
    context = _context(driver, platform)
    normalized = _normalized_state_text(state_text)
    identity = f"{platform}\n{context}\n{normalized}".encode("utf-8")
    return {
        "platform": platform,
        "context": context,
        "state_text": normalized,
        "fingerprint": hashlib.sha256(identity).hexdigest(),
    }


def capture_state_safely(driver, platform: str) -> Optional[dict[str, str]]:
    try:
        return capture_state(driver, platform)
    except Exception:
        # Graph learning must never turn an otherwise valid automation step
        # into a failed test because a transient UI dump could not be read.
        return None


def _upsert_state(session, snapshot: dict[str, str]) -> ApplicationState:
    state = session.query(ApplicationState).filter_by(fingerprint=snapshot["fingerprint"]).one_or_none()
    if state is None:
        state = ApplicationState(
            platform=snapshot["platform"], context=snapshot["context"],
            fingerprint=snapshot["fingerprint"], state_json=json.dumps(snapshot),
        )
        session.add(state)
        session.flush()
    else:
        state.last_seen_at = datetime.now(timezone.utc)
    return state


def record_transition(before: dict[str, str], after: dict[str, str], step: dict[str, Any], flow_name: str | None = None) -> None:
    """Persist or strengthen an edge after a successful explicit step."""
    action_key = step.get("action")
    if not action_key:
        return
    session = get_session()
    try:
        source = _upsert_state(session, before)
        destination = _upsert_state(session, after)
        encoded_step = json.dumps(step, sort_keys=True)
        transition = session.query(StateTransition).filter_by(
            from_state_id=source.id, to_state_id=destination.id,
            execution_step_json=encoded_step,
        ).one_or_none()
        if transition is None:
            session.add(StateTransition(
                from_state_id=source.id, to_state_id=destination.id,
                action_key=action_key,
                target_description=step.get("target_description"),
                execution_step_json=encoded_step, flow_name=flow_name,
            ))
        else:
            transition.success_count += 1
            transition.last_succeeded_at = datetime.now(timezone.utc)
        session.commit()
    finally:
        session.close()


def _terms(value: str) -> set[str]:
    return {word for word in re.findall(r"[a-z0-9]+", (value or "").lower()) if len(word) > 2}


def _matches_goal(transition: StateTransition, instruction: str) -> bool:
    target = _terms(transition.target_description or "")
    goal = _terms(instruction)
    # Avoid guessing: a route is eligible only when its target has a concrete
    # semantic overlap with the request, or its full target phrase appears.
    phrase = (transition.target_description or "").lower().strip()
    return bool(target and (phrase in instruction.lower() or len(target & goal) >= min(2, len(target))))


def _build_idf(edges: list[StateTransition]) -> dict[str, float]:
    """Rarer words in a target_description carry more identifying weight
    than common ones: 'Advanced' names one specific, rarely-reached
    screen, while 'Account' or 'Settings' show up as a navigational
    stepping-stone in nearly every flow - matching one of those alone says
    far less about what was actually asked for than matching a rare word
    does. Standard inverse-document-frequency, treating each edge's
    target_description as one "document"."""
    doc_count = max(len(edges), 1)
    freq: dict[str, int] = {}
    for edge in edges:
        for term in _terms(edge.target_description or ""):
            freq[term] = freq.get(term, 0) + 1
    return {term: math.log((doc_count + 1) / (count + 1)) + 1.0 for term, count in freq.items()}


def _match_specificity(transition: StateTransition, instruction: str, idf: dict[str, float]) -> tuple[float, float]:
    """How confidently `transition` is what the instruction actually means,
    for ranking AMONG _matches_goal's (deliberately permissive) candidates -
    not for eligibility itself. Returns (coverage_ratio, raw_weight),
    compared as a tuple (coverage first, raw_weight only as a tiebreak).

    Coverage - what fraction of the TARGET's own total weight the overlap
    accounts for - comes first because it's what tells a target that's
    mostly ABOUT the request (like "Advanced", fully covered) apart from
    one that only incidentally shares a couple of generic words with it
    (like the account icon's full a11y label "Account and settings icon
    (signed in as UAT Automation)", which shares "account" and "settings"
    with almost any settings-related instruction but is mostly its OWN,
    unrelated text) - confirmed in practice: a raw rarity-weighted sum
    without this ratio favored that long, incidental label purely because
    it happened to overlap on two words instead of one, even though
    neither word remotely describes what it actually overlapped for.

    Raw weight only matters to break a tie AFTER coverage is equal - e.g.
    two different single-word targets ("Account" and "Advanced") that are
    each fully covered by the instruction. That's where term rarity
    (_build_idf) does its job: 'Advanced' names one specific, rarely-
    reached screen, while 'Account' recurs as a stepping-stone in nearly
    every flow, so it should lose that tie in a graph with enough history
    to reflect that difference."""
    target = _terms(transition.target_description or "")
    if not target:
        return (0.0, 0.0)
    goal = _terms(instruction)
    overlap = target & goal
    overlap_weight = sum(idf.get(term, 1.0) for term in overlap)
    target_weight = sum(idf.get(term, 1.0) for term in target)
    coverage = overlap_weight / target_weight if target_weight else 0.0
    return (coverage, overlap_weight)


def _reconstruct_flow_path(same_flow_edges: list[StateTransition], target: StateTransition) -> list[StateTransition]:
    """Every edge from one flow run is inserted in strict execution order
    (see record_transition, called once per step as the flow runs), so
    "all this flow's edges up to and including the target, in id order"
    already reconstructs its real recorded sequence - including any
    self-loop steps (e.g. a 'select' that picked the option already in
    effect, a no-op state-wise) that a backward state-to-state chain would
    otherwise silently skip, since a self-loop's to_state_id can't be
    told apart from a later edge arriving at that same state from
    elsewhere just by destination alone."""
    return sorted(
        (e for e in same_flow_edges if e.id <= target.id),
        key=lambda e: e.id,
    )


def _strip_redundant_self_loops(path: list[StateTransition]) -> list[StateTransition]:
    """Drops any step whose from_state_id equals its to_state_id (the
    action ran but didn't navigate anywhere - e.g. selecting a dropdown
    option that was already the current value) EXCEPT the last step,
    which is always kept since it's the one the caller actually asked
    for. Such a step happened to be part of the original flow's recorded
    sequence, but it never moved the app any closer to (or further from)
    the requested destination, so replaying it is dead weight, not a
    real dependency of the steps around it - confirmed in practice:
    TC003's own recorded route to "Advanced" passes through a "select
    Current country" step that only re-picked the country already in
    effect, with no bearing on reaching Advanced settings at all."""
    if not path:
        return path
    return [step for step in path[:-1] if step.from_state_id != step.to_state_id] + [path[-1]]


def _truncate_at_wrong_value_click(
    path: list[StateTransition], instruction: str, replaced_values: set[str] | None = None
) -> list[StateTransition]:
    """Deterministic safety net, independent of whether the LLM followed
    ROUTE_SELECT_SYSTEM_PROMPT's own instructions: a "click" that
    immediately follows a "type" step is almost always picking a result
    from whatever that typed text just filtered (a contact, a search
    result) - a specific, data-dependent choice, not a fixed, app-defined
    control label. If it shares no words at all with the instruction AND
    wasn't already validated as an intentional substitution (see
    _llm_select_route's value_replacements), it's very likely the wrong
    recorded contact/item slipping through uncorrected. Confirmed in
    practice: asking to message "AL entertainment" still got a route
    ending in "click AL cricket" despite the prompt explicitly warning
    against exactly this, on the small/fast model this project runs
    (gpt-4.1-mini via Azure OpenAI) - a wrong contact silently selected is
    worse than no route at all, so this doesn't rely on the model getting
    it right; a validated replacement means it DID get it right, so this
    exists purely to catch the cases where it didn't.

    Deliberately narrow - ONLY a click directly after a type step, not
    every click with no word overlap: an earlier, broader version of this
    check also flagged ordinary multi-step settings navigation (e.g.
    "click Messages settings" on the way to a much more specifically-
    worded deep target like "toggle iPhone reactions emoji"), which
    legitimately shares no words with the final goal without being wrong
    at all - confirmed as a real regression before narrowing this to the
    type-then-click pattern that's actually specific to the failure this
    exists for."""
    if not path:
        return path
    goal = _terms(instruction)
    replaced_values = replaced_values or set()
    for i, step in enumerate(path[:-1]):
        if i == 0:
            continue
        if step.action_key != "click" or path[i - 1].action_key != "type":
            continue
        if (step.target_description or "") in replaced_values:
            continue
        target = _terms(step.target_description or "")
        if target and not (target & goal):
            return path[:i]
    return path


def _apply_value_replacements(steps: list[dict], replacements: dict[str, str]) -> list[dict]:
    """Swaps in the validated instruction-specific value for a step whose
    recorded target named a different instance of the same kind of thing
    (see _llm_select_route's value_replacements). Also drops that step's
    locator/fingerprint: both describe exactly where the OLD value sat on
    screen (a different contact's row, at a different position in a
    filtered list) - meaningless, and actively misleading, for the new
    value, which the normal three-tier resolver must find fresh from its
    (now-updated) target_description instead, exactly as it would for any
    freshly-authored step."""
    if not replacements:
        return steps
    for step in steps:
        old = step.get("target_description")
        if old in replacements:
            step["target_description"] = replacements[old]
            step.pop("locator", None)
            step.pop("fingerprint", None)
        params = step.get("params")
        if isinstance(params, dict):
            for key in DATA_VALUE_PARAM_KEYS:
                if params.get(key) in replacements:
                    params[key] = replacements[params[key]]
    return steps


def _sync_search_text_with_click_target(steps: list[dict]) -> list[dict]:
    """A "type" step immediately followed by a "click" step is a
    search-then-select pattern: the typed text is only useful if it
    actually narrows the list down to include what gets clicked next -
    otherwise the search would never surface that result at all, and the
    click fails. This can't be left to the LLM's own judgment: asked to
    substitute both a click target and its preceding search text for the
    same new contact, 5 identical calls got the two inconsistent 3 times
    out of 5 - once reusing the old, unrelated search text untouched
    (which wouldn't surface the new contact at all: "AL" isn't even a
    substring of "airtel store"), twice making the new search text the
    ENTIRE target name instead of a short realistic prefix - confirmed
    in practice, not theoretical. So the typed text is deterministically
    re-derived from the (possibly substituted) click target's own value
    whenever it isn't already a substring of it, rather than trusting
    whatever the model separately proposed for that field."""
    for i in range(len(steps) - 1):
        type_step, click_step = steps[i], steps[i + 1]
        if type_step.get("action") != "type" or click_step.get("action") != "click":
            continue
        target = (click_step.get("target_description") or "").strip()
        if not target:
            continue
        params = type_step.get("params")
        if not isinstance(params, dict):
            continue
        typed = (params.get("text") or "").strip()
        if typed and typed.lower() in target.lower():
            continue  # already consistent - leave it as proposed/recorded
        params["text"] = target.split()[0]
    return steps


def _group_by_flow(edges: list[StateTransition]) -> dict[str, list[StateTransition]]:
    """Groups edges into their recorded flows, in original execution order.
    Ungrouped (flow_name-less) edges are left out - they're isolated,
    ad-hoc single steps with no other steps to offer alongside them, so
    there's nothing for a "pick a prefix of this sequence" decision to
    choose between; the deterministic fallback still considers them on
    their own."""
    by_flow: dict[str, list[StateTransition]] = {}
    for edge in edges:
        if edge.flow_name:
            by_flow.setdefault(edge.flow_name, []).append(edge)
    return by_flow


async def _llm_select_route(
    instruction: str, flows: dict[str, list[StateTransition]]
) -> tuple[list[StateTransition] | None, dict[str, str]]:
    """Asks the LLM to pick which already-verified flow (and how much of
    it) accomplishes `instruction`, instead of the cruder keyword-overlap
    heuristic in _match_specificity - it can actually understand that
    "open advanced menu in account settings" is asking for the step
    labeled "Advanced", not the unrelated step merely labeled "Account"
    that happens to share a word with the request. It can only select
    among real, already-executed step sequences (validated below against
    the actual data, never trusted blindly) - so a bad pick means the
    wrong verified route gets returned, never a fabricated one.

    Also asks for value_replacements (old recorded value -> new value
    from the instruction) so a step whose recorded target was a specific
    instance of what's being asked for (a contact name, e.g. "AL
    cricket") gets adapted to the actually-requested instance ("AL
    entertainment") instead of either being reused wrong or dropped -
    see ROUTE_SELECT_SYSTEM_PROMPT's own comment. Each proposed
    replacement is validated here, not trusted blindly: the old value
    must be verbatim one of the selected steps' own recorded target, and
    the new value must share at least one word with the instruction
    itself (i.e. it has to have actually come from what was asked, not
    be invented from nothing) - a replacement failing either check is
    silently dropped rather than applied."""
    if not flows:
        return None, {}

    def _describe_step(step_json: dict) -> str:
        action = step_json.get("action", "")
        target = step_json.get("target_description") or ""
        params = step_json.get("params") or {}
        data_bits = [f'{k}="{params[k]}"' for k in DATA_VALUE_PARAM_KEYS if params.get(k)]
        parts = [action]
        if target:
            parts.append(f'"{target}"')
        parts.extend(data_bits)
        return " ".join(parts)

    parsed_flows: dict[str, list[dict]] = {
        name: [json.loads(s.execution_step_json) for s in steps] for name, steps in flows.items()
    }
    listing_parts = []
    for name, step_jsons in parsed_flows.items():
        lines = [f"  {i}. {_describe_step(sj)}" for i, sj in enumerate(step_jsons, start=1)]
        listing_parts.append(f'Flow "{name}":\n' + "\n".join(lines))
    user_prompt = (
        f"Instruction: {instruction}\n\nKnown verified flows:\n\n" + "\n\n".join(listing_parts)
    )
    try:
        result = await achat_json(ROUTE_SELECT_SYSTEM_PROMPT, user_prompt, timeout=LLM_CALL_TIMEOUT_S)
    except Exception:
        return None, {}
    name = result.get("flow_name")
    count = result.get("steps_needed")
    if not name or name not in flows or not isinstance(count, int):
        return None, {}
    steps = flows[name]
    if not (1 <= count <= len(steps)):
        return None, {}
    path = steps[:count]
    path_step_jsons = parsed_flows[name][:count]

    goal = _terms(instruction)
    known_values = {sj.get("target_description") or "" for sj in path_step_jsons}
    for sj in path_step_jsons:
        params = sj.get("params") or {}
        for key in DATA_VALUE_PARAM_KEYS:
            if params.get(key):
                known_values.add(params[key])
    # Match old values by normalized whitespace, not byte-for-byte: a
    # recorded value can carry incidental double-spacing/etc from the
    # real UI text it came from (confirmed in practice - "AL  cricket",
    # two spaces, from an actual contact row) that the model harmlessly
    # normalizes away when it reproduces the value in its response. Look
    # up by normalized form but keep the REAL recorded string as the
    # actual replacement key, so it still matches the exact string
    # _apply_value_replacements compares against in the real step JSON.
    by_normalized = {" ".join(v.split()): v for v in known_values if v}
    raw_replacements = result.get("value_replacements")
    replacements: dict[str, str] = {}
    if isinstance(raw_replacements, dict):
        for old, new in raw_replacements.items():
            if not isinstance(old, str) or not isinstance(new, str):
                continue
            if not old.strip() or not new.strip():
                continue
            real_old = by_normalized.get(" ".join(old.split()))
            if real_old is None:
                continue  # not a value actually in the steps being returned
            if not (_terms(new) & goal):
                continue  # must genuinely derive from the instruction's own words
            replacements[real_old] = new
    return path, replacements


async def find_known_route(instruction: str) -> list[dict[str, Any]] | None:
    """Return a previously verified sequence of real flow steps ending in a
    transition matching `instruction`, replayed from ITS OWN recorded
    starting point - not matched against whatever screen the live device
    happens to be on right now.

    Every flow run starts from a fresh app launch (run_flow's own
    DriverManager.start()), so "where does this route begin" is already
    answered by how the original flow that taught it began; there's no
    need to also require the CURRENT live screen to exactly match a
    recorded state before returning anything. That extra requirement used
    to be how this worked, and it was a real, confirmed failure mode: a
    state's identity fingerprint includes every conversation preview/
    timestamp visible on screen (see _normalized_state_text), so a single
    new incoming SMS arriving between recording a route and asking for it
    again made the live-state lookup fail before it ever even looked at
    whether the requested target was reachable - reporting "no known
    route" for a route that was, in fact, fully verified and still valid.

    Tries the LLM first (_llm_select_route) - it can understand that
    "open advanced menu in account settings" means the step actually
    labeled "Advanced", not one merely labeled "Account" that shares a
    word with the request, which a keyword-overlap heuristic alone
    cannot reliably tell apart (confirmed in practice - see
    _match_specificity's own comment for exactly that failure). Falls
    back to the deterministic heuristic below on any LLM failure/timeout/
    non-match, so a slow or unreachable model degrades this feature
    rather than breaking it outright.

    ``None`` means no known route matches; normal AI planning remains
    responsible."""
    session = get_session()
    try:
        edges = session.query(StateTransition).order_by(StateTransition.id).all()
        candidates = [edge for edge in edges if _matches_goal(edge, instruction)]
        if not candidates:
            return None

        relevant_flow_names = {edge.flow_name for edge in candidates if edge.flow_name}
        relevant_flows = {
            name: steps for name, steps in _group_by_flow(edges).items() if name in relevant_flow_names
        }
        llm_path, value_replacements = await _llm_select_route(instruction, relevant_flows)
        if llm_path:
            llm_path = _strip_redundant_self_loops(llm_path)
            llm_path = _truncate_at_wrong_value_click(llm_path, instruction, set(value_replacements))
            llm_steps = [json.loads(item.execution_step_json) for item in llm_path]
            llm_steps = _apply_value_replacements(llm_steps, value_replacements)
            return _sync_search_text_with_click_target(llm_steps)

        idf = _build_idf(edges)
        best_path: list[StateTransition] | None = None
        best_score = (-1.0, -1.0)
        for target in candidates:
            score = _match_specificity(target, instruction, idf)
            if target.flow_name:
                same_flow = [e for e in edges if e.flow_name == target.flow_name]
                path = _reconstruct_flow_path(same_flow, target)
            else:
                path = [target]
            # Specificity first (how confidently this target IS what was
            # asked for) - never overridden by path length. On a genuine
            # tie (rare - two equally rare/specific words both matching),
            # prefer the LONGER path: a deeper, more specific route is a
            # safer default than a shorter one that reached its match more
            # by accident than by intent.
            if best_path is None or score > best_score or (score == best_score and len(path) > len(best_path)):
                best_score = score
                best_path = path
        best_path = _strip_redundant_self_loops(best_path)
        best_path = _truncate_at_wrong_value_click(best_path, instruction)
        return [json.loads(item.execution_step_json) for item in best_path]
    finally:
        session.close()


def list_graph() -> dict[str, list[dict[str, Any]]]:
    session = get_session()
    try:
        return {
            "states": [state.to_dict() for state in session.query(ApplicationState).order_by(ApplicationState.id).all()],
            "transitions": [edge.to_dict() for edge in session.query(StateTransition).order_by(StateTransition.id).all()],
        }
    finally:
        session.close()
