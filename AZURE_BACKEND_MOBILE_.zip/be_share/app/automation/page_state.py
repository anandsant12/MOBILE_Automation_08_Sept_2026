"""
Turns the raw page/app into a short, LLM-friendly list of interactive
elements, instead of dumping the entire HTML/XML tree.

Each element gets a short ref tag like [E3] PLUS enough metadata - label
text, placeholder, input type, current value, dropdown options, checkbox/
radio state - that the LLM can decide what to type/select/toggle from text
alone, without ever needing a screenshot. Vision should only be needed for
genuinely unusual custom widgets that don't expose this metadata.
"""

import re
import time

from selenium.webdriver.common.by import By

# ---------------------------------------------------------------------------
# Shared page_source read
#
# One step used to dump the whole accessibility tree up to 6 times back to
# back on the SAME unchanged screen (popup check, graph snapshot, target
# resolution, click before/after verification, graph snapshot) - each dump
# is ~1-2s on Android. read_page_source() lets those consumers share one
# dump. Correctness rests on the invalidation rule, not the TTL: the driver
# is wrapped so ANY command that could change the screen (a click, a swipe,
# typing, a key press, an app-level script...) drops the cached dump, and
# only known read-only commands leave it alone. A command missing from the
# read-only list below merely lowers the hit rate; it can never serve a
# stale dump. The short TTL is only a backstop against the app changing by
# itself between two reads.
# ---------------------------------------------------------------------------
PAGE_SOURCE_CACHE_TTL_S = 3.0

_READ_ONLY_COMMANDS = frozenset({
    "getPageSource", "findElement", "findElements", "findChildElement",
    "findChildElements", "getElementAttribute", "getElementProperty",
    "getElementText", "getElementRect", "getElementTagName", "getElementLocation",
    "getElementSize", "isElementDisplayed", "isElementEnabled", "isElementSelected",
    "getWindowSize", "getWindowRect", "screenshot", "elementScreenshot",
    "getCurrentUrl", "getTitle", "getCurrentContext", "getCapabilities",
})
_READ_ONLY_SCRIPT_PREFIXES = (
    "mobile:getcurrentpackage", "mobile:getcurrentactivity", "mobile:getsystembars",
    "mobile:iskeyboardshown", "mobile:getdisplaydensity", "mobile:deviceinfo",
)


def _install_page_source_cache(driver):
    if getattr(driver, "_ps_cache_installed", False):
        return
    original_execute = driver.execute

    def execute(driver_command, params=None):
        if driver_command not in _READ_ONLY_COMMANDS:
            is_safe_script = False
            # Appium's client sends scripts as "w3cExecuteScript" (plain
            # Selenium as "executeScript") - matching only the latter meant
            # every harmless "which app/activity is this" call wiped the cache.
            if driver_command in ("executeScript", "w3cExecuteScript"):
                script = str((params or {}).get("script", "")).replace(" ", "").lower()
                is_safe_script = script.startswith(_READ_ONLY_SCRIPT_PREFIXES)
            if not is_safe_script:
                driver._ps_cache = None
                driver._activity_cache = None
        return original_execute(driver_command, params)

    driver.execute = execute
    driver._ps_cache = None
    driver._activity_cache = None
    driver._ps_cache_installed = True


def read_current_activity(driver) -> str:
    """driver.current_activity, cached under the SAME rules as the page dump
    (see above). Sound for exactly the same reason: the activity can only
    change if the screen changed, and anything that could change the screen
    already drops the cache. Measured ~170ms per call, x2 snapshots a step."""
    try:
        _install_page_source_cache(driver)
    except Exception:
        return driver.current_activity or ""
    cached = getattr(driver, "_activity_cache", None)
    if cached and (time.time() - cached[0]) < PAGE_SOURCE_CACHE_TTL_S:
        return cached[1]
    activity = driver.current_activity or ""
    driver._activity_cache = (time.time(), activity)
    return activity


def invalidate_page_source(driver):
    if getattr(driver, "_ps_cache_installed", False):
        driver._ps_cache = None
        driver._activity_cache = None


def read_page_source(driver, fresh: bool = False) -> str:
    """driver.page_source, shared across back-to-back readers on an
    unchanged screen - see the block comment above. fresh=True always
    dumps anew (use when waiting for the screen to change)."""
    try:
        _install_page_source_cache(driver)
    except Exception:
        return driver.page_source  # driver not wrappable - behave exactly as before
    cached = getattr(driver, "_ps_cache", None)
    if not fresh and cached and (time.time() - cached[0]) < PAGE_SOURCE_CACHE_TTL_S:
        return cached[1]
    source = driver.page_source
    driver._ps_cache = (time.time(), source)
    return source


def _sanitize(s: str) -> str:
    """
    Collapses any embedded newlines/carriage returns/tabs to a single space.
    Matters more than it looks: state_text packs one element per LINE
    (joined with "\\n" between elements), and _line_for_ref (resolver.py)
    extracts a specific element's matchable text by splitting state_text on
    newlines and taking the line starting with its [ref] tag. A real-world
    content-desc CAN itself contain an embedded "\\n" (seen in practice:
    "Upto 15% OFF\\nMutual Fund" on a promo banner ImageView) - left
    unsanitized, that single element's own text silently splits across two
    lines of state_text, and _line_for_ref then returns only the first
    half, permanently truncating whatever fell after the embedded newline
    right out of every fuzzy/LLM match attempt - with no error, just a
    match that can never succeed because the word it needed was cut off
    before matching ever started.

    ALSO strips the literal string "null" down to "" - confirmed via
    direct probe that Appium/UiAutomator2's LIVE element-attribute fetch
    (WebElement.text / .get_attribute(...), a real HTTP round trip -
    distinct from the page_source XML dump, which is unaffected) returns
    that literal 4-character string instead of None/empty when the
    underlying attribute is genuinely absent. Every "value or ''"
    truthiness guard at every call site was completely blind to this - a
    non-empty, truthy string - silently treating "there is no text here
    at all" as if it were real content: recorded locators ending up with
    resource_id="null" (which can never match anything real on replay),
    and an icon-only element's own_text/hint always looking "present",
    which meant recorder.py's vision-fallback trigger (see its own
    docstring) never actually fired for the elements it exists for.
    """
    cleaned = " ".join((s or "").split())
    return "" if cleaned.lower() == "null" else cleaned

ANDROID_INTERACTIVE_XPATH = (
    "//*[@clickable='true' or @long-clickable='true' or @checkable='true' or "
    "contains(@class,'EditText') or contains(@class,'Button') or contains(@class,'Spinner')]"
)

# Same as above, OR'd with "has its own text/content-desc at all" - used
# instead of ANDROID_INTERACTIVE_XPATH when include_text_only=True (see
# get_android_state_full). Click/type-type actions correctly only ever
# need INTERACTIVE candidates - but read/verify actions (assert_text,
# assert_value, get_text, assert_visible) very often target exactly the
# opposite: a plain, non-interactive status/message/banner TextView with
# no clickable affordance at all. Confirmed in practice: an assert_text
# step targeting "Message at the bottom" (a plain "Please insert a SIM
# card to continue" banner) could never resolve - not matched badly, but
# structurally unable to, since that banner isn't clickable/checkable/an
# EditText/Button/Spinner and so never appeared in the interactive-only
# candidate list at all, regardless of how well-worded the description was.
# Deliberately built as ONE combined XPath (not two separate queries merged
# afterward) so the live find_elements() call and the offline page_source-
# parsed attribute list below stay aligned by the same document order -
# see get_android_state_full's docstring for why that alignment matters.
ANDROID_INTERACTIVE_OR_TEXT_XPATH = (
    ANDROID_INTERACTIVE_XPATH.rstrip("]")
    + " or string-length(@text) > 0 or string-length(@content-desc) > 0]"
)

# Attributes captured per Android element. Deliberately CURATED, not the full
# ~30-attribute dump the accessibility tree exposes: the omitted ones
# (elementId, index, package, window-id, drawing-order, a11y-focused,
# live-region, context-clickable, content-invalid, dismissable, showing-hint,
# text-entry-key, heading, screen-reader-focusable, a11y-important) are
# internal rendering/accessibility plumbing that can't distinguish one element
# from another in practice - and elementId in particular is an internal
# per-session handle that is actively misleading if treated as stable.
# Everything here earns its place by being usable for identification or for
# deciding how to interact:
#   password        - does this field mask input (know before typing into it)
#   multiline       - single-line vs textarea-style input
#   max-text-length - a max-length=6 field is very likely an OTP box, which is
#                     genuinely distinct from a general text field
#   hint            - Android's placeholder text; often the ONLY signal for an
#                     empty, untouched input (see the CIF vs Mobile No case)
#   focused/selected- which tab/field is currently active
ANDROID_CAPTURED_ATTRS = (
    "text", "content-desc", "resource-id", "class", "hint", "bounds",
    "clickable", "long-clickable", "checkable", "checked", "enabled",
    "scrollable", "selected", "focused", "password", "multiline",
    "max-text-length", "displayed",
)

# Attributes shown in the LEAN state_text line (what fuzzy matching scores
# against). Kept minimal on purpose: fuzzy scoring compares whole strings, so
# padding these lines with extra attribute text shifts token_sort_ratio/ratio
# scores unpredictably - the exact scoring we tuned for the "Mutual Fund" vs
# "Loan Against Mutual Fund" fix. Everything else captured above goes into
# the per-element attribute dict instead, available to the LLM tier and to
# recording, without ever touching fuzzy scoring.
def _android_extra_text(attrs: dict, label: str) -> str:
    extra = ""
    if attrs.get("checkable") == "true":
        extra += f" checkable=True checked={attrs.get('checked') == 'true'}"
    if attrs.get("enabled") == "false":
        extra += " disabled"
    hint = attrs.get("hint") or ""
    if hint and label != hint:
        extra += f" hint='{hint}'"
    if attrs.get("password") == "true":
        extra += " password"
    return extra


def _is_interactive(attrs: dict) -> bool:
    """Mirrors ANDROID_INTERACTIVE_XPATH's filter, applied to a parsed
    attribute dict instead of via an XPath query - so the same definition of
    "interactive" holds whether elements came from page_source parsing or a
    find_elements call."""
    if attrs.get("clickable") == "true" or attrs.get("long-clickable") == "true" \
            or attrs.get("checkable") == "true":
        return True
    cls = attrs.get("class") or ""
    return any(k in cls for k in ("EditText", "Button", "Spinner"))


def _is_interactive_or_has_text(attrs: dict) -> bool:
    """Mirrors ANDROID_INTERACTIVE_OR_TEXT_XPATH's filter - see its own
    comment for why this broader definition exists (read/verify actions
    needing to target plain, non-interactive text)."""
    return _is_interactive(attrs) or bool(attrs.get("text")) or bool(attrs.get("content-desc"))


# Below this size (in either dimension, raw device pixels) an element is
# treated as visually collapsed, not really "on screen" - see
# _is_visibly_sized's docstring for the concrete case this covers.
MIN_VISIBLE_DIMENSION = 10


def _is_visibly_sized(bounds_str: str | None) -> bool:
    """
    False only for an element whose own bounds are near-zero in width or
    height. Observed in practice on YONO SBI's post-onboarding landing
    screen: a 4-item product carousel ("Open Savings/Current Account",
    "View All Products", ...) is present in the accessibility tree - with
    correct content-desc text - but laid out with bounds like
    "[0,2091][1080,2096]", 5px tall, before the screen has been scrolled;
    a manual scroll re-lays it out to its real ~460px-tall size with the
    same content-desc text. So the SAME element is both "attached to the
    tree" (fails no filter) and "not actually visible/tappable" at once -
    unlike a browser DOM's is_displayed(), which would already tell this case apart
    this case, Android's raw tree alone can't.
    Without this, get_state's promise of "only what's currently on
    screen" is broken for exactly this case, and callers that depend on
    it - most importantly _swipe_to_with_search / _swipe_within_with_search
    in step_runner.py, which use "found via fuzzy on the CURRENT screen"
    as their signal to stop swiping - conclude the target is already
    visible and never swipe to actually reveal it, then silently report
    success after a no-op scroll_to on a collapsed element.
    A missing/unparseable bounds string is treated as visible (don't
    filter what can't be evaluated) rather than being silently dropped.
    """
    if not bounds_str:
        return True
    bounds = _parse_android_bounds(bounds_str)
    if not bounds:
        return True
    x1, y1, x2, y2 = bounds
    return (x2 - x1) >= MIN_VISIBLE_DIMENSION and (y2 - y1) >= MIN_VISIBLE_DIMENSION


# An element counts as sitting in the top/bottom "bar" strip if it falls
# within this fraction of the screen's height from that edge.
EDGE_STRIP_FRACTION = 0.10

# Shared with step_runner.py, which checks a match's matched_text for this
# prefix: a synthetic label means the element had NO genuine accessible
# text/content-desc/hint/resource-id at all, so - unlike an ordinary label
# match - the match itself carries no corroborating evidence that the
# element's ACCESSIBLE BOUNDS correspond to its real on-screen tap area
# (confirmed in practice: a header's NAF icon strip's bounds span the
# whole screen width, but only a small portion of that width is actually
# tappable). step_runner.py uses this to decide when a failed click is
# worth escalating all the way to a fresh vision attempt.
SYNTHETIC_LABEL_PREFIX = "unlabeled icon"


def _screen_size_from_parsed(parsed: list):
    """The first bounds="[0,0][W,H]" node in document order is always the
    top-level FrameLayout covering the whole screen - reusing it here
    avoids a separate driver.get_window_size() round trip just to learn
    the screen's own dimensions."""
    for attrs in parsed:
        bounds = _parse_android_bounds(attrs.get("bounds") or "")
        if bounds and bounds[0] == 0 and bounds[1] == 0 and bounds[2] > 0 and bounds[3] > 0:
            return bounds[2], bounds[3]
    return None


def _descendant_text_for_element(el) -> str:
    """
    Fallback label source for an interactive element whose OWN text/
    content-desc/hint/resource-id are all empty - the common Compose/
    Material "Row"-style pattern of a clickable container wrapping a
    separate icon + label as its own CHILD nodes, rather than carrying any
    text itself. Tried BEFORE _synthetic_label_for_unlabeled's positional
    guess (a real nested label beats a coarse "top/bottom edge icon"
    placeholder whenever one is actually available), and reaches
    elements _synthetic_label_for_unlabeled can't at all (it only covers
    the screen's top/bottom edge strips - a list row in the middle of the
    screen falls through both and was previously just dropped from
    state_text entirely).

    Confirmed in practice as the actual cause of a real failure, not
    theoretical: Google Messages' account-switcher panel's "Help and
    feedback" row - plainly visible on screen, unambiguous - never once
    appeared as candidate text across several separate runs, because the
    clickable row itself has no text of its own; "Help and feedback" lives
    in a nested child text node this fallback is what actually reaches.
    Without it, fuzzy/semantic matching (tier 1) and the LLM tier (tier 2)
    were both working from a candidate list that structurally could not
    contain the word, however clearly it read on screen - guaranteed to
    fail every time, not merely likely to.
    """
    try:
        descendants = el.find_elements(By.XPATH, ANDROID_TEXT_XPATH_RELATIVE)
    except Exception:
        return ""
    for d in descendants:
        try:
            text = _sanitize(d.get_attribute("text") or d.get_attribute("content-desc") or "")
            if text:
                return text[:60]
        except Exception:
            continue
    return ""


def _descendant_text_from_parsed(parsed: list, index: int) -> str:
    """Same result as _descendant_text_for_element, read out of the ALREADY
    fetched page_source dump instead of one find_elements + get_attribute
    round trip per unlabeled element (a menu/list with many unlabeled
    clickable rows meant dozens of extra round trips per screen capture).
    Descendants follow their ancestor in document order and sit inside its
    bounds, so the first following node whose bounds stay inside this
    element's and that carries text/content-desc is the same nested label
    the XPath lookup would have returned."""
    box = _parse_android_bounds(parsed[index].get("bounds") or "")
    if not box:
        return ""
    x1, y1, x2, y2 = box
    for node in parsed[index + 1:]:
        b = _parse_android_bounds(node.get("bounds") or "")
        if not b or b[0] < x1 or b[1] < y1 or b[2] > x2 or b[3] > y2:
            break
        text = _sanitize(node.get("text") or node.get("content-desc") or "")
        if text:
            return text[:60]
    return ""


def _synthetic_label_for_unlabeled(bounds_str: str | None, screen_size) -> str | None:
    """
    A handful of icon-only toolbar buttons (a help/headphone icon, a
    hamburger menu, a notification bell...) carry NO text, content-desc,
    hint, or resource-id at all - Android's own accessibility tooling
    flags elements like this "NAF" (Not Accessibility-Friendly). Without
    this, such an element is dropped from state_text entirely (nothing to
    match against), forcing EVERY step targeting it through the vision
    fallback - and confirmed in practice to miss: a "Headphone icon on
    top right corner" step's vision guess landed at y=94, inside the
    phone's status bar, 16px above the real button's bounds (y >= 110) -
    a plausible-looking but simply imprecise coordinate for a small
    corner icon, tapping nothing.

    Elements sitting in the screen's top or bottom strip are almost
    always exactly this kind of icon toolbar/app bar, so give them a
    coarse, honest synthetic label instead - enough for the fuzzy/LLM
    tiers to have a real shot at a "top right icon"/"bottom nav"-style
    description, resolving to an actual element handle (reliable) rather
    than an estimated screen coordinate (approximate), without ever
    needing a screenshot. Deliberately conservative: only the unambiguous
    top/bottom edges, not "somewhere in the middle" guesses that could
    just as easily be wrong.
    """
    if not screen_size:
        return None
    bounds = _parse_android_bounds(bounds_str or "")
    if not bounds:
        return None
    _x1, y1, _x2, y2 = bounds
    _screen_w, screen_h = screen_size
    edge_margin = screen_h * EDGE_STRIP_FRACTION
    if y2 <= edge_margin:
        return f"{SYNTHETIC_LABEL_PREFIX} (top of screen)"
    if y1 >= screen_h - edge_margin:
        return f"{SYNTHETIC_LABEL_PREFIX} (bottom of screen)"
    return None


def _nearby_label_from_parsed(parsed: list, own_bounds: tuple) -> str | None:
    """Last-resort label source for an interactive element with no text of
    its own, no nested descendant text (_descendant_text_from_parsed), and
    not sitting in the top/bottom toolbar strip
    (_synthetic_label_for_unlabeled) - e.g. a bare icon button (favorite/
    delete/edit) inside a list row or card in the middle of the screen.
    Rather than drop it from state_text entirely - leaving it reachable
    ONLY via a vision-guessed coordinate, which is measurably worse for
    small icons (see _synthetic_label_for_unlabeled's own comment on a
    corner icon's vision guess missing by 16px) - find the nearest OTHER
    on-screen element with short, non-numeric, above-or-level text and
    describe this one relative to it: "unlabeled icon near 'Balance'"
    gives the fuzzy/LLM tiers a genuine, data-grounded anchor to resolve a
    description like "the icon next to the balance" against, rather than
    a vague, collision-prone positional guess. This is also why it's kept
    SEPARATE from _synthetic_label_for_unlabeled's coarse top/bottom-edge
    labels rather than folded into one function covering the whole
    screen: that function's own docstring deliberately stayed conservative
    ("not 'somewhere in the middle' guesses that could just as easily be
    wrong") specifically because a bare positional guess has no way to
    tell two different mid-screen icons apart - grounding the label in an
    actual nearby piece of on-screen text is what makes extending
    coverage past the toolbar edges safe to do at all.

    Same closest-qualifying-neighbor heuristic as recorder.py's
    _find_nearby_label (short/non-numeric text, positioned above or level
    with the target - the conventional place for a field/row's own
    label), but reads it straight out of the SAME already-parsed
    page_source dump get_android_state_full already has in hand, rather
    than that function's own fresh get_state_full call - this runs inside
    the state-building loop itself, potentially once per unlabeled
    element on a crowded screen, so a per-candidate round trip here would
    be exactly the cost _descendant_text_from_parsed's own docstring
    already explains avoiding.
    """
    x1, y1, x2, y2 = own_bounds
    target_cx, target_cy = (x1 + x2) / 2, (y1 + y2) / 2

    best_text = None
    best_distance = None
    for attrs in parsed:
        text = _sanitize(attrs.get("text") or attrs.get("content-desc") or "").strip()
        if not text or len(text) > 40:
            continue
        if re.fullmatch(r"[\d,.\s₹$€£%-]+", text):
            continue  # looks numeric/currency -- not a label
        bounds = _parse_android_bounds(attrs.get("bounds") or "")
        if not bounds:
            continue
        bx1, by1, bx2, by2 = bounds
        if by1 > y2:
            continue  # sits below the target -- not the conventional label position
        cx, cy = (bx1 + bx2) / 2, (by1 + by2) / 2
        distance = ((cx - target_cx) ** 2 + (cy - target_cy) ** 2) ** 0.5
        if best_distance is None or distance < best_distance:
            best_distance = distance
            best_text = text[:40]

    if best_text:
        return f"{SYNTHETIC_LABEL_PREFIX} near '{best_text}'"
    return None


def parse_android_page_source(page_source: str) -> list:
    """
    Parses the whole accessibility tree from ONE driver.page_source call
    into a list of {attribute: value} dicts, in document order.

    This is why capturing many attributes is cheap: page_source returns the
    entire screen's tree, every attribute included, in a single HTTP round
    trip. The alternative (find_elements + one get_attribute() call per
    attribute per element) costs one WebDriver round trip PER ATTRIBUTE -
    which is what made a richer attribute set expensive before, and is
    entirely a property of the extraction mechanism, not of the data.
    """
    import xml.etree.ElementTree as ET

    try:
        root = ET.fromstring(page_source)
    except ET.ParseError:
        return []

    results = []
    for node in root.iter():
        attrs = {k: v for k, v in node.attrib.items() if k in ANDROID_CAPTURED_ATTRS}
        if not attrs:
            continue
        # ElementTree exposes the Android class as the tag name for some
        # dumps and as a "class" attribute for others - normalize both.
        if "class" not in attrs and node.tag not in ("hierarchy",):
            attrs["class"] = node.tag
        results.append(attrs)
    return results


def get_android_state(driver, max_elements: int = 50, include_text_only: bool = False):
    """Same idea, but for an Appium/Android session using the UI hierarchy.
    Note: unlike web DOM, only elements CURRENTLY ON SCREEN appear here -
    the planner is instructed to scroll if what it needs isn't listed.

    Returns (state_text, ref_map) as before, plus populates attrs_map (see
    get_android_state_full) for callers that want the richer per-element
    attribute data - state_text itself stays deliberately LEAN, because
    that's what fuzzy matching scores against.
    """
    state_text, ref_map, _attrs_map = get_android_state_full(driver, max_elements, include_text_only)
    return state_text, ref_map


def get_android_state_full(driver, max_elements: int = 50, include_text_only: bool = False):
    """
    Returns (state_text, ref_map, attrs_map).

    attrs_map maps the same "E0"/"E1" refs to that element's full captured
    attribute dict (ANDROID_CAPTURED_ATTRS) - so the LLM tier and the
    recorder can use everything available, while state_text (what fuzzy
    matching scores against) stays lean.

    Attributes come from ONE page_source call rather than per-attribute
    get_attribute() round trips; ref_map still holds real WebElements,
    since downstream code has to actually click/type on them. The two are
    aligned by document order over the same element filter.

    include_text_only=True widens that filter from "interactive only" to
    "interactive OR has its own text/content-desc" (see
    ANDROID_INTERACTIVE_OR_TEXT_XPATH's comment) - opt-in, not the default,
    since it pulls in every plain text label on screen and would add noise
    to ordinary click-target resolution. Callers pass this for read/verify
    actions (assert_text, get_text, ...) where the target is often exactly
    a non-interactive status/message element that the narrower default
    filter can never find.
    """
    try:
        page_source = read_page_source(driver)
        parsed = parse_android_page_source(page_source)
    except Exception:
        parsed = []

    xpath = ANDROID_INTERACTIVE_OR_TEXT_XPATH if include_text_only else ANDROID_INTERACTIVE_XPATH
    is_match = _is_interactive_or_has_text if include_text_only else _is_interactive

    screen_size = _screen_size_from_parsed(parsed)
    elements = driver.find_elements(By.XPATH, xpath)
    parsed_indices = [j for j, a in enumerate(parsed) if is_match(a)]
    if len(parsed_indices) != len(elements):
        # The shared dump was taken a moment before these live elements were
        # found, and the screen moved in between (typically a list still
        # settling after a swipe) - so they no longer line up one-to-one.
        # Re-dump once, fresh, rather than falling into the per-element
        # attribute fallback below (measured: 143 extra round trips).
        try:
            parsed = parse_android_page_source(read_page_source(driver, fresh=True))
            screen_size = _screen_size_from_parsed(parsed)
            parsed_indices = [j for j, a in enumerate(parsed) if is_match(a)]
        except Exception:
            pass
    interactive_attrs = [parsed[j] for j in parsed_indices]

    ref_map = {}
    attrs_map = {}
    lines = []
    idx = 0
    for i, el in enumerate(elements):
        try:
            attrs = interactive_attrs[i] if i < len(interactive_attrs) else {}

            # Fall back to direct attribute reads if page_source parsing came
            # up empty or out of alignment - correctness beats the round-trip
            # saving, and this keeps behavior identical to before in that case.
            if not attrs:
                attrs = {
                    "text": el.text or "",
                    "content-desc": el.get_attribute("content-desc") or "",
                    "resource-id": el.get_attribute("resource-id") or "",
                    "hint": el.get_attribute("hint") or "",
                    "class": el.get_attribute("className") or "",
                    "checkable": el.get_attribute("checkable") or "false",
                    "checked": el.get_attribute("checked") or "false",
                    "enabled": el.get_attribute("enabled") or "true",
                    "bounds": el.get_attribute("bounds") or "",
                }

            if not _is_visibly_sized(attrs.get("bounds")):
                continue

            text = _sanitize(attrs.get("text") or "")[:60]
            desc = _sanitize(attrs.get("content-desc") or "")
            resource_id = _sanitize(attrs.get("resource-id") or "")
            hint = _sanitize(attrs.get("hint") or "")
            cls = attrs.get("class") or ""

            label = text or desc or hint or resource_id
            if not label:
                if i < len(parsed_indices) and interactive_attrs and attrs is interactive_attrs[i]:
                    label = _descendant_text_from_parsed(parsed, parsed_indices[i])
                else:
                    label = _descendant_text_for_element(el)  # parse misaligned - fall back to the live lookup
            if not label:
                label = _synthetic_label_for_unlabeled(attrs.get("bounds"), screen_size)
            if not label:
                # Last resort before dropping this element entirely - see
                # _nearby_label_from_parsed's own comment for why this is
                # safe to try for ANY position on screen, not just the
                # top/bottom edges _synthetic_label_for_unlabeled covers.
                own_bounds = _parse_android_bounds(attrs.get("bounds") or "")
                if own_bounds:
                    label = _nearby_label_from_parsed(parsed, own_bounds)
                if not label:
                    continue

            extra = _android_extra_text(attrs, label)

            ref = f"E{idx}"
            ref_map[ref] = el
            attrs_map[ref] = attrs
            lines.append(f"[{ref}] <{cls} id='{resource_id}'>{label}</{cls}>{extra}")
            idx += 1
            if idx >= max_elements:
                break
        except Exception:
            continue

    state_text = "Interactive elements (only what's currently on screen):\n" + "\n".join(lines)
    return state_text, ref_map, attrs_map


def get_android_state_light(driver, max_elements: int = 50, include_text_only: bool = True) -> str:
    """Same lines get_android_state_full would produce, built ONLY from the
    (shared) page_source dump: no find_elements XPath walk and no element
    handles. For callers that need a screen's identity/content but never
    act on an element (the flow graph's before/after snapshots) - they were
    paying for the full handle-building capture twice per step."""
    is_match = _is_interactive_or_has_text if include_text_only else _is_interactive
    parsed = parse_android_page_source(read_page_source(driver))
    screen_size = _screen_size_from_parsed(parsed)
    lines = []
    for j, attrs in enumerate(parsed):
        if not is_match(attrs) or not _is_visibly_sized(attrs.get("bounds")):
            continue
        text = _sanitize(attrs.get("text") or "")[:60]
        desc = _sanitize(attrs.get("content-desc") or "")
        resource_id = _sanitize(attrs.get("resource-id") or "")
        hint = _sanitize(attrs.get("hint") or "")
        cls = attrs.get("class") or ""
        label = text or desc or hint or resource_id or _descendant_text_from_parsed(parsed, j)
        if not label:
            label = _synthetic_label_for_unlabeled(attrs.get("bounds"), screen_size)
        if not label:
            own_bounds = _parse_android_bounds(attrs.get("bounds") or "")
            if own_bounds:
                label = _nearby_label_from_parsed(parsed, own_bounds)
            if not label:
                continue
        lines.append(f"[E{len(lines)}] <{cls} id='{resource_id}'>{label}</{cls}>{_android_extra_text(attrs, label)}")
        if len(lines) >= max_elements:
            break
    return "Interactive elements (only what's currently on screen):\n" + "\n".join(lines)


WEBVIEW_INTERACTIVE_XPATH = (
    "//a | //button | //input | //select | //textarea | "
    "//*[@role='button'] | //*[@role='checkbox'] | //*[@role='combobox'] | //*[@onclick]"
)


def _webview_label_for(driver, el) -> str:
    """Find the <label> text associated with a form field, if any."""
    try:
        el_id = el.get_attribute("id")
        if el_id:
            labels = driver.find_elements(By.XPATH, f"//label[@for='{el_id}']")
            if labels and labels[0].text.strip():
                return _sanitize(labels[0].text)
        parent_label = el.find_elements(By.XPATH, "./ancestor::label[1]")
        if parent_label and parent_label[0].text.strip():
            return _sanitize(parent_label[0].text)
    except Exception:
        pass
    return ""


def _describe_webview_element(driver, el) -> str | None:
    try:
        if not el.is_displayed():
            return None

        tag = el.tag_name
        text = _sanitize(el.text)[:60]
        el_id = el.get_attribute("id") or ""
        name = el.get_attribute("name") or ""
        placeholder = _sanitize(el.get_attribute("placeholder") or "")
        aria_label = _sanitize(el.get_attribute("aria-label") or "")
        el_type = el.get_attribute("type") or ""
        required = el.get_attribute("required") is not None
        label = _webview_label_for(driver, el)

        extra = ""
        if tag == "select":
            try:
                options = [o.text.strip() for o in el.find_elements(By.TAG_NAME, "option") if o.text.strip()]
            except Exception:
                options = []
            extra = f" options=[{', '.join(options[:15])}]"
        elif el_type in ("checkbox", "radio"):
            try:
                checked = el.is_selected()
            except Exception:
                checked = False
            extra = f" checked={checked}"
        elif tag in ("input", "textarea"):
            try:
                current_value = el.get_attribute("value") or ""
            except Exception:
                current_value = ""
            if el_type == "password" and current_value:
                current_value = "*" * len(current_value)
            extra = f" current_value='{current_value}'"

        display_label = label or aria_label or placeholder or text or name or el_id or el_type
        if not display_label and not extra:
            return None

        meta_bits = []
        if el_type:
            meta_bits.append(f"type={el_type}")
        if placeholder and placeholder != display_label:
            meta_bits.append(f"placeholder='{placeholder}'")
        if required:
            meta_bits.append("required")
        meta = (" " + " ".join(meta_bits)) if meta_bits else ""

        return f"<{tag} id='{el_id}'{meta}>{display_label}</{tag}>{extra}"
    except Exception:
        return None


def get_webview_state(driver, max_elements: int = 50):
    """State extraction for content genuinely rendered INSIDE an embedded
    WebView (see action_executor.py's WebView section) - the DOM
    equivalent of get_android_state, used automatically by get_state
    whenever the driver's current context is a WEBVIEW_* one (see
    action_executor.is_in_webview). Same (state_text, ref_map) shape
    either way, so every resolution tier (fuzzy/semantic/LLM) and every
    action (click, type, ...) already work identically regardless of
    which kind of state produced a given candidate - nothing about them
    needs to know or care whether an element came from the native tree or
    a WebView's DOM.

    Returns (state_text, ref_map)."""
    elements = driver.find_elements(By.XPATH, WEBVIEW_INTERACTIVE_XPATH)
    ref_map = {}
    lines = []
    idx = 0
    for el in elements:
        desc = _describe_webview_element(driver, el)
        if not desc:
            continue
        ref = f"E{idx}"
        ref_map[ref] = el
        lines.append(f"[{ref}] {desc}")
        idx += 1
        if idx >= max_elements:
            break

    try:
        url = driver.current_url
        title = driver.title
    except Exception:
        url, title = "", ""

    state_text = (
        f"WebView URL: {url}\nWebView Title: {title}\n"
        f"Interactive elements:\n" + "\n".join(lines)
    )
    return state_text, ref_map


def _in_webview(driver) -> bool:
    try:
        return str(driver.context or "").upper() != "NATIVE_APP"
    except Exception:
        return False


def get_state(driver, platform: str, include_text_only: bool = False):
    if _in_webview(driver):
        return get_webview_state(driver)
    return get_android_state(driver, include_text_only=include_text_only)


def get_state_full(driver, platform: str, include_text_only: bool = False):
    """
    Returns (state_text, ref_map, attrs_map) - same as get_state but with
    the per-element attribute dicts too (hint, password, max-text-length
    etc. via one page_source parse). WebView-sourced state returns an
    empty attrs_map: that richer capture is an Android accessibility-tree
    feature (one page_source parse gives every attribute for free); on a
    WebView the DOM equivalents are already folded into state_text
    directly via _describe_webview_element. Callers must therefore treat
    a missing/empty attrs entry as "no extra context available", never as
    an error - already true for every other caller of this function.
    """
    if _in_webview(driver):
        state_text, ref_map = get_webview_state(driver)
        return state_text, ref_map, {}
    return get_android_state_full(driver, include_text_only=include_text_only)


# ---------------------------------------------------------------------------
# Element-at-point reverse lookup - core primitive for recording: given a
# tap coordinate on the live screenshot, find which real element is there.
# ---------------------------------------------------------------------------

def _parse_android_bounds(bounds_str: str):
    """Android bounds attribute looks like "[59,988][299,1251]" -> (x1,y1,x2,y2)."""
    try:
        parts = bounds_str.replace("][", ",").strip("[]").split(",")
        x1, y1, x2, y2 = (int(p) for p in parts)
        return x1, y1, x2, y2
    except Exception:
        return None


def _is_actionable_attrs(attrs: dict) -> bool:
    """Same predicate used elsewhere in this file for 'is this a genuine
    interactive element' (clickable/long-clickable/checkable) - reused
    here so find_element_at_point_android's actionable-preference (see
    its docstring) means the exact same thing as everywhere else this
    codebase asks the question."""
    return (
        attrs.get("clickable") == "true"
        or attrs.get("long-clickable") == "true"
        or attrs.get("checkable") == "true"
    )


def find_element_at_point_android(driver, x: int, y: int):
    """
    Returns the SMALLEST element (by area) whose bounds contain (x, y), or
    None. Smallest-by-area rather than first-match: a tap point is very
    often contained by several nested elements at once (a button inside a
    card inside a list row) - the smallest one is the most specific, and
    almost always what a person visually intended when they tapped there.

    Prefers the smallest ACTIONABLE (clickable/long-clickable/checkable)
    match over the smallest match overall, when the two differ - a static
    text label or decorative container sitting exactly at the tap point
    is a much less likely genuine target than the nearest thing that
    actually responds to a tap, even if it happens to have a smaller
    bounding box. Confirmed necessary in practice: a real Android runtime
    permission dialog's tap was resolving to its message TextView
    (android:id/permission_message, non-clickable) rather than the Allow
    button that was actually tapped. Falls back to the overall smallest
    match when nothing actionable contains the point at all, so this
    never makes an existing successful resolution worse.

    Two things this fixes over a naive "//* + get_attribute per element"
    scan:

    1. **Speed.** The old version called driver.find_elements(By.XPATH,
       "//*") - literally every node on screen, often 100-300+ on a real
       app - then did a SEPARATE get_attribute("bounds") HTTP round trip
       PER element just to find the one under the tap. That's the
       dominant cost behind "every recorded tap takes a second or two".
       This does exactly ONE page_source call (bounds/displayed/etc. for
       every node in a single response, same parser get_android_state
       already uses) to pick the winning node, then ONE targeted
       find_elements call to fetch just that element's live handle - two
       round trips total, not 1 + N.

    2. **Correctness.** Bounds alone can't tell a currently-visible node
       from one that's off-screen/collapsed/mid-transition but still
       geometrically overlaps the tap point (a hidden tab's content, an
       overlay animating out, etc.) - and a hidden node like that is
       often SMALLER than the real on-screen target, so it used to win
       the "smallest area" contest outright. Filtering on the
       "displayed" attribute (also captured by parse_android_page_source)
       excludes exactly that case.
    """
    try:
        page_source = driver.page_source
    except Exception:
        return None
    parsed = parse_android_page_source(page_source)

    best_attrs = None
    best_area = None
    best_actionable_attrs = None
    best_actionable_area = None
    for attrs in parsed:
        if attrs.get("displayed") == "false":
            continue
        bounds_str = attrs.get("bounds")
        if not bounds_str:
            continue
        bounds = _parse_android_bounds(bounds_str)
        if not bounds:
            continue
        x1, y1, x2, y2 = bounds
        if not (x1 <= x <= x2 and y1 <= y <= y2):
            continue
        area = (x2 - x1) * (y2 - y1)
        if area <= 0:
            continue
        if best_area is None or area < best_area:
            best_area = area
            best_attrs = attrs
        if _is_actionable_attrs(attrs) and (best_actionable_area is None or area < best_actionable_area):
            best_actionable_area = area
            best_actionable_attrs = attrs

    # Prefer the smallest ACTIONABLE match - see docstring - falling back
    # to the smallest match overall (today's original behavior) only when
    # nothing actionable contains the point at all.
    best_attrs = best_actionable_attrs or best_attrs

    if best_attrs is None:
        return None

    # One targeted lookup for the live WebElement handle callers actually
    # need (click/type/.rect/etc. all require a real element, not just the
    # parsed attribute dict). bounds is a reliable disambiguator on its
    # own - two on-screen elements sharing the exact same pixel rect would
    # be indistinguishable to tap anyway - and resource-id (when present)
    # narrows it further in the rare case bounds repeats (e.g. a
    # zero-size or fully-overlapping decorative sibling).
    bounds_str = best_attrs["bounds"]
    resource_id = best_attrs.get("resource-id") or ""
    try:
        if resource_id:
            xpath = f'//*[@resource-id="{resource_id}" and @bounds="{bounds_str}"]'
        else:
            xpath = f'//*[@bounds="{bounds_str}"]'
        candidates = driver.find_elements(By.XPATH, xpath)
        return candidates[0] if candidates else None
    except Exception:
        return None


def find_element_at_point(driver, x: int, y: int, platform: str):
    return find_element_at_point_android(driver, x, y)


# ---------------------------------------------------------------------------
# Scoped extraction - used by "Get Value Within" to search only inside a
# specific element's subtree (e.g. one account's row) instead of the whole
# screen. This is what makes it possible to disambiguate a repeated label
# like "Balance" that appears once per account: resolve the account's own
# section first, then only look for "Balance" among ITS descendants.
#
# Deliberately a SEPARATE, broader query than the interactive-element scan
# above: a value being extracted (a balance figure, a status label) is very
# often a plain, non-interactive text view, not a button/input/spinner - the
# INTERACTIVE_XPATH queries would silently miss it entirely since they only
# match clickable/checkable/EditText/Button/Spinner elements.
# ---------------------------------------------------------------------------

ANDROID_TEXT_XPATH_RELATIVE = ".//*[string-length(@text) > 0 or string-length(@content-desc) > 0]"


def get_android_state_within(driver, scope_element, max_elements: int = 50):
    """Same idea as get_android_state, but only elements inside
    scope_element's own subtree - not the whole screen. Returns
    (state_text, ref_map)."""
    elements = scope_element.find_elements(By.XPATH, ANDROID_TEXT_XPATH_RELATIVE)
    ref_map = {}
    lines = []
    idx = 0
    for el in elements:
        try:
            if not _is_visibly_sized(el.get_attribute("bounds")):
                continue
            text = _sanitize(el.text)[:60]
            desc = _sanitize(el.get_attribute("content-desc") or "")
            resource_id = _sanitize(el.get_attribute("resource-id") or "")
            hint = _sanitize(el.get_attribute("hint") or "")
            cls = el.get_attribute("className") or ""
            label = text or desc or hint or resource_id
            if not label:
                continue
            extra = f" hint='{hint}'" if hint and label != hint else ""
            ref = f"E{idx}"
            ref_map[ref] = el
            lines.append(f"[{ref}] <{cls} id='{resource_id}'>{label}</{cls}>{extra}")
            idx += 1
            if idx >= max_elements:
                break
        except Exception:
            continue

    state_text = "Elements within the scoped section:\n" + "\n".join(lines)
    return state_text, ref_map


def get_state_within(driver, scope_element, platform: str):
    return get_android_state_within(driver, scope_element)