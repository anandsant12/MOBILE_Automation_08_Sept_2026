"""
The loop: dismiss popups -> Plan -> Locate -> Act -> Verify -> repeat, until
the LLM says "finish"/"fail", a repetition guard trips, or a step budget is
hit.

Two entry points share one engine (_run_loop):

  - run_agent(goal)
        Standalone: opens its own driver session, runs until finish/fail/
        max_steps, closes the session when done. Used by the free-text
        "one goal" mode.

  - run_plan_loop(driver, goal, max_substeps, platform, step_prefix)
        Bounded: reuses an ALREADY-OPEN driver session (does not open or
        close one), capped at max_substeps. Used by step_runner.py's
        "AI Action" step type, so it can drop into the exact same
        browser/app session as the explicit steps around it.

Async so the LLM calls (network-bound) don't block; blocking Selenium/
Appium driver calls are pushed onto a thread via asyncio.to_thread so they
don't stall the event loop either. Both entry points are async generators
that yield exactly once per step.
"""

import asyncio

from app.automation.driver_manager import DriverManager
from app.automation.page_state import get_state
from app.automation.planner import aplan_next_step
from app.automation.locator_engine import aresolve_target
from app.automation.resolver import aresolve_by_description
from app.automation import action_executor as ex
from app.automation.verifier import averify, verify_field_value
from app.automation.popup_handler import dismiss_popups
from app.utils.screenshot import take_screenshot
from config import settings


def _fingerprint(action: dict) -> tuple:
    return (
        action.get("action"), action.get("ref"), action.get("text"),
        action.get("select_value"), action.get("direction"),
    )


async def _run_loop(driver, platform: str, goal: str, max_steps: int, step_prefix: str = ""):
    """Shared engine for both entry points below. Yields one log dict per step."""
    history: list[str] = []
    last_fingerprint = None
    repeat_count = 0

    for step_num in range(1, max_steps + 1):
        await asyncio.to_thread(dismiss_popups, driver, platform)

        state_text, ref_map = await asyncio.to_thread(get_state, driver, platform)
        action = await aplan_next_step(goal, history, state_text)
        act_type = action.get("action")

        log = {"step": f"{step_prefix}{step_num}", "action": action, "verification": None,
               "screenshot": None, "status": "ok"}

        if act_type == "finish":
            log["status"] = "finished"
            yield log
            return

        if act_type == "fail":
            log["status"] = "failed"
            yield log
            return

        # Safety net: if the model proposes the exact same action twice in a
        # row, it's stuck -- almost always because the goal was already
        # achieved but the model didn't say "finish". Stop rather than churn
        # through the remaining steps doing nothing new.
        fp = _fingerprint(action)
        repeat_count = repeat_count + 1 if fp == last_fingerprint else 0
        last_fingerprint = fp
        if repeat_count >= 2:
            log["status"] = "finished"
            log["action"] = {
                **action,
                "reasoning": (
                    "Stopped automatically: the same action was proposed "
                    "repeatedly, which usually means the goal was already achieved."
                ),
            }
            yield log
            return

        description = action.get("expected_result") or action.get("reasoning") or goal
        ref = action.get("ref")

        verify_target = None  # set below for type/select, so the deterministic
                               # field-value fast path can read it back directly

        try:
            if act_type in ("click", "type", "select", "toggle"):
                target = await aresolve_target(driver, ref, ref_map, description)
                if target is None:
                    raise RuntimeError(f"Could not locate element for: {description}")
                if act_type == "click":
                    await asyncio.to_thread(ex.click, driver, target)
                elif act_type == "type":
                    await asyncio.to_thread(ex.type_text, driver, target, action.get("text") or "")
                    verify_target = target
                elif act_type == "select":
                    # No real HTML <select> on Android -- open whatever the
                    # target turns out to be (native picker, Material
                    # dropdown, ...) and search the resulting screen for the
                    # requested option, the same click-then-search pattern
                    # step_runner.py's "select" dispatch uses.
                    await asyncio.to_thread(ex.click, driver, target)
                    select_value = action.get("select_value") or ""
                    option_state_text, option_ref_map = await asyncio.to_thread(get_state, driver, platform)
                    option_target, _ = await aresolve_by_description(
                        driver, select_value, option_state_text, option_ref_map, platform=platform
                    )
                    if option_target is None:
                        raise RuntimeError(
                            f"Opened the picker for '{description}' but couldn't find an "
                            f"option matching '{select_value}'."
                        )
                    await asyncio.to_thread(ex.click, driver, option_target)
                    target = option_target
                    verify_target = target
                elif act_type == "toggle":
                    await asyncio.to_thread(ex.click, driver, target)  # checkbox/radio toggle == click

            elif act_type == "submit":
                target = None
                if ref:
                    target = await aresolve_target(driver, ref, ref_map, description)
                await asyncio.to_thread(ex.submit, driver, target)

            elif act_type == "scroll":
                await asyncio.to_thread(ex.scroll, driver, platform, action.get("direction") or "down", "normal")

            elif act_type == "browser_back":
                await asyncio.to_thread(ex.go_back, driver)

            elif act_type == "browser_forward":
                await asyncio.to_thread(ex.go_forward, driver)

            elif act_type == "refresh":
                await asyncio.to_thread(ex.refresh, driver)

            elif act_type == "wait":
                await asyncio.sleep(2)

            elif act_type == "verify":
                pass  # verification always happens below regardless

            else:
                raise RuntimeError(f"Unknown action type: {act_type}")

        except Exception as e:
            log["status"] = "error"
            log["error"] = str(e)
            history.append(f"Step {step_num}: {act_type} on {ref} -> ERROR: {e}")
            log["screenshot"] = await asyncio.to_thread(take_screenshot, driver, f"step{step_num}_error")
            yield log
            continue

        # Deterministic fast path: a type/select action has a ground-truth
        # value to check (what's actually in the field now), so skip the
        # fuzzy/vision tiers entirely rather than fuzzy-matching a whole
        # natural-language expected_result sentence against page text (which
        # is what was landing plenty of these in the grey zone and burning
        # an unnecessary, much slower vision call for something answerable
        # with certainty in milliseconds).
        if verify_target is not None and act_type == "type":
            verification = verify_field_value(verify_target, action.get("text") or "", platform)
        elif verify_target is not None and act_type == "select":
            verification = verify_field_value(verify_target, action.get("select_value") or "", platform)
        else:
            verification = await averify(driver, action.get("expected_result", ""), platform)
        log["verification"] = verification
        log["screenshot"] = await asyncio.to_thread(take_screenshot, driver, f"step{step_num}")

        history.append(
            f"Step {step_num}: {act_type} (ref={ref}) -> "
            f"{'PASSED' if verification['passed'] else 'FAILED'} "
            f"({verification['method']}): {verification['reasoning']}"
        )

        yield log


async def run_agent(goal: str):
    """Standalone: opens its own driver session, runs until finish/fail/
    max_steps, closes it. Runs the goal exactly once and stops - status
    "finished"/"failed" is terminal."""
    dm = DriverManager()
    driver = await asyncio.to_thread(dm.start)
    try:
        # Cookie/consent banners often appear immediately on load.
        await asyncio.to_thread(dismiss_popups, driver, settings.platform)
        async for log in _run_loop(driver, settings.platform, goal, settings.max_steps):
            yield log
    finally:
        await asyncio.to_thread(dm.quit)


async def run_plan_loop(driver, goal: str, max_substeps: int, platform: str, step_prefix: str = ""):
    """Bounded: reuses an already-open driver/session (does not open or
    close one) -- used by step_runner.py's 'AI Action' step type so it
    shares the same session/state as the explicit steps around it."""
    async for log in _run_loop(driver, platform, goal, max_substeps, step_prefix=step_prefix):
        yield log
