"""
Implements the Wait-category actions: wait, wait_for, wait_for_text,
wait_for_navigation. Polling-based since Appium doesn't expose one
universal "wait for the app to settle" primitive. Android/Appium only.
"""

import asyncio
import time

from selenium.webdriver.common.by import By

from app.automation.page_state import get_state
from app.automation.resolver import aresolve_by_description

# Android's own accessibility class for a Toast popup. Whether a given
# Toast actually surfaces here at all is genuinely device/OS-version/OEM-
# skin dependent (some Android builds route a Toast through a window the
# standard accessibility tree doesn't expose) - this is best-effort, not a
# guarantee, which is exactly why wait_for_text below tries this ALONGSIDE
# a plain page_source text search rather than instead of it: a Toast that
# doesn't surface this way very often still shows up in the ordinary
# accessibility dump for the moment it's on screen, and a Toast that DOES
# surface this way is otherwise invisible to page_source entirely (it
# renders in a system-level window layered on top of the app, outside the
# app's own view hierarchy) - so relying on only one of the two misses
# real cases the other one alone catches.
TOAST_XPATH = "//*[@class='android.widget.Toast']"


async def wait_seconds(seconds: float):
    await asyncio.sleep(seconds)


async def wait_for_element(driver, platform: str, description: str, timeout: float = 10, poll: float = 0.5):
    deadline = time.time() + timeout
    while time.time() < deadline:
        state_text, ref_map = await asyncio.to_thread(get_state, driver, platform)
        target, _resolution_info = await aresolve_by_description(driver, description, state_text, ref_map)
        if target is not None:
            return target
        await asyncio.sleep(poll)
    raise RuntimeError(f"Timed out waiting for: {description}")


def _read_toast_text(driver) -> str:
    """One-shot, synchronous check for a currently-showing Toast's text -
    see TOAST_XPATH's own comment on why this can't be relied on alone.
    Never raises; a XPath/driver hiccup here should never break the
    caller's own polling loop over a genuinely transient failure."""
    try:
        for el in driver.find_elements(By.XPATH, TOAST_XPATH):
            text = (el.text or el.get_attribute("content-desc") or "").strip()
            if text:
                return text
    except Exception:
        pass
    return ""


async def wait_for_text(driver, text: str, timeout: float = 10, poll: float = 0.5):
    """Polls for `text` appearing anywhere on screen - the ordinary
    accessibility dump (page_source, which includes every on-screen text/
    content-desc value) AND, separately, Android's own Toast-window check
    (see TOAST_XPATH) each poll, since a Toast popup is the single most
    common thing this action is used to wait for ("Item added to cart",
    "Copied to clipboard", ...) and is exactly the case page_source alone
    can silently miss - not because the text-match logic is wrong, but
    because the Toast may never have been part of that dump to search in
    the first place. Polls FAST relative to a Toast's own lifetime
    (Android's default durations are ~2s/~3.5s) - a slower poll interval
    could step over a genuine Toast's entire visible window between checks.
    """
    deadline = time.time() + timeout
    needle = text.lower()
    while time.time() < deadline:
        page_text = await asyncio.to_thread(lambda: driver.page_source)
        if needle in page_text.lower():
            return True
        toast_text = await asyncio.to_thread(_read_toast_text, driver)
        if toast_text and needle in toast_text.lower():
            return True
        await asyncio.sleep(poll)
    raise RuntimeError(f"Timed out waiting for text: {text}")


async def wait_for_navigation(driver, timeout: float = 10):
    """Waits for the foreground ACTIVITY to change - the Android
    equivalent of "navigated somewhere new" (there's no URL/page-load
    concept on a native app)."""
    deadline = time.time() + timeout
    try:
        start_activity = driver.current_activity
    except Exception:
        start_activity = None
    while time.time() < deadline:
        try:
            current = driver.current_activity
        except Exception:
            current = None
        if current and current != start_activity:
            return True
        await asyncio.sleep(0.3)
    raise RuntimeError("Timed out waiting for navigation (Android activity change).")
