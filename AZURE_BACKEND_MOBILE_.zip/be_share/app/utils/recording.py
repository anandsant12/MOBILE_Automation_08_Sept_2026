"""
Screen recording for a whole flow run - start_recording/stop_recording_and_save
wrap Appium's driver.start_recording_screen()/stop_recording_screen() (see
their own extensive docstrings in the Appium Python client for every
available option; only the handful actually used here are surfaced).

Android's own recording command caps a SINGLE recording at 180 seconds (3
minutes) - not an Appium limitation, a hard ceiling on the underlying
`adb shell screenrecord` command it wraps. A flow that runs longer than
that will have its recording silently cut off at 180s by the platform
itself, with the run continuing normally past that point - there is no
practical way to chain multiple recordings into one continuous video
without a visible seam, so this is a known, honest limitation rather than
something worked around here.

Both functions are best-effort and never raise: screen recording is a
nice-to-have for reviewing a run afterward, not something that should ever
fail the run itself if it can't be set up (an emulator without hardware
video encoding support, an Appium build without the feature, ...).
"""

import base64
import time
from pathlib import Path

from config import settings

RECORDINGS_DIR = Path(settings.base_dir) / "logs" / "recordings"

# Android's own hard ceiling (see module docstring) - never pass a bigger
# value through, since a caller-requested but not-actually-possible limit
# gives no indication the recording will simply stop early anyway.
ANDROID_MAX_TIME_LIMIT_S = 180


def start_recording(driver, time_limit_s: int = ANDROID_MAX_TIME_LIMIT_S) -> bool:
    """Starts screen recording for the CURRENT driver session. Returns
    whether it actually started - callers should only attempt
    stop_recording_and_save later if this returned True, since stopping a
    recording that never started just wastes a call for an empty result
    stop_recording_and_save already treats as "nothing to save" anyway."""
    try:
        driver.start_recording_screen(
            timeLimit=min(int(time_limit_s), ANDROID_MAX_TIME_LIMIT_S),
            # A leftover recording from a previous run that crashed before
            # calling stop_recording_screen shouldn't block a new one from
            # starting - without this, start_recording_screen's own default
            # behavior is to hand back whatever that stale prior capture is
            # instead of beginning a fresh one.
            forcedRestart=True,
        )
        return True
    except Exception:
        return False


def stop_recording_and_save(driver, label: str = "run") -> str | None:
    """Stops the current recording and writes it to RECORDINGS_DIR as an
    .mp4. Returns the saved file's path, or None if there was nothing to
    save (recording was never started/supported, or stopping it failed)."""
    try:
        payload_b64 = driver.stop_recording_screen()
    except Exception:
        return None
    if not payload_b64:
        return None
    try:
        RECORDINGS_DIR.mkdir(parents=True, exist_ok=True)
        safe_label = "".join(c if c.isalnum() or c in "-_" else "_" for c in (label or "run"))
        filename = f"{safe_label}_{int(time.time())}.mp4"
        path = RECORDINGS_DIR / filename
        path.write_bytes(base64.b64decode(payload_b64))
        return str(path)
    except Exception:
        return None
