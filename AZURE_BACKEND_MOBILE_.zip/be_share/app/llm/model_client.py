"""
Thin wrapper so planner.py, locator_engine.py, resolver.py, verifier.py,
recorder.py, flow_graph.py, and semantic_matcher.py all go through one
place for every Azure OpenAI call, and never construct a client
themselves.

This project is Azure OpenAI ONLY - one deployment for text/planning
calls, one (often the same) deployment for vision calls, and one
embedding deployment for semantic candidate matching:

  achat_json(...)        -> AZURE_OPENAI_DEPLOYMENT            (gpt-4.1-mini)
  achat_vision_json(...) -> AZURE_OPENAI_VISION_DEPLOYMENT      (gpt-4.1-mini,
                             falls back to AZURE_OPENAI_DEPLOYMENT - it's
                             natively multimodal, so one deployment can
                             cover both text and vision)
  aembed_texts(...)      -> AZURE_OPENAI_EMBEDDING_DEPLOYMENT  (text-embedding-ada-002)

Uses AsyncAzureOpenAI throughout (from the `openai` SDK - Azure OpenAI is
served through the same client library, just pointed at your Azure
resource). The "model" param on every call below is your Azure
DEPLOYMENT NAME (set in Azure AI/OpenAI Studio), never the underlying
model name like "gpt-4.1-mini" or "text-embedding-ada-002" - Azure routes
by deployment name, not model name.

This module also centralizes two things every caller used to handle (or
fail to handle) on its own:

1. STRUCTURED OUTPUTS. achat_json/achat_vision_json take an optional
   `schema` - a {"name": ..., "schema": {...}} JSON Schema dict. When
   given, the call uses response_format={"type": "json_schema", ...,
   "strict": true}, which makes the API itself reject/repair a response
   that doesn't match the schema, instead of just requesting "some JSON"
   (the older json_object mode) and hoping the model picked real field
   names/enum values. Falls back automatically, in order, to json_object
   then to no response_format at all, if a specific deployment/API
   version rejects the stricter mode (see _complete) - a caller passing a
   schema always degrades gracefully rather than hard-failing on an older
   snapshot that doesn't support it yet.

2. TIMEOUT + RETRY. Every call is bounded (never hangs indefinitely - see
   REQUEST_TIMEOUT_S's own comment for the real multi-minute stall this
   fixes) and automatically retries a genuinely transient failure (a rate
   limit, a connection hiccup, a request timeout, a 5xx) a couple of
   times with short backoff before giving up - see _with_retry. Before
   this was centralized here, three different call sites (resolver.py,
   locator_engine.py, flow_graph.py) had each independently wrapped their
   own call in asyncio.wait_for as a band-aid for the same missing
   client-level timeout, and at least two more (planner.py, verifier.py)
   had no bound at all. Callers that already had their own measured,
   reasoned timeout value keep passing it explicitly via `timeout=`;
   everyone else gets a sane default.
"""

import asyncio
import json
import random
import re

from openai import AsyncAzureOpenAI
from openai import BadRequestError as OpenAIBadRequestError
from openai import RateLimitError, APIConnectionError, APITimeoutError, InternalServerError

from config import settings

MAX_TOKENS = 4096
# Vision responses are a tiny fixed JSON shape ({"found", "x", "y",
# "reasoning"}) - nowhere near 4096 tokens' worth of content. A smaller,
# still-generous budget keeps vision calls fast without ever truncating a
# real response.
VISION_MAX_TOKENS = 900

# Per-HTTP-request ceiling, set on the client itself (distinct from the
# retry/backoff logic below, and from the overall per-call `timeout=`
# every achat_json/achat_vision_json call is also wrapped in). Confirmed
# necessary by a real incident, not theoretical: with no client-level
# timeout at all, a single bad response once stalled for ~4.5 MINUTES with
# nothing externally distinguishing it from "still legitimately
# searching" - by the time it gave up, the app's own idle-session timeout
# had already fired, making the eventual on-screen state look like the
# cause when it was actually a symptom (see resolver.py's and
# locator_engine.py's own per-caller timeouts, added at the time as a
# band-aid for exactly this before it was centralized here). Generous
# enough to never cut off a genuinely slow-but-healthy call - the route-
# selection model alone has been measured up to ~17s for one attempt -
# while still being far short of minutes.
REQUEST_TIMEOUT_S = 40.0

# Retried ONLY for genuinely transient failures - a rate limit, a
# connection hiccup, a request timeout, or a 5xx. Deliberately NOT a 400
# (BadRequestError - the response_format degrade-on-400 logic in
# _complete handles that differently, and retrying the identical request
# verbatim would just fail the identical way again) and NOT an auth/
# permission/not-found error (a bad key or wrong deployment name doesn't
# fix itself by waiting a second and trying again).
_RETRYABLE_ERRORS = (RateLimitError, APIConnectionError, APITimeoutError, InternalServerError)
MAX_RETRIES = 2  # extra attempts after the first - 3 total
RETRY_BASE_DELAY_S = 1.0
RETRY_MAX_DELAY_S = 4.0

# Overall wall-clock budget for ONE logical call - every attempt AND every
# backoff sleep between them combined - when a caller doesn't specify its
# own via `timeout=`. Callers with their own measured latency
# characteristics (resolver.py's and flow_graph.py's own LLM_CALL_TIMEOUT_S,
# locator_engine.py's VISION_CALL_TIMEOUT_S) pass that value through
# instead, so this default only matters for call sites that never had one
# at all (planner.py, verifier.py, recorder.py's classify call).
DEFAULT_CALL_TIMEOUT_S = 30.0
DEFAULT_VISION_CALL_TIMEOUT_S = 35.0

_client: AsyncAzureOpenAI | None = None


def _get_client() -> AsyncAzureOpenAI:
    """Lazy singleton - one AsyncAzureOpenAI client for chat, vision, AND
    embeddings (they're all the same Azure resource, just different
    deployments passed as `model` per-call).

    max_retries=0: the SDK's own client has a built-in retry (default 2,
    for a similar set of transient errors) - explicitly disabled here so
    there is exactly ONE retry layer, ours (_with_retry), with full
    visibility into which errors it's retrying and how. Leaving both
    active would stack two uncoordinated retry loops on top of each
    other, multiplying actual attempts unpredictably."""
    missing = [
        name for name, val in [
            ("AZURE_OPENAI_API_KEY", settings.azure_openai_api_key),
            ("AZURE_OPENAI_ENDPOINT", settings.azure_openai_endpoint),
        ] if not val
    ]
    if missing:
        raise RuntimeError(
            f"Missing Azure OpenAI config: {', '.join(missing)}. Fill these in your .env."
        )
    global _client
    if _client is None:
        _client = AsyncAzureOpenAI(
            api_key=settings.azure_openai_api_key,
            azure_endpoint=settings.azure_openai_endpoint,
            api_version=settings.azure_openai_api_version,
            timeout=REQUEST_TIMEOUT_S,
            max_retries=0,
        )
    return _client


def _text_deployment() -> str:
    if not settings.azure_openai_deployment:
        raise RuntimeError("Missing AZURE_OPENAI_DEPLOYMENT. Fill this in your .env.")
    return settings.azure_openai_deployment


def _vision_deployment() -> str:
    model = settings.azure_openai_vision_deployment or settings.azure_openai_deployment
    if not model:
        raise RuntimeError(
            "Missing AZURE_OPENAI_DEPLOYMENT (or AZURE_OPENAI_VISION_DEPLOYMENT). "
            "Fill this in your .env."
        )
    return model


async def _with_retry(call_fn):
    """Retries a zero-arg async callable up to MAX_RETRIES extra times
    (see _RETRYABLE_ERRORS for exactly which failures qualify), with
    exponential backoff plus jitter (jitter avoids every in-flight call
    retrying at the exact same instant if several fail together, e.g. a
    shared quota getting briefly exhausted). Backoff is deliberately
    short - 1s, then 2s, capped at RETRY_MAX_DELAY_S - so the total added
    latency in the worst case (a few seconds) stays comfortably inside
    every caller's own per-call timeout budget instead of eating most of
    it just on sleeping between attempts."""
    last_error = None
    for attempt in range(MAX_RETRIES + 1):
        try:
            return await call_fn()
        except _RETRYABLE_ERRORS as e:
            last_error = e
            if attempt >= MAX_RETRIES:
                raise
            delay = min(RETRY_BASE_DELAY_S * (2 ** attempt), RETRY_MAX_DELAY_S)
            delay += random.uniform(0, delay * 0.25)
            await asyncio.sleep(delay)
    raise last_error  # pragma: no cover - loop above always returns or raises


def _schema_response_format(schema: dict | None) -> dict | None:
    """schema is {"name": "...", "schema": {<JSON Schema object>}}. Every
    property must be listed in the schema's own "required" (even ones
    that are logically optional - express that with a nullable type
    instead, e.g. {"type": ["string", "null"]}) and every object needs
    "additionalProperties": false - both are hard requirements of
    strict-mode structured outputs, not stylistic choices made here.
    schema=None means "no schema available for this call" (e.g.
    flow_graph.py's route-selection response has a free-form
    value_replacements dict with arbitrary keys, which strict mode
    fundamentally can't express) - falls back to plain json_object mode,
    the same behavior every call had before schemas existed."""
    if schema is None:
        return {"type": "json_object"}
    return {
        "type": "json_schema",
        "json_schema": {"name": schema["name"], "strict": True, "schema": schema["schema"]},
    }


def _strip_think_blocks(raw: str) -> str:
    # Defensive only - gpt-4.1-mini doesn't emit <think> blocks, but this
    # keeps _extract_json robust if a future deployment ever does.
    cleaned = re.sub(r"<think>.*?</think>", "", raw or "", flags=re.DOTALL).strip()
    if "<think>" in cleaned:
        cleaned = cleaned.split("<think>")[0].strip()
    return cleaned


def _extract_json(raw: str) -> dict:
    if not raw or not raw.strip():
        raise ValueError("Empty response from model")

    cleaned = _strip_think_blocks(raw)
    if cleaned.startswith("```"):
        cleaned = cleaned.strip("`")
        if cleaned.lower().startswith("json"):
            cleaned = cleaned[4:]
        cleaned = cleaned.strip()

    if not cleaned:
        raise ValueError("Empty response from model after stripping reasoning")

    try:
        return json.loads(cleaned)
    except json.JSONDecodeError:
        pass

    match = re.search(r"\{.*\}", cleaned, re.DOTALL)
    if match:
        return json.loads(match.group(0))

    raise ValueError(f"Could not parse JSON from model output: {raw!r}")


async def _complete(model: str, messages: list, response_format: dict | None,
                     max_tokens: int = MAX_TOKENS) -> str:
    client = _get_client()
    kwargs = {
        "model": model,
        "messages": messages,
        "temperature": 0.2,
        "max_tokens": max_tokens,
    }
    if response_format is not None:
        kwargs["response_format"] = response_format

    async def _do_call() -> str:
        completion = await client.chat.completions.create(**kwargs)
        return completion.choices[0].message.content

    try:
        return await _with_retry(_do_call)
    except OpenAIBadRequestError:
        # This exact response_format wasn't accepted - either a strict
        # json_schema request against a deployment/API version that
        # doesn't support it yet, or (pre-existing behavior) a forced
        # json_object mode a particular prompt 400'd on. Step down one
        # level rather than hard-failing a call a stricter mode would
        # have made more reliable, not less.
        if response_format and response_format.get("type") == "json_schema":
            return await _complete(model, messages, {"type": "json_object"}, max_tokens)
        if response_format is not None:
            return await _complete(model, messages, None, max_tokens)
        raise


async def _call_and_parse(model: str, messages: list, schema: dict | None = None,
                           max_tokens: int = MAX_TOKENS) -> dict:
    response_format = _schema_response_format(schema)
    raw = await _complete(model, messages, response_format, max_tokens)
    try:
        return _extract_json(raw)
    except ValueError:
        retry_messages = messages + [
            {"role": "assistant", "content": raw or ""},
            {"role": "user", "content": "That was not valid JSON. Reply again with ONLY a single "
                                         "valid JSON object, no markdown fences, no other text."},
        ]
        raw2 = await _complete(model, retry_messages, None, max_tokens)
        return _extract_json(raw2)


async def achat_json(system_prompt: str, user_prompt: str, schema: dict | None = None,
                      timeout: float = DEFAULT_CALL_TIMEOUT_S) -> dict:
    """Text-only planning/reasoning call against AZURE_OPENAI_DEPLOYMENT.

    schema: optional {"name", "schema"} JSON Schema dict for strict
    structured outputs - see _schema_response_format. Omit for a call
    whose shape can't be expressed in strict mode (e.g. a free-form dict
    with arbitrary keys); every other call site should pass one.
    timeout: overall budget for this call, including retries - pass your
    own measured value if you have one (see this module's own docstring),
    otherwise the default is sized generously for a typical text call."""
    model = _text_deployment()
    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": user_prompt},
    ]
    return await asyncio.wait_for(_call_and_parse(model, messages, schema=schema), timeout=timeout)


async def achat_vision_json(system_prompt: str, user_prompt: str, image_b64: str,
                             schema: dict | None = None,
                             timeout: float = DEFAULT_VISION_CALL_TIMEOUT_S) -> dict:
    """Vision call (screenshot -> JSON) against AZURE_OPENAI_VISION_DEPLOYMENT
    (falls back to AZURE_OPENAI_DEPLOYMENT) - a normal system + user(text+image)
    shape, which Azure's multimodal deployments (e.g. gpt-4.1-mini) handle fine.
    schema/timeout: see achat_json - same meaning, vision-sized default timeout."""
    model = _vision_deployment()
    messages = [
        {"role": "system", "content": system_prompt},
        {
            "role": "user",
            "content": [
                {"type": "text", "text": user_prompt},
                {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{image_b64}"}},
            ],
        },
    ]
    return await asyncio.wait_for(
        _call_and_parse(model, messages, schema=schema, max_tokens=VISION_MAX_TOKENS),
        timeout=timeout,
    )


async def aembed_texts(texts: list[str]) -> list[list[float]]:
    """Batched embedding call against AZURE_OPENAI_EMBEDDING_DEPLOYMENT (a
    text-embedding-ada-002 deployment). Returns one vector per input text,
    in the same order as `texts` - used by semantic_matcher.py in place of
    the old local sentence-transformers model. Same retry/timeout
    treatment as every chat call above."""
    if not settings.azure_openai_embedding_deployment:
        raise RuntimeError("Missing AZURE_OPENAI_EMBEDDING_DEPLOYMENT. Fill this in your .env.")
    client = _get_client()

    async def _do_call() -> list[list[float]]:
        response = await client.embeddings.create(
            model=settings.azure_openai_embedding_deployment,
            input=texts,
        )
        return [item.embedding for item in response.data]

    return await asyncio.wait_for(_with_retry(_do_call), timeout=DEFAULT_CALL_TIMEOUT_S)
