"""
Central configuration for the project.

Everything reads from .env via pydantic-settings. Import `settings` anywhere
you need a config value - never read os.environ directly in other modules.
"""

from pathlib import Path
from typing import Optional
from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict

BASE_DIR = Path(__file__).resolve().parent


class Settings(BaseSettings):
    # ---- LLM provider ----
    # Azure OpenAI only - one provider for text/planning, vision, AND
    # embeddings (tier-1 semantic candidate matching in resolver.py /
    # semantic_matcher.py). Kept as a plain constant (not read from .env)
    # purely so /api/config and the frontend's status line still have a
    # provider name to display - there's no other provider to select.
    llm_provider: str = "azure"

    # ---- Azure OpenAI ----
    azure_openai_api_key: Optional[str] = Field(None, alias="AZURE_OPENAI_API_KEY")
    azure_openai_endpoint: Optional[str] = Field(None, alias="AZURE_OPENAI_ENDPOINT")
    azure_openai_api_version: str = Field("2024-08-01-preview", alias="AZURE_OPENAI_API_VERSION")
    # Deployment name (from Azure AI/OpenAI Studio, NOT the underlying model
    # name) used for text/planning calls. This project points it at a
    # gpt-4.1-mini deployment.
    azure_openai_deployment: Optional[str] = Field(None, alias="AZURE_OPENAI_DEPLOYMENT")
    # Optional: only needed if your vision-capable deployment has a different
    # name than your main text deployment. Falls back to azure_openai_deployment.
    # gpt-4.1-mini is natively multimodal, so most setups can leave this
    # blank and reuse the same deployment for vision calls too.
    azure_openai_vision_deployment: Optional[str] = Field(None, alias="AZURE_OPENAI_VISION_DEPLOYMENT")
    # Deployment name for embeddings (semantic_matcher.py's tier-1 candidate
    # scoring, replacing the old local sentence-transformers model). This
    # project points it at a text-embedding-ada-002 deployment.
    azure_openai_embedding_deployment: Optional[str] = Field(None, alias="AZURE_OPENAI_EMBEDDING_DEPLOYMENT")

    # ---- Target under test ----
    # Android/Appium only - kept as a plain constant (not read from .env)
    # purely so /api/config and the frontend's status line still have a
    # platform name to display; there's no other platform to select.
    platform: str = "android"

    # ---- Appium / mobile ----
    appium_server_url: str = Field("http://127.0.0.1:4723", alias="APPIUM_SERVER_URL")
    android_device_name: str = Field("Android Device", alias="ANDROID_DEVICE_NAME")
    android_app_package: str = Field("", alias="ANDROID_APP_PACKAGE")
    android_app_activity: str = Field("", alias="ANDROID_APP_ACTIVITY")
    android_app_wait_activity: Optional[str] = Field(None, alias="ANDROID_APP_WAIT_ACTIVITY")
    android_udid: Optional[str] = Field(None, alias="ANDROID_UDID")
    android_platform_version: Optional[str] = Field(None, alias="ANDROID_PLATFORM_VERSION")
    android_no_reset: bool = Field(True, alias="ANDROID_NO_RESET")
    android_new_command_timeout: int = Field(900, alias="ANDROID_NEW_COMMAND_TIMEOUT")
    # Skips Appium's per-session re-check/reinstall of the UiAutomator2 server
    # and device initialization (~3s of every session start). Needs the
    # server already installed on the device from an earlier normal session -
    # if the fast start fails, driver_manager retries the normal way.
    android_fast_session: bool = Field(False, alias="ANDROID_FAST_SESSION")
    # How long to poll/retry bringing the target app to the foreground after
    # session start before giving up with a clear error (see driver_manager.py
    # -> activate_and_verify_app). Session-capability auto-launch is only a
    # single best-effort attempt; this catches (and clearly reports) the cases
    # where that silently didn't stick.
    android_launch_verify_timeout: int = Field(15, alias="ANDROID_LAUNCH_VERIFY_TIMEOUT")

    # ---- Appium server lifecycle ----
    # If true (default) and no Appium server is reachable at appium_server_url,
    # one is started automatically as a subprocess (via AppiumService) instead
    # of requiring you to run `appium` in a separate terminal yourself. If a
    # server is already reachable there (you started one, or CI did), it's
    # reused as-is either way.
    auto_start_appium_server: bool = Field(True, alias="AUTO_START_APPIUM_SERVER")
    appium_server_startup_timeout: int = Field(30, alias="APPIUM_SERVER_STARTUP_TIMEOUT")
    appium_server_log_path: Optional[str] = Field(None, alias="APPIUM_SERVER_LOG_PATH")

    # ---- Agent behaviour ----
    max_steps: int = Field(15, alias="MAX_STEPS")
    fuzzy_match_threshold: int = Field(75, alias="FUZZY_MATCH_THRESHOLD")
    # How long (seconds) an explicit step's target resolution retries before
    # giving up, instead of a single one-shot attempt - covers a screen still
    # transitioning/rendering right after the previous action.
    dynamic_resolve_timeout: float = Field(5.0, alias="DYNAMIC_RESOLVE_TIMEOUT")
    enable_vision_fallback: bool = Field(True, alias="ENABLE_VISION_FALLBACK")
    # When a needs-target step's element isn't on the current screen, swipe
    # to look for it before failing, instead of requiring the flow to carry
    # an explicit "Swipe Up To" step. Makes a flow authored on one screen
    # size work on a smaller one, where the same element sits below the fold.
    auto_scroll_to_find: bool = Field(True, alias="AUTO_SCROLL_TO_FIND")
    auto_scroll_max_swipes: int = Field(5, alias="AUTO_SCROLL_MAX_SWIPES")
    android_auto_grant_permissions: bool = Field(True, alias="ANDROID_AUTO_GRANT_PERMISSIONS")
    popup_dismiss_enabled: bool = Field(True, alias="POPUP_DISMISS_ENABLED")
    # Records a video of the device screen for the whole run, saved under
    # logs/recordings/ once the run finishes - off by default (adds
    # overhead and storage; a nice-to-have for reviewing a run afterward,
    # not needed for most runs). Android itself caps a single recording at
    # 180 seconds (3 minutes) - see app/utils/recording.py's own comment.
    enable_screen_recording: bool = Field(False, alias="ENABLE_SCREEN_RECORDING")
    screen_recording_time_limit: int = Field(180, alias="SCREEN_RECORDING_TIME_LIMIT")

    # ---- Paths (not read from env) ----
    base_dir: Path = BASE_DIR
    screenshot_dir: Path = BASE_DIR / "logs" / "screenshots"

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        populate_by_name=True,
        extra="ignore",
    )


settings = Settings()
settings.screenshot_dir.mkdir(parents=True, exist_ok=True)