"""
FastAPI layer wrapping the EXISTING, already-tested automation engine
(app/automation/*) for the Next.js frontend. This file owns HTTP/WebSocket
plumbing only - it never re-implements resolution, execution, or
recording logic; every request just calls into step_runner.py/recorder.py
directly.

Endpoints:
  GET    /api/config              - platform + settings summary for display
  GET    /api/actions             - action schema, for building the step form
  GET    /api/flows               - list saved flow names
  GET    /api/flows/{name}        - load one flow's steps
  POST   /api/flows/{name}        - save a flow's steps
  DELETE /api/flows/{name}        - delete a saved flow
  POST   /api/executions          - start a tracked, cancellable execution;
                                     returns an execution id immediately
  GET    /api/executions          - list recent executions (summary only)
  GET    /api/executions/{id}     - one execution's full detail incl. steps
  GET    /api/reports/summary     - aggregated total runs/pass rate/flaky/healed
  GET    /api/flow-graph          - learned states and verified transitions
  POST   /api/executions/{id}/cancel - actually stop a running execution,
                                     not just disconnect from it
  WS     /ws/executions/{id}      - observe a running (or just-finished)
                                     execution's live step-by-step progress
  POST   /api/recording/start     - start a recording session (own driver,
                                     separate from a run's), returns the
                                     MJPEG stream URL to embed
  POST   /api/recording/stop      - stop the recording session
  POST   /api/recording/action    - perform one recorded interaction
                                     (tap/type/assert/capture), returns the
                                     resulting step dict
  GET    /api/recording/screenshot- one-off static screenshot (fallback for
                                     when MJPEG isn't available/working)
  GET    /api/recording/physical_events - drain steps produced by REAL
                                     physical taps on the device itself
                                     (see app/automation/physical_touch.py),
                                     as an alternative to clicking the
                                     mirror image for every step
"""

import asyncio
import json
import queue
import socket
import time
from pathlib import Path
from typing import Optional

from fastapi import FastAPI, WebSocket, WebSocketDisconnect, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from pydantic import BaseModel

from config import settings
from app.automation.action_schema import CATEGORY_ORDER, ACTIONS, actions_in_category
from app.utils.recording import RECORDINGS_DIR
from app.automation.driver_manager import DriverManager
from app.automation import recorder
from app.automation.physical_touch import PhysicalTouchListener, detect_single_adb_serial
from app.utils.screenshot import take_screenshot
from app.db.session import init_db
from app.execution import manager as exec_manager
from app.automation.flow_graph import list_graph
from app.automation.step_runner import generate_plan_from_graph

app = FastAPI(title="Mobile Automation API")


@app.on_event("startup")
def _on_startup():
    init_db()
    # Any execution still "running" belongs to a process that no longer
    # exists (previous restart/crash) - its asyncio Task is gone, so it can
    # never actually finish. Mark it rather than leaving it stuck forever.
    exec_manager.reconcile_stale_executions()
    # Semantic matching now calls the Azure OpenAI embeddings API per
    # request (see app/automation/semantic_matcher.py) instead of loading a
    # local model, so there's nothing to warm up anymore - just a cheap
    # config check so a missing AZURE_OPENAI_EMBEDDING_DEPLOYMENT shows up
    # in the startup log instead of silently falling back to fuzzy-only on
    # every single resolve call.
    from app.automation.semantic_matcher import semantic_available
    if not semantic_available():
        print(
            "[startup] Azure OpenAI embeddings not configured - semantic "
            "matching will fall back to fuzzy-only. Set AZURE_OPENAI_API_KEY, "
            "AZURE_OPENAI_ENDPOINT, and AZURE_OPENAI_EMBEDDING_DEPLOYMENT in "
            ".env to enable it."
        )


# Next.js dev server origin - tighten this to the real deployed origin later.
# Both localhost and 127.0.0.1 variants are allowed: browsers treat them as
# DIFFERENT origins for CORS purposes even though they resolve the same way,
# so whichever one the frontend actually got opened at (easy to get either
# depending on what you click/type) needs to be present here or every
# request silently fails as a generic "Failed to fetch" with no other clue.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000", "http://127.0.0.1:3000"],
    allow_methods=["*"],
    allow_headers=["*"],
)

FLOWS_DIR = settings.base_dir / "flows"
FLOWS_DIR.mkdir(parents=True, exist_ok=True)


def _port_reachable(port: int, retries: int = 5, delay: float = 0.4) -> bool:
    """Real TCP-connect check, with a few retries - the ADB port-forward
    for a working mjpegServerPort session can take a brief moment to
    establish even when it's going to succeed, so a single immediate
    check would produce false negatives on working setups."""
    for _ in range(retries):
        try:
            with socket.create_connection(("127.0.0.1", port), timeout=0.5):
                return True
        except OSError:
            time.sleep(delay)
    return False


# ---------------------------------------------------------------------------
# Config / action schema
# ---------------------------------------------------------------------------

@app.get("/api/config")
def get_config():
    return {
        "platform": settings.platform,
        "appium_server_url": getattr(settings, "appium_server_url", None),
        "android_device_name": getattr(settings, "android_device_name", None),
        "android_app_package": getattr(settings, "android_app_package", None),
        "llm_provider": settings.llm_provider,
        "enable_vision_fallback": settings.enable_vision_fallback,
    }


@app.get("/api/actions")
def get_actions():
    """Serializes the action schema so the frontend can build the step
    form dynamically."""
    categories = {}
    for cat in CATEGORY_ORDER:
        options = actions_in_category(cat, settings.platform)
        categories[cat] = [
            {
                "key": a.key,
                "label": a.label,
                "needs_target": a.needs_target,
                "fields": [
                    {"name": f.name, "label": f.label, "kind": f.kind,
                     "options": f.options, "default": f.default, "help": f.help}
                    for f in a.fields
                ],
            }
            for a in options
        ]
    return {"category_order": CATEGORY_ORDER, "categories": categories}


# ---------------------------------------------------------------------------
# Flow CRUD
# ---------------------------------------------------------------------------

def _safe_flow_path(name: str) -> Path:
    safe_name = "".join(c for c in name.strip() if c.isalnum() or c in (" ", "_", "-")).strip()
    if not safe_name:
        raise HTTPException(400, "Invalid flow name.")
    return FLOWS_DIR / f"{safe_name}.json"


@app.get("/api/flows")
def list_flows():
    return {"flows": sorted(p.stem for p in FLOWS_DIR.glob("*.json"))}


@app.get("/api/flows/{name}")
def load_flow(name: str):
    path = _safe_flow_path(name)
    if not path.exists():
        raise HTTPException(404, f"No saved flow named '{name}'.")
    parsed = json.loads(path.read_text(encoding="utf-8"))
    # Defensive: a flow saved by a since-fixed bug in step_runner.py's
    # self-healing persistence could have written {"steps": [...]} to the
    # FILE itself instead of the raw list every other writer uses - which
    # then double-wraps here into {"steps": {"steps": [...]}}, handing the
    # frontend an object where it expects an array ("steps.map is not a
    # function"). Unwrap and re-save in the correct format if this shape
    # is ever encountered, so a flow saved by the old bug self-repairs on
    # its next load instead of staying broken forever.
    if isinstance(parsed, dict) and "steps" in parsed:
        parsed = parsed["steps"]
        path.write_text(json.dumps(parsed, indent=2), encoding="utf-8")
    return {"steps": parsed}


class SaveFlowBody(BaseModel):
    steps: list


@app.post("/api/flows/{name}")
def save_flow(name: str, body: SaveFlowBody):
    path = _safe_flow_path(name)
    path.write_text(json.dumps(body.steps, indent=2), encoding="utf-8")
    return {"ok": True}


@app.delete("/api/flows/{name}")
def delete_flow(name: str):
    path = _safe_flow_path(name)
    if path.exists():
        path.unlink()
    return {"ok": True}


# ---------------------------------------------------------------------------
# Executions - decoupled from any websocket connection (see module
# docstring). Starting one returns an id immediately; the caller can watch
# it live over WS /ws/executions/{id}, poll GET /api/executions/{id}, or
# ignore it entirely and just check back later - the run itself doesn't
# depend on anything staying connected.
# ---------------------------------------------------------------------------

class StartExecutionBody(BaseModel):
    steps: list[dict]
    flow_name: Optional[str] = None  # set when running a saved flow, so self-healing has somewhere to persist to


@app.post("/api/executions")
async def start_execution(body: StartExecutionBody):
    execution_id = await exec_manager.start_execution(body.steps, flow_name=body.flow_name)
    return {"execution_id": execution_id}


@app.get("/api/executions")
def list_executions(flow_name: Optional[str] = None, limit: int = 50):
    return {"executions": exec_manager.list_executions(flow_name=flow_name, limit=limit)}


@app.get("/api/executions/{execution_id}")
def get_execution(execution_id: str):
    execution = exec_manager.get_execution(execution_id)
    if execution is None:
        raise HTTPException(404, f"No execution: {execution_id}")
    return execution


@app.get("/api/reports/summary")
def get_report_summary():
    return exec_manager.get_report_summary()


@app.get("/api/flow-graph")
def get_flow_graph():
    """Inspectable map learned from successful flow transitions."""
    return list_graph()


class GenerateAssistPlanBody(BaseModel):
    instruction: str


@app.post("/api/assist/plan")
async def generate_assist_plan(body: GenerateAssistPlanBody):
    """"Generate with AI" test-case creation path: looks up a verified route
    for `instruction` in the learned graph and returns its real steps,
    ready to review/edit in the flow editor - does not invent a new route
    via live AI planning."""
    steps = await generate_plan_from_graph(body.instruction)
    if not steps:
        raise HTTPException(404, "No known route yet for this instruction — record or run a similar flow first.")
    # Tag so run_flow doesn't feed a replayed route back into the graph.
    return {"steps": [{**s, "_from_ai": True} for s in steps]}


@app.post("/api/executions/{execution_id}/cancel")
def cancel_execution(execution_id: str):
    cancelled = exec_manager.cancel_execution(execution_id)
    if not cancelled:
        raise HTTPException(404, f"No running execution: {execution_id} (already finished, or never existed)")
    return {"ok": True}


@app.websocket("/ws/executions/{execution_id}")
async def ws_observe_execution(websocket: WebSocket, execution_id: str):
    """Observes an execution already started via POST /api/executions -
    does NOT start or drive it. Connecting late (or not at all) doesn't
    affect the run; disconnecting doesn't stop it either - that's the
    whole point of the split from the old /ws/run, where the socket WAS
    the run."""
    await websocket.accept()

    # Already finished by the time we connected (e.g. a fast flow, or a
    # slow client) - replay what's already persisted, then done, rather
    # than hanging waiting for messages that will never come.
    existing = exec_manager.get_execution(execution_id)
    if existing is None:
        await websocket.send_json({"status": "error", "error": f"No execution: {execution_id}"})
        await websocket.close()
        return
    if existing["status"] != "running":
        for step in existing["steps"]:
            await websocket.send_json(_json_safe(step))
        await websocket.send_json({"status": "done"})
        return

    queue = exec_manager.subscribe(execution_id)
    try:
        while True:
            message = await queue.get()
            await websocket.send_json(_json_safe(message))
            if message.get("status") == "done":
                break
    except WebSocketDisconnect:
        pass
    finally:
        exec_manager.unsubscribe(execution_id, queue)


def _json_safe(obj):
    """Log dicts can contain a Path (screenshot, on the rare pre-fix code
    path) - make the whole thing JSON-serializable defensively."""
    if isinstance(obj, dict):
        return {k: _json_safe(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_json_safe(v) for v in obj]
    if isinstance(obj, Path):
        return str(obj)
    return obj


# ---------------------------------------------------------------------------
# Recording - separate driver session from a run's, lives for as long as
# "recording mode" is active in the frontend.
# ---------------------------------------------------------------------------

class _RecordingSession:
    dm: Optional[DriverManager] = None
    driver = None
    mjpeg_port: Optional[int] = None
    # Cache of the most recent peek_tap's raw result, keyed by the exact
    # (x, y) it was taken at. Single-use: consumed and cleared by the next
    # tap/type at that same point, so it can never be reused for an
    # unrelated later gesture that happens to land on the same pixel.
    peek_xy: Optional[tuple] = None
    peek_result: Optional[tuple] = None  # (el, locator, fingerprint, classification, own_text, nearby)

    # Physical-touch capture (see app/automation/physical_touch.py) - an
    # alternative to clicking the mirror image, driven by real finger
    # taps on the device itself. Optional/best-effort: physical is None
    # and physical_error explains why whenever it couldn't start (e.g. no
    # touchscreen event device found), and mirror-click recording keeps
    # working exactly as before regardless.
    physical: Optional[PhysicalTouchListener] = None
    physical_error: Optional[str] = None
    # Background task draining `physical` the instant a gesture arrives -
    # see _physical_touch_pump. NOT driven by the frontend's poll cycle;
    # that would put a real screen-transition race between a physical tap
    # and inspecting what was tapped (confirmed in practice: a tap that
    # immediately opens a new screen would sometimes get looked up AFTER
    # the transition, describing the wrong screen's element entirely).
    physical_pump_task: Optional[asyncio.Task] = None
    # Steps the pump has already fully built - /api/recording/physical_events
    # just drains this list; all the actual work happens in the pump.
    physical_ready_steps: list = None
    # A tap that landed on an editable field, held here until the NEXT
    # gesture (or recording stop) reveals what was actually typed - see
    # recorder.finish_physical_gesture / flush_pending_edit.
    pending_edit: Optional[dict] = None


_recording = _RecordingSession()


async def _physical_touch_pump(driver, platform: str, listener: PhysicalTouchListener):
    """Runs for the life of a recording session with physical-touch
    capture active. NOT gated by the frontend's poll interval - reacts to
    the device's own raw touch stream directly.

    Two-signal design, keyed off PhysicalTouchListener's two queues:

      touch_starts fires at touch-DOWN, before the gesture is even
      complete or its kind (tap/swipe/long_press) known. The moment one
      arrives, the fast device lookup (recorder.locate_at) is kicked off
      IMMEDIATELY as a background task - nothing else is awaited first.
      This is the part that has to win a real race: Android only fires a
      click - and whatever screen transition follows it - on the matching
      UP event, never on DOWN, so starting here is guaranteed correct by
      Android's own event ordering, not just "fast enough in practice".
      (An earlier version started this lookup at touch-UP instead, right
      when the gesture was dequeued - confirmed via live testing that
      this still occasionally lost the race on a screen that transitions
      fast enough; down-time is what actually closes it.)

      gestures fires at touch-UP (gesture complete, kind now known). Its
      matching lookup (started above at that SAME gesture's down) is
      awaited here, and only now does the slower LLM classification run.

    Pairing the two by simple FIFO order (not an explicit id) is safe
    because PhysicalTouchListener only ever tracks one finger at a time
    (multi-touch gestures are dropped, not merged) - so a new touch_starts
    entry physically cannot arrive before the PREVIOUS gesture's own
    gestures entry does, and this loop always drains touch_starts before
    gestures within the same iteration. That ordering holds no matter how
    far behind this loop gets processing a slow classification - it just
    means several (start, complete) pairs queue up, still in lockstep.
    """
    pending_locate: Optional[asyncio.Task] = None
    while True:
        try:
            x, y = listener.touch_starts.get_nowait()
            if pending_locate is not None:
                pending_locate.cancel()  # stale - its gesture already finalized without us seeing the completion in time (shouldn't normally happen)
            pending_locate = asyncio.create_task(recorder.locate_at(driver, platform, x, y))
        except queue.Empty:
            pass

        try:
            gesture = listener.gestures.get_nowait()
        except queue.Empty:
            await asyncio.sleep(0.01)
            continue
        except Exception:
            return  # listener torn down mid-loop (recording stopped) - just exit

        if gesture.kind == "swipe":
            if pending_locate is not None:
                pending_locate.cancel()
                pending_locate = None
            prepared = await recorder.locate_physical_gesture(driver, platform, gesture)  # no device call for a swipe - just builds the step dict
        elif pending_locate is not None:
            try:
                loc = await pending_locate
                prepared = {"loc": loc, "gesture": gesture}
            except Exception:
                prepared = {"ready_step": None}  # mis-tap, or the lookup itself failed - drop silently, same as elsewhere in this module
            pending_locate = None
        else:
            # No touch-down signal arrived for this gesture (only
            # expected right as the listener starts) - fall back to a
            # late lookup rather than dropping the tap outright.
            prepared = await recorder.locate_physical_gesture(driver, platform, gesture)

        if _recording.pending_edit is not None:
            flushed = recorder.flush_pending_edit(_recording.pending_edit)
            _recording.pending_edit = None
            if flushed is not None and _recording.physical_ready_steps is not None:
                _recording.physical_ready_steps.append(flushed)

        try:
            step, pending = await recorder.finish_physical_gesture(platform, prepared)
        except Exception:
            # Never let one gesture's failure (a rate-limited vision/LLM
            # call, etc.) take down the whole pump - every later tap for
            # the rest of the session would silently stop being captured
            # at all, which is worse than losing just this one step.
            continue
        if pending is not None:
            _recording.pending_edit = pending
        elif step is not None and _recording.physical_ready_steps is not None:
            _recording.physical_ready_steps.append(step)


@app.post("/api/recording/start")
async def start_recording():
    if _recording.driver is not None:
        raise HTTPException(409, "A recording session is already active.")
    enable_mjpeg = settings.platform == "android"
    dm = DriverManager(enable_mjpeg=enable_mjpeg)
    # async def + asyncio.to_thread for every blocking call in here (not a
    # plain sync def, like this endpoint used to be) - needed so
    # asyncio.create_task below actually lands on the real running loop,
    # for the physical-touch pump task started later in this function.
    driver = await asyncio.to_thread(dm.start)
    _recording.dm = dm
    _recording.driver = driver
    _recording.mjpeg_port = dm.mjpeg_port

    # mjpegServerPort has a known, documented reliability issue
    # (appium/appium#18325) - the capability being accepted doesn't
    # guarantee the ADB port-forward actually happened. Verify it's
    # genuinely reachable before telling the frontend it can use it,
    # rather than letting it fail invisibly later the way it just did in
    # a browser tab with no explanation. Falls back to polling
    # /api/recording/screenshot when it isn't.
    mjpeg_available = False
    mjpeg_url = None
    if dm.mjpeg_port:
        mjpeg_url = f"http://127.0.0.1:{dm.mjpeg_port}"
        mjpeg_available = await asyncio.to_thread(_port_reachable, dm.mjpeg_port)

    try:
        size = await asyncio.to_thread(driver.get_window_size)
        screen_width, screen_height = size["width"], size["height"]
    except Exception:
        # Non-fatal - the frontend falls back to the image's natural size,
        # which is usually the same thing anyway (only actually wrong if
        # the screenshot/mjpeg frame is scaled down from true resolution).
        screen_width = screen_height = None

    # Physical-touch capture (real finger taps on the device) - optional
    # and best-effort. Never lets a failure here (no adb, no touchscreen
    # event device found, etc.) block starting the recording session
    # itself; mirror-click recording works with or without this.
    _recording.physical = None
    _recording.physical_error = None
    _recording.physical_pump_task = None
    _recording.physical_ready_steps = []
    _recording.pending_edit = None
    if settings.platform == "android" and screen_width and screen_height:
        try:
            serial = settings.android_udid or await asyncio.to_thread(detect_single_adb_serial)
            listener = await asyncio.to_thread(PhysicalTouchListener, serial, screen_width, screen_height)
            listener.start()
            _recording.physical = listener
            _recording.physical_pump_task = asyncio.create_task(
                _physical_touch_pump(driver, settings.platform, listener)
            )
        except Exception as e:
            _recording.physical_error = str(e)

    return {
        "ok": True,
        "mjpeg_url": mjpeg_url,
        "mjpeg_available": mjpeg_available,
        "screenshot_url": "/api/recording/screenshot",
        "screen_width": screen_width,
        "screen_height": screen_height,
        "physical_touch_available": _recording.physical is not None,
        "physical_touch_error": _recording.physical_error,
    }


@app.post("/api/recording/stop")
async def stop_recording():
    # Cancel the physical-touch pump FIRST and wait for it to actually
    # stop before touching physical_ready_steps/pending_edit below -
    # otherwise it could still be mid-append to either one while this
    # reads them, and something added in that window would be silently
    # lost the instant the driver quits right after.
    if _recording.physical_pump_task is not None:
        _recording.physical_pump_task.cancel()
        try:
            await _recording.physical_pump_task
        except (asyncio.CancelledError, Exception):
            pass

    # Flush any in-flight physical edit (typed into a field, then
    # recording stopped before another gesture triggered the usual
    # flush) so it isn't silently lost - see recorder.flush_pending_edit.
    final_step = None
    if _recording.pending_edit is not None:
        final_step = recorder.flush_pending_edit(_recording.pending_edit)

    # Any already-built steps the frontend hadn't polled yet (its last
    # poll could easily have landed just before the pump appended one).
    leftover_steps = _recording.physical_ready_steps or []

    if _recording.driver is not None:
        await asyncio.to_thread(_recording.dm.quit)
    if _recording.physical is not None:
        _recording.physical.stop()
    _recording.dm = None
    _recording.driver = None
    _recording.mjpeg_port = None
    _recording.physical = None
    _recording.physical_error = None
    _recording.physical_pump_task = None
    _recording.physical_ready_steps = None
    _recording.pending_edit = None
    _recording.peek_xy = None
    _recording.peek_result = None
    return {"ok": True, "final_step": final_step, "steps": leftover_steps}


@app.get("/api/recording/status")
def recording_status():
    return {"active": _recording.driver is not None, "mjpeg_port": _recording.mjpeg_port}


class PeekTapBody(BaseModel):
    x: int
    y: int


@app.post("/api/recording/peek")
async def recording_peek(body: PeekTapBody):
    """Inspection only - performs NO action on the device. The frontend
    calls this on pointerup for what LOOKS like a tap (see recorder.peek_tap)
    to decide whether to prompt for text (editable field) or just record
    the tap immediately (anything else), without tapping twice to find out.

    Caches the raw inspection result (including the one LLM classification
    call it just made) keyed to this exact point - /api/recording/action
    reuses it if the very next tap/type lands on the same point, instead of
    classifying the same element a second time."""
    if _recording.driver is None:
        raise HTTPException(409, "No active recording session - call /api/recording/start first.")
    try:
        result = await recorder.peek_tap(_recording.driver, settings.platform, body.x, body.y)
    except RuntimeError as e:
        _recording.peek_xy = None
        _recording.peek_result = None
        raise HTTPException(422, str(e))

    _recording.peek_xy = (body.x, body.y)
    _recording.peek_result = result
    _el, _locator, _fingerprint, classification, _own_text, _nearby = result
    return {
        "description": classification["description"],
        "is_editable": classification["is_editable"],
        "is_dynamic": classification["is_dynamic"],
    }


class RecordActionBody(BaseModel):
    mode: str            # "tap" | "type" | "swipe" | "assert_text" | "assert_visible" | "capture"
    x: int
    y: int
    x2: Optional[int] = None              # for "swipe" - drag end point
    y2: Optional[int] = None              # for "swipe" - drag end point
    text: Optional[str] = None            # for "type"
    variable_name: Optional[str] = None   # for "capture"


def _consume_matching_peek(x: int, y: int):
    """Returns the cached peek result if it was taken at exactly this
    point, and clears the cache either way (single-use - a hit is
    consumed so it can't be reused for a later unrelated gesture at the
    same pixel; a miss is cleared so a stale peek from an old point never
    lingers to be wrongly matched by coincidence later)."""
    result = _recording.peek_result if _recording.peek_xy == (x, y) else None
    _recording.peek_xy = None
    _recording.peek_result = None
    return result


@app.post("/api/recording/action")
async def recording_action(body: RecordActionBody):
    if _recording.driver is None:
        raise HTTPException(409, "No active recording session - call /api/recording/start first.")
    driver = _recording.driver
    platform = settings.platform

    try:
        if body.mode == "tap":
            cached = _consume_matching_peek(body.x, body.y)
            if cached is not None:
                el, locator, fingerprint, classification, _own_text, nearby = cached
                step = recorder.execute_tap(driver, el, locator, fingerprint, classification, nearby)
            else:
                step = await recorder.record_tap(driver, platform, body.x, body.y)
        elif body.mode == "type":
            if not body.text:
                raise HTTPException(400, "text is required for mode=type.")
            cached = _consume_matching_peek(body.x, body.y)
            if cached is not None:
                el, locator, fingerprint, classification, _own_text, _nearby = cached
                step = recorder.execute_type(driver, el, locator, fingerprint, classification, body.text)
            else:
                step = await recorder.record_type(driver, platform, body.x, body.y, body.text)
        elif body.mode == "swipe":
            if body.x2 is None or body.y2 is None:
                raise HTTPException(400, "x2 and y2 are required for mode=swipe.")
            step = await recorder.record_swipe(driver, platform, body.x, body.y, body.x2, body.y2)
        elif body.mode == "assert_text":
            step = await recorder.record_assert(driver, platform, body.x, body.y, mode="text")
        elif body.mode == "assert_visible":
            step = await recorder.record_assert(driver, platform, body.x, body.y, mode="visible")
        elif body.mode == "capture":
            if not body.variable_name:
                raise HTTPException(400, "variable_name is required for mode=capture.")
            step = await recorder.record_capture(driver, platform, body.x, body.y, body.variable_name)
        else:
            raise HTTPException(400, f"Unknown mode: {body.mode}")
    except RuntimeError as e:
        # No element at that point, etc. - a normal, expected outcome of a
        # mis-tap, not a server error.
        raise HTTPException(422, str(e))

    return {"step": step}


@app.get("/api/recording/physical_events")
async def recording_physical_events():
    """Drains steps the physical-touch pump (_physical_touch_pump) has
    already fully built since the last poll - the frontend calls this on
    an interval (same pattern as /api/recording/screenshot, e.g. every
    400-500ms) instead of requiring a click on the mirror image for every
    single step.

    All the actual work (element lookup, classification, pending-edit
    flushing) happens in the pump, NOT here - deliberately: this endpoint
    only runs when the frontend happens to poll, and gating the element
    lookup on that poll cycle would put a real race between a physical
    tap and inspecting what was tapped (confirmed in practice - a tap
    that immediately opens a new screen would sometimes get looked up
    AFTER the transition, describing the wrong screen's element). The
    pump reacts the instant a gesture arrives, independent of this
    endpoint; this just returns whatever it's produced so far.

    physical_touch_active tells the frontend whether physical-touch
    capture is actually running for this session at all - false with an
    error explains why (e.g. no touchscreen event device found), so the
    UI can say so instead of silently doing nothing."""
    if _recording.driver is None:
        raise HTTPException(409, "No active recording session.")
    if _recording.physical is None:
        return {"steps": [], "physical_touch_active": False, "error": _recording.physical_error}

    steps = _recording.physical_ready_steps or []
    _recording.physical_ready_steps = []

    return {"steps": steps, "physical_touch_active": True, "error": None}


@app.get("/api/recording/screenshot")
def recording_screenshot():
    """
    Fallback for when MJPEG isn't available/working (see the known Appium
    reliability issue with mjpegServerPort - appium/appium#18325). Serves
    the actual image BYTES, not a server-side file path - a browser/
    frontend can't read the server's local filesystem, so returning a path
    alone (the original version of this endpoint) was never actually
    usable by a real client, only convenient to test with curl locally.

    Intended usage without true live video: a frontend polls this
    endpoint on an interval (e.g. every 300-500ms) and swaps the <img> src
    each time - not real video, but a fast-refreshing sequence of frames,
    which degrades gracefully to something usable when MJPEG streaming
    itself isn't cooperating.
    """
    if _recording.driver is None:
        raise HTTPException(409, "No active recording session.")
    path = take_screenshot(_recording.driver, "recording")
    return FileResponse(path, media_type="image/png")


def _safe_run_video_path(filename: str) -> Path:
    # Only the bare filename, no directory components - .name strips
    # anything else (e.g. "../../etc/passwd") down to just its last
    # segment, so this can never resolve outside RECORDINGS_DIR regardless
    # of what a caller sends.
    safe_name = Path(filename).name
    if not safe_name:
        raise HTTPException(400, "Invalid recording filename.")
    path = RECORDINGS_DIR / safe_name
    if not path.is_file():
        raise HTTPException(404, "Recording not found.")
    return path


@app.get("/api/run-video/{filename}")
def get_run_video(filename: str):
    """
    Serves a saved FLOW-RUN screen recording (see app/utils/recording.py
    and run_flow's own final "recording" log entry, whose recording_path
    field is exactly the {filename} to pass back here) - an actual video
    of the whole run, distinct from every /api/recording/* endpoint above,
    which are all about the STEP-RECORDER feature (watching a user's own
    taps to build a flow), not a video at all. Named run-video specifically
    to avoid that collision.
    """
    path = _safe_run_video_path(filename)
    return FileResponse(path, media_type="video/mp4")
